from base import BoxScraper


class EventsScraper(BoxScraper):
    url = 'http://www.thrashermagazine.com/component/option,com_hwdvideoshare/Itemid,90/cat_id,26/lang,en/task,viewcategory/'
