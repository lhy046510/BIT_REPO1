from base import GenericItemScraper


class SkatelineScraper(GenericItemScraper):
    url = 'http://www.thrashermagazine.com/tags/skateline/'
