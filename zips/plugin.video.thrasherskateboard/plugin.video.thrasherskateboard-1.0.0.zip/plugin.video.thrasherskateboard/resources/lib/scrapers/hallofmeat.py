from base import BoxScraper


class HallOfMeatScraper(BoxScraper):
    url = 'http://www.thrashermagazine.com/component/option,com_hwdvideoshare/Itemid,90/cat_id,13/lang,en/task,viewcategory/'
