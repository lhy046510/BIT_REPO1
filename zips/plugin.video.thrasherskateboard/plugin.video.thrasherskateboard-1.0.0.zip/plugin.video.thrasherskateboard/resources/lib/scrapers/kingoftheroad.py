from base import GenericItemScraper


class KingOfTheRoadScraper(GenericItemScraper):
    url = 'http://www.thrashermagazine.com/tags/king+of+the+road+2013/'
