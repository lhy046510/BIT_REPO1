from base import BoxScraper


class PStoneScraper(BoxScraper):
    url = 'http://www.thrashermagazine.com/component/option,com_hwdvideoshare/Itemid,90/cat_id,17/lang,en/task,viewcategory/'
