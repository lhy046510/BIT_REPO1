from base import GenericItemScraper


class GreatestHitsScraper(GenericItemScraper):
    url = 'http://www.thrashermagazine.com/tags/greatest+hits/'
