from base import BoxScraper


class SkateRockScraper(BoxScraper):
    url = 'http://www.thrashermagazine.com/component/option,com_hwdvideoshare/Itemid,90/cat_id,36/lang,en/task,viewcategory/'
