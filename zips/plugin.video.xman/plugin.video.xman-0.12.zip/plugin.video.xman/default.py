import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon
import os,base64,time
# -*- coding: iso-8859-9 -*-

__settings__ = xbmcaddon.Addon(id='plugin.video.xman')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)
import xbmctools
l_check=xbmctools.inside()
if l_check:
        pass
else:
        xbmctools.hata()
        sys.exit()

        
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

#!/usr/bin/python
# -*- coding: utf-8 -*-
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmakersco@gmail.com

def CATEGORIES():
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        update='http://www.hdtubes.net/most-popular/'
        addDir('[COLOR blue]<<< INFO >>>[/COLOR]','Info',5,'http://s1.directupload.net/images/130123/pqjl3kha.png')
        addDir('[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Yeni Eklenenler [/B][/COLOR]',update,2,"http://s1.directupload.net/images/130123/pqjl3kha.png")
        url='http://www.befuck.com/categories/'
        link=get_url(url)
        match=re.compile('<div class="ic">\n\t\t\t<a href="(.*?)" title="">\n\t\t\t\t<div class=".*?">\n\t\t\t\t   \t\t\t\t      <img src="(.*?)">\n\t\t\t\t   \t\t\t\t</div>\n\t\t\t\t<figcaption>\n\t\t\t\t\t(.*?)\n\t\t\t\t</figcaption>').findall(link)
        for url,thumbnail,name in match:
            addDir('[COLOR orange][B]>>[/COLOR]  [COLOR lightblue] '+name+'[/B][/COLOR]',url,13,thumbnail)

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/230008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
###########################
def update(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('<div class="image " >\n\t\t\t\t\t\t\t\t\t\t\t<a href="(.*?)" class="kt_imgrc" title=".*?"><img class="thumb" src="(.*?)" alt="(.*?)"').findall(link)
        for url,t,n in match:
                addDir('[COLOR pink][B]>>[/COLOR][COLOR lightblue] '+n+'[/B][/COLOR]',url,3,t)
        p=re.compile('<span>.*?</span>\n\t\t\t\t\t\t\t\t\t\t\t\t<a href="(.*?)"').findall(link)
        for url in p:
                url='http://www.hdtubes.net'+url
                n='Sonraki Sayfa'
                addDir('[COLOR blue][B]>> '+n+'[/B][/COLOR]',url,2,'http://people.eecs.ku.edu/~miller/Courses/IntroToCurvesAndSurfaces/images/NextArrow.png')

def updateayristirma(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('video_url: \'(.*?)/\', \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tpostfix: \'_240p.mp4\'').findall(link)
        for url in match:
                n='240p izle'
                addDir('[COLOR pink][B]>>[/COLOR]  [COLOR lightblue] '+n+'[/B][/COLOR]',url,4,'')
        match1=re.compile('video_alt_url: \'(.*?)/\', \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tvideo_alt_url_text: \'360\'').findall(link)
        for url in match1:
                n='360p izle'
                addDir('[COLOR pink][B]>>[/COLOR]  [COLOR lightgreen] '+n+'[/B][/COLOR]',url,4,'')
        match2=re.compile('video_alt_url2: \'(.*?)/\', \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tvideo_alt_url2_text: \'480\'').findall(link)
        for url in match2:
                n='480p izle'
                addDir('[COLOR pink][B]>>[/COLOR]  [COLOR lightblue] '+n+'[/B][/COLOR]',url,4,'http://i60.tinypic.com/oh8n49.png')
        match3=re.compile('video_alt_url3: \'(.*?)/\', \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tvideo_alt_url3_text: \'720\'').findall(link)
        for url in match3:
                n='720p izle'
                addDir('[COLOR pink][B]>>[/COLOR]  [COLOR lightgreen] '+n+'[/B][/COLOR]',url,4,'http://i62.tinypic.com/2zs2pgw.png')
        match=re.compile('video_alt_url4: \'(.*?)/\', \t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tvideo_alt_url4_text: \'1080\'').findall(link)
        for url in match:
                n='1080p izle'
                addDir('[COLOR pink][B]>>[/COLOR]  [COLOR lightblue] '+n+'[/B][/COLOR]',url,4,'')

def updateoynat(name,url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.turkweb.tv/video-etiketler/?search_query='+query)
            RECENT(url)

def liste(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        link=link.replace('\xc5\x9f',"s").replace('\xc3\xbc',"u").replace('\xc4\xb1',"i")
        match=re.compile('<div class="ic">\n\t\t\t\t<a href="(.*?)" title=".*?">\n\t\t\t\t\t<div class=".*?">\n\t\t\t\t\t\t<img src="(.*?)" alt=".*?" onmouseover=".*?" onmouseout=".*?">\n\t\t\t\t\t\t<span>.*?</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<figcaption>\n\t\t\t\t\t\t(.*?) \n\t\t\t\t\t</figcaption>').findall(link)
        for url,thumbnail,name in match:
            addDir('[COLOR pink][B]>>'+name+'[/B][/COLOR]',url,11,thumbnail)
            

        sayfalama=re.compile('<a href="" title=".*?" class="active">.*?</a>\n                <a href="(.*?)" title=".*?">(.*?)</a>\n').findall(link)
        for url,name in sayfalama:
                url='http://www.befuck.com'+url
                addDir('[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',url,13,'')            

def VideoLinks(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(2)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                link=link.replace('\\',"")
                response.close()
                match=re.compile('video_url: \'(.*?)/\',').findall(link)
                for url in match:
                        addLink('~~izlemeye basla~~',url,'')
                        playList.add(name)

                xbmcPlayer.play(playList)
                
def INFO(url):
  try:
        CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "xbmcTR Team [COLOR yellow]HappyFeets[/COLOR] ","iyi seyirler..")
  except:
        
        pass 

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode==2:
        
        update(url)

elif mode==3:
        
        updateayristirma(url)

elif mode==4:
        
        updateoynat(name,url)

elif mode==6:
        
        Search()
        
elif mode==5:
        
        INFO(url)

elif mode==11:
        
        VideoLinks(url)

elif mode==13:
        
        liste(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
