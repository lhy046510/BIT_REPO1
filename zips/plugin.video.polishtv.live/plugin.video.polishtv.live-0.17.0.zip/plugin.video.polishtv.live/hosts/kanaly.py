# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, xbmc
import traceback

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_IMAGE_PATH = 'http://sd-xbmc.org/repository/xbmc-addons/'
BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdSettings, sdCommon, sdErrors, sdParser, sdNavigation, urlparser

log = sdLog.pLog()

dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

SERVICE = 'kanaly'
NEXTURL = BASE_IMAGE_PATH +  "dalej.png"

MAINURL = 'http://www.youtube.com'
lUrl = '/videos?view=1&shelf_id=8&sort=dd'
imgUrl = 'http://i.ytimg.com/vi/'
fUrl = 'http://www.youtube.com/user/'

CAT_TAB = [
                [0, "Ogólnotematyczne", ""],
                [1, "Informacyjne", ""],
                [2, "Sportowe", ""],
                [3, "Muzyczne", ""],
                [4, "Przyrodnicze", ""],
                [5, "Rozrywkowe", ""],
                [6, "Filmowe", ""]
               ]

MENU_TAB = [
    [3, "ArmadaTV", "armadamusic", "armada"],
    [3, "KontorTV", "kontor", "kontor"],
    [3, "VEVO", "vevo", "vevo"],
    [3, "Peja/Slums Attack", "Pejaslumsattack", "peja"],
    [3, "PROSTOtv", "PROSTOtv", "prosto"],
    [3, "UrbanRecTv", "UrbanRecTv", "urban"],
    [4, "Animal Planet TV", "AnimalPlanetTV", "animal"],
    [6, "Filmy dokumentalne", "FilmydokumentalneTV", "dokument"],
    [5, "SA Wardega", "wardegasa", "wardega"],
    [5, "Matura To Bzdura", "MaturaToBzduraTV", "mtb"],
    [0, "TVN" , "tvnpl", "tvnyt"],
    [0, "Auto Świat", "autoswiatv", "autoswiat"],
    [2, "FC Barcelona", "fcbarcelona", "barca"],
    [1, "TVP Info", "YTtvpinfo", "tvpinfo"],
    [5, "Niekryty Krytyk", "Macfra84", "krytyk"],
    [2, "RingPolskaPL", "ringpolskapl", "ring"]
]

class Kanaly:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.cm = sdCommon.common()
	self.exception = sdErrors.Exception()
	self.parser = sdParser.Parser()
	self.gui = sdNavigation.sdGUI()
	self.up = urlparser.urlparser()

    def listsCatMenu(self):
        CAT_TAB.sort(key = lambda x: x[0])
	for i in range(len(CAT_TAB)):
	    params = {'service': SERVICE, 'name': 'cat-menu','category': CAT_TAB[i][0], 'title': CAT_TAB[i][1], 'icon': BASE_IMAGE_PATH +  CAT_TAB[i][1] + ".png"}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsMainMenu(self, ID):
        MENU_TAB.sort(key = lambda x: x[1])
	for i in range(len(MENU_TAB)):
            if MENU_TAB[i][0]==int(ID):
                params = {'service': SERVICE, 'name': 'main-menu','category': MENU_TAB[i][2], 'title': MENU_TAB[i][1], 'icon': BASE_IMAGE_PATH +  MENU_TAB[i][3] + ".png"}
                self.gui.addDir(params)
	self.gui.endDir()

    def listsPlaylistMenu(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	if 'ajax' in url:
            data = _json.dumps(_json.loads(data), ensure_ascii=False).encode('utf-8').replace('&quot;', '').replace('\\', '').replace('[', '')
        else:
            data = data.replace('&quot', '')
        match = re.compile('data-context-item-title="(.+?)"').findall(data)
        match1 = re.compile('data-context-item-id="(.+?)"').findall(data)
        if 'ajax' in url:
            match2 = re.compile('data-context-item-videos="(.+?),').findall(data)
        else:
            match2 = re.compile('data-context-item-videos=".+?;(.+?);').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = self.cm.html_entity_decode(match[i])
		link = MAINURL + '/playlist?list=' + match1[i]
		img = imgUrl + match2[i] + '/0.jpg'
		params = {'service': SERVICE, 'name': 'clip', 'title': title, 'page': link, 'icon': img}
		self.gui.addDir(params)
	match = re.compile('data-uix-load-more-href="(.+?)fluid=True".+?>Poka.+?<').findall(data)
	if len(match) > 0:
            link = MAINURL + match[0] + 'fluid=True'
            print link
            params = {'service': SERVICE, 'name': 'next', 'title': 'Następna strona', 'page': link, 'icon': NEXTURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsClipMenu(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<div class="thumb-container">.+?v=(.+?)&amp;list=.+?index=.+?" title="(.+?)"', re.DOTALL).findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = self.cm.html_entity_decode(match[i][1])
		link = 'http://www.youtube.com/' + match[i][0]
		img = imgUrl + match[i][0] + '/0.jpg'
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': link, 'icon': img}
		self.gui.playVideo(params)
	self.gui.endDir()

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

    #CAT MENU
	if name == None:
	    self.listsCatMenu()
    #MAIN MENU
        if name == 'cat-menu':
            self.listsMainMenu(category)
    #PLAYLISTY
	elif name == 'main-menu':
	    self.listsPlaylistMenu(fUrl + category + lUrl)
	if name == 'next':
	    self.listsPlaylistMenu(page)
    #LISTA UTWORÓW
	if name == 'clip':
	    self.listsClipMenu(page)
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
            linkVideo = self.up.getVideoLink(page)
            self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)
    #POBIERZ
	if action == 'download' and link != '':
	    if link.startswith('http://'):
		linkVideo = self.up.getVideoLink(link).replace("action=play_video","action=download")
		if linkVideo != False:
		    xbmc.executebuiltin('XBMC.RunPlugin(%s)' % (linkVideo))
