# -*- coding: utf-8 -*-
import urllib, re, sys, os
import xbmcaddon
import traceback

if sys.version_info >= (2,7): import json as _json
else: import simplejson as _json

scriptID = 'plugin.video.polishtv.live'
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + "tvn24.png"
THUMB_NEXT = os.path.join(ptv.getAddonInfo('path'), "images/") + 'dalej.png'

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors, downloader

log = sdLog.pLog()

dstpath = ptv.getSetting('default_dstpath')
dbg = sys.modules[ "__main__" ].dbg

SERVICE = 'tvn24'
MAINURL_BASE = 'http://www.tvn24.pl'
MAINURL = 'http://www.tvn24.pl/wideo'
QUERYURL = 'http://www.tvn24.pl/szukaj.html?r=5&q='

SERVICE_MENU_TABLE = {
    #0: 'Kategorie',
    1: "Informacje",
    2: "Magazyny",
    3: "Wyszukaj",
    4: "Historia Wyszukiwania"
}

class TVN24:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()

    def setTable(self):
	return SERVICE_MENU_TABLE

    def listsMainMenu(self, table):
	for num, val in table.items():
	    params = {'service': SERVICE, 'name': 'main-menu','category': val, 'title': val, 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsBaseCategoryMenu(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))

        idx = data.find('<ul class="mainMenuList') #To je dobre, zastosować ;)
        if idx == -1: return
        idx2 = data.find('<div class="clearer">', idx)
        if idx2 == -1: return
        data = data[idx:idx2]

        dataTab = data.split('<li')
        data = ''
        for item in dataTab:
            if -1 == item.find('class="activeRegional"'):
                match = re.search('title="([^"]+?)" ? href="(/[^"^,]+?\,[0-9]+?)"', item)
                if match:
		    params = {'service': SERVICE, 'name': 'main-cat', 'category': 'main-cat', 'title': match.group(1), 'page': match.group(2), 'icon': LOGOURL}
		    self.gui.addDir(params)
	self.gui.endDir()

    def listsCategoryMenu(self, url, name):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	result = _json.loads(data)
	sidebar = result["sidebar"].encode('UTF-8')
	r = re.compile('<a id="cat.+?" href="/wideo(/(?:z-anteny|magazyny)/lista/.+?/).+?>(.+?)</a>').findall(sidebar)
	if len(r)>0:
	    for i in range(len(r)):
		params = {'service': SERVICE, 'name': name,'category': r[i][0].replace("/lista/","/wiecej/"), 'title': self.cm.html_entity_decode(r[i][1]), 'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def listsVideo(self, url, page):
	query_data = { 'url': url+page, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	result = _json.loads(data)
	content = result["content"].encode('UTF-8')
	showBtnMore = result["showBtnMore"]
	r = re.compile('<li>.+?<img src="(.+?)".+?<h2 class="title-cont">(.+?)<.+?data-mp4="(.+?)"', re.DOTALL).findall(content)
	if len(r)>0:
	    for i in range(len(r)):
		title = self.cm.html_entity_decode(r[i][1].strip())
		img = self.cm.html_entity_decode(urllib.unquote(r[i][0]))
		mp4 = self.cm.html_entity_decode(urllib.unquote(r[i][2]))
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': mp4, 'icon': img}
		self.gui.playVideo(params)
	    if showBtnMore == True:
		params = {'service': SERVICE, 'name': 'nextpage','category': url, 'title': 'Następna strona','page': str(int(page)+1), 'icon': THUMB_NEXT}
		self.gui.addDir(params)
	self.gui.endDir()

    def listsVideo2(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    quit()
        nextPage = ''
        match = re.search('<a rel="next" href="([^"]+?)"', data)
        if match:
            nextPage = match.group(1)

        dataTab = data.split('<article ')
        del dataTab[0]
        data = ''
        for item in dataTab:
            if -1 < item.find('class="btnPlayOnImg'):
                match = re.search('href="([^"^#]+?)#autoplay"', item)
                if match:
                    url = match.group(1)
                    if not url.startswith('http'):
                        url = url
                        title = ''
                        img   = ''
                        match = re.search('<img src="([^"]+?)" alt="([^"]+?)" />', item)
                        if match:
                            img   = match.group(1).replace('&amp;', '&')
                            title = match.group(2)
                        plot = ''
                        match = re.search('<p>([^<]+?)<', item)
                        if match:
                            plot = match.group(1)
                        match = re.search('datetime="([^"]+?)"', item)
                        if match:
                            plot = match.group(1) + ' ' + plot
			params = {'service': SERVICE, 'dstpath': dstpath, 'category': 'playSearchedVideo', 'title': title, 'page': url, 'icon': img, 'plot': plot}
			self.gui.playVideo(params)
        if '' != nextPage:
	    params = {'service': SERVICE, 'name': 'main-cat','category': 'main-cat', 'title': 'Następna strona','page': 'nextPage', 'icon': THUMB_NEXT}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsSearchVideo(self, url, page):
	query_data = { 'url': url+page, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	r = re.compile('<div class="imageHolder"><a href="/wideo(/.+?)"><img src="(.+?)".+?class="title size18"><a.+?>(.+?)<', re.DOTALL).findall(data)
	if len(r)>0:
	    for i in range(len(r)):
		title = r[i][2].strip()
		img = self.cm.html_entity_decode(urllib.unquote(r[i][1]))
		urlw = self.cm.html_entity_decode(urllib.unquote(r[i][0]))
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'category': 'playSearchedVideo', 'page': urlw, 'icon': img}
		self.gui.playVideo(params)
	    if 'class="arrowRight"' in data:
		params = {'service': SERVICE, 'name': 'nextsearchpage','category': url, 'title': 'Następna strona','page': str(int(page)+1), 'icon': THUMB_NEXT}
		self.gui.addDir(params)
	self.gui.endDir()

    def listsHistory(self, table):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history', 'title': table[i],'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def getVideoLink(self,url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	match = re.compile('data-mp4="(.+?)"').findall(data)
	if len(match) > 0:
	    return match[0]

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	vtitle = self.parser.getParam(params, "vtitle")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

	if str(page)=='None' or page=='': page = '1'

    #MAIN MENU
	if name == None:
	    self.listsMainMenu(SERVICE_MENU_TABLE)
    #KATEGORIE
	#~ if category == self.setTable()[0]:
            #~ self.listsBaseCategoryMenu(MAINURL_BASE)
	#~ if category == 'main-cat':
	    #~ if page.startswith('http'):
		#~ self.listsVideo2(page)
	    #~ else:
		#~ self.listsVideo2(MAINURL_BASE + page)
    #INFORMACJE
	if category == self.setTable()[1]:
	    self.listsCategoryMenu(MAINURL+"?ajax=1", "catset")
    #MAGAZYNY
	if category == self.setTable()[2]:
	    self.listsCategoryMenu(MAINURL+"/magazyny?ajax=1", "genset")
	if name == 'genset' or name == 'catset':
	    url = MAINURL+category+"?ajax=1&page="
	    self.listsVideo(url, page)
	if name == 'nextpage':
	    url = category
	    self.listsVideo(url, page)
    #WYSZUKAJKA
	if category == self.setTable()[3]:
	    text = self.gui.searchInput(SERVICE)
	    url = QUERYURL+urllib.quote_plus(text)+"&page="
	    self.listsSearchVideo(url, page)
	if name == 'nextsearchpage':
	    url = category
	    self.listsSearchVideo(url, page)
    #HISTORIA WYSZUKIWANIA
	if category == self.setTable()[4]:
	    t = self.history.loadHistoryFile(SERVICE)
	    self.listsHistory(t)
	if name == 'history':
	    url = QUERYURL+title+"&page="
	    self.listsSearchVideo(url, page)
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
	    if category == 'playSearchedVideo':
		linkVideo = self.getVideoLink(MAINURL+page)
	    else:
		linkVideo = page

	    if linkVideo != False:
		self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)

	    #~ if service == SERVICE and action == 'download' and link != '':
		    #~ self.cm.checkDir(os.path.join(dstpath, SERVICE))
		    #~ newlink = urllib.unquote_plus(link)
		    #~ if newlink.startswith('http://'):
			    #~ linkVideo = self.getVideoLink(newlink)
			    #~ if linkVideo != False:
				    #~ dwnl = downloader.Downloader()
