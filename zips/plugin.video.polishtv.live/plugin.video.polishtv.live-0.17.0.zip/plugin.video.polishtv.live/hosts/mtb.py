# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, xbmc
import traceback

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdSettings, sdCommon, sdErrors, sdParser, sdNavigation, urlparser

log = sdLog.pLog()

dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

SERVICE = 'mtb'
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep +  SERVICE + ".png"

MAINURL = 'http://www.youtube.com'

class MTB:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.cm = sdCommon.common()
	self.exception = sdErrors.Exception()
	self.parser = sdParser.Parser()
	self.gui = sdNavigation.sdGUI()
	self.up = urlparser.urlparser()

    def listsPlaylistMenu(self):
	url = MAINURL + '/user/MaturaToBzduraTV/videos?view=1&shelf_id=8&sort=dd'
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	data = data.replace('&quot;', 'AA')
        match = re.compile('data-context-item-title="(.+?)"').findall(data)
        match1 = re.compile('data-context-item-id="(.+?)"').findall(data)
        match2 = re.compile('data-context-item-videos=".+?AA(.+?)AA').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = self.cm.html_entity_decode(match[i])
		link = MAINURL + '/playlist?list=' + match1[i]
		img = 'http://i.ytimg.com/vi/' + match2[i] + '/0.jpg'
		params = {'service': SERVICE, 'name': 'clip', 'title': title, 'page': link, 'icon': img}
		self.gui.addDir(params)
	self.gui.endDir()

    def listsClipMenu(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<div class="thumb-container">.+?v=(.+?)&amp;list=.+?index=.+?" title="(.+?)"', re.DOTALL).findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = self.cm.html_entity_decode(match[i][1])
		link = 'http://www.youtube.com/' + match[i][0]
		img = 'http://i.ytimg.com/vi/' + match[i][0] + '/0.jpg'
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': link, 'icon': img}
		self.gui.playVideo(params)
	self.gui.endDir()

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

    #PLAYLISTY
	if name == None:
	    self.listsPlaylistMenu()
    #LISTA UTWORÓW
	if name == 'clip':
	    self.listsClipMenu(page)
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
            linkVideo = self.up.getVideoLink(page)
            self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)
    #POBIERZ
	if action == 'download' and link != '':
	    if link.startswith("plugin://plugin.video.youtube"):
		linkVideo = link.replace("action=play_video","action=download")
		if linkVideo != False:
		    xbmc.executebuiltin('XBMC.RunPlugin(%s)' % (linkVideo))
