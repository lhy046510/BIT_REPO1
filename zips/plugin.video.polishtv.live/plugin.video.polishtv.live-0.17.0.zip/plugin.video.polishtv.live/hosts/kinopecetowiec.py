# -*- coding: utf-8 -*-
import os, string, StringIO
import urllib, urllib2, re, sys
import xbmcaddon, xbmcgui
import xbmc, traceback

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "../resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import sdLog, sdSettings, sdParser, urlparser, sdCommon, sdNavigation, sdErrors, downloader

log = sdLog.pLog()

dstpath = ptv.getSetting('default_dstpath')
dbg = sys.modules[ "__main__" ].dbg

SERVICE = 'kinopecetowiec'
MAINURL = 'http://www.kino.pecetowiec.pl'
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + SERVICE + '.png'
THUMB_NEXT = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + "dalej.png"
IMGURL = MAINURL + '/chimg/'
SURL = MAINURL + '/search/basic/?search_id='

NEW_LINK = MAINURL + '/videos/basic/mr/'
POP_LINK = MAINURL + '/videos/basic/mv/'
COM_LINK = MAINURL + '/videos/basic/md/'
FAV_LINK = MAINURL + '/videos/basic/tf/'
SCR_LINK = MAINURL + '/videos/basic/tr/'
PRC_LINK = MAINURL + '/videos/basic/rf/'
RDM_LINK = MAINURL + '/videos/basic/rd/'

SERVICE_MENU_TABLE = {
    1: "Kategorie filmowe",
    2: "Najnowsze",
    3: "Najczęściej oglądane",
    4: "Najczęściej komentowane",
    5: "Ulubione",
    6: "Najwyżej ocenione",
    7: "Wyróżnione",
    8: "Losowe",
    9: "Wyszukaj",
    10: "Historia wyszukiwania"
}

class KinoPecetowiec:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.settings = sdSettings.TVSettings()
	self.parser = sdParser.Parser()
	self.up = urlparser.urlparser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()

    def setTable(self):
	return SERVICE_MENU_TABLE

    def listsMainMenu(self, table):
	for num, val in table.items():
	    params = {'service': SERVICE, 'name': 'main-menu', 'title': val, 'category': val, 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsCategoriesMenu(self,url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<div class=".+?"><a href="http://www.kino.pecetowiec.pl/categories/(.+?)/(.+?)" title=".+?"><span').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		img = IMGURL + match[i][0] + '.jpg'
		params = {'service': SERVICE, 'name': 'category', 'title': match[i][1].replace('-', ' '), 'category': match[i][0], 'icon': img}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def getFilmTable(self, url, category, pager):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	    print data + ' datata'
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	#Kategorie
	if category.isdigit()==True:
	    match = re.compile('<div class="channel-details-thumb-box-texts"> <a href="http://www.kino.pecetowiec.pl/video/(.+?)/(.+?)">(.+?)</a><br/>').findall(data)
	else:
	#Najnowsze, Najczescie Ogladane
	    match = re.compile('<div class="video-title"><center><a href="http://www.kino.pecetowiec.pl/video/(.+?)/(.+?)" title="(.+?)">').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = self.cm.html_entity_decode(match[i][2])
		img = MAINURL + '/thumb/1_' + match[i][0] +'.jpg'
		page = MAINURL + '/video/' + match[i][0] + '/' + match[i][1]
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': page, 'icon': img}
		self.gui.playVideo(params)
	#pagination
	match = re.compile('<a href="(.+?)">&raquo;</a>').findall(data)
	if len(match) > 0:
	    params = {'service': SERVICE, 'name': 'category', 'category': category, 'title': 'Następna strona', 'page': str(int(pager) + 1), 'icon': THUMB_NEXT}
	    self.gui.addDir(params)
	self.gui.endDir(False, 'movies')

    def listsHistory(self, table):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history', 'title': table[i],'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def getSearchTable2(self, table):
	for i in range(len(table)):
	    value = table[i]
	    title = value[2].replace("&#039;", "'").replace('&amp;', '&')
	    self.addDir(SERVICE, 'playSelectedMovie', 'history', title, '', value[1], value[0], True, False)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def getSearchTable(self, url):
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	img = re.compile('<img src="(.+?)" width="126"  height="160" id="rotate').findall(data)
	match = re.compile('<div class="video-title"><a href="(.+?)" title="(.+?)">').findall(data)
	if len(match) > 0:
	    for i in range(len(match)):
		title = self.cm.html_entity_decode(match[i][1])
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': title, 'page': match[i][0], 'icon': img[i]}
		self.gui.playVideo(params)
	self.gui.endDir(False, 'movies')

    def getHostTable(self,url):
	valTab = []
	videoID = ''
	query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
	try:
	    data = self.cm.getURLRequestData(query_data)
	    #print data + 'data2'
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('<div id="videoplayer">(.+?)</div>', re.DOTALL).findall(data)
	match2 = []
	if len(match) > 0:
	    #match2 = re.compile("(http://.+?)(?:'|\\\")").findall(match[0])    #oryginal
	    match2 = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', match[0])  #zmiana
	    #print match2 
	return self.up.hostSelect(match2)

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

	if page==None or page=='': page = '1'

    #MAIN MENU
	if name == None:
	    self.listsMainMenu(SERVICE_MENU_TABLE)
    #KATEGORIE FILMOWE
	elif category == self.setTable()[1]:
	    self.listsCategoriesMenu(MAINURL + '/categories')
    #NAJNOWSZE
	elif category == self.setTable()[2]:
	    self.getFilmTable(NEW_LINK + page, category, page)
    #NAJCZESCIEJ OGLADANE
	elif category == self.setTable()[3]:
	    self.getFilmTable(POP_LINK + page, category, page)
    #NAJCZESCIEJ KOMENTOWANE
	elif category == self.setTable()[4]:
	    self.getFilmTable(COM_LINK + page, category, page)
    #ULUBIONE
	elif category == self.setTable()[5]:
	    self.getFilmTable(FAV_LINK + page, category, page)
    #NAJWYZEJ OCENIONE
	elif category == self.setTable()[6]:
	    self.getFilmTable(SCR_LINK + page, category, page)
    #WYROZNIONE
	elif category == self.setTable()[7]:
	    self.getFilmTable(PRC_LINK + page, category, page)
    #LOSOWE
	elif category == self.setTable()[8]:
	    self.getFilmTable(RDM_LINK + page, category, page)
    #WYSZUKAJ
	elif category == self.setTable()[9]:
	    text = self.gui.searchInput(SERVICE)
	    if text != None:
	    	self.getSearchTable(SURL+ text)
    #HISTORIA WYSZUKIWANIA
	elif category == self.setTable()[10]:
	    t = self.history.loadHistoryFile(SERVICE)
	    self.listsHistory(t)
	if name == 'history':
	    self.getSearchTable(SURL+ title)
    #LISTA TYTULOW W KATEGORII
	if name == 'category':
	    if int(category) > 0:
		pagefix = title.replace(' ', '-')
		url = MAINURL + '/categories/' + category + '/' + page + '/' + pagefix
		self.getFilmTable(url, category, page)
    #ODTWÓRZ VIDEO
	if name == 'playSelectedVideo':
	    url = self.getHostTable(page)
	    if url != False:
		linkVideo = self.up.getVideoLink(url)
		self.gui.LOAD_AND_PLAY_VIDEO(linkVideo, title)
	    else:
		pass
    #POBIERZ
	if action == 'download' and link != '':
	    if link.startswith('http://'):
		linkVideo = self.up.getVideoLink(elf.getHostTable(link))
		if linkVideo != False:
		    self.cm.checkDir(os.path.join(dstpath, SERVICE))
		    dwnl = downloader.Downloader()
		    dwnl.getFile({ 'title': title, 'url': linkVideo, 'path': path })
