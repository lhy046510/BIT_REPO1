'''
    Subsonic XBMC Plugin
    Copyright (C) 2011 t0mm0

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import simplejson as json
import urllib, urllib2
import xbmc
import Addon
import xbmcplugin, sys

class Subsonic:
    bitrates = [32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320]
    def __init__(self, servers):

        self.servers = servers
        for server in servers:
            server['api_version'] = '1.4.0'
            server['client_name'] = 'xbmc'
        
    def ping(self):
        Addon.log('ping')
        payloads = self.__get_json('ping.view')
        if payloads:
            if len(payloads) == len(self.servers):
                return True

        return False
        
    def get_music_folders(self):
        Addon.log('get_music_folders')
        payloads = self.__get_json('getMusicFolders.view')

        for payload in payloads:
            folders = self.listify(payload['musicFolders']['musicFolder'])
            total = len(folders)
            for folder in folders:
                if type(folder) is dict:
                    Addon.add_directory({'mode': 'list_indexes', 
                                         'server': payload['server'],
                                         'folder_id': folder['id']}, 
                                        folder['name'], total_items=total)
            Addon.add_directory({'mode': 'albums', 'server':payload['server']}, Addon.get_string(30031))
            Addon.add_directory({'mode': 'search', 'server':payload['server']}, Addon.get_string(30006))
            Addon.add_directory({'mode': 'list_playlists', 'server':payload['server']}, 
                                Addon.get_string(30011))
            Addon.add_directory({'mode': 'random', 'server':payload['server']}, Addon.get_string(30012))
            Addon.end_of_directory()

    def get_indexes(self, folder_id):
        Addon.log('get_indexes: ' + folder_id)
        payloads = self.__get_json('getIndexes.view', {'musicFolderId': folder_id})

        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL ) 
        if payloads:

            cnt = 1
            for payload in payloads:
                indexes = payload['indexes'].get('index', False)
                shortcuts = self.listify(payload['indexes'].get('shortcut', False))
                if indexes:
                    index = []
                    if shortcuts:
                        for s in shortcuts:
                            if type(s) is dict:
                                s['server'] = cnt
                                Addon.add_artist(s)
                        #[Addon.add_artist(s) for s in shortcuts if type(s) is dict]
                    [index.extend(i) for i in [self.listify(i['artist']) 
                        for i in self.listify(indexes)]]
                    #[Addon.add_artist(i) for i in index if type(i) is dict]
                    for i in index:
                        if type(i) is dict:
                            i['server'] = cnt
                            Addon.add_artist(i)
                else:
                    Addon.show_dialog([Addon.get_string(30030)])

                cnt = cnt + cnt;
            Addon.end_of_directory()

    def get_music_directory(self, music_id, server):
        Addon.log('get_music_directory: ' + music_id)
        payloads = self.__get_json('getMusicDirectory.view', {'id': music_id, 'server': server})
        if payloads:
            for payload in payloads:
                songs = self.listify(payload['directory']['child'])
                self.display_music_directory(songs, True, server)

    def get_album_list(self, sort, page=0):
        Addon.log('get_album_list: ' + sort)
        payloads = self.__get_json('getAlbumList.view', {'type': sort,
                                  'size': 50, 'offset': int(page) * 50})

        xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL ) 
        if payloads:
            for payload in payloads:
                if payload['albumList']:
                    albums = self.listify(payload['albumList']['album'])
                    self.display_music_directory(albums, False, payload['server'])
                    if len(albums) == 50:
                        Addon.add_directory({'mode': 'albums', 'sort': sort, 'server':payload['server'],
                                         'page': int(page) + 1},
                                        Addon.get_string(30037), payload['server'])
            Addon.end_of_directory()
        
    def display_music_directory(self, songs, done=True, server=None):
        for song in songs: 
            if type(song) is dict:
                cover_art = self.get_cover_art_url(song.get('coverArt', None), server)
                if song['isDir']:
                    song['server'] = server
                    Addon.add_album(song, cover_art)
                else:    
                    Addon.add_song(song, server, cover_art)
        if done:
            Addon.end_of_directory()
    
    def get_playlists(self, server=None):
        Addon.log('get_playlists')
        if server is None: # hakk
            payloads = self.__get_json('getPlaylists.view')
        else:
            payloads = self.__get_json('getPlaylists.view', {'server': server})
        if payloads:
            for payload in payloads:
                if payload.has_key('playlists'):
                    playlists = payload['playlists']
                    if type(playlists) is dict:
                        if playlists.has_key('playlist'):
                            playlists = self.listify(payload['playlists']['playlist'])
                            total = len(playlists)
                            Addon.log('playlists: ' + str(playlists))
                            for playlist in playlists:
                                if type(playlist) is dict:
                                    Addon.add_directory({'mode': 'playlist', 'server':payload['server'],
                                                         'playlist_id': playlist['id']}, 
                                                          playlist['name'], 
                                                          total_items=total)
                            Addon.end_of_directory()

    def get_playlist(self, playlist_id, server):
        Addon.log('get_playlist: ' + playlist_id)
        payloads = self.__get_json('getPlaylist.view', {'id': playlist_id, 'server': server})
        if payloads:
            for payload in payloads:
                if payload.has_key('playlist'): # consider moving location of ppayload['server']
                                                # to avoid this "if" mess
                    playlist = payload['playlist']
                    if playlist.has_key('entry'):
                        songs = self.listify(payload['playlist']['entry'])
                        self.display_music_directory(songs, True, payload['server'])

    def get_random(self, queries):
        Addon.log('get_random: ' + str(queries))
        payloads = self.__get_json('getRandomSongs.view', queries)
        for payload in payloads:
            if payload.get('randomSongs', False):
                songs = self.listify(payload['randomSongs']['song'])
                self.display_music_directory(songs, True, payload['server'])
#            else:
#                Addon.show_dialog([Addon.get_string(30010)])
            
    def play(self, song_id, server_num):

        server = self.servers[int(server_num)-1]
        Addon.log('play: ' + song_id)
        if Addon.get_setting('transcode') == 'true':
            bitrate = self.bitrates[int(Addon.get_setting('bitrate'))]
            Addon.resolve_url(self.build_rest_url(server,'stream.view', 
                                                  {'id': song_id,
                                                   'server': server,
                                                   'maxBitRate': bitrate}))
        else:
            Addon.resolve_url(self.build_rest_url(server,'stream.view', 
                                                  {'id': song_id,
                                                   'server': server}))
 
            #Addon.resolve_url(self.build_rest_url(server,'download.view', 
            #                                      {'id': song_id, 'server': server}))
    def search(self, search_mode, query): 
        Addon.log('search: ' + query)
        queries = {'query': query, 'albumCount': 0, 'artistCount': 0,
                   'songCount': 0}
        queries[search_mode + 'Count'] = 999
        payloads = self.__get_json('search2.view', queries)        
        for payload in payloads:
            if payload['searchResult2']:
                items = self.listify(payload['searchResult2'][search_mode])
                if search_mode == 'artist':
                    #[Addon.add_artist(i) for i in items if type(i) is dict]
                    for i in items:
                        if type(i) is dict:
                            i['server'] = payload['server']
                            Addon.add_artist(i)
                    Addon.end_of_directory()
                else:
                    self.display_music_directory(items, True, payload['server'])

#makes no sence on multihost
#            else:
#                Addon.show_dialog([Addon.get_string(30010)])

    def get_cover_art_url(self, cover_art_id, server_num):
        server = self.servers[int(server_num)-1]
        url = ''
        if cover_art_id:
            url = self.build_rest_url(server, 'getCoverArt.view', {'id': cover_art_id})
            Addon.log('cover art: ' + url)
        return url
                      
    def build_rest_url(self, server, method, queries):
        queries.update({'v': server['api_version'], 
                        'c': server['client_name'], 
                        'u': server['user'], 
                        'p': server['password'],
                        'f': 'json'})
        Addon.log('queries: ' + str(queries))
        query = Addon.build_query(queries)
        return '%s/rest/%s?%s' % (server['server']+':'+server['port'], method, query) 
    
    def listify(self, data):
        if type(data) is not list:
            return [data]
        else:
            return data

    def __get_json(self, method, queries={}):

        payloads = []
        cnt = 0
        for server in self.servers:
            cnt = cnt +1

            if queries.has_key('server'):
                if str(server['name']) != str(queries['server']):
                    continue
            json_response = None

            url = self.build_rest_url(server, method, queries)
            print url
            Addon.log('getting ' + url)
            try:
                response = urllib2.urlopen(url)
                try:
                    json_response = json.loads(response.read())
                except ValueError:
                    Addon.show_error([Addon.get_string(30002)])
                    return False
            except urllib2.URLError, e:
                Addon.show_error([Addon.get_string(30001), str(e.reason)])
                return False

            payload = json_response.get('subsonic-response', None)

            payload['server'] = str(cnt) # test
            if payload.get('status', 'failed') == 'ok':              
                payloads.append(payload)
            else:
                Addon.show_error([payload['error']['message'], 
                       'json version: ' + payload['version']])  
                return False 

        return payloads
