import os
import re

cwd = os.getcwd()

num = 0
servers = ''
r = open(cwd+'/settings.xml', 'r')
beg = 0
for line in r:
    match = re.compile('</settings>').findall(line)
    if match:
        break
    match = re.compile('category label="30106"').findall(line)
    if match:
        beg = 1
        print "P" + line
        num = num + 1
    if not beg == 1:
        continue
    servers = servers + line
r.close()

w = open(cwd+'/settings.xml', 'w')
w.write('<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n')
 
w.write('<settings>\n')

w.write('  <category label="Add">\n')
w.write('    <setting type="action" label="Add server" action="RunScript($CWD/resources/add_server.py,add)" option="close"/>\n');
w.write('    <settings type="text" label="servers" value="'+str(num+1)+'" />\n')
w.write('  </category>\n')

w.write(servers)
r = open(cwd+'/server.xml', 'r')
text = r.read()
text=text.replace('<num>', str(num+1))
r.close()
w.write(text)

w.write('</settings>\n')

w.close()
