xbmc-plugin-day9 (plugin.video.day9)
========================================

An XBMC plugin to view the Day[9].tv Daily Archives.


This is based very heavily off of the day9 plugin by
petersson.krill@gmail.com (http://code.google.com/p/xbmc-plugin-day9/)

The plugin has been updated to use the new day9.tv website as it's archive
source, and to use the youtube plugin as the video player.

forum thread
============
http://forum.xbmc.org/showthread.php?tid=143022
