#!/usr/bin/python
# -*- coding: utf-8 -*-
from xbmcswift2 import Module, Plugin, xbmcgui
import re
import urllib
import urllib2
import datetime
from ..bt import decode_btih
from ..utils import (fetch_url, get_btih_playurl, get_ed2k_playurl,
                     NEXT_PAGE_NAME, keyboard)


m = Module(__name__)
m.storage_path = Plugin().storage_path  # a bug from xbmcswift2


@m.route('/')
def index():
    return [
        {'label': '电影', 'path': m.url_for('firspage', genre='movies')},
        {'label': '电视剧', 'path': m.url_for('firspage', genre='movies/series')},
        {'label': '高分', 'path': m.url_for('firspage', genre='movies/top')},
        {'label': '*搜索*', 'path': m.url_for('search')}]


@m.route('/search/')
def search():
    query = (keyboard(heading=u'请输入搜索内容') or '').strip()
    if query:
        url = 'http://imax.im/movies/search?q=' + urllib.quote_plus(query, '')
        try:
            return m.plugin.finish(get_movies(url), view_mode='thumbnail')
        except urllib2.HTTPError as e:
            if e.code == 404:
                return []
            raise


_DEFAULT_PARAMS = {'country': '全部', 'category': '全部',
                   'year': '全部', 'sort': 'upload', 'to_change': '0'}


@m.route(
    '/firspage/<genre>/<country>/<category>/<year>/<sort>/<to_change>/',
    options=_DEFAULT_PARAMS)
def firspage(genre, country, category, year, sort, to_change):
    params = locals().copy()
    params.pop('genre')
    params.pop('to_change')
    if to_change in params:
        new_val = change_cond(genre, country, category, year, sort, to_change)
        if new_val:
            params[to_change] = new_val
        else:
            return

    # params = dict((k, v[0]) for k, v in m.request.args.items())
    items = [{
        'label': u'国家/地区 【[COLOR FF00FF00]%s[/COLOR]】' % params['country'],
        'path': m.url_for('firspage', genre=genre,
                          to_change='country', **params)
    }, {
        'label': u'类型 【[COLOR FF00FF00]%s[/COLOR]】' % params['category'],
        'path': m.url_for('firspage', genre=genre,
                          to_change='category', **params)
    }, {
        'label': u'年份 【[COLOR FF00FF00]%s[/COLOR]】' % params['year'],
        'path': m.url_for('firspage', genre=genre,
                          to_change='year', **params)
    }, {
        'label': u'按【[COLOR FF00FF00]%s[/COLOR]】排序' %
        {'recent': '上映时间', 'upload': '资源上传',
            'rank': '豆瓣评分'}[params['sort']],
        'path': m.url_for('firspage', genre=genre,
                          to_change='sort', **params)
    }]

    url = 'http://imax.im/' + genre
    param_str = ''
    for key, val in params.items():
        if params[key] != _DEFAULT_PARAMS[key]:
            param_str += '&%s=%s' % (key, val)

    if param_str:
        url += '?' + param_str[1:]

    items += get_movies(url)

    return m.plugin.finish(items, view_mode='thumbnail')


def change_cond(genre, country, category, year, sort, to_change):
    pastyears = map(str, range(datetime.date.today().year, 2005, -1))
    all_choices = {
        'country': ('请选择国家/地区',
                    ['全部', '美国', '中国大陆', '香港', '日本', '韩国',
                     '法国', '德国', '泰国']),
        'category': ('请选择类型',
                     ['全部', '科幻', '动作', '喜剧', '爱情', '剧情', '魔幻',
                     '动画', '悬疑', '惊悚', '战争', '历史']),
        'year': ('请选择年份',
                 pastyears + ['00年代', '90年代', '80年代', '70年代'],
                 pastyears + ['00', '90', '80', '70']),
        'sort': ('请选择排序方式',
                 ['上映时间', '资源上传', '豆瓣评分'],
                 ['recent', 'upload', 'rank'])
    }
    current = all_choices.get(to_change)
    index = xbmcgui.Dialog().select(current[0], current[1])
    if index >= 0:
        return current[2 if len(current) > 2 else 1][index]


@m.route('/list_resources/<id>/')
def list_resources(id):
    url = 'http://imax.im/movies/' + id
    html = fetch_url(url, headers={'Cookie': 'rel=douban'})
    _RE_RESOURCE = re.compile(
        r'<td class="qu">\s*(\S+)\s*</td>\s*'
        '<td class="size"><span>(.+?)</span></td>\s*'
        '<td class="name">\s*'
        '<a href="([^"]+)" class="attach">(.+?)</a>'
    )
    _RE_MAGNET_URL = re.compile(
        r'magnet:\?xt=urn:btih:([0-9a-fA-F]{40}|[2-7A-Z]{32})')

    items = []
    for match in _RE_RESOURCE.finditer(html):
        linkurl = match.group(3)
        m_btih = _RE_MAGNET_URL.match(linkurl)
        if m_btih:
            btih = m_btih.group(1)
            if len(btih) == 32:
                btih = decode_btih(btih)
            path = get_btih_playurl(btih, match.group(4))
        else:
            path = get_ed2k_playurl(linkurl, match.group(4))

        items.append({
                     'label': '[%s][%s]%s' % tuple(
                         map(match.group, (1, 2, 4))),
                     'path': path,
                     'is_playable': True,
                     'properties': {'isPlayable': ''}
                     })

    return items


@m.route('/list/<url>/<page>', options={'page': 1})
def get_movies(url, page=1):
    _RE_URL_LINK = re.compile(
        r'<div class="cover"><a href="/movies/(\d+)" title="(.+?)">'
        '<img.+?src="(.+?)"')
    items = []

    page_idx = int(page)
    if page_idx > 1:
        url += ('&' if '?' in url else '?') + 'page=' + page

    html = fetch_url(url, headers={'Cookie': 'rel=douban'})

    for match in _RE_URL_LINK.finditer(html):
        movie_id, name, thumbnail = match.groups()
        items.append({
            'label': name,
            'path': m.url_for('list_resources', id=movie_id),
            'thumbnail': thumbnail
        })

    if '<a rel="next"' in html:
        items.append({
            'label': NEXT_PAGE_NAME,
            'path': m.url_for('get_movies', url=url, page=page_idx + 1)
        })

    return items if page_idx == 1 \
        else m.plugin.finish(items, view_mode='thumbnail')


def get_main_menu_items():
    return [{
        'label': u'从[COLOR FF00CC00]iMax.im[/COLOR]获取种子',
        'path': m.url_for('index'),
        'thumbnail': 'http://movieso.b0.upaiyun.com/assets/logo-b235d752f75b0f7c13106e284012dc2e.png'
    }]
