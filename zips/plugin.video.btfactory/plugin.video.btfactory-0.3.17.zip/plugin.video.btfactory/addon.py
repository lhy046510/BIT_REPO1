#!/usr/bin/python
# -*- coding: utf-8 -*-
from xbmcswift2 import Plugin, CLI_MODE
import sys
import re
import traceback
from pkgutil import iter_modules
from resources.lib import modules
from resources.lib.loadcfg import load_cfgs


plugin = Plugin()
menu_items = []


@plugin.route('/')
def index():
    return menu_items + [{
        'label': u'设置解析器',
        'path': plugin.url_for('urlresolvercn_settings'),
        'is_playable': True,
        'properties': {'isPlayable': ''}
    }, {
        'label': u'清空缓存',
        'path': plugin.url_for('clear_cache'),
        'is_playable': True,
        'properties': {'isPlayable': ''}
    }]


@plugin.route('/urlresolvercn_settings/')
def urlresolvercn_settings():
    import urlresolvercn
    urlresolvercn.display_settings()


@plugin.route('/clear_cache/')
def clear_cache():
    plugin.clear_function_cache()
    plugin.notify(u'缓存清除完毕！'.encode('utf-8'))


def register_modules(modname=None):
    if modname:
        try:
            module = __import__(
                modules.__name__ + '.' + modname, fromlist='dummy')
        except ImportError:
            pass
        else:
            plugin.register_module(module.m, '/' + modname)
            return True

        return

    for _, modname, _ in iter_modules(modules.__path__, ):
        try:
            module = __import__(
                modules.__name__ + '.' + modname, fromlist='dummy')
        except ImportError:
            plugin.log.debug(traceback.print_exc())
            continue

        plugin.register_module(module.m, '/' + modname)
        menu_items.extend(module.get_main_menu_items())


reload(sys)
sys.setdefaultencoding('utf-8')

plugin_url = sys.argv[2] if CLI_MODE else sys.argv[0]
match = re.search(r':\/\/[^\/]+\/([^\/]+)', plugin_url)
modname = match.group(1) if match else ''
if modname:
    register_modules(modname) or load_cfgs(plugin, modname)
else:
    register_modules()
    menu_items.extend(load_cfgs(plugin))

if __name__ == '__main__':
    plugin.run()
