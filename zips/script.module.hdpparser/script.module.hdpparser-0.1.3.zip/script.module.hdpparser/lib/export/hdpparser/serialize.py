# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
from base64 import b64encode, b64decode
from zlib import compress, decompress
from string import maketrans
import marshal

tr = maketrans('+/', '-_')
tr2 = maketrans('-_', '+/')


def dumps(obj):
    return b64encode(compress(marshal.dumps(obj))).strip('=').translate(tr)


def loads(s):
    to_padding = len(s) % 4
    if to_padding:
        s += '=' * (4 - to_padding)

    return marshal.loads(decompress(b64decode(s.translate(tr2))))
