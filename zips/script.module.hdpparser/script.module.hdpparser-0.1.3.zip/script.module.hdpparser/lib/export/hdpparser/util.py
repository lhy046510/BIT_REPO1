# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import time
import gzip
import urllib2
from urllib import urlencode

try:
    from cStringIO import StringIO
except ImportError:
    from StringIO import StringIO  # noqa

try:
    import ujson as json
except ImportError:
    import json  # noqa

try:
    from third_party import chardet
except ImportError:
    import chardet  # noqa

try:
    import xbmc  # noqa
    import xbmcgui  # noqa
    import xbmcplugin  # noqa
    import xbmcaddon  # noqa
    import xbmcvfs  # noqa

    in_xbmc = True
except ImportError:
    in_xbmc = False

USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.22 (KHTML, like Gecko) Chrome/25.0.1364.84 Safari/537.22'  # noqa


def copy_dict_value(old_d, new_d=None, keys=[], strict_keys=[]):
    if new_d is None:
        new_d = {}

    if not old_d:
        return new_d

    for k in strict_keys:

        if isinstance(k, basestring):
            new_d[k] = old_d[k]

        else:
            k, new_k = k
            new_d[new_k] = old_d[k]

    for k in keys:

        if isinstance(k, basestring):
            if k in old_d:
                new_d[k] = old_d[k]

        else:
            k, new_k = k
            if k in old_d:
                new_d[new_k] = old_d[k]

    return new_d


http_proxy = None


def fetch_url_with_headers(url, data=None, headers=None, timeout=None,
                           proxies=None, headers_only=False):
    if headers is None:
        headers = {}

    headers.setdefault('User-Agent', USER_AGENT)
    headers.setdefault('Accept-Encoding', 'gzip,deflate')

    if data and isinstance(data, dict):
        data = urlencode(data)

    req = urllib2.Request(url, data, headers)

    if proxies or http_proxy:
        if not proxies:
            if isinstance(http_proxy, basestring):
                proxies = {'http': http_proxy, 'https': http_proxy}
            else:
                proxies = http_proxy
        proxy_handler = urllib2.ProxyHandler(proxies)
        opener = urllib2.build_opener(proxy_handler)
        r = opener.open(req, timeout=timeout)
    else:
        r = urllib2.urlopen(req, timeout=timeout)

    if headers_only:
        content = None
    else:
        content = r.read()

        if r.headers.get('content-encoding') == 'gzip':
            content = gzip.GzipFile(fileobj=StringIO(
                content), mode='rb').read()

    r.close()

    return content, r.headers, r.url


def fetch_url(url, data=None, headers={}, timeout=None, proxies=None):
    return fetch_url_with_headers(url, data, headers, timeout, proxies)[0]


def get_tick():
    return int(1000 * time.time())


class DictCombiner():

    def __init__(self, *args):
        self._dicts = args

    def __contains__(self, key):
        return any(key in d for d in self._dicts)

    def __getitem__(self, key):
        for d in self._dicts:
            if key in d:
                return d.__getitem__(key)
        else:
            raise KeyError

    def get(self, key, default=None):
        for d in self._dicts:
            if key in d:
                return d.__getitem__(key)
        else:
            return default
