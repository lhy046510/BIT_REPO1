# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import re
from urllib import quote_plus, urlencode
from urlparse import parse_qsl

from ...util import (json, copy_dict_value, get_tick, fetch_url_with_headers)
from ... import cache


PAGE_SIZE = 60
SHARE_LIST_SIZE = 100


class APIError(Exception):

    def __init__(self, errno, data):
        self.errno = errno
        self.data = data

    def __str__(self):
        return 'APIError(%s): %r' % (self.errno, self.data)


class CaptchaError(Exception):

    def __init__(self, reason):
        self.reason = reason


class ShareUrlCancelled(Exception):

    def __init__(self, reason):
        self.reason = reason


def fetch_url_with_cookies(url, data=None, headers=None, timeout=None,
                           proxies=None):
    baiduid = cache.get('bdyun.cookie.baiduid')
    if baiduid:
        if headers and 'Cookie' in headers:

            if 'BAIDUID=' not in headers['Cookie']:
                headers['Cookie'] += '; BAIDUID=%s' % baiduid

        else:
            headers = headers or {}
            headers.update(Cookie='BAIDUID=' + baiduid)

    content, headers, new_url = fetch_url_with_headers(
        url, data, headers, timeout, proxies)

    if 'set-cookie' in headers:
        match = re.search(r'BAIDUID=(.+?);', headers['set-cookie'])

        if match:
            cache.set('bdyun.cookie.baiduid', match.group(1), 24 * 60 * 60)

    return content, headers, new_url


def fetch_url(url, data=None, headers=None, timeout=None,
              proxies=None):
    return fetch_url_with_cookies(url, data, headers, timeout,
                                  proxies)[0]


def fetch_api(url, data=None, headers={}, timeout=None, proxies=None):
    return fetch_api_with_cookies(url, data, headers, timeout, proxies)[0]


def fetch_api_with_cookies(url, data=None, headers={}, timeout=None,
                           proxies=None):
    content, headers, _ = fetch_url_with_cookies(
        url, data, headers, timeout, proxies)

    res = json.loads(content)

    errno = res['errno']
    if errno != 0:
        raise APIError(errno, res)

    return res, headers


def get_feed_sharelist(uk, start=0, limit=PAGE_SIZE, video_only=True):

    def get_record_type(record):
        if record['category'] not in (1, 6, 10):
            return 'other'

        if 'album_id' in record:
            return 'album'

        elif record['filecount'] > 1 or record['filelist'][0]['isdir'] == 1:
            return 'dir'

        return 'file'

    def create_record_album(r):
        # nr = {
        #     'type': 'album',
        #     'title': r['title'],
        #     'filecount': r['filecount'],
        #     'album_id': r['album_id'],
        #     'thumb': r'cover_thumb',
        # }

        # if 'shorturl' in r:
        #     nr['shorturl'] = r['shorturl']

        return copy_dict_value(
            r,
            {'type': 'album'}, keys=['shorturl'],
            strict_keys=[
                'title', 'album_id', 'filecount', ('cover_thumb', 'thumb')]
        )

    def create_record_file(r):
        # f = r['filelist'][0]
        # nr = {
        #     'type': 'file',
        #     'title': r['title'],
        #     'shareid': r['shareid'],
        #     'fs_id': f['fs_id'],
        #     'size': f['size'],
        #     'path': f['path'],
        # }

        # if 'shorturl' in r:
        #     nr['shorturl'] = r['shorturl']

        # if 'thumburl' in f:
        #     nr['thumb'] = f['thumburl']

        nr = {'type': 'file'}

        copy_dict_value(
            r, nr,
            keys=['shorturl'],
            strict_keys=['title', 'shareid']
        )

        copy_dict_value(
            r['filelist'][0], nr,
            keys=[('thumburl', 'thumb')],
            strict_keys=['fs_id', 'size', 'path']
        )

        return nr

    def create_record_dir(r):
        # nr = {
        #     'type': 'dir',
        #     'title': r['title'],
        #     'shareid': r['shareid'],
        #     'path': r['filelist'][0]['path'],
        # }

        # if 'shorturl' in r:
        #     nr['shorturl'] = r['shorturl']

        return copy_dict_value(
            r,
            {'type': 'dir', 'path': r['filelist'][0]['path']},
            keys=['shorturl'],
            strict_keys=['title', 'shareid']
        )

    def create_record(record):

        record_type = get_record_type(record)

        if video_only and (
            record_type == 'other'
            or (record_type == "file" and record['category'] != 1)
        ):
            return

        return {
            'album': create_record_album,
            'file': create_record_file,
            'dir': create_record_dir,
        }[record_type](record)

    api_res = _fetch_feed_sharelist(uk, start, limit)

    return {
        'total_count': api_res['total_count'],
        'count': len(api_res['records']),
        'list': filter(bool, map(create_record, api_res['records'])),
    }


def _fetch_feed_sharelist(uk, start=0, limit=PAGE_SIZE):
    url = 'http://pan.baidu.com/pcloud/feed/getsharelist?t=%s&category=0&auth_type=1&request_location=share_home&start=%d&limit=%d&query_uk=%s&channel=chunlei&clienttype=0&web=1&bdstoken=null' % (  # noqa
        get_tick(), start, limit, uk
    )

    return fetch_api(url)


def get_album_list(uk, start=0, limit=PAGE_SIZE):
    api_res = _fetch_album_list(uk, start, limit)

    return {
        'total_count': api_res['count'],
        'count': len(api_res['album_list']),
        'list': [
            {
                'type': 'album',
                'thumb': r['cover_thumb'],
                'title': r['title'],
                'filecount': r['filecount'],
                'album_id': r['album_id'],
            }
            for r in api_res['album_list']
        ]
    }


def _fetch_album_list(uk, start=0, limit=PAGE_SIZE):
    url = 'http://pan.baidu.com/pcloud/album/getlist?t=%s&start=%d&limit=%d&query_uk=%s&channel=chunlei&clienttype=0&web=1&bdstoken=null' % (  # noqa
        get_tick(), start, limit, uk
    )

    return fetch_api(url)


def get_album_listfile(uk, album_id, start=0, limit=PAGE_SIZE,
                       video_only=True):

    def create_record(r):
        if video_only and r['category'] != 1:
            return

        # nr = {
        #     'type': 'file',
        #     'title': r['server_filename'],
        #     'fs_id': r['fs_id'],
        #     'size': r['size'],
        #     'path': r['path'],
        #     'dlink': r['dlink'],
        # }

        # if 'thumburl' in r:
        #     nr['thumb'] = r['thumburl']

        # return nr

        return copy_dict_value(
            r, {'type': 'file'},
            keys=[('thumburl', 'thumb')],
            strict_keys=[
                ('server_filename', 'title'), 'fs_id', 'size', 'path', 'dlink']
        )

    api_res = _fetch_album_listfile(uk, album_id, start, limit)

    return {
        'total_count': api_res['count'],
        'count': len(api_res['list']),
        'list': filter(bool, map(create_record, api_res['list'])),
    }


def _fetch_album_listfile(uk, album_id, start=0, limit=PAGE_SIZE):
    url = 'http://pan.baidu.com/pcloud/album/listfile?album_id=%s&query_uk=%s&start=%d&limit=%d&bdstoken=null&channel=chunlei&clienttype=0&web=1' % (  # noqa
        album_id, uk, start, limit
    )

    return fetch_api(url)


def _fetch_album_listfilerange(uk, album_id, fs_id, start=0, limit=PAGE_SIZE):
    '''主要用作显示专辑列表，没太大作用'''
    url = 'http://pan.baidu.com/pcloud/album/listfilebyrange?query_uk=%s&fs_id=%s&album_id=%s&bdstoken=null&channel=chunlei&clienttype=0&web=1' % (  # noqa
            uk, fs_id, album_id
    )

    return fetch_api(url)


def _fetch_homerecord(uk, page=1, size=PAGE_SIZE):
    url = 'http://pan.baidu.com/share/homerecord?uk=%s&page=%d&pagelength=%d' % (  # noqa
        uk, page, size
    )

    return fetch_api(url)


def get_share_list(uk, shareid, path, page=1, size=SHARE_LIST_SIZE,
                   bdclnd=None, video_only=True):

    def create_dir_record(r):
        return {
            'type': 'dir',
            'title': r['server_filename'],
            'path': quote_plus(r['path'].encode('utf-8')),
        }

    def create_file_record(r):
        if video_only and r['category'] != 1:
            return

        nr = {
            'type': 'file',
            'title': r['server_filename'],
            'path': quote_plus(r['path'].encode('utf-8')),
            'fs_id': r['fs_id'],
        }

        if 'thumbs' in r and 'url1' in r['thumbs']:
            nr['thumb'] = r['thumbs']['url1']

        return nr

    def create_record(r):
        if r['isdir'] == 1:
            return create_dir_record(r)

        return create_file_record(r)

    item_list = _fetch_share_list(
        uk, shareid, path, page, size, bdclnd)['list']

    return {
        'count': len(item_list),
        'list': filter(bool, map(create_record, item_list)),
    }


def _fetch_share_list(uk, shareid, path, page=1, size=SHARE_LIST_SIZE,
                      bdclnd=None):
    if not path.startswith('%2F'):
        if isinstance(path, unicode):
            path = path.encode('utf-8')

        path = quote_plus(path)

    url = 'http://pan.baidu.com/share/list?channel=chunlei&clienttype=0&web=1&num=%d&t=%s&page=%d&dir=%s&t=0.64537&uk=%s&shareid=%s&order=time&desc=1&bdstoken=null' % (  # noqa
        size, get_tick(), page, path, uk, shareid
    )

    return fetch_api(
        url, headers={'Cookie': 'BDCLND=' + bdclnd} if bdclnd else None)


def get_share_download(uk, shareid, fid, sign, timestamp, fn_get_captcha=None,
                       retry_count=3, bdclnd=None):

    vcode = captcha = None

    for x in range(retry_count):
        try:

            dlink = _fetch_share_download(
                uk, shareid, fid, sign, timestamp, vcode, captcha,
                {'Cookie': 'BDCLND=' + bdclnd} if bdclnd else None
            )['dlink']

            cache.set('bdyun.fid_dlink.' + str(fid), dlink, 2 * 60 * 60)

            return dlink

        except APIError as e:

            if not (e.errno == -19 and callable(fn_get_captcha)):
                raise

            cache.delete('bdyun.cookie.baiduid')

            res = e.data
            vcode = res['vcode']

            captcha = fn_get_captcha(res['img'])
            if captcha == 'CANCEL':
                raise CaptchaError('UserCancelled')
    else:
        raise CaptchaError('WrongCaptcha')


def _fetch_share_download(uk, shareid, fid, sign, timestamp, vcode=None,
                          captcha=None, headers=None):
    assert sign and timestamp

    url = 'http://yun.baidu.com/share/download?channel=chunlei&clienttype=0&web=1&uk=%s&shareid=%s&timestamp=%s&sign=%s&bdstoken=null' % (  # noqa
        uk, shareid, timestamp, sign
    )

    if vcode and captcha:
        data = 'fid_list=%5B%22{0}%22%5D&input={1}&vcode={2}'.format(
            fid, captcha, vcode)
    else:
        data = 'fid_list=%5B%22{0}%22%5D'.format(fid)

    return fetch_api(url, data, headers)


def parse_pan_html(content):

    def get_viewShareData():
        match = re.search(
            r'disk\.util\.ViewShareUtils\.viewShareData\s*=\s*"(.+?)(?<!\\)"',
            content)

        if match:
            return json.loads(match.group(1).decode('string_escape'))

    def get_dir_list():
        match = re.search(r'applicationConfig,"(\[\{.+?\}\])"', content)

        return json.loads(match.group(1).decode('string_escape'))

    def get_xxx(pattern):
        match = re.search(pattern, content)
        if match:
            return match.group(1)

    def create_file_record(vs_data):
        res = {
            'type': 'file',
            'title': vs_data['server_filename'],
            'path': quote_plus(vs_data['path'].encode('utf-8')),
        }

        copy_dict_value(vs_data, res, ['fs_id', 'dlink', 'size', 'md5'])

        if 'thumbs' in vs_data and 'url1' in vs_data['thumbs']:
            res['thumb'] = vs_data['thumbs']['url1']

        return res

    if u'<title>百度云 网盘-链接不存在</title>' in content:
        raise ShareUrlCancelled(u'分享的文件已经被取消了！')

    view_share_data = get_viewShareData()

    if view_share_data:
        res = create_file_record(view_share_data)

    else:
        res = {
            'type': 'dir',
            'list': [{
                'title': item['server_filename'],
                'path': item['path'].encode('utf-8'),
                'type': 'dir' if item['isdir'] == '1' else 'file',
                'fs_id': item['fs_id'],
            } for item in get_dir_list()],
        }

    for k, v in [
        ('uk', r'FileUtils\.share_uk="(\d+)"'),
        ('shareid', r'FileUtils\.share_id="(\d+)"'),
        ('timestamp', r'FileUtils\.share_timestamp="(\d+)"'),
        ('sign', r'FileUtils\.share_sign="(.+?)"'),
    ]:
        value_found = get_xxx(v)
        if value_found:
            res[k] = value_found

    if all(k in res for k in ('sign', 'timestamp', 'shareid')):
        cache.set('bdyun.sign_timestamp.' + res['shareid'],
                  [res['sign'], res['timestamp']], 60 * 60)

    return res


def parse_pan_url(url, bdclnd=None):
    return parse_pan_html(fetch_url(
        url, headers={'Cookie': 'BDCLND=' + bdclnd} if bdclnd else None))


def get_bdclnd(uk, shareid, passwd):
    content, headers, _ = fetch_url_with_cookies(
        'http://pan.baidu.com/share/verify?shareid=%s&uk=%s' % (shareid, uk),
        'pwd=%s&vcode=' % passwd
    )

    if json.loads(content)['errno'] != 0:
        return

    bdclnd = re.search(r'BDCLND=(.+?);', headers['set-cookie']).group(1)

    cache.set('bdyun.bdclnd.' + shareid, bdclnd, 365 * 24 * 60 * 60)

    return bdclnd


def get_inbox_unpanfileinfo(**kwargs):
    params = kwargs.copy()
    params.setdefault('channel', 'chunlei')
    params.setdefault('clienttype', '0')
    params.setdefault('web', '1')
    params.setdefault('bdstoken', 'null')

    url = 'http://pan.baidu.com/inbox/object/unpanfileinfo?' + \
        urlencode(params)

    return fetch_api(url)


def get_inbox_download(session_id, founder_uk, object_id, fs_id):
    return fetch_api('http://pan.baidu.com/inbox/object/download?session_id={0}&founder_uk={1}&object_array=%5B%22{2}%22%5D&fsid_array=%5B{3}%5D&channel=chunlei&clienttype=0&web=1&bdstoken=null'.format(  # noqa
        session_id, founder_uk, object_id, fs_id
    ))


def get_inbox_uppanstream_url(session_id, founder_uk, object_id, fs_id,
                              type_='m3u8_auto_360'):
    return 'http://pan.baidu.com/inbox/object/unpanstream?session_id=%s&founder_uk=%s&object_id=%s&fs_id=%s&type=%s' % (  # noqa
        session_id, founder_uk, object_id, fs_id, type_)


def parse_inbox_url(url):

    def get_xxx(pattern):
        match = re.search(pattern, content)
        if match:
            return match.group(1)

    content, _, new_url = fetch_url_with_cookies(url)
    if url != new_url:
        raise ShareUrlCancelled(u'分享的文件已经被取消了！')

    if u'分享的文件已过期了' in content:
        raise ShareUrlCancelled(u'分享的文件已过期了')

    res = {}
    for k, v in [
        ('bdstoken', r'FileUtils\.bdstoken="(.+?)"'),
        ('session_id', r'FileUtils\.session_id="(\d+)"'),
        ('title', r'FileUtils\.session_title="(.+?)"'),
        ('category', r'FileUtils\.session_category=(\d)'),
        ('founder_uk', r'FileUtils\.founder_uk=(\d+)'),
    ]:
        value_found = get_xxx(v)
        if value_found:
            res[k] = value_found

    return res


def parse_inbox_mobile_url(url, video_only=True):

    def get_xxx(pattern):
        match = re.search(pattern, content)
        if match:
            return match.group(1)

    content, _, new_url = fetch_url_with_cookies(url,
        headers={'User-Agent': 'Mozilla/5.0 (Linux; U; Android 2.3.7; en-us; Nexus One Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1'})  # noqa

    if url != new_url:
        raise ShareUrlCancelled(u'分享的文件已经被取消了！')

    res = {}
    match = re.search(r'mpan.viewsingle_param={(.+?)};', content)
    if match:
        for item in match.group(1).split(','):
            k, _, v = item.partition(':')
            k = k.strip()
            if k == 'server_filename':
                res['title'] = v.strip(' "')
            elif k == 'dlink':
                res['dlink'] = v.strip(' "')
            elif k == 'fs_id':
                res['fs_id'] = v.strip(' "')
            elif k == 'path':
                res['path'] = v.strip(' "')
            elif k == 'size':
                res['size'] = v.strip(' "')

        res['type'] = 'file'

        for k, v in [
            ('bdstoken', r'FileUtils\.bdstoken="(.+?)"'),
            ('session_id', r'FileUtils\.session_id="(\d+)"'),
            ('founder_uk', r'FileUtils\.founder_uk=(\d+)'),
            ('thumb',
             r'<img[^>]+src="(http://d.pcs.baidu.com/thumbnail/.+?")'),
        ]:
            value_found = get_xxx(v)
            if value_found:
                res[k] = value_found

        return res

    res['type'] = 'dir'
    item_list = []

    # for match in re.finditer(
    # r'<li data-ac="active" data-fd="(\d)" data-fn="(.+?)">\s*<a class="list-item share-item" data-path="(.+?)" data-url="\?&amp;object_id=(\d+)&amp;fs_id=(\d+)"',  # noqa
    #     content
    # ):
    #     item_list.append({
    #         'type': 'dir' if match.group(1) == '1'else '0',
    #         'title': match.group(2),
    #         'path': match.group(3),
    #         'object_id': match.group(4),
    #         'fs_id': match.group(5),
    #     })

    match = re.search('listArr:JSON\.parse\("(.+?)"\)', content)
    listarr = json.loads(match.group(1).decode('string_escape'))
    for item in listarr:
        if video_only and item['isdir'] == 0 and item['category'] != 1:
            continue

        item_list.append(
            copy_dict_value(item, keys=['isdir', ('server_filename', 'title'), 'path', 'object_id', 'fs_id']))

    res['list'] = item_list

    if len(item_list) == 20:
        params = dict(parse_qsl(url.partition('?')[2]))
        res['next_page'] = int(params.get('page', 1)) + 1

    return res
