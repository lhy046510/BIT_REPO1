# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import os
from urllib import quote_plus

from .. import Parser, handle_exception, man
from ..util import in_xbmc

if in_xbmc:
    import xbmcvfs


VIDEO_FORMAT = [
    'mkv', 'rmvb', 'rm', 'avi', 'mpg', 'mpeg', 'mp4',
    'mov', '3gp', 'asf', 'wmv', 'flv', 'ts'
]


class ListDirParser(Parser):
    name = 'listdir'
    icon = 'folder'
    protocols = ['file']

    @handle_exception
    def parse(self, uri, params=None):
        path = self._get_path(uri)

        if not self._isdir(path):
            return

        return {'list': self._listdir(path)}

    def _get_path(self, uri):
        if uri.startswith('file:'):
            uri = uri[5:]

            if uri.startswith('//'):
                uri = uri[2:]

        return uri

    def match(self, uri):
        return self._isdir(self._get_path(uri))

    def _isdir(self, path):
        if in_xbmc:
            return xbmcvfs.exists(path)

        return os.path.isdir(path)

    def _listdir(self, path):
        if in_xbmc:
            return self._listdir_xbmcvfs(path)

        dirs = []
        files = []
        for name in os.dir(path):
            fullname = os.path.join(path, name)

            if os.path.isdir(fullname):
                dirs.append(self._create_folder_record(name, fullname))
                continue

            r = self._create_file_record(name, fullname)
            if r:
                files.append(r)

        return dirs + files

    def _listdir_xbmcvfs(self, path):
        dirs, files = xbmcvfs.listdir(path)

        res = [self._create_folder_record(d, os.path.join(path, d))
               for d in dirs]

        for name in files:
            r = self._create_file_record(name, os.path.join(path, name))

            if r:
                res.append(r)

        return res

    def _create_file_record(self, name, fullpath):
        basename, ext = os.path.splitext(name)
        ext = ext[1:].lower()

        if ext in VIDEO_FORMAT:
            return {
                'title': name,
                'link': fullpath,
                'direct_url': 1,
            }

        if ext in ['zip', 'rar'] and in_xbmc:
            return {
                'icon': ext,
                'title': name,
                'link': 'ext://%s/' % (quote_plus(fullpath)),
            }

        if ext in ['asx', 'bth'] and man.has_parser(ext):
            return {
                'isdir': 1,
                'icon': ext,
                'title': name,
                'link': {
                    'uri': fullpath,
                    'parser': ext,
                },
            }

    def _create_folder_record(self, dirname, fullpath):
        return {
            'isdir': 1,
            'title': dirname,
            'icon': 'dir',
            'link': {
                'uri': fullpath,
                'parser': self.name,
            },
        }
