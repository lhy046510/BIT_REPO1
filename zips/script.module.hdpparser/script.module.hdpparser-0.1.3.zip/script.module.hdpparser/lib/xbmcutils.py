# coding=utf-8
#   Author: jackyspy
#   Year: 2014
#
#   Distributed under the terms of the GPL (GNU Public License)
#
#   UliPad is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
import string

import xbmc
import xbmcaddon

try:
    from ChineseKeyboard import Keyboard
except ImportError:
    Keyboard = xbmc.Keyboard  # noqa

PLUGIN_ID = 'script.module.hdpparser'
addon = xbmcaddon.Addon(PLUGIN_ID)

plugin_path = addon.getAddonInfo('path')
plugin_name = addon.getAddonInfo('name')


def notify(msg, title=None, delay=5000, image=''):
    xbmc.executebuiltin('XBMC.Notification("%s", "%s", "%s", "%s")' %
                       (msg, title or plugin_name, delay, image))


def refresh():
    xbmc.executebuiltin('Container.Refresh')


def update_plugin_url(plugin_url):
    xbmc.executebuiltin('Container.Update(%s)' % plugin_url)


def keyboard(heading='', default='', hidden=False):

    if hidden:
        kb = xbmc.Keyboard(default, heading, hidden)
    else:
        kb = Keyboard(default, heading)

    xbmc.sleep(1000)

    kb.doModal()

    if (kb.isConfirmed()):
        return kb.getText()


def translate_icon_url(url):
    if not url:
        return ''

    if '://' in url:
        return url

    return ''


def colorize_title(title, color):
    if not title:
        return ''

    if '[/COLOR]' in title or not color:
        return title

    if color.startswith('0x'):
        color = color[2:]

    if (not all(c in set(string.hexdigits) for c in color) or
       len(color) not in (6, 8)):
        return title

    if len(color) == 6:
        color = 'FF' + color.upper()
    else:
        color = color.upper()

    return '[COLOR %s]%s[/COLOR]' % (color, title)
