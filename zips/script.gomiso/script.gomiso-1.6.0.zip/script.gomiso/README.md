Gomiso XBMC
=============

XBMC integration of [Gomiso](http://www.gomiso.com/)

Purpose
-------
The project is 100% functional but this is my first attempt to develop for XBMC so please be kind when reading the code ;)
Also, this is the first time for me with Python so, again, be kind when reading the code.

This XBMC script is using my [Gomiso Python lib](https://github.com/metabaron/Gomiso-Python)

Contributing
------------
When to contribut? Please contact [me](https://github.com/metabaron) instead of forking the project.

Usage
-----
The XMBC plugin for gomiso updates it with what you've been watching in XBMC. For best results, make sure you are in library mode.
		
		The script is available through the official XBMC repository:
		System > Add-ons > Get add-ons > XBMC.org Add-ons > Program Add-ons > Gomiso
		
		After installing this plugin, sign up for an account at http://gomiso.com.  Then.. 
		
		1. Navigate to Home > Programs and activate gomiso (location of gomiso activation is skin dependent and may be in other
		 places labeled Addons, Scripts, etc.)
		2. Enter in username and password that you have set up on the gomiso website and any other configuration you would like 
		
		Note: if you do not configure gomiso to autostart, you will need to repeat step 1 any time you would like to submit tv
		 shows or movies