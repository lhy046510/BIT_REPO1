"lore tests"
