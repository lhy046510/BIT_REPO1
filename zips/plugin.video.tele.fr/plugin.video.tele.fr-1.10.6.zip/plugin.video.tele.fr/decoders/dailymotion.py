# -*- coding: UTF-8 -*-

import urllib, urllib2, re

def stream_decoder(url):
    vid = ''.join(re.findall('playpath=(.*?) swfVfy', url))
    req = urllib2.Request('http://www.dailymotion.com/video/'+vid)
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36')
    req.add_header('Referer', 'http://www.dailymotion.com/swf/video/'+vid)
    try:
        f = urllib2.urlopen(req)
        for line in f.readlines():
            if 'http%3A%5C%2F%5C%2Fwww.dailymotion.com' in line:
                token_url = re.findall('URL%22%3A%22http%3A%5C%2F%5C%2Fwww.dailymotion.com%5C%2Fcdn%5C%2Flive%5C%2Fvideo%5C%2F(.*?)%22%2C%22', line)
                print 'http://www.dailymotion.com/cdn/live//video/'+urllib.unquote(token_url[0])+'&redirect=0'
                req = urllib2.Request('http://www.dailymotion.com/cdn/live/video/'+urllib.unquote(token_url[0])+'&redirect=0')
                req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.31 (KHTML, like Gecko) Chrome/26.0.1410.64 Safari/537.31')
                req.add_header('Referer', 'http://www.dailymotion.com/swf/video/'+vid)
                f2 = urllib2.urlopen(req)
                for line2 in f2.readlines():
                    if "f4m" in line2:
                        url = line2.replace("live.f4m","index.m3u8")
                    else:
                        url = line2+" swfUrl=http://static1.dmcdn.net/flash/dmplayerv4/dmplayer-prod-compressed.swf.v66041df7ddec5c549 pageUrl=http://www.dailymotion.com/video/"+vid+" live=true swfVfy=true timeout=30"
                    print url
        return url
    except:
        return url
        
        


