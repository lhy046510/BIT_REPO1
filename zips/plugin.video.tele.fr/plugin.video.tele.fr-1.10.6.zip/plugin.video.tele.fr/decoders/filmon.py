# -*- coding: UTF-8 -*-

import urllib, urllib2, re, datetime

def stream_decoder(url):
    req = urllib2.Request(url.replace("?q=high",""))
    req.add_unredirected_header('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3')
    req.add_header('Referer', url)
    try:
        f = urllib2.urlopen(req)
        vid = re.findall('\"low\"\,\"url\"\:\"(.*?)\"', f.read())
        new_url = vid[0].replace("\\","")
        if 'q=high' in url:
            new_url = new_url.replace("low","high")
        return new_url
    except:
        return url
