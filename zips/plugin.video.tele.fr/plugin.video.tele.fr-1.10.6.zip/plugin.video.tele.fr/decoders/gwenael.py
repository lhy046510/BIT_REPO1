# -*- coding: UTF-8 -*-

import urllib, urllib2, re, os, json

def stream_decoder(url):
    return url+"|User-Agent=T%C3%A9l%C3%A9fr%20(Windows%20NT%206.1%3BWOW64%3BWin64%3Bx64%3B%20http%3A%2F%2Fwww.gwenael.org)"
