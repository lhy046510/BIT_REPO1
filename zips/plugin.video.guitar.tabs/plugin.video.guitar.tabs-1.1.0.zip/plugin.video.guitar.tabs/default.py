﻿#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# Copyright 2013 TvM 
#

#######################################################################
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, urllib, urllib2, re, json

#######################################################################

### get addon info
__addon__       = xbmcaddon.Addon(id='plugin.video.guitar')
__addonid__     = __addon__.getAddonInfo('id')
__addonpath__   = __addon__.getAddonInfo('path')
__addonprofile__= xbmc.translatePath(__addon__.getAddonInfo('profile')).decode('utf-8')
__icon__        = __addon__.getAddonInfo('icon')
__localize__    = __addon__.getLocalizedString


__url_guitar_tabs__ = 'http://www.tabcrawler.com/artist//'
__url_tabs__ =  'http://www.tabcrawler.com/printable.php?'
__user_agent__ =  'Mozilla/5.0 (Windows NT 6.1; rv:19.0) Gecko/20100101 Firefox/19.0'
__url_txt2png__ = 'http://tvmpt.x10.mx/code/'

ACTION_PREVIOUS_MENU = 10
ACTION_NEXT_ITEM = 1
ACTION_PREV_ITEM = 2
ACTION_NAV_BACK = 92

def getImagesUrl(tabs):
  values = dict(txt=tabs)
  data = urllib.urlencode(values)
  req = urllib2.Request(__url_txt2png__ +'txt2png.php', data)
  req.add_header('User-Agent', __user_agent__)
  rsp = urllib2.urlopen(req)
  content = rsp.read()
  rsp.close()
  img_urls=re.compile('<img src="(.+?)"').findall(content)
  return img_urls

class WindowTabs(xbmcgui.Window):
  def __init__(self):
    xbmc.executebuiltin('Notification(Loading...,Please wait,3)')
    self.i = 0
    self.ControlImageList =  {}
 
  def Load(self, name, tabs):
    self.imagens = getImagesUrl(tabs)
    width = self.getWidth()
    center_pos = (width/2)-400
    self.strActionInfo = xbmcgui.ControlLabel(center_pos, 5, 800, 200,name +' : Page '+ str(self.i+1) + ' / '+str(len(self.imagens)), 'font12', '0xFFFFFFFF')
    self.addControl(self.strActionInfo)
    for idx, image in enumerate(self.imagens):
      self.ControlImageList[idx] = xbmcgui.ControlImage(center_pos, 30, 0, 0,filename=__url_txt2png__ + self.imagens[idx], aspectRatio=1)
    self.addControl(self.ControlImageList[0])
    xbmc.executebuiltin('Notification(Loading...,Please wait,2)')

  def onAction(self, action):
    if ( action in ( ACTION_PREVIOUS_MENU, ACTION_NAV_BACK ) ):
      self.close()
    if action == 2:
      if self.i < len(self.imagens)-1:
        self.removeControl(self.ControlImageList[self.i])
        self.i = self.i+1
        self.addControl(self.ControlImageList[self.i])
    if action == 1:
      if self.i > 0:
        self.removeControl(self.ControlImageList[self.i])
        self.i=self.i-1
        self.addControl(self.ControlImageList[self.i])  
    self.strActionInfo.setLabel(name +' : Page '+ str(self.i+1) + ' / '+str(len(self.imagens)))
    # dummy action to refresh window??
    xbmc.executebuiltin('Notification(Loading...,Please wait or press OK,3)')

 
def Menu(): 
  addDir('Artist - Guitar Tabs','menu',1,'')
  addDir('Artist - Guitar Chords','menu',2,'')
  addDir('Artist - Bass Tabs','menu',3,'')
  addDir('Free Search (Artist or/and Song)','menu',4,'')

def SearchWindow():
  encode = ''
  keyb = xbmc.Keyboard('', 'Search')
  keyb.doModal()
  if (keyb.isConfirmed()):
    search = keyb.getText()
    encode=urllib.quote_plus(search)
  return encode

def GetArtistInfo(artist):
  artist_info = {}
  try:
    url = 'http://www.theaudiodb.com/api/v1/json/7490823590829082gdkljas/search.php?s=' + urllib.quote(artist)
    req = urllib2.urlopen(url)
    data = json.load(req)
    if data['artists'] is None:
      artist_info = {'logo': '', 'fanart': ''}
    else:  
      artist_info = {'logo': data['artists'][0]['strArtistLogo'], 'fanart': data['artists'][0]['strArtistFanart'] }
    req.close()
  except:
    artist_info = {'logo': '', 'fanart': ''}  
    pass
  return artist_info
   
def GuitarTabs(search):
  page_num = 1
  while page_num < 100:
    url = __url_guitar_tabs__ + search + '/filter/1/page/' + str(page_num)
    page_num = page_num + 1
    req = urllib2.Request(url)
    req.add_header('User-Agent', __user_agent__)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    match=re.compile('<a class="boxlistlink1" href="search.php\?show=viewfile&letter=&artist=(.+?)&filter=1&tabname=(.+?)&tabtype=guitar tab&id=(.+?)">').findall(link)
    artist_info = {}
    if not match:
      break
    artist_info[match[0][0]] = GetArtistInfo(match[0][0])
    for artist,title, song_id in match:
      artist_logo = artist_info[artist]['logo']
      artist_fanart = artist_info[artist]['fanart']
      addLink('[COLOR blue]'+ artist.title() +'[/COLOR][COLOR yellow] - [/COLOR][COLOR white]'+ title.title() +'[/COLOR]','tabs',song_id, artist_logo, artist_fanart,song_name=title)
    del match, link, req, response
  xbmcplugin.endOfDirectory(int(sys.argv[1]))
  
def GuitarChords(search):
  page_num = 1
  while page_num < 100:
    url = __url_guitar_tabs__ + search + '/filter/3/page/' + str(page_num)
    page_num = page_num + 1
    req = urllib2.Request(url)
    req.add_header('User-Agent', __user_agent__)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    match=re.compile('<a class="boxlistlink1" href="search.php\?show=viewfile&letter=&artist=(.+?)&filter=3&tabname=(.+?)&tabtype=chords&id=(.+?)">').findall(link)
    artist_info = {}
    if not match:
      break
    artist_info[match[0][0]] = GetArtistInfo(match[0][0])
    for artist,title, song_id in match:
      artist_logo = artist_info[artist]['logo']
      artist_fanart = artist_info[artist]['fanart']
      addLink('[COLOR blue]'+ artist.title() +'[/COLOR][COLOR yellow] - [/COLOR][COLOR white]'+ title.title() +'[/COLOR]','tabs',song_id, artist_logo, artist_fanart,song_name=title)
    del match, link, req, response
  xbmcplugin.endOfDirectory(int(sys.argv[1]))
  
def BassTabs(search):
  page_num = 1
  while page_num < 100:
    url = __url_guitar_tabs__ + search + '/filter/4/page/' + str(page_num)
    page_num = page_num + 1
    req = urllib2.Request(url)
    req.add_header('User-Agent', __user_agent__)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    match=re.compile('<a class="boxlistlink1" href="search.php\?show=viewfile&letter=&artist=(.+?)&filter=4&tabname=(.+?)&tabtype=bass tab&id=(.+?)">').findall(link)
    artist_info = {}
    if not match:
      break
    artist_info[match[0][0]] = GetArtistInfo(match[0][0])
    for artist,title, song_id in match:
      artist_logo = artist_info[artist]['logo']
      artist_fanart = artist_info[artist]['fanart']
      addLink('[COLOR blue]'+ artist.title() +'[/COLOR][COLOR yellow] - [/COLOR][COLOR white]'+ title.title() +'[/COLOR]','tabs',song_id, artist_logo, artist_fanart,song_name=title)
    del match, link, req, response
  xbmcplugin.endOfDirectory(int(sys.argv[1]))
  
def FreeSearch(search):
  page_num = 1
  while page_num <= 2:
    url = 'http://www.tabcrawler.com/search/' + search +'/' + str(page_num)
    page_num = page_num + 1
    req = urllib2.Request(url)
    req.add_header('User-Agent', __user_agent__)
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    match=re.compile('<a class="boxlistlink1" href="search.php\?show=viewfile&id=(.+?)&letter=(.+?)&artist=(.+?)&tabname=(.+?)&tabtype=(.+?)">').findall(link)
    artist_info = {}
    if not match:
      break
    for song_id, letter, artist,title, type in match:   
      artist = artist.replace('+', ' ')
      title = title.replace('+', ' ')
      type = type.replace('+', ' ')
      if type not in ['chords','guitar tab']:
        continue
      if artist not in artist_info:     
        artist_info[artist] = GetArtistInfo(artist)
      artist_logo = artist_info[artist]['logo']
      artist_fanart = artist_info[artist]['fanart']
      addLink('[COLOR blue]'+ artist.title() +'[/COLOR][COLOR yellow] - [/COLOR][COLOR white]'+ urllib.unquote(title.title()) +'  ('+  type +') [/COLOR]','tabs',song_id, artist_logo, artist_fanart,song_name=title)
    del match, link, req, response
  xbmcplugin.endOfDirectory(int(sys.argv[1]))  
  
  

def GetTabs(song_name,song_id):
  url = __url_tabs__ + 'tabname=' + urllib.quote(song_name) + '&id='+ song_id
  req = urllib2.Request(url)
  req.add_header('User-Agent', __user_agent__)
  response = urllib2.urlopen(req)
  link=response.read()
  response.close()
  hey=re.compile('<pre>([\S\s]*)</pre>').findall(link)
  result = hey[0].decode("string-escape")
  return result.replace('\r\n', '\n')
  
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
							
	return param
      
def addDir(name,url,mode,iconimage,count=0,input=''):
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+name+"&count="+str(count)+"&input="+input
  ok=True
  liz=xbmcgui.ListItem(name, name,iconImage="DefaultFolder.png", thumbnailImage=iconimage)
  liz.setInfo( type="video", infoLabels={"Title": name} )
  return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True,totalItems=0)
  
def addLink(name,url,mode,iconimage,fanart='',count=0,input='',song_name=''):
  u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+name+"&count="+str(count)+"&input="+input+"&song_name="+song_name
  ok=True
  liz=xbmcgui.ListItem(name, name,iconImage="DefaultFolder.png", thumbnailImage=iconimage)
  liz.setInfo( type="video", infoLabels={"Title": name} )
  liz.setProperty('fanart_image', fanart)
  return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False,totalItems=0)
    
params=get_params()
url=None
mode=None
name=None
song_name=None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
try: song_name=urllib.unquote_plus(params["song_name"])
except: pass

if mode==None:
	Menu()
elif mode==1 and url =='menu':
	search = SearchWindow()
	GuitarTabs(search)
elif mode==2 and url =='menu':
	search = SearchWindow()
	GuitarChords(search)
elif mode==3 and url =='menu':
	search = SearchWindow()
	BassTabs(search)
elif mode==4 and url =='menu':
	search = SearchWindow()
	FreeSearch(search)    
elif url == 'tabs':
  tabs = GetTabs(song_name,str(mode))
  mydisplay = WindowTabs()
  mydisplay.Load(name, tabs)
  xbmc.sleep(1000)
  mydisplay.doModal()
  del mydisplay
	
xbmcplugin.endOfDirectory(int(sys.argv[1]))
