AmbiBox-XBMC
============

This is an XBMC script for use with Ambibox on windows. Ambibox is a separate windows program that drives many types of LED's setup for ambient lighting. The script provides profile switching based upon content as well as a capture mode directly from the XBMC video buffer. There are complete instructions at http://wiki.xbmc.org/index.php?title=Add-on:AmbiBox
