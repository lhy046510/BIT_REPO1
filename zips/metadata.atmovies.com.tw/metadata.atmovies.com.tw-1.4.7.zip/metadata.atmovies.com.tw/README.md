metadata.atmovies.com.tw
========================

[XBMC]開眼電影網(AtMovies)正體中文刮削器(scraper) 

給 XBMC 使用的正體中文電影資料 scraper

接觸 XBMC 也有一段時間了,很感謝之前一些大大的貢獻, 讓我們得以在XBMC裡 看到正體中文的電影資料, 如 mingjen 兄 的 https://code.google.com/p/traditional-chinese-xbmc-scrapers/

但隨著XBMC的版本不斷演進, 這些 scraper 已經幾乎都無法順利使用了, 也被 XBMC 標示損壞而從官方釋出版本中移出. 後來就只能使用簡體中文的 scraper 暫時撐著, 但兩者畢竟有很大的差異.

於是自已利用閒暇時間, 參考網路上找到的資料, 重新寫了新的 AtMovies 的 scraper, 目前這一版本看起來已經有不錯的效果, 希望大家試試看, 若有任何問題或建議, 請再提出.

理論上, 這些 scraper 應該要從之前的專案繼續延續下去才對, 但個人對 那機制不熟, 也不知道要如何把結果放回 XBMC 官方版本中, 因此想 說還是先把東西作出來, 等成果出來後, 到時再來瞭解這個機制. 若有人 知道這程序的話, 可以幫忙的話, 十分歡迎, 後續我想把 yahoo.movies 及 kingnet 電影, 都放進來, 先這樣囉!

若對這有任何問題或建議, 請至底下的blog, 那裡有較多的說明也比較方便 回覆, 謝謝! http://1somethings.blogspot.tw/search/label/XBMC

為了將 scraper 送進官方庫裡,以方便讓更多人可以直接點選安裝,不用再另外下載, 
所以從 AtMovies_v1.4.4 , Yahoo_v1.0.3 開始, 拆成2個專案, 以符合要求, 

若要查看之前的的原始碼, 請到原來的專案 
https://github.com/angp/xbmc-traditional-chinese-scraper

Yahoo!奇摩電影 scraper: https://github.com/angp/metadata.tw.movie.yahoo.com

直接下載:

AtMovies: https://github.com/angp/metadata.atmovies.com.tw/releases/download/atmovies_v1.4.7/metadata.atmovies.com.tw_v.1.4.7.zip

Yahoo!Movie : https://github.com/angp/metadata.tw.movie.yahoo.com/archive/yahoo_v1.0.3.zip
