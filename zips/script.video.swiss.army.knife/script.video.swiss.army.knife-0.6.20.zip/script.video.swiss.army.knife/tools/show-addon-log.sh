###########################################################
# scriptname : show-addon-log.sh                          #
###########################################################
# This script is part of the addon swiss-army-knife for   #
# xbmc and is licenced under the gpl-licence              #
# http://code.google.com/p/swiss-army-knife/              #
###########################################################
# author     : linuxluemmel.ch@gmail.com                  #
# parameters : none                                       #
###########################################################


cd $HOME/.xbmc/temp

grep swiss-army-knife xbmc.log

