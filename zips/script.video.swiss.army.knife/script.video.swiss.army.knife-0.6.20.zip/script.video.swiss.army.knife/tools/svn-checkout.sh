###########################################################
# scriptname : svn-checkout.sh                            #
###########################################################
# This script is part of the addon swiss-army-knife for   #
# xbmc and is licenced under the gpl-licence              #
# http://code.google.com/p/swiss-army-knife/              #
###########################################################
# author     : linuxluemmel.ch@gmail.com                  #
# parameters : none                                       #
###########################################################

cd ../..
svn checkout http://swiss-army-knife.googlecode.com/svn/trunk/script.video.swiss.army.knife/ swiss-army-knife
