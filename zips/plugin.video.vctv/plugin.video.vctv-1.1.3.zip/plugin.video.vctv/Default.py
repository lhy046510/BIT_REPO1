import urllib2
from urllib2 import urlopen
import urllib
import cookielib
import re
import sys
import os
import time
from BeautifulSoup import BeautifulSoup
import xbmcplugin,xbmcgui,xbmc,xbmcaddon
#TODO:    mark as watched(possible?), set color for newly added episodes, watch trailer for movies, download option, analytics(?), browse multiple pages
#TOFIX:   prev/next episode names

''' username password '''
api_url = 'http://cwal.me/xbmc/vc/?l='
vc_url = 'http://videocluster.org'
__settings__ = xbmcaddon.Addon(id="plugin.video.vctv")
username = __settings__.getSetting("username")
password = __settings__.getSetting("password")
if username == "" or password == "": # not set yet
	if xbmcgui.Dialog().yesno('Error', 'No username/password', 'Set now?'): # prompt if user wants to set it
		__settings__.openSettings()
	else: # if user chose no then end the script
		sys.exit()

f = urllib2.urlopen('http://cwal.me/xbmc/vc/index.php') # get main page for imgur urls
soup = BeautifulSoup(f.read())
imgururls = {} # create dictionary
for imgurs in soup.findAll('a', 'imgur'):
	imgururls[imgurs.get('data-section')] = imgurs.get('href')
		
def LOGIN(url):
		''' log in to vc '''		
		LOGIN_URL = 'http://videocluster.org/Login/'
		url = url.replace(api_url,vc_url)

		# for handling cookies to and from all requests we make in this script
		# because the site uses cookies for authentication data.
		cj = cookielib.LWPCookieJar()
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

		# sign in by sending the correct credentials to the login form
		credentials = {'LoginForm[username]': username,
					'LoginForm[password]': password,
					'LoginForm[rememberMe]': '0',
					'yt0': 'Login'
					}
		
		headers = {
			'User-agent': 'curl/7.30.0'
		}
		
		req = urllib2.Request(LOGIN_URL, urllib.urlencode(credentials), headers=headers)
		raw_html = opener.open(req).read()
		try:
			req = urllib2.Request(url, headers=headers)
			return opener.open(req)
		except:
			return xbmcgui.Dialog().ok('Error', 'There was a connection error.', 'Please verify VC is online', 'and your user/pass is correct')
		
def ACCOUNT(url):
		if url == '0': # from CATEGORIES()
			addDir('Speedtest','1',3,imgururls['speedtest'])
			addDir('Premium user status','2',3,imgururls['premium'])
			addDir('Change user/pass','3',3,imgururls['userpass'])
			addDir('Back To Main Menu','','',imgururls['mainmenu'])
		if url == '1':
			SPEED('http://speedtest.wdc01.softlayer.com/downloads/test10.zip')
			ACCOUNT('0')
		if url == '2':
			f = LOGIN(vc_url+'/Settings/')
			soup = BeautifulSoup(f.read())
			date = soup.find('td', href=False, text='Date User Joined this Site').findNext('td').contents[0]
			prem = soup.find('td', href=False, text='Premium User Status').findNext('td').contents[0].strip()
			email = soup.find('td', href=False, text='Email in Use').findNext('td').find('span').contents[0]
			credit = soup.find('td', href=False, text='Your Available credits ').findNext('td').contents[0]
			xbmcgui.Dialog().ok('Account information', 'Date joined: '+date, 'Premium status: '+prem+' (Credit: '+credit+')', 'Email: '+email)
			ACCOUNT('0')
		if url == '3':
			__settings__.openSettings()
			ACCOUNT('0')

def SPEED(url):
		if xbmcgui.Dialog().yesno('Speedtest', 'This may take several minutes,', 'depending on your internet connection.', 'Continue?'): # prompt if user wants to continue
			f = urllib2.urlopen(url)
			start = time.time()
			data = f.read()
			total = time.time() - start
			speed = "%.2f Mbps" % ((len(data) / 131072) / total)
			f.close()
			return xbmcgui.Dialog().ok('Speedtest', 'This machines download speed', 'is approx [COLOR gold]'+speed+'[/COLOR]')
		else:
			ACCOUNT('0')
		
def CATEGORIES():
		addDir('Lineup',api_url+'/Home',1,imgururls['lineup'])
		addDir('Bookmarks',api_url+'/video/bookmarklist',1,imgururls['bookmarks'],4)
		addDir('TV Shows',api_url+'/video/tvshows',1,imgururls['tvshows'])
		addDir('Movies',api_url+'/video/movies',1,imgururls['movies'],2)
		addDir('Cartoons',api_url+'/video/cartoons',1,imgururls['cartoons'])
		addDir('Anime',api_url+'/video/anime',1,imgururls['anime'])
		addDir('Documentaries',api_url+'/video/docs',1,imgururls['docs'])
		addDir('Account','0',3,imgururls['account'])

def INDEX(url,name,rpt):
		oldUrl = url
		if rpt == 1: # if rpt = 1 then its the second time in for episodes
			f = urllib2.urlopen(url) # get show page
			soup = BeautifulSoup(f.read())
			seasons = []
			episodes = []
			for link in soup.findAll('a', 'episode'): # find all episodes
				name = link['title'].encode('utf-8')
				url = api_url + link['href']
				pieces = url.split('/') # isolate season from list
				season = ('Season ' + pieces[11]).encode('utf-8')
				if pieces[11]: seasons.append(season) # make human readable seasons and add to array
				episodes.append((season + ' ' + name,url)) # make array of ALL episodes
			seasons = list(set(seasons)) # reduce to unique seasons only
			seasons = natural_sort(seasons) # sort into natural order (ex: 1-10)
			if len(seasons) == 1: # if only 1 season don't ask user which season they want (duh!)
				ret = -1 # make ret -1 so it displays all available episodes
			else: # otherwise show the popup with seasons listed
				ret = xbmcgui.Dialog().select('Filter by season', seasons) # store the selected season
			for episode in episodes:
				if ret < 0: # ret is -1 if its the only season or if user opted out of the filter by seasons popup
					addDir(episode[0],episode[1],2,imgururls['episode']) # episode[0] is name episode[1] is url
				else:
					if episode[0].startswith(seasons[ret].encode('utf-8') + ' '): # only display episodes from selected season
						addDir(episode[0],episode[1],2,imgururls['episode'])
		if rpt == 3:
			alpha = [('#','4WaDP'),('A','UpQin'),('B','Qi6L8'),('C','Qhj5s'),('D','nCUgJ'),('E','toyb9'),('F','Q1iuB'),('G','w3SnK'),('H','8iy8P'),('I','9GEDv'),('J','ivehN'),('K','Tldt4'),('L','c2KBO'),('M','R0DjC'),('N','NmgA8'),('O','DV1Cg'),('P','cxmcd'),('Q','KGdF7'),('R','V0CzF'),('S','N6pAU'),('T','DU1Zz'),('U','4eZCV'),('V','ZKaXW'),('W','h6O3p'),('X','yXDUZ'),('Y','7sJIS'),('Z','MbAwT')]
			for a in alpha: # a becomes an array with a[0] = letter and a[1] = imgur url
				if a[0] == '#':
					aurl = '0'
				else:
					aurl = a[0]
				if url == api_url+'/video/movies':
					rptint = 2 # mark as a movie for future processing
				else:
					rptint = ''
				addDir(a[0],url+'/alpha/'+aurl+'/ajax/ajaxListView/Show_page/1?ajax=ajaxListView',1,'http://i.imgur.com/'+a[1]+'.png',rptint)
		else:
			browse = url.split('/')
			if len(browse) == 8 and 'alpha' not in url and not name.startswith('Browse all ') and not name == 'Bookmarks':
				addDir('Browse all '+name+' by alphabet',url,1,imgururls['alphabrowse'],3)
			if rpt == 4: # get the persons bookmarks and not the API bookmarks (which are my personal ones)
				f = LOGIN(url)
				soup = BeautifulSoup(f.read())
			else:
				f = urllib2.urlopen(url) # get homepage
				soup = BeautifulSoup(f.read())
			for link in soup.findAll('a', 'banner'): # find all links with class banner
				name = link.get('title').encode('utf-8') # get the name from the title of the link and encode it
				url = api_url + link.get('href') # grab the location of the link
				if rpt == 2 or url.startswith(api_url+'/video/viewmovie') or url.startswith(vc_url+'/video/viewmovie'): # movie banners arent hosted on vc.org
					pre = ''
				else:
					pre = vc_url
				try: # some shows/movies are missing images
					image = pre + link.contents[0].get('src')
				except:
					image = vc_url + '/images/no-image.jpg'
				if not rpt: # no rpt so its for shows
					addDir(name,url,1,image, 1, 'bookmark') # send it back into INDEX with a marker so it scrapes with second method for eps
				elif rpt == 2: # rpt = 2 so its a movie
					addDir(name,url,2,image, 2, 'bookmark') # send directly to VIDEOLINKS since its a movie
				elif rpt == 4: # its bookmarks
					if url.startswith(api_url+'/video/movies'): # its a movie so dont try to find episodes
						addDir(name,url,2,image, 'bookmark')
					else:
						addDir(name,url,1,image, 1, 'bookmark') # its something else, find episode list
			if 'alpha' in oldUrl: # add a next page button if browsing alpha
				pages = soup.find('a', 'pages').get('href') # gets the max number of pages
				oldPage = browse[13].replace('?ajax=ajaxListView', '') # isolate page number
				if oldPage < pages: # show the next page link if the page your viewing is smaller then the max number of pages
					newPage = str(int(oldPage)+1) # convert to int, add 1, back to string
					newUrl = oldUrl.replace(oldPage+'?ajax=ajaxListView', newPage+'?ajax=ajaxListView') # replace it in the url
					addDir('Next >>',newUrl,1,imgururls['next'],rpt)

def VIDEOLINKS(url,name):
		f = LOGIN(url)
		fread = f.read() # f.read() can only be used once so save it to a variable
		soup = BeautifulSoup(fread)
		link = re.findall("file: '.*?'", fread)[0]
		url = link.replace("file: ", "").replace("'", "")
		for epTitle in soup.findAll('span', 'episode_video_title'):
			name = epTitle.contents[0]
		addLink('Play - ' + name,url,imgururls['play'])
		# prev/next links
		for prev in soup.findAll('a', attrs={'title': 'Prev'}):
			prev_ep = prev.get('onclick')
			link = re.findall("'url':'.*?'", prev_ep)[0]
			url = link.replace("'", "").replace("url:", "")
			addDir('Prev - ',vc_url+url,2,imgururls['prev'])
		for next in soup.findAll('a', attrs={'title': 'Next'}):
			next_ep = next.get('onclick')
			link = re.findall("'url':'.*?'", next_ep)[0]
			url = link.replace("'", "").replace("url:", "")
			addDir('Next - ',vc_url+url,2,imgururls['next'])
		addDir('Back To Main Menu','','',imgururls['mainmenu'])

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage,rpt=0, context=''):
		u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&rpt="+str(rpt)
		ok=True
		liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
		liz.setInfo( type="Video", infoLabels={ "Title": name } )
		if context == 'bookmark': # add the context menu option to bookmark if its a folder for a show or movie (not on sections, episodes, play etc...)
			commands = []
			argsToPass = url
			scriptToRun = "special://home/addons/plugin.video.vctv/resources/lib/bookmark.py"
			runner = "XBMC.RunScript(" + scriptToRun + ", " + argsToPass + ")"
			name = "Bookmark/Unboomark"
			commands.append(( name, runner, ))
			liz.addContextMenuItems( commands )
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
		return ok
		
def natural_sort(l): 
 	   convert = lambda text: int(text) if text.isdigit() else text.lower() 
 	   alphanum_key = lambda key: [ convert(c) for c in re.split('([0-9]+)', key) ] 
	   return sorted(l, key = alphanum_key)

params=get_params()
url=None
name=None
mode=None
rpt=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        rpt=int(params["rpt"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "Rpt: "+str(rpt)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()

elif mode==1:
        print ""+url
        INDEX(url,name,rpt)

elif mode==2:
        print ""+url
        VIDEOLINKS(url,name)

elif mode==3:
        print "Account"
        ACCOUNT(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))