import urllib2
from urllib2 import urlopen
import urllib
import cookielib
import re
import sys
import os
import time
from BeautifulSoup import BeautifulSoup
import xbmcplugin,xbmcgui,xbmc,xbmcaddon

api_url = 'http://cwal.me/xbmc/vc/?l='
vc_url = 'http://videocluster.org'
__settings__ = xbmcaddon.Addon(id="plugin.video.vctv")
username = __settings__.getSetting("username")
password = __settings__.getSetting("password")

def LOGIN(url):
		''' log in to vc '''		
		LOGIN_URL = 'http://videocluster.org/Login/'
		url = url.replace(api_url,vc_url)

		# for handling cookies to and from all requests we make in this script
		# because the site uses cookies for authentication data.
		cj = cookielib.LWPCookieJar()
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

		# sign in by sending the correct credentials to the login form
		credentials = {'LoginForm[username]': username,
					'LoginForm[password]': password,
					'LoginForm[rememberMe]': '0',
					'yt0': 'Login'
					}
		
		headers = {
			'User-agent': 'curl/7.30.0'
		}
		
		req = urllib2.Request(LOGIN_URL, urllib.urlencode(credentials), headers=headers)
		raw_html = opener.open(req).read()
		try:
			req = urllib2.Request(url, headers=headers)
			return opener.open(req)
		except:
			return xbmcgui.Dialog().ok('Error', 'There was a connection error.', 'Please verify VC is online', 'and your user/pass is correct')
			
url = sys.argv[1] # this gets the url that was sent from Default.py
f = LOGIN(url) # get the page from USERS pov since bookmark links have user ID in them
fread = f.read()
bookmarkURL = re.findall("jQuery.ajax\(\{&#039;url&#039;:&#039;.*?&#039;,&#039;type", fread)[0][:-17][35:] # cut beginning and end of string to isolate url
LOGIN(vc_url + bookmarkURL) # visit the bookmark URL to toggle it
xbmc.executebuiltin('Notification(Success!,Bookmark/Unbookmark toggled,5000,)') # give success message