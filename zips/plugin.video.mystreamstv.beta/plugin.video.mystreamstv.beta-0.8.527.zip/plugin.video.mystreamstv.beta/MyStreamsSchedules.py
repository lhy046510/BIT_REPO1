'''
    Smoothstreams plugin for XBMC
    Copyright (C) 2012-2013 Smoothstreams

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
import os
import re
import sys
import json
import urllib
import time
import operator

class MyStreamsSchedules:
    def __init__(self):
        self.settings = sys.modules["__main__"].settings
        self.language = sys.modules["__main__"].language
        self.cache = sys.modules["__main__"].cache
        self.common = sys.modules["__main__"].common
        self.xbmc = sys.modules["__main__"].xbmc
        self.xbmcplugin = sys.modules["__main__"].xbmcplugin
        self.xbmcgui = sys.modules["__main__"].xbmcgui
        self.xbmcvfs = sys.modules["__main__"].xbmcvfs
        self.xmltv_url = "http://cdn.smoothstreams.tv/schedule/feed.json"
        self.use_cache=True

        self.categories = self.settings.getSetting("categories")
        if self.categories == "":
            self.categories = []
        else:
            try:
                self.categories = json.loads(self.categories)
            except:
                self.categories = []

        return None

    def jsonToDict(self, xml):
        self.common.log(str(len(xml)), 5)
        temp = []
        keys = {}
        channel_names = {}
        try:
            result = json.loads(xml)
        except Exception as e:
            self.common.log("Exception: " + repr(e))
            self.common.log("Exception data: " + repr(xml))
            return temp, keys
            
        if len(result) > 0:
            self.categories = []

        for i in result:
            self.common.log("item1: " + repr(result[i]), 3)
            did = result[i]["channel_id"]
            dname = result[i]["name"].replace("&amp;", "&")
            if len(did) == 1:
                did = "0" + did
            channel_names[did] = dname
            
            if "items" not in result[i]:
                self.common.log("No items in: " + repr(result[i]))
                continue

            for j, item in enumerate(result[i]["items"]):
                self.common.log("item2: " + repr(item), 3)
                if "quality" in item:
                    quality = item["quality"].replace("&amp;", "&")
                else:
                    quality = ""
                
                if len(quality) == 0:
                    quality = "sd"

                titem = { "local_start": self.convertTimeZone(item["time"]), "local_end": self.convertTimeZone(item["end_time"]), "location": item["channel"], "summary": item["name"].replace("&amp;", "&"), "quality": quality}

                if len(item["description"]) > 0:
                    titem["desc"] = item["description"].replace("&amp;", "&")

                if len(item["category"]) > 0:
                    item["category"] = item["category"].replace("&amp;", "&")
                    titem["category"] = item["category"]
                    if not item["category"] in self.categories:
                        self.categories.append(item["category"])

                temp.append(titem)
                if titem["local_start"] != 0.0:
                    keys[len(keys)] = titem["local_start"]

        self.common.log("SETTING channel_names: " + repr(channel_names))
        self.settings.setSetting("channel_names", json.dumps(channel_names))

        keys = sorted(keys.iteritems(), key=operator.itemgetter(1), reverse=False) # Lets bring these along with us for speed
            
        self.common.log("SETTING categories: " + repr(self.categories))
        self.settings.setSetting("categories", json.dumps(self.categories))
        self.common.log("Done: " + repr(keys), 0)
        return temp, keys

    def fetchSchedule(self):
        self.common.log("")

        result = self.common.fetchPage({"link": self.xmltv_url})

        result, keys = self.jsonToDict(result["content"])

        self.common.log("Done")
        return result, keys

    def getNow(self, round_by=100): # Default round to 1 minute
        now = time.time()
        if time.daylight != 0 and False:
            now -= time.altzone - time.timezone
        now = float(( int(now) / round_by) * round_by)
        return now - (3600 * 24 * 0)

    def isDST(self):
        self.common.log("DST set. adding +1h to timezone: " + repr(time.localtime()))
        return time.localtime()[8]

    def local_time_offset(self):
        """Return offset of local zone from GMT, either at present or at time t."""

        if time.localtime().tm_isdst and time.daylight:
            self.common.log("DST set. altzone: " + repr(time.altzone))
            return -time.altzone
        else:
            self.common.log("DST set. timezone: " + repr(time.timezone))
            return -time.timezone

    def autoTimeZone(self, value):
        self.common.log(value, 50)

        value -= time.timezone
        if False and self.isDST(): # Disabled
            self.common.log("DST set. adding +1h to timezone")
            value -= 3600
        #t= self.local_time_offset()
        #self.common.log("DST set. adding +1h to timezone: " + repr(t) + " - " + repr(time.timezone))
        #value += 1

        self.common.log("Done: " + repr(value), 50)
        return value

    def settingsTimeZone(self, value):
        self.common.log(value, 50)
        gmt_offset = int(self.settings.getSetting("gmt_offset"))
        if gmt_offset == 0:
            return 0

        gmt_offset_half = self.settings.getSetting("gmt_offset_half") == "true"
        daylight_saving_time = self.settings.getSetting("daylight_saving_time") == "true"

        if gmt_offset == 1:
            self.common.log("Timezone gmt0", 50)
        elif gmt_offset < 14:
            self.common.log("Timezone gmt+", 50)
            value += 3600 * (gmt_offset - 1)
        elif gmt_offset > 13:
            self.common.log("Timezone gmt-", 50)
            value -= 3600 * (gmt_offset - 1)

        if daylight_saving_time:
            self.common.log("Daylight saving time", 50)
            value += 3600

        if gmt_offset_half:
            self.common.log("gmt + 30 min", 50)
            value += 1800
        return value

    def convertXMLTVTime(self, org_value):
        self.common.log(str(org_value), 5)

        if org_value.find("-", 10) > -1:
            org_value = org_value.split(" ")

            value = time.strptime(org_value[0], "%Y%m%d%H%M%S")
            diff = int(org_value[1])
        else:
            value = time.strptime(org_value, "%Y-%m-%d %H:%M:%S")
            diff = int("-0500")

        value = time.mktime(value)

        if diff > 0:
            self.common.log("do stuff diff > 0")
            if False: # Not tested.. at all
                tdiff = diff % 100
                diff = (diff / 100) * 3600
                if tdiff > 0:
                    diff -= tdiff * 60
                value -= diff
        else:
            self.common.log("doing diff < 0", 5)
            diff = 0 - diff
            tdiff = diff % 100
            diff = (diff / 100) * 3600
            if tdiff > 0:
                diff += tdiff * 60
            value += diff

        self.common.log("Done: " + str(value), 5)
        return value

    def convertTimeZone(self, value):
        self.common.log(repr(value), 5)
        gmt_offset = int(self.settings.getSetting("gmt_offset"))
        value = self.convertXMLTVTime(value)
        if value != 0.0:
            if gmt_offset == 0:
                value = self.autoTimeZone(value)
            else:
                value = self.settingsTimeZone(value)
        self.common.log("Done: " + repr(value), 5)
        return value

    def getChan(self, chan):
        self.common.log(chan, 5)
        chan = chan.strip()
        org_chan = chan

        items = []
        # First see if only chan number is given
        try:
            items.append({"chan": str(int(chan)), "quality": "", "language": "", "other": ""})
            chan = ""
        except:
            pass

        # Then see if multiple real format channels are given.
        while chan.find("-") == 2 and len(chan) > 0:  # Check if there is a - in the second positon, this matches new new layout.
            if chan.find(";") > -1:
                temp_chan = chan[:chan.find(";")]
                temp_chan = temp_chan.strip()
                chan = chan[chan.find(";") + 1:]
                chan = chan.strip()
            else:
                temp_chan = chan
                chan = ""

            key = ""
            qual = ""
            lang = ""

            if temp_chan.find("-") > 0:
                key = temp_chan[:temp_chan.find("-")]
                temp_chan = temp_chan[temp_chan.find("-") + 1:]

            if temp_chan.find("-") > 0:
                qual = temp_chan[:temp_chan.find("-")]
                temp_chan = temp_chan[temp_chan.find("-") + 1:]

            if len(temp_chan) > 0:
                lang = temp_chan

            items.append({"chan": key, "quality": qual, "language": lang})

        # Finally we try the old version
        if len(items) == 0:
            chan = org_chan.replace("Where", "Chan")
            while chan.find(";") > -1 or chan.find("Chan") > -1:
                if chan.find(";") > -1:
                    temp_chan = chan[:chan.find(";")]
                    temp_chan = temp_chan.strip()
                    chan = chan[chan.find(";") + 1:]
                    chan = chan.strip()
                else:
                    temp_chan = chan
                    chan = ""

                res = self.getChan_old(temp_chan)
                items.append(res)

        for chan in items:
            chan["chan"] = str(chan["chan"])
            try:
                if int(chan["chan"]) < 10:
                    chan["chan"] = "0" + str(int(chan["chan"]))
            except:
                pass

        self.common.log("Done: " + repr(items), 5)
        return items

    def getChan_old(self, chan):
        chan = chan.replace("\\", "")
        self.common.log(chan, 5)

        if chan.find("-") > -1:
            chan = chan[0:chan.find("-")]

        qual = ""
        lang = ""
        other = ""
        nchan = ""

        while chan.find(" ") > -1 or len(chan) > 0:
            if chan.find(" ") > -1:
                temp = chan[:chan.find(" ")]
                temp = temp.strip()
                chan = chan[chan.find(" ") + 1:]
                chan = chan.strip()
            else:
                temp = chan
                chan = ""

            try:
                nchan = str(int(temp))
            except:
                low = temp.lower()
                if low.find("hd") > -1:
                    qual = temp
                elif low.find("lq") > -1:
                    qual = temp
                elif low.find("spa") > -1:
                    lang = temp
                elif low.find("eng") > -1 or low.find("uk") > -1:
                    lang = temp
                elif low.find("ger") > -1 or low.find("de") > -1:
                    lang = temp
                else:
                    other = temp

        if len(nchan) == 1:
            nchan = "0" + nchan

        res = {"chan": nchan, "quality": qual, "language": lang, "other": other}
        self.common.log("Done: " + repr(res), 5)
        return res

    def sortSchedule_inner(self, now, item, minus_limit, plus_limit, get_names=False):
        ret = False
        rett = False
        start = item["local_start"]
        end = item["local_end"]
        self.common.log("Item start: " + repr(start) + " > " + repr(now - minus_limit) + " and " + repr(now + plus_limit) + " || " + repr(end), 3)
        if start == 0.0:
            self.common.log("Couldn't find any limiter for item : " + repr(item))
        elif (start > now - minus_limit and start < now + plus_limit) or (get_names and start < now and end > now):
            self.common.log("Found match within limits", 3)
            gmstart = time.localtime(start)
            gmnow = time.localtime(now)
            if gmstart.tm_yday == gmnow.tm_yday:
                rett = start
            else:
                ret = start
        else:
            self.common.log("Skipping item : " + repr(item), 3)
        return (ret, rett)

    # Refactor for rPI. This is called with 1771 items, which is too much for the rPI to handle.
    # Maybe it is playingnow that has to be refactored.
    def sortSchedule(self, now, items=[], minus_limit=0, plus_limit=0, get_names=False):
        self.common.log("now: " + repr(now) + " - items: " + repr(len(items)) + " - minus_limit: " + repr(minus_limit) + " - plus_limit: " + repr(plus_limit) + " - get_names: " + repr(get_names), 0)

        if plus_limit == 0 and minus_limit == 0:
            self.common.log("A +- limiter in seconds must be set")
            return []

        keys_today = {}
        keys = {}
        for i in range(0, len(items)):
            ret, rett = self.sortSchedule_inner(now, items[i], minus_limit, plus_limit, get_names)
            if ret:
                keys[i] = ret
            if rett:
                keys_today[i] = rett

        keys = sorted(keys_today.iteritems(), key=operator.itemgetter(1), reverse=False) + sorted(keys.iteritems(), key=operator.itemgetter(1), reverse=False)

        self.common.log("Done: " + repr(len(keys)))
        self.common.log(repr(keys), 3)
        return keys

    def playingToday(self):
        self.common.log("")
        if self.use_cache:
            items = self.cache.cacheFunction(self.getChannels)
        else:
            items = self.getChannels()
        now = self.getNow()
        keys = {}
        ret_items = []
        for i in range(0, len(items)):
            if "local_start" in items[i]:
                ret, rett = self.sortSchedule_inner(now, items[i], 3600 * 24, 3600 * 24, False)
                if ret or rett:
                    start = items[i]["local_start"]
                    if "local_end" in items[i]:
                        end = items[i]["local_end"]
                    else:
                        end = 0.0

                    gmstart = time.localtime(start)
                    gmend = time.localtime(end)
                    gmnow = time.localtime(now)

                    if start == 0.0 or gmstart.tm_yday == gmnow.tm_yday or (gmend.tm_yday == gmnow.tm_yday and (gmend.tm_hour > 0 or gmend.tm_min > 0)):
                        keys[len(ret_items)] = start
                        ret_items.append(items[i])

        keys = sorted(keys.iteritems(), key=operator.itemgetter(1), reverse=False)
        self.common.log("Done: " + repr(len(items)) + " - " + repr(len(keys)))
        return (ret_items, keys)

    def playingSchedule(self, ical, now):
        self.common.log(ical)

        if self.use_cache:
            titems, tkeys = self.cache.cacheFunction(self.fetchSchedule)
        else:
            titems, tkeys = self.fetchSchedule()

        if self.settings.getSetting("schedule_plus_limiter") != "":
            plus_limiter = 3600 * 24 * int(self.settings.getSetting("schedule_plus_limiter"))
        else:
            plus_limiter = 3600 * 24 * 7

        if self.settings.getSetting("schedule_minus_limiter") != "":
            minus_limiter = 3600 * 24 * int(self.settings.getSetting("schedule_minus_limiter"))
        else:
            minus_limiter = 3600 * 24 * 7

        items = []
        keys = {}
        keys_today = {}
        for i in range(0, len(titems)):
            if i != "keys" and "category" in titems[i] and titems[i]["category"] == ical:
                ret, rett = self.sortSchedule_inner(now, titems[i], minus_limiter, plus_limiter, False)
                if ret:
                    keys[len(keys)] = ret
                if rett:
                    keys_today[len(keys_today)] = rett
                if ret or rett:
                    items.append(titems[i])

        keys = sorted(keys_today.iteritems(), key=operator.itemgetter(1), reverse=False) + sorted(keys.iteritems(), key=operator.itemgetter(1), reverse=False)
        self.common.log("Done")
        return (items, keys)

    def getChannels(self):
        self.common.log("")

        if self.use_cache:
            titems, tkeys = self.cache.cacheFunction(self.fetchSchedule)
        else:
            titems, tkeys = self.fetchSchedule()
        items = []

        now = self.getNow()

        # rPI slowdown is THIS!!! Limit to +- 24 hours 
        # The return value of this needs to be much much smaller.
        # Also, sortschedule

        for k in tkeys:
            ret, rett = self.sortSchedule_inner(now, titems[k[0]], 3600 * 24, 3600 * 24, True)
            if ret or rett:
                items.append(titems[k[0]])
                
        self.common.log("items: " + str(len(items)))
        self.common.log("Done")
        return items

    def getChanInfo(self, now=False):
        self.common.log("")
        channel_name = {}
        playing_now = {}
        playing_next = {}
        if self.settings.getSetting("show_now_next") == "true":
            if self.use_cache:
                items = self.cache.cacheFunction(self.getChannels)
            else:
                items = self.getChannels()

            self.common.log("Getting channel names")
            try:
                channel_name = json.loads(self.settings.getSetting("channel_names"))
            except Exception as e:
                self.common.log("Exception: " + repr(e))

            playing_now = {}
            playing_next = {}
            self.common.log("Getting now and next")
            for item in items:
                ret, rett = self.sortSchedule_inner(now, item, 3600 * 24, 3600 * 24, False)
                if ret or rett and ("local_start" in item and "local_end" in item and "summary" in item):
                    start = item["local_start"]
                    if start != 0.0 and start > now:
                        location = self.getChan(item["location"])
                        hstart = time.strftime("%H:%M", time.localtime(start))
                        for iloc in location:
                            if iloc["chan"] not in playing_next:
                                playing_next[iloc["chan"]] = "[%s] %s" % (hstart, item["summary"])

                    if "local_end" in item:
                        end = item["local_end"]
                        if start != 0.0 and start < now and end > now:
                            hstart = time.strftime("%H:%M", time.localtime(start))
                            location = self.getChan(item["location"])
                            for iloc in location:
                                if iloc["chan"] not in playing_now:
                                    playing_now[iloc["chan"]] = "[%s] %s" % (hstart, item["summary"])
        self.common.log("Done: %s %s %s" % ( len(channel_name), len(playing_now), len(playing_next)))
        return channel_name, playing_now, playing_next

    def _getScheduleNameAndUrl(self, now, start, temp_chan, temp_item):
        chan = temp_chan["chan"]
        if temp_chan["language"] != "":
            chan += "-" + temp_chan["language"]

        if temp_chan["quality"] != "":
            chan += "-" + temp_chan["quality"]

        if temp_chan["language"] == "" and temp_chan["quality"] == "" and temp_chan["other"] != "" and False:
            chan += "-" + temp_chan["quality"]

        url = sys.argv[0] + "?path=/root/channels/&action=play_channel&chan=%s" % chan

        if start == 0.0:
            self.common.log("Start1: %s - Org: %s" % (start, now), 5)
            delta = "24/7"
            name = "[%s] %s (#%s)" % (delta, temp_item["summary"], chan)
        else:
            self.common.log("Start2: %s - Org: %s" % (start, now), 5)
            if time.localtime(now).tm_yday == time.localtime(start).tm_yday:
                delta = time.strftime("%H:%M", time.localtime(start))
                if "local_end" in temp_item:
                    delta += "-" + time.strftime("%H:%M", time.localtime(temp_item["local_end"]))
            else:
                delta = time.strftime("%d.%b %H:%M", time.localtime(start))
            name = "[%s] %s (#%s)" % (delta, temp_item["summary"], chan)

        return (name, url)

    def getSchedule(self, params={}):
        self.common.log(repr(params))
        if "schedule" in params:
            keys = []
            items = []
            ical = urllib.unquote(params["schedule"])
            now = self.getNow()

            if self.use_cache:
                if ical == "Airs Today":
                    (items, keys) = self.cache.cacheFunction(self.playingToday)
                else:
                    (items, keys) = self.cache.cacheFunction(self.playingSchedule, ical, now)
            else:
                if ical == "Airs Today":
                    (items, keys) = self.playingToday()
                else:
                    (items, keys) = self.playingSchedule(ical, now)

            inserted = []
            for (i, start) in keys:
                temp_item = items[i]

                channels = self.getChan(temp_item["location"])

                for temp_chan in channels:
                    (name, url) = self._getScheduleNameAndUrl(now, start, temp_chan, temp_item)
                    
                    if name not in inserted:
                        inserted.append(name)
                        listitem = self.xbmcgui.ListItem(name)
                        listitem.setProperty("Video", "true")
                        listitem.setProperty("IsPlayable", "true")
                        if "quality" in temp_item:
                            if temp_item["quality"] == "720p":
                                listitem.addStreamInfo("video", {"codec": "h264", "width": 1280, "height": 720})
                            elif temp_item["quality"] == "1080p" or temp_item["quality"] == "1080i":
                                listitem.addStreamInfo("video", {"codec": "h264", "width": 1920, "height": 1080})
                            else:
                                listitem.addStreamInfo("video", {"codec": "h264", "width": 854, "height": 480})

                        if "language" in temp_item:
                            listitem.addStreamInfo("audio", {"codec": "aac", "language": temp_item["language"]})
                        else:
                            listitem.addStreamInfo("audio", {"codec": "aac", "language": "en"})

                                
                        plot = temp_item["location"] + " | " + temp_item["summary"] + "\r\n"

                        if start > 0.0:
                            plot += time.strftime("%Y-%m-%d %H:%M", time.localtime(start))
                            if "local_end" in temp_item:
                                plot += " - " + time.strftime("%Y-%m-%d %H:%M", time.localtime(temp_item["local_end"]))
                            plot += "\r\n"

                        listitem.setInfo(type='Video', infoLabels={"Title": name, "plot": plot, "Date": time.strftime("%Y-%m-%d", time.localtime(start))})
                        cm = []
                        cm.append((self.language(30108), "XBMC.Action(Info)",))
                        listitem.addContextMenuItems(cm)

                        self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False, totalItems=len(keys))

            self.xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=self.xbmcplugin.SORT_METHOD_UNSORTED)
            self.xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=self.xbmcplugin.SORT_METHOD_LABEL)
            self.xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=self.xbmcplugin.SORT_METHOD_DATE)
            self.xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True, cacheToDisc=False)

    def makeListOfSchedules(self, params={}):
        self.common.log("")

        if self.use_cache:
            self.cache.cacheFunction(self.fetchSchedule)
        else:
            self.fetchSchedule()

        setting = self.settings.getSetting("show_30501")
        name = self.language(30501)
        
        if not setting or setting == "true":
            self.common.log("Name: %s" % (name), 5)
            url = sys.argv[0] + "?path=/root/schedule/%s&schedule=%s" % (urllib.quote(name), urllib.quote(name))
            listitem = self.xbmcgui.ListItem(name)
            listitem.setProperty("Folder", "true")

            self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=True, totalItems=len(self.categories) + 1)

        for key in self.categories:
            self.common.log("Key: %s" % (key), 5)
            setting = self.settings.getSetting("show_" + key)
            if not setting or setting == "true":
                url = sys.argv[0] + "?path=/root/schedule/%s&schedule=%s" % (urllib.quote(key), urllib.quote(key))
                listitem = self.xbmcgui.ListItem(self.common.replaceHTMLCodes(key))
                listitem.setProperty("Folder", "true")

                self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=True, totalItems=len(self.categories) + 1)

        self.xbmcplugin.addSortMethod(handle=int(sys.argv[1]), sortMethod=self.xbmcplugin.SORT_METHOD_LABEL)
        self.xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True, cacheToDisc=False)
