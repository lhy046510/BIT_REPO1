# -*- encoding: utf-8 -*- 
""" NovaTV plugin for accessing www.nova.cz videos from XBMC """

__all__ = ["novatvPlugin"]

from lib.basePlugin import *
import urlparse
from lib.parseutils import *
import re
import time
import datetime

class NovatvPlugin(BasePlugin):
    """ NovaTV plugin class """
    BASE_URL = "http://archiv.nova.cz"

    @plugin_folder
    def root(self):
        """ plugin root folder """
        self.core.setSorting('NONE')
        
        url = self.BASE_URL
        
        doc=read_page(url)
        items=doc.find('div', id='sub_letter')
        
        for item in items.findAll('a', 'list_item'):
            title_a = item.getText(" ").encode('utf-8')
            yield PFolder(label=title_a, call='NovaProgramDirectory', param={'path': item['href']})
              


    @plugin_folder
    def NovaProgramDirectory(self, path, index_page=1):
        """ list newest videos """
#        self.core.setSorting('NONE')

        url = self.BASE_URL + path
        self.wget.request(url)

        self.debug('URL: '+str(url))

        for item in self.wget.select('#searched_videos li'):

            try:
              self.debug('searched_videos li ok')
            
              title = item.h3.a 
              title_a = title.getText(" ").encode('utf-8')

              if title_a:
                   self.debug('video_title ok: ' + str(title_a))

              date_elem=item.find('div', 'info_body').find('span', 'date')

              self.debug('date_time ok ' + str(date_elem))

              date=date_elem.getText(" ")

              self.debug('date_time ok: ' + str(date))
              
              dej_a=item.find('div', 'info_body').find('p', 'perex')
              dej = dej_a.getText(" ").encode('utf-8')
              
              info = {
                      'title': str(title_a),
                      'plot': str(dej),
                      'date': str(date)
                  }
              # label 
              label = info['title']
        
              self.debug('label: ' + str(label))
              self.debug('iconURL: ' + str(item.a.img['src']))

              yield PItem(
                      label   = label,
                      call    = 'play',
                      param   = {'path': title['href']},
                      info    = info,
                      iconURL = item.a.img['src']
                  )
            except:
              plot=''


        try:
          for page in self.wget.select('#pager a'):
              try:
                page_from = page.getText(" ")
                self.debug('page from: %s'%page_from)
                if int(page_from) > int(index_page):
                   page_href = page['href']
                   self.debug('assigned page href %s'%page_href)
                   yield PFolder(
                           label   = "<Dal�� str�nka>",
                           call    = 'NovaProgramDirectory',
                           param   = {'path': page_href, 'index_page': int(page_from)}
                         )
                   break
              except:
                self.debug('error converting page %s to number'%page_from)

          for page in self.wget.select('#pager a'):
              page_to = page.getText(" ")
            
          print page_href
       
        except:
          self.debug('no pager')


    @plugin_call
    def play(self, path):
        """ Play stream on given path """
        # prepare program path
        url = self.BASE_URL + path
        self.debug('get_program_info on path: ' + repr(url))
        
        bs=read_page(url, HTML)

        vars=parse_vars(bs, [var_re('site_id', VAR_TYPE_INT), var_re('media_id', VAR_TYPE_STR), 
                             var_re('section_id',VAR_TYPE_STR)])
        print vars
        summary=bs.body.find('div',id="video_summary")
        title=summary.find('h2', 'video_title').string.strip()
        try:
            date=re.match(r'\((.+)\)',summary.find('span','date'))
        except:
            date=''
        try:
            plot=summary.find('p', 'video_description').string.strip()
        except:
            plot=''
        cfg_url="http://tn.nova.cz/bin/player/config.php?site_id=%s"
    
        doc=read_page(cfg_url%vars['site_id'])
    
        servers={}
        primary_server=None
        for server in doc.findAll('flvserver'):
            servers[server['id']]=server['url']  
            if server.get('primary'):
               primary_server=server.get('url') 
        print servers
    
        stream_url="http://tn.nova.cz/bin/player/serve.php?site_id=%s&media_id=%s&section_id=%s"\
        % (vars['site_id'], vars['media_id'], vars['section_id'])
        doc=read_page(stream_url)
        video=doc.playlist.item
        additional_info={"Date": date,'Plot':plot, 'Plotoutline':plot}
        path_format="%s"
        server=servers.get(video.get('server')) or primary_server
        self.core.play(server + "/?slist=mp4:" + video['src'])


