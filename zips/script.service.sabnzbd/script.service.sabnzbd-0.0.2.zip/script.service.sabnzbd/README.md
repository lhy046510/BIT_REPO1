PauseSABnzbdService
=========
This is a XBMC addon for pausing or speed throttling SABnzbd
when playing media.