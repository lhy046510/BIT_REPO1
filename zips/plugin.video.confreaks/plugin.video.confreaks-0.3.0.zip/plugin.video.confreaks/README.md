# xbmc-confreaks

[Confreaks](http://www.confreaks.com) is a great resource for watching Ruby presentations from conferences around the world; [XBMC](http://www.xbmc.org) is a powerful media player which you can use to enjoy them from the comfort of you sofa.

## Notes

- This addon has been tested with XBMC Frodo and Gotham Beta 2
- Currently the following Confreaks video formats are supported: downloadable files, YouTube, and Vimeo. Please raise an issue if new formats are added and I'll do my best to add support for them.

## Acknowledgements

This plugin uses [xbmcswift2](http://github.com/jbeluch/xbmcswift2), a "A micro framework to enable rapid development of XBMC plugins". Thanks to Jonathan Beluch for this.
