XBMC movie information scraper from www.cinemagia.ro

Use with XBMC installed (www.xbmc.org).
For bugreports and feature requests, please fill in an issue.