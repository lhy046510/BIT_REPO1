ORF TVthek XBMC Addon
=======
ORF TVthek is an addon that gives you access to the ORF TVthek Video Platform.


Requirements
------------
Tested on XBMC Eden/Frodo/Gotham


Supported platforms
-------------------
Windows, Linux , Android and OSX


Current Features
----------------
* Livestream
* All Shows
* Schedule Search
* HTTP Stream H264 (Stable)
* Search Function
* Missed Shows

Missing Features
----------------
* Download Function


Known Issues
------------
* you tell me


Legal
-----
This addon gives you access to videos on the ORF TVthek Website but is not endorsed, certified or otherwise approved in any way by ORF.
