# -*- encoding: utf-8 -*- 
"""
 Plugin for accessing streams/videos on http://www.stv.sk
"""
import sys
from xbmcPluginInterface import *

def run():
    from stvPlugin import STVPlugin
    iface = XBMCPluginInterface("plugin.video.xbmc-czech.STV")
    plugin = STVPlugin( iface )
    plugin.call( *sys.argv )

if __name__ == '__main__':
    run()

