Al Qahera Al Youm XBMC plugin
=============================

#### About the show ####
Spear headed by leading Arab presenter Amr Adeeb, Al Qahera Al Youm (Arabic: القاهرة اليوم‎, English: Cairo Today) is a live television talk show that broadcasts nearly everyday throughout the year from Cairo. The program efficiently covers all aspects of life in Egypt from politics, to arts, sports, cultural and economic issues, and even international affairs. It airs on Al Yawm channel which is part of Orbit Communications Company now known as the OSN.

#### Online presence ####
Clips of the program used to be uploaded daily on to the show's official YouTube channel until recently; the official YouTube channel has been shutdown. The program clips are now instead being directly uploaded to the official program website (http://www.alqaheraalyoum.net).

#### A XBMC video plugin ####
The Al Qahera Al Youm XBMC plugin scrapes the show's online website and delivers their video clip content through XBMC for convenient consumption.

Using the XBMC plugin
---------------------
#### Installation ####
Install the **[Arabic XBMC addons repository](https://github.com/hadynz/repository.arabic.xbmc-addons#arabic-xbmc-repository)** and select to install this plugin from it.

#### Configuration #####
No configuration is required for this plugin.