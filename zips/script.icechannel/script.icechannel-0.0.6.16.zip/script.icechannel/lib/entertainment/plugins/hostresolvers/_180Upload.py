'''
    Ice Channel    
    Copyright (C) 2013 the-one
'''

from entertainment.plugnplay.interfaces import HostResolver
from entertainment.plugnplay import Plugin
from entertainment import common
import xbmcgui

class _180Upload(HostResolver):
    implements = [HostResolver]
    
    name = '180upload'
    
    match_list = ['180upload.com']
    
    def Resolve(self, url):
    
        try:
            
            #Show dialog box so user knows something is happening
            dialog = xbmcgui.DialogProgress()
            dialog.create('Resolving', 'Resolving ' + self.name.upper() + ' Link...')
            dialog.update(0)
            
            common.addon.log( self.name.upper() + ' - Link: %s' % url )
            
            from entertainment.net import Net
            net = Net(cached=False)
            html = net.http_GET(url).content
            
            if dialog.iscanceled(): return None
            dialog.update(25)
            
            #Check page for any error msgs
            import re
            if re.search('>File Not Found', html):
                common.addon.log(self.name.upper() + ' - File not found')
                common.addon.show_small_popup('[B][COLOR white]' + self.name.upper() + '[/COLOR][/B]', '[COLOR red]File not found.[/COLOR]')                
                return None
            if re.search('\.(rar|zip)</b>', html):
                common.addon.log(self.name.upper() + ' - File not found')
                common.addon.show_small_popup('[B][COLOR white]' + self.name.upper() + '[/COLOR][/B]', '[COLOR red]File not found.[/COLOR]')                
                return None
                
            if dialog.iscanceled(): return None
            dialog.update(50)

            data = {}
            r = re.findall(r'type="hidden" name="(.+?)" value="(.+?)">', html)

            if r:
                for name, value in r:
                    data[name] = value
            else:
                common.addon.log(self.name.upper() + ' - Unable to resolve.')
                common.addon.show_small_popup('[B][COLOR white]' + self.name.upper() + '[/COLOR][/B]', '[COLOR red]Unable to resolve.[/COLOR]')                
                return None
            
            #Check for SolveMedia Captcha image
            solvemedia = re.search('<iframe src="(http://api.solvemedia.com.+?)"', html)

            if solvemedia:
               import os
               captcha = os.path.join(common.captchas_path, "180upload.png")
               html = net.http_GET(solvemedia.group(1)).content
               hugekey=re.search('id="adcopy_challenge" value="(.+?)">', html).group(1)
               open(captcha, 'wb').write(net.http_GET("http://api.solvemedia.com%s" % re.search('<img src="(.+?)"', html).group(1)).content)
               img = xbmcgui.ControlImage(450,15,400,130, captcha)
               wdlg = xbmcgui.WindowDialog()
               wdlg.addControl(img)
               wdlg.show()
               
               import xbmc
               kb = xbmc.Keyboard('', 'Please enter the text in the image', False)
               kb.doModal()
               capcode = kb.getText()

               if (kb.isConfirmed()):
                   userInput = kb.getText()
                   if userInput != '':
                       solution = kb.getText()
                   elif userInput == '':
                       common.addon.log(self.name.upper() + ' - Image-Text not entered')
                       common.addon.show_small_popup('[B][COLOR white]' + self.name.upper() + '[/COLOR][/B]', '[COLOR red]Image-Text not entered.[/COLOR]')                
                       return None
               else:
                   return None
                   
               wdlg.close()
               if solution:
                   data.update({'adcopy_challenge': hugekey,'adcopy_response': solution})
            
            if dialog.iscanceled(): return None
            dialog.update(75)
                
            html = net.http_POST(url, data).content
            
            if dialog.iscanceled(): return None
            dialog.update(100)
            
            link = re.search('id="lnk_download" href="([^"]+)"', html)
            if link:
                link = link.group(1)
            else:
                common.addon.log(self.name.upper() + ' - Unable to resolve.')
                common.addon.show_small_popup('[B][COLOR white]' + self.name.upper() + '[/COLOR][/B]', '[COLOR red]Unable to resolve.[/COLOR]')                
                return None

            return link
            
        except Exception, e:
            common.addon.log(self.name.upper() + ' - Exception occured: %s' % e)
            common.addon.show_small_popup('[B][COLOR white]' + self.name.upper() + '[/COLOR][/B]', '[COLOR red]Exception occured, check logs.[/COLOR]')                
            return None
        finally:
            dialog.close()