'''
    Ice Channel
    muchmovies.org
    Copyright (C) 2013 the-one, Mikey1234
'''

from entertainment.plugnplay.interfaces import MovieSource
from entertainment.plugnplay import Plugin
from entertainment import common
from entertainment.xgoogle.search import GoogleSearch

class MuchMovies(MovieSource):
    implements = [MovieSource]
    
    name = "MuchMovies"
    display_name = "Much Movies"
    base_url = 'http://www.muchmovies.org'
    
    source_enabled_by_default = 'true'
    
    def GetFileHosts(self, url, list, lock, message_queue): 
        self.AddFileHost(list, 'HD', url)
                
    def GetFileHostsForContent(self, title, name, year, season, episode, type, list, lock, message_queue):                 
        
        title = self.CleanTextForSearch(title) 
        name = self.CleanTextForSearch(name) 
        
        search_term = name + ' ' + year
        helper_term = 'movies'
        
        movie_url = self.GoogleSearchByTitleReturnFirstResultOnlyIfValid(self.base_url, search_term, helper_term, title_extrctr='muchmovies \:\: (.*)')

        if movie_url != '':
            self.GetFileHosts(movie_url, list, lock, message_queue)
                
            
    def Resolve(self, url):
        
        import re        
        from entertainment.net import Net
        net = Net(user_agent='Apple-iPhone/')
        
        content = net.http_GET(url).content
        content = content.replace('\n','')
                
        resolved_media_url = re.search('Choose an action</li><li><a href="(.+?)">Stream</a>', content)
        if resolved_media_url:
            resolved_media_url = resolved_media_url.group(1)
        else:
            resolved_media_url = ''
                
        return resolved_media_url
            
                
                