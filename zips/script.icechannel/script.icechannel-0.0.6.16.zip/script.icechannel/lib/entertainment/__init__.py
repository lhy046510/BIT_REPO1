#    Ice Channel
#    Copyright (C) 2013 the-one

import os
import common
import plugnplay
from plugnplay.interfaces import Indexer
from plugnplay.interfaces import Source
from plugnplay.interfaces import CustomSettings
from plugnplay.interfaces import iStreamSettings

#load all available plugins
plugin_dirs = [common.plugins_path]
from glob import glob
plugin_dirs.extend( glob( os.path.join( os.path.dirname(common.addon_path), common.addon_id + '.extn.*', 'plugins' ) ) )
plugnplay.set_plugin_dirs(*plugin_dirs)
plugnplay.load_plugins()

iStream_settings = {}

def Initialize():  

    #from multiprocessing.pool import ThreadPool as Pool    
    from threadpool import ThreadPool as Pool
    pool = Pool(4)
    
    import threading
    lock = threading.RLock()    
    
    try:
        import Queue as queue
    except:
        import queue
    message_queue = queue.Queue()
    
    list=[]
    
    unique_list=[]
    
    return (pool, list, unique_list, lock, message_queue)

def Destroy(pool):
    pool.dismissWorkers(4, True)
    
def FinalizeSearch(pool, item_list, unique_list, message_queue):

    pool.wait()
    
    import threading
    threading.Thread(target=Destroy, args=(pool, )).start()
        
    import odict
    temp_dict = odict.odict()

    for item in item_list:        
    
        if '_info' in item['id']:
        
            info_temp_dict_item = temp_dict.get('info', '')
            if info_temp_dict_item == '':
                item.update( { 'individual_total_pages': {} } )
                #item.update( { 'urls': {} } )
                temp_dict[ 'info' ] = item
                info_temp_dict_item = temp_dict[ 'info' ]
                            
            info_temp_dict_item['individual_total_pages'].update( {item['website']:item['total_pages']} )
                        
            #info_temp_dict_item['urls'].update( {item['website']:item['url']} )
            
            if int(item['total_pages']) > int(info_temp_dict_item['total_pages']):
                info_temp_dict_item['total_pages'] = item['total_pages']
        
        else:
            temp_dict_item = temp_dict.get(item['id'], '')
            if temp_dict_item == '':
                item.update( { 'urls': {} } )                
                temp_dict[ item['id'] ] = item
                temp_dict_item = temp_dict[ item['id'] ]
                
            temp_dict_item['urls'].update({item['website']:item['url']})
    
    for value in temp_dict.values():
        urls = value.get('urls', '')
        if urls != '':
            value['urls'] = common.ConvertDictToString(urls)
            
        individual_total_pages = value.get('individual_total_pages', '')
        if individual_total_pages != '':
            value['individual_total_pages'] = common.ConvertDictToString(individual_total_pages)

        unique_list.append( value )

    message_queue.put('done')
    
    
def Finalize(pool, src_type, item_list, unique_list, message_queue):

    pool.wait()
    
    import threading
    threading.Thread(target=Destroy, args=(pool, )).start()
    
    sort = GetiStreamSettings(src_type, 'sort')
    if sort == "true":
    
        sort_quality_ranking = {}
        sort_qualities = GetiStreamSettings(src_type, 'sort_quality')        
        sort_qualities_list = sort_qualities.split(',')
        sort_quality_index = 1
        for sort_quality in sort_qualities_list:
            if sort_quality:
                sort_quality_ranking.update({sort_quality.upper() : sort_quality_index * 100})
                sort_quality_index += 1
        na_sort_quality_ranking = sort_quality_index * 100
        
        import re
        
        sort_hosts = ''
        sort_host_ranking = {}
        hosts_input_fields = 5
        for x in range(0,5):
            hosts_at_x = GetiStreamSettings(src_type, 'sort_hosts_' + str(x+1))
            if hosts_at_x:
                if sort_hosts:
                    sort_hosts += ','
                sort_hosts += hosts_at_x        
        sort_hosts_list = sort_hosts.split(',')
        sort_host_index = 1
        for sort_host in sort_hosts_list:
            if sort_host:
                sort_host_ranking.update({sort_host.upper() : sort_host_index})
                sort_host_ranking.update({re.sub('\..*', '', sort_host.upper()) : sort_host_index})
                sort_host_index += 1
        na_sort_host_ranking = sort_host_index * 1000

    import odict
    
    for unique_item in odict.odict((item['id'],item) for item in item_list).values():
        if sort == "true":
            item_quality_ranking = sort_quality_ranking.get( unique_item.get('quality', 'NA'),  na_sort_quality_ranking )
            item_host_ranking = sort_host_ranking.get( unique_item.get('host', 'NA'),  na_sort_host_ranking )
            if item_host_ranking == na_sort_host_ranking:
                item_host_ranking = sort_host_ranking.get( unique_item.get('website', 'NA').upper(),  na_sort_host_ranking )
            item_ranking = item_quality_ranking + item_host_ranking
            unique_item.update( { 'ranking' : item_ranking } )
        unique_list.append( unique_item )

    if sort == "true":
        unique_list.sort(key=lambda k: k['ranking'])

    message_queue.put('done')
    
def GetMainSection():
    unique_list = []      
    
    for indxr in Indexer.implementors(): 
        stg = iStream_settings.get(indxr.indexer_type, None)
        if stg is not None:
            for indxrtyp in indxr.implementors():            
                if stg.Settings().get_setting(indxr.indexer_type + '_' + indxrtyp.name + '_indexer_enabled') == 'true':
                    unique_list.append( {'indexer':indxr.indexer_type, 'section':'main', 'title':indxr.indexer_section_name, 'mode':common.mode_Indexer} )    
                    break
    
    # unique_list.append( {'title':'Playlists', 'mode':common.mode_File_Stores, 'indexer':'file_stores', 'section':'file_stores'} )    
    unique_list.append( {'title':'Search', 'mode':common.mode_Search, 'indexer':'search', 'section':'search'} )    
    unique_list.append( {'title':'Settings', 'mode':common.mode_Settings, 'indexer':'settings', 'section':'settings'} )        
    unique_list.append( {'title':'Tools', 'mode':common.mode_Tools, 'indexer':'tools', 'section':'tools'} )        

    return unique_list
    
def GetSearchItem(indexer):    
    unique_list = []
    
    for indxr in Indexer.implementors(): 
        if indxr.indexer_type == indexer:
            if indxr.search_supported:
                unique_list.append( {'indexer':indxr.indexer_type, 'indexer_id':'search', 'section':'search', 'title':'Search', 'mode':common.mode_Search} )    
            break
            
    return unique_list
    
def GetAllSearchItems():    
    unique_list = []
    
    for indxr in Indexer.implementors(): 
        if indxr.search_supported:
            unique_list.append( {'indexer':indxr.indexer_type, 'indexer_id':'search', 'section':'search', 'title':'Search ' + indxr.indexer_section_name, 'mode':common.mode_Search} )    
            
    return unique_list
    
def GetIndexers(indexer):

    unique_list = []      
    
    stg = iStream_settings.get(indexer, None)
    if not stg:
        return unique_list
    
    for indxr in Indexer.implementors():         
        if indxr.indexer_type == indexer:
            for indxrtyp in indxr.implementors():
                if stg.Settings().get_setting(indxr.indexer_type + '_' + indxrtyp.name + '_indexer_enabled') == 'true':
                    unique_list.append( 
                        {
                            'indexer':indxr.indexer_type, 
                            'indexer_id':indxrtyp.name, 
                            'section':'main', 
                            'title':indxrtyp.display_name, 
                            'mode':common.mode_Sports if indexer == common.indxr_Sports else ( common.mode_Live_TV if indexer == common.indxr_Live_TV else common.mode_Section ),
                            'img':indxrtyp.img if indexer == common.indxr_Live_TV else '',
                            'fanart':indxrtyp.fanart if indexer == common.indxr_Live_TV else ''
                        } )
                        
            break
                
    
    return unique_list

def GetSettings():
    unique_list = []      

    for cs in CustomSettings.implementors(): 
        unique_list.append( {'settings_name':cs.settings_name, 'settings_id':cs.settings_id} )
        
    return unique_list
    
def GetExternalSettings():
    unique_list = []      
    
    unique_list.append( {'settings_name':'Metahandler', 'settings_id':'script.module.metahandler'} )
    unique_list.append( {'settings_name':'Universal Toolkit', 'settings_id':'script.module.universal'} )
    unique_list.append( {'settings_name':'URL Resolver', 'settings_id':'script.module.urlresolver'} )
        
    return unique_list

    
def GetiStreamSettings(type=None, id=None):
    if type and id:
    
        xs = iStream_settings.get(type, None)
        if xs:
            return xs.Settings().get_setting(id)
            
        else:
            return ''
    else:
        unique_list = []  

        unique_list.append( {'settings_name':'General', 'settings_id':'script.icechannel'} )        
        
        for cs in iStreamSettings.implementors(): 
            unique_list.append( {'settings_name':cs.name, 'settings_id':cs.settings_id} )
            
        return unique_list
        
def SetiStreamSettings(type, id, value):
    xs = iStream_settings.get(type, None)
    if xs:
        xs.Settings().set_setting(id, value)
    
def Search(indexer, keywords, type, page='', total_pages='', individual_total_pages=''):
    
    if individual_total_pages != '':
        individual_total_pages = common.ConvertStringToDict(individual_total_pages)    
    
    (pool, list, unique_list, lock, message_queue) = Initialize()
    
    from threadpool import WorkRequest
    
    processed_items =[]
    
    stg = iStream_settings.get(indexer, None)
    if stg:
        for indx in Indexer.implementors(): 
            if indx.indexer_type == indexer: 
                for indxr in indx.implementors():
                    if indxr.name not in processed_items:                        
                        indxr_enabled = stg.Settings().get_setting(indx.indexer_type + '_' + indxr.name + '_indexer_enabled')
                        if indxr_enabled == 'true':
                            processed_items.append(indxr.name)
                            if individual_total_pages != '':
                                indxr_individual_total_pages = individual_total_pages.get(indxr.name, '')
                                if indxr_individual_total_pages:                            
                                    pool.putRequest( WorkRequest(indxr.Search, args=(indexer, keywords, type, list, lock, message_queue, page, indxr_individual_total_pages)))
                            elif total_pages == '':                    
                                pool.putRequest( WorkRequest(indxr.Search, args=(indexer, keywords, type, list, lock, message_queue, page, total_pages)) )
                break
                
        for src in Source.implementors(): 
            if src.source_type == indexer: 
                for srcr in src.implementors():
                    if srcr.name not in processed_items:                        
                        srcr_enabled = stg.Settings().get_setting(src.source_type + '_' + srcr.name + '_source_enabled')
                        if srcr_enabled == 'true':
                            processed_items.append(srcr.name)
                            if individual_total_pages != '':
                                srcr_individual_total_pages = individual_total_pages.get(srcr.name, '')
                                if srcr_individual_total_pages:                            
                                    pool.putRequest( WorkRequest(srcr.Search, args=(indexer, keywords, type, list, lock, message_queue, page, srcr_individual_total_pages)))
                            elif total_pages == '':                    
                                pool.putRequest( WorkRequest(srcr.Search, args=(indexer, keywords, type, list, lock, message_queue, page, total_pages)) )
                break
    
    import threading
    threading.Thread(target=FinalizeSearch, args=(pool, list, unique_list, message_queue)).start()
    
    return (unique_list, message_queue)


def GetSection(indexer, indexer_to_use, section, url, type, page='', total_pages='', sort_by='', sort_order=''): 

    unique_list = []
    meta = []
    
    the_indexer = None
    
    for indxr in Indexer.implementors(): 
        if indxr.indexer_type == indexer: 
            for indxrtyp in indxr.implementors():
                if indxrtyp.name == indexer_to_use:
                    the_indexer = indxrtyp
                    break
            break
            
    if the_indexer:
        the_indexer.GetSection(indexer, section, url, type, unique_list, page=page, total_pages=total_pages, sort_by=sort_by, sort_order=sort_order)
    
    return (unique_list, meta)
    
def GetContent(indexer, indexer_to_use, url, title, name, year, season, episode, type):

    unique_list = []
    meta = []
    
    the_indexer = None
    
    for indxr in Indexer.implementors(): 
        if indxr.indexer_type == indexer: 
            for indxrtyp in indxr.implementors():
                if indxrtyp.name == indexer_to_use:
                    the_indexer = indxrtyp
                    break
            break
            
    if the_indexer:
        the_indexer.GetContent(indexer, url, title, name, year, season, episode, type, unique_list)
    
    return (unique_list, meta)    
    
def GetSportsContent(indexer, indexer_id ):

    (pool, list, unique_list, lock, message_queue) = Initialize()
    
    from threadpool import WorkRequest
    
    from plugnplay.interfaces import SportsSource
    
    for sprtsrcs in SportsSource.implementors():
        if indexer_id in sprtsrcs.source_sports_list:
            pool.putRequest( WorkRequest(sprtsrcs.GetSportsContent, args=(indexer, indexer_id, list, lock, message_queue)))
            
    import threading
    threading.Thread(target=FinalizeSearch, args=(pool, list, unique_list, message_queue)).start()
            
    return (unique_list, message_queue)

def GetLiveTVRegions( ):

    unique_list = []
    
    stg = iStream_settings.get(common.indxr_Live_TV, None)
    if not stg:
        return unique_list
    
    regions_list = ''
    
    from plugnplay.interfaces import LiveTVIndexer
    for livetvindxr in LiveTVIndexer.implementors():
        regions = livetvindxr.regions
        for region in regions:
            region_name = region['name']
            region_id = common.CreateIdFromString(region_name)
            enabled = True if stg.Settings().get_setting( 'live_tv_' + region_id + '_indexer_enabled') == 'true' else False
            if not enabled: continue
            region.update({'indexer_id':region_id})
            region.update({'title':region_name})
            if region_id not in regions_list:
                regions_list += region_id + '|'
                unique_list.append(region)
    
    return unique_list
    
def GetLiveTVForRegion( rgn_id ):    
    unique_list = []
    
    channels_list = ''
    
    stg = iStream_settings.get(common.indxr_Live_TV, None)
    if not stg:
        return unique_list
    
    regions_list = ''
    
    from plugnplay.interfaces import LiveTVIndexer
    for livetvindxr in LiveTVIndexer.implementors():
        if livetvindxr.name not in channels_list: channels_list += livetvindxr.name + '|'
        regions = livetvindxr.regions
        for region in regions:
            region_name = region['name']
            region_id = common.CreateIdFromString(region_name)
            if region_id == rgn_id:
                enabled = True if stg.Settings().get_setting( 'live_tv_' + livetvindxr.name + '_indexer_enabled') == 'true' else False
                if not enabled: continue
                unique_list.append( 
                    {
                        'indexer':common.indxr_Live_TV, 
                        'indexer_id':livetvindxr.name, 
                        'section':'main2', 
                        'title':livetvindxr.display_name, 
                        'mode':common.mode_Live_TV,
                        'region':rgn_id,
                        'img':livetvindxr.img,
                        'fanart':livetvindxr.fanart
                    } )
                
    
    return unique_list
    
def GetLiveTVLanguages( ):

    unique_list = []
    
    stg = iStream_settings.get(common.indxr_Live_TV, None)
    if not stg:
        return unique_list
    
    languages_list = ''
    
    from plugnplay.interfaces import LiveTVIndexer
    for livetvindxr in LiveTVIndexer.implementors():
        languages = livetvindxr.languages
        for language in languages:
            language_name = language['name']
            language_id = common.CreateIdFromString(language_name)
            enabled = True if stg.Settings().get_setting( 'live_tv_' + language_id + '_indexer_enabled') == 'true' else False
            if not enabled: continue
            language.update({'indexer_id':language_id})
            language.update({'title':language_name})
            if language_id not in languages_list:
                languages_list += language_id + '|'
                unique_list.append(language)
    
    return unique_list    
    
def GetLiveTVForLanguage( lang_id ):    
    unique_list = []
    
    channels_list = ''
    
    stg = iStream_settings.get(common.indxr_Live_TV, None)
    if not stg:
        return unique_list
    
    from plugnplay.interfaces import LiveTVIndexer
    for livetvindxr in LiveTVIndexer.implementors():
        if livetvindxr.name not in channels_list: channels_list += livetvindxr.name + '|'
        languages = livetvindxr.languages
        for language in languages:
            language_name = language['name']
            language_id = common.CreateIdFromString(language_name)
            if language_id == lang_id:
                enabled = True if stg.Settings().get_setting( 'live_tv_' + livetvindxr.name + '_indexer_enabled') == 'true' else False
                if not enabled: continue
                unique_list.append( 
                    {
                        'indexer':common.indxr_Live_TV, 
                        'indexer_id':livetvindxr.name, 
                        'section':'main2', 
                        'title':livetvindxr.display_name, 
                        'mode':common.mode_Live_TV,
                        'language':lang_id,
                        'img':livetvindxr.img,
                        'fanart':livetvindxr.fanart
                    } )
                
    
    return unique_list
    
def GetLiveTVGenres( ):

    unique_list = []
    
    stg = iStream_settings.get(common.indxr_Live_TV, None)
    if not stg:
        return unique_list
    
    genres_list = ''
    
    from plugnplay.interfaces import LiveTVIndexer
    for livetvindxr in LiveTVIndexer.implementors():
        genres = livetvindxr.genres
        for genre in genres:
            genre_name = genre['name']
            genre_id = common.CreateIdFromString(genre_name)
            enabled = True if stg.Settings().get_setting( 'live_tv_' + genre_id + '_indexer_enabled') == 'true' else False
            if not enabled: continue
            genre.update({'indexer_id':genre_id})
            genre.update({'title':genre_name})
            if genre_id not in genres_list:
                genres_list += genre_id + '|'
                unique_list.append(genre)
    
    return unique_list
    
def GetLiveTVForGenre( gnr_id ):    
    unique_list = []
    
    channels_list = ''
    
    stg = iStream_settings.get(common.indxr_Live_TV, None)
    if not stg:
        return unique_list
    
    genres_list = ''
    
    from plugnplay.interfaces import LiveTVIndexer
    for livetvindxr in LiveTVIndexer.implementors():
        if livetvindxr.name not in channels_list: channels_list += livetvindxr.name + '|'
        genres = livetvindxr.genres
        for genre in genres:
            genre_name = genre['name']
            genre_id = common.CreateIdFromString(genre_name)
            if genre_id == gnr_id:
                enabled = True if stg.Settings().get_setting( 'live_tv_' + livetvindxr.name + '_indexer_enabled') == 'true' else False
                if not enabled: continue
                unique_list.append( 
                    {
                        'indexer':common.indxr_Live_TV, 
                        'indexer_id':livetvindxr.name, 
                        'section':'main2', 
                        'title':livetvindxr.display_name, 
                        'mode':common.mode_Live_TV,
                        'img':livetvindxr.img,
                        'fanart':livetvindxr.fanart
                    } )
                
    
    return unique_list    
    
def GetLiveTVLinks(indexer, indexer_id, region, language ):

    stg = iStream_settings.get(indexer, None)

    (pool, list, unique_list, lock, message_queue) = Initialize()
    
    from threadpool import WorkRequest
    
    from plugnplay.interfaces import LiveTVSource
    from plugnplay.interfaces import LiveTVIndexer
    
    for livetvsrcs in LiveTVSource.implementors():
        srcr_enabled = True
        if not isinstance(livetvsrcs, LiveTVIndexer):
            print livetvsrcs.source_type + '_' + livetvsrcs.name + '_source_enabled'
            srcr_enabled = stg.Settings().get_setting(livetvsrcs.source_type + '_' + livetvsrcs.name + '_source_enabled') == "true"
            print srcr_enabled
        if srcr_enabled:
            pool.putRequest( WorkRequest(livetvsrcs.GetFileHosts, args=(indexer_id, region, language, list, lock, message_queue)))
            
    import threading
    threading.Thread(target=FinalizeSearch, args=(pool, list, unique_list, message_queue)).start()
            
    return (unique_list, message_queue)   

def GetTools():    
    unique_list = []
    
    from plugnplay.interfaces import Tools
    
    for tool in Tools.implementors(): 

        unique_list.append({'title':tool.display_name, 'mode':common.mode_Tools, 'indexer':'tools', 'section':'tools', 'name':tool.name,
            'img':tool.img, 'fanart':tool.fanart, 'notify_msg_header':tool.notify_msg_header, 'notify_msg_success':tool.notify_msg_success,
            'notify_msg_failure':tool.notify_msg_failure})
    
    return unique_list
    
def ExecuteTool(name):    
    
    from plugnplay.interfaces import Tools
    
    tool_to_execute = None
    
    for tool in Tools.implementors(): 
        if name == tool.name:
            tool_to_execute = tool
            break
        
    if tool_to_execute:
        return tool_to_execute.Execute()
        
    return False


def GetSportsLinks(indexer, indexer_id ):

    urls = common.ConvertStringToDict(urls)    
        
def GetFileHosts(indexer, indexer_to_use, url, title, name, year, season, episode, type, urls='', autoplay=False ):    
    
    if urls != '':
        urls = common.ConvertStringToDict(urls)    
    
    (pool, list, unique_list, lock, message_queue) = Initialize()
    
    from threadpool import WorkRequest
    
    stg = iStream_settings.get(indexer, None)
    if stg:
        for src in Source.implementors(): 
            if src.source_type == indexer: 
                for srcr in src.implementors():
                
                    fetch = True
                    if autoplay == True:
                        fetch = srcr.auto_play_supported
                        
                    if urls != '':
                        url = urls.get(srcr.name, '')
                        if url != '' and fetch == True:
                            pool.putRequest( WorkRequest(srcr.GetFileHosts, args=(url, list, lock, message_queue)))
                            continue
                    srcr_enabled = stg.Settings().get_setting(src.source_type + '_' + srcr.name + '_source_enabled')
                    if srcr_enabled == 'true' and fetch == True:
                        if srcr.name == indexer_to_use:
                            pool.putRequest( WorkRequest(srcr.GetFileHosts, args=(url, list, lock, message_queue)))
                        else:
                            pool.putRequest( WorkRequest(srcr.GetFileHostsForContent, args=(title, name, year, season, episode, type, list, lock, message_queue)))
                break
    
    import threading
    threading.Thread(target=Finalize, args=(pool, indexer, list, unique_list, message_queue)).start()
    
    return (unique_list, message_queue)
    
def GetSortByOptions(indexer, indexer_to_use):
    
    the_indexer = None
    
    sort_by_options = None
    
    for indxr in Indexer.implementors(): 
        if indxr.indexer_type == indexer: 
            for indxrtyp in indxr.implementors():
                if indxrtyp.name == indexer_to_use:
                    the_indexer = indxrtyp
                    break
            break
            
    if the_indexer:
        sort_by_options = the_indexer.GetSortByOptions()
        
    return sort_by_options
        
def GetSortOrderOptions(indexer, indexer_to_use):
    
    the_indexer = None
    
    sort_order_options = None
    
    for indxr in Indexer.implementors(): 
        if indxr.indexer_type == indexer: 
            for indxrtyp in indxr.implementors():
                if indxrtyp.name == indexer_to_use:
                    the_indexer = indxrtyp
                    break
            break
            
    if the_indexer:
        sort_order_options = the_indexer.GetSortOrderOptions()       

    return sort_order_options
    
def ResolveUrl(url):
    src = Source()
    return src.Resolve(url)
    
def ResolveFileHostUrl(source, source_to_use, url):
    
    resolved_url = ''
    
    for src in Source.implementors():
        if src.source_type == source: 
            for srcr in src.implementors():
                if srcr.name == source_to_use:
                    resolved_url = srcr.Resolve(url)
                    break
            break
    
    return resolved_url
    
def _update_settings_xml():
    '''
    This function writes a new ``resources/settings.xml`` file which contains
    all settings for this addon and its plugins.
    '''
    try:
        try:
            os.makedirs(os.path.dirname(common.settings_file))
        except OSError:
            pass
            
        account_settings = ''

        f = open(common.settings_file, 'w')
        try:
            f.write('<?xml version="1.0" encoding="utf-8" standalone="yes"?>\n')
            f.write('<settings>\n')    
                        
            f.write('<category label="General">\n')                        
            f.write('<setting type="sep" visible="false"/>\n')
            f.write('<setting id="theme" type="labelenum" values="Default" label="Theme" default="Default" visible="false"/>\n')
            f.write('<setting type="sep"/>\n')
            f.write('<setting id="timeformat" type="enum" values="12-Hour|24-Hour" label="Time Format" default="0"/>\n')
            f.write('<setting id="timezonesource" type="enum" values="Auto Detect|Custom" label="Time Zone" default="0"/>\n')
            f.write('<setting id="timezone" enable="eq(-1,1)" type="labelenum" values="-12|-11|-10|-9|-8|-7|-6|-5|-4|-3|-2|-1|0|+1|+2|+3|+4|+5|+6|+7|+8|+9|+10|+11|+12" label="     GMT Offset" default="0"/>\n')
            f.write('<setting type="sep"/>\n')
            f.write('<setting id="search_history" type="bool" label="Search History" default="true"/>\n')
            f.write('<setting type="sep"/>\n')
            f.write('<setting id="cache_retention" type="labelenum" values="2|5|10|15|20" label="Cache Retention Time (in Hours)" default="2"/>\n')
            f.write('<setting id="cache_playlists" type="bool" label="     Cache Playlists" default="false"/>\n')
            f.write('</category>\n')
            
            f.write('<category label="Auto-View">\n')	
            f.write('<setting id="auto-view" type="bool" label="Enable Automatic View" default="true"/>\n')
            f.write('<setting id="default-view" type="number" label="     Default View" default="50" enable="!eq(-1,false)"/>\n')
            f.write('<setting id="movie-view" type="number" label="     Movies View" default="503" enable="!eq(-2,false)"/>\n')   
            f.write('<setting id="tvshow-view" type="number" label="     TV Shows View" default="503" enable="!eq(-3,false)"/>\n')
            f.write('<setting id="season-view" type="number" label="     Seasons View" default="503" enable="!eq(-4,false)"/>\n')
            f.write('<setting id="episode-view" type="number" label="     Episodes View" default="503" enable="!eq(-5,false)"/>\n')
            f.write('</category>\n')
            
            f.write('<category label="Database">\n')
            f.write('<setting id="local_db_location" type="folder" label="Local DB Location" default="special://profile/addon_data/script.icechannel/databases"/>\n')
            f.write('<setting id="use_remote_db" type="bool" 	label="Use a remote MySQL DB" default="false"/>\n')
            f.write('<setting id="db_address" type="text" 	label="     Address" enable="eq(-1,true)" default="" />\n')
            f.write('<setting id="db_port" 	 type="integer" label="     Port" enable="eq(-2,true)" default="" />\n')
            f.write('<setting id="db_user" 	 type="text" 	label="     Username" enable="eq(-3,true)" default="" />\n')
            f.write('<setting id="db_pass"	 type="text" 	label="     Password" enable="eq(-4,true)" default="" option="hidden"/>\n')
            f.write('<setting id="db_name"	 type="text" 	label="     Database" enable="eq(-5,true)" default="iStream" />\n')
            f.write('</category>\n')
            
            f.write('</settings>')
        finally:            
            f.close
    except IOError:
        common.addon.log_error('error writing ' + common.settings_file)

def GetFileStores():
    unique_list = []
    
    from entertainment.plugnplay.interfaces import FileStore
    for fs in FileStore.implementors():
        unique_list.append( {'title':fs.display_name, 'mode':common.mode_File_Stores, 'indexer':'file_stores', 'section':'file_stores', 'indexer_id':fs.name} )
    
    return unique_list

def GetFileFormats():
    unique_list = []
    
    from entertainment.plugnplay.interfaces import FileStore
    for fs in FileStore.implementors():
        unique_list.append( {'title':fs.display_name, 'mode':common.mode_File_Stores, 'indexer':'file_stores', 'section':'file_stores', 'indexer_id':fs.name} )
    
    return unique_list
    
def GetFileFormatExtensionsMask():
    
    extensions_mask = ''
    
    from entertainment.plugnplay.interfaces import FileFormat
    for fs in FileFormat.implementors():
        extensions_mask += '|' + fs.extensions
        
    extensions_mask = extensions_mask[1:]
    
    return extensions_mask

def GetFileFormats():
    
    unique_list = []
    
    from entertainment.plugnplay.interfaces import FileFormat
    for fs in FileFormat.implementors():
        unique_list.append( { 'name' : fs.name, 'display_name' : fs.display_name })
    
    return unique_list
    
def GetFileFormatObj(format):
    
    ff = None
    
    from entertainment.plugnplay.interfaces import FileFormat
    for fs in FileFormat.implementors():
        if fs.name == format:
            ff = fs
            break
    
    return ff
    
def ReadFile(format, path):
    
    title = ''
    unique_list = []
    
    from entertainment.plugnplay.interfaces import FileFormat
    for fs in FileFormat.implementors():
        if fs.name == format:
            (title, unique_list) = fs.ReadFile(path)
            break
    
    return (title, unique_list)  

def GetFileTitle(format, path):    
    title = 'NA'
    
    from entertainment.plugnplay.interfaces import FileFormat
    for fs in FileFormat.implementors():
        if fs.name == format:
            title = fs.ReadFile(path, True)
            break
            
    return title

def ReadItem(format, item):
    title = ''
    unique_list = []
    
    from entertainment.plugnplay.interfaces import FileFormat
    for fs in FileFormat.implementors():
        if fs.name == format:
            (title, unique_list) = fs.ReadItem(item)
            break
    
    return (title, unique_list)  
    
def DetectFileFormat(path):
    
    from entertainment.plugnplay.interfaces import FileFormat
    ff = FileFormat()
    
    raw_data = ff.ReadFile(path, send_raw_data=True)
    
    if not raw_data:
        return (None, 'ISTREAM_MSG_NOT_AVAILABLE')
        
    
    detected_ff = None
    
    for fs in FileFormat.implementors():
        can_parse_response = fs.CanParse(raw_data)
        if can_parse_response in ( ff.ff_can_parse_yes, ff.ff_can_parse_maybe):
            detected_ff = fs
            if can_parse_response == ff.ff_can_parse_yes: break

    return (detected_ff, raw_data)

    
#make sure settings.xml is up to date
_update_settings_xml()

#make sure settings for other items are up to date
GetSettings()

for cs in iStreamSettings.implementors(): 
    cs.Initialize()
    iStream_settings[cs.type] = cs

import xbmc
xbmc.executebuiltin('UpdateLocalAddons ')
    
