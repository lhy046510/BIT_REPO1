RTP PLAY PLUGIN FOR XBMC
========================


### Summary ###
This is a plugin for [XBMC](http://xbmc.org) that enables watching videos and
the live stream from <http://rtp.pt/play>.

### Setup/Installation ###
The plugin should be available from fusion repository.

Contact: <92enen@gmail.com>
