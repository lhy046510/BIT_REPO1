# -*- coding: latin-1 -*-

'''
    Telly Nagari (tellynagari.com) XBMC Plugin
    Copyright (C) 2013 the-one

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.		
'''

import re
import os
import string
import sys
import urlresolver
import xbmc, xbmcaddon, xbmcplugin, xbmcgui

from t0mm0.common.addon import Addon
from t0mm0.common.net import Net

addon_id = 'plugin.video.tellynagari'
addon = Addon(addon_id, sys.argv)

net = Net()

def AddSysPath(path):
    if path not in sys.path:
        sys.path.append(path)

#PATHS
AddonPath = addon.get_path()
LibsPath = os.path.join(AddonPath, 'resources', 'libs')
AddSysPath(LibsPath)        

from universal import watchhistory

class Paths:
    rootDir = addon.get_path()

    if rootDir[-1] == ';':
        rootDir = rootDir[0:-1]

    resDir = os.path.join(rootDir, 'resources')
    imgDir = os.path.join(resDir, 'images')
    
    defaultVideoIcon = os.path.join(imgDir, 'video.png')

mode = addon.queries['mode']
url = addon.queries.get('url', '')
title = addon.queries.get('title', '')
img = addon.queries.get('img', '')
start = addon.queries.get('start', '')
section = addon.queries.get('section', '')
queued = addon.queries.get('queued', '')

historytitle = addon.queries.get('historytitle', '')
historylink = addon.queries.get('historylink', '')
iswatchhistory = addon.queries.get('watchhistory', '')

BASEURL = 'http://www.tellynagari.com/'

def WatchedCallback():
    print 'Video completed successfully.'
    
def unescape(text):
        try:            
            rep = {                   
                   "&nbsp;": " ",
                   "\n": "",
                   "\t": "",  
                   "&amp;" : "&",
                   "&#038;" : "&",
                   "&#8217;" : "'",
                   "&#8211;" : "-",
                   "&#8230;" : "...",
                   u'\u2013' : '-',
                   u'\u0026' : '&',
                   u'\u2019' : "'",
                   u'\u2026' : '...'
                   }
            for s, r in rep.items():
                text = text.replace(s, r)
				
            # remove html comments
            text = re.sub(r"<!--.+?-->", "", text)    
				
        except TypeError:
            pass

        return text

def mediaHost(pihost):
    pimhost = ''
    if pihost == 'dplay':
        pimhost = 'dailymotion.com'
    elif pihost == 'yplay':
        pimhost = 'youtube.com'
    elif pihost == 'plplay':
        pimhost = 'putlocker.com'
    elif pihost == 'pwplay':
        pimhost = 'playwire.com'
    elif pihost == 'vwplay':
        pimhost = 'videoweed.es'
    return pimhost

def MainMenu():
    addon.add_directory({'mode' : 'Browse', 'section': 'tvshows'}, {'title':  'TV Shows'})
    addon.add_directory({'mode': 'Resolver'}, {'title':  'Resolver Settings'})
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def Browse(section):    
    if section == 'tvshows':
        addon.add_directory({'mode' : 'section', 'section': 'recentepisodes'}, {'title':  'Recently Added Episodes'})
        addon.add_directory({'mode' : 'section', 'section': 'topepisodes'}, {'title':  'Top Episodes This Week'})
        addon.add_directory({'mode' : 'section', 'section': 'specialepisodes'}, {'title':  'Special Episodes'})
        addon.add_directory({'mode' : 'section', 'section': 'alltimeepisodes'}, {'title':  'All Time Popular Episodes'})
        addon.add_directory({'mode' : 'channels'}, {'title':  'TV Shows by Channel'})
        addon.add_directory({'mode' : 'section', 'section': 'tellycapsuleshows'}, {'title':  'Telly Capsule'})
        addon.add_directory({'mode' : 'section', 'section': 'newshows'}, {'title':  'New TV Shows'})
        addon.add_directory({'mode' : 'section', 'section': 'mostviewedshows'}, {'title':  'Most Viewed TV Shows'})
        addon.add_directory({'mode' : 'section', 'section': 'topshows'}, {'title':  'Top 10 TV Shows'})
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def GetSection(section):
    site_data = net.http_GET(BASEURL).content

    if ( section.endswith('episodes') ):        
        COMMON_REGEX = r"\n{0,3}<ul id=['\"]slisting['\"]>\n{0,3}(.+?)</ul>\n{0,3}"
        REGEX = r"";
        if ( section.startswith('recentepisodes') ):
            REGEX = r"(?s)<li>\n{0,3}<h2>Recently Added Episodes</h2>" + COMMON_REGEX + r"</li>"
        elif ( section.startswith('topepisodes') ):
            REGEX = r"(?s)<div id=\"tabcontent1\">" + COMMON_REGEX + r"</div>"
        elif ( section.startswith('specialepisodes') ):
            REGEX = r"(?s)<div id=\"tabcontent2\">" + COMMON_REGEX + r"</div>"
        elif ( section.startswith('alltimeepisodes') ):
            REGEX = r"(?s)<div id=\"tabcontent3\">" + COMMON_REGEX + r"</div>"

        episodes = re.search(REGEX, site_data).group(1)
        episodes = episodes.decode('utf8')
        episodes = addon.unescape(episodes)
        episodes = unescape(episodes)
        for episode_match in re.finditer(r"<li><a href=\"(.+?)\".*?>(.+?)<", episodes):
            episode_url = episode_match.group(1)
            episode_url_data = net.http_GET(episode_url).content
            
            episode_img_search = re.search(r"<img id=\"leadpic\" src=\"(.+?)\"", episode_url_data)
            episode_img = ''
            if episode_img_search:
                episode_img = episode_img_search.group(1)
            else:
                episode_img_search = re.search(r"<img src=\"(.+?)\" id=\"leadpic\"", episode_url_data)
                episode_img = episode_img_search.group(1)
            
            episode_name = episode_match.group(2)
            
            episode_name = episode_name.decode('utf8')
            episode_name = addon.unescape(episode_name)
            episode_name = unescape(episode_name)
            
            addon.add_directory({'mode' : 'links', 'url': episode_url, 'title' : episode_name}, {'title':  episode_name}, img= episode_img)           

    elif ( section.endswith('shows') ):
        COMMON_REGEX = r"<ul>(.+?)</ul>"
        REGEX = r"";
        if ( section.startswith('tellycapsuleshows') ):
            REGEX = r"(?s)capsule.*?" + COMMON_REGEX
        elif ( section.startswith('newshows') ):
            REGEX = r"(?s)New Tv Shows.*?" + COMMON_REGEX
        elif ( section.startswith('mostviewedshows') ):
            REGEX = r"(?s)Most Viewed Tv Shows.*?" + COMMON_REGEX
        elif ( section.startswith('topshows') ):
            REGEX = r"(?s)TV Ratings.*?" + COMMON_REGEX

        shows = re.search(REGEX, site_data).group(1)
        
        shows = shows.decode('utf8')
        shows = addon.unescape(shows)
        shows = unescape(shows)
        for show in re.finditer(r"<li.*?<a.+?href=\"(.+?)\".*?>(.+?)<", shows):
            show_url = show.group(1) + "/page/1"
            show_url_data = net.http_GET(show_url).content
            
            show_img_search = re.search(r"<img id=\"leadpic\" src=\"(.+?)\"", show_url_data)
            show_img = ''
            if show_img_search:
                show_img = show_img_search.group(1)
            else:
                show_img_search = re.search(r"<img src=\"(.+?)\" id=\"leadpic\"", show_url_data)
                show_img = show_img_search.group(1)
            
            show_name = show.group(2)
            
            addon.add_directory({'mode' : 'episodes', 'url': show_url}, {'title':  show_name}, img= show_img)           
            
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetChannels():
    site_data = net.http_GET(BASEURL).content
    channels = re.search(r"(?s)<ul.*?id=\"nav\".*?\">(.+?)</ul>", site_data).group(1)
    channels = channels.decode('utf8')
    channels = addon.unescape(channels)
    channels = unescape(channels)

    for channel in re.finditer(r"<li.*?class=\"page_item.*?\"><a.*?href=\"(.+?)\".*?title=\"(.+?)\">.*?</a></li>", channels):
        channel_url = channel.group(1)
        channel_name = channel.group(2)        
        channel_img = os.path.join( Paths.imgDir, channel_url[channel_url.rindex('/')+1:] + ".png" )
        addon.add_directory({'mode' : 'shows', 'url': channel_url}, {'title':  channel_name}, img= channel_img)   
        
    for channel in re.finditer(r"<li.*?class=\"page_item.*?\"><a.*?href=\"(.+?)\">(.+?)</a></li>", channels):
        channel_url = channel.group(1)
        if re.search("title=", channel_url):
            continue
        channel_name = channel.group(2)
        channel_img = os.path.join( Paths.imgDir, channel_url[channel_url.rindex('/')+1:] + ".png" )
        addon.add_directory({'mode' : 'shows', 'url': channel_url}, {'title':  channel_name}, img= channel_img)   
                    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def GetShows(url):
    channel_url = url
    channel_url_data = net.http_GET(channel_url).content

    new_shows = re.search(r"name=\"new\".*?<div(.+?)</div></div>", channel_url_data).group(1) + "</div>"
    new_shows = new_shows.decode('utf8')
    new_shows = addon.unescape(new_shows)
    new_shows = unescape(new_shows)
    for new_show in re.finditer(r"<a.+?href=\"(.+?)\">.*?<img.+?src=\"(.+?)\" width.*?><br/>(.+?)</a></div>", new_shows):
        new_show_name = new_show.group(3)
        new_show_url = new_show.group(1) + "/page/1"
        new_show_img = new_show.group(2)
        addon.add_directory({'mode' : 'episodes', 'url': new_show_url}, {'title':  new_show_name}, img= new_show_img)           

    current_shows = re.search(r"name=\"current\".*?<div(.+?)</a></ul></div></div>", channel_url_data).group(1)
    current_shows = current_shows.decode('utf8')
    current_shows = addon.unescape(current_shows)
    current_shows = unescape(current_shows)
    for current_show in re.finditer(r"<li>.*?<a.+?href=\"(.+?)\">(.+?)</a>.*?</li>", current_shows):
        current_show_name = current_show.group(2)
        current_show_url = current_show.group(1) + "/page/1"
        current_show_url_data = net.http_GET(current_show_url).content
                    
        current_show_img_search = re.search(r"<img id=\"leadpic\" src=\"(.+?)\"", current_show_url_data)
        current_show_img = ''
        if current_show_img_search:
            current_show_img = current_show_img_search.group(1)
        else:
            current_show_img_search = re.search(r"<img src=\"(.+?)\" id=\"leadpic\"", current_show_url_data)
            current_show_img = current_show_img_search.group(1)
        
        addon.add_directory({'mode' : 'episodes', 'url': current_show_url}, {'title':  current_show_name}, img= current_show_img)           
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def GetEpisodes(url):
    show_url = url
    show_url_data = net.http_GET(show_url).content

    episodes = re.search(r"(?s)Latest Episodes.*?<ul>(.+?)</ul>", show_url_data).group(1)
    episodes = episodes.decode('utf8')
    episodes = addon.unescape(episodes)    
    episodes = unescape(episodes)

    episode_img_search = re.search(r"<img id=\"leadpic\" src=\"(.+?)\"", show_url_data)
    episode_img = ''
    if episode_img_search:
        episode_img = episode_img_search.group(1)
    else:
        episode_img_search = re.search(r"<img src=\"(.+?)\" id=\"leadpic\"", show_url_data)
        episode_img = episode_img_search.group(1)

    for episode in re.finditer(r"<li>.*?<a.+?href=\"(.+?)\">(.+?)</a>.*?</li>", episodes):
        episode_name = episode.group(2)
        episode_url = episode.group(1)
        
        addon.add_directory({'mode' : 'links', 'url': episode_url, 'title' : episode_name}, {'title':  episode_name}, img= episode_img)           
  
    if ( re.search(r"class='last'", show_url_data) ):
        show_url_without_page = show_url[0:show_url.rindex('/')]
        show_url_next_page = int(show_url[show_url.rindex('/')+1:]) + 1
        show_next_page_url = show_url_without_page + "/" + str(show_url_next_page)

        addon.add_directory({'mode' : 'episodes', 'url': show_next_page_url}, {'title':  "Next Page >> "}, img= episode_img)                          
        
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
def GetLinks(url):
    episode_url = url
    episode_url_data = net.http_GET(episode_url).content

    if re.search(r"(?s)<h3 style=.*?\">(.+?)</h3>\n{0,3}<p>(.+?)</p>", episode_url_data):
        for video_match in re.finditer(r"(?s)<h3 style=.*?\">(.+?)</h3>\n{0,3}<p>(.+?)</p>", episode_url_data):
            video_name = video_match.group(1)
            video_data = video_match.group(2)
            video_data = video_data.decode('utf8')
            video_data = addon.unescape(video_data)
            video_data = unescape(video_data)
            
            links_iter = r"<a href=\"(.+?)\" .*?>(.+?)</a>"
            if re.search(r"onClick=itm\('(.+?)'\)", video_data):
                links_iter = r"<a.+?onClick=itm\('(.+?)'\).*?>(.+?)</a>"
                
            for playable_item in re.finditer(links_iter, video_data):
                playable_item_url = playable_item.group(1)                
                playable_item_host = video_name[:(video_name + " ").find(" ")+1].lower()               
                #playable_item_host = playable_item_url[playable_item_url.rindex('/')+1:playable_item_url.rindex('.')]                
                #playable_item_host = mediaHost(playable_item_host)
                
                if (playable_item_host == ''):
                    continue

                playable_item_id = playable_item_url[playable_item_url.rindex('=')+1:]

                hosted_media = urlresolver.HostedMediaFile(host=playable_item_host, media_id=playable_item_id)
                if hosted_media:            
                    hosted_url = hosted_media.get_url()
                    if hosted_url:
                        playable_item_name = video_name + " - " + playable_item.group(2)
                        
                        queries = {'mode' : 'play', 'url': hosted_url, 'title':  playable_item_name, 'historytitle' : title, 'historylink' : sys.argv[0]+sys.argv[2]}
                        contextMenuItems = []
                        from universal import playbackengine    
                        contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, title + ' - ' + playable_item_name, addon.build_plugin_url( queries ) ) ) )
                        
                        addon.add_directory(queries, {'title':  playable_item_name}, contextMenuItems, context_replace=False, img= Paths.defaultVideoIcon)                                          
                    
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    if re.search(r"(?s)<b>Episode.+?([0-9]+?)</b>.*?<p>(.+?)</p>", episode_url_data):
        for diff_match_1 in re.finditer(r"(?s)<b>Episode.+?([0-9]+?)</b>.*?<p>(.+?)</p>", episode_url_data):

            video_name = "Episode " + diff_match_1.group(1)        
            
            diff_match_1_items = diff_match_1.group(2)
            diff_match_1_items = diff_match_1_items.decode('utf8')
            diff_match_1_items = addon.unescape(diff_match_1_items)
            diff_match_1_items = unescape(diff_match_1_items)

            for playable_item in re.finditer(r"<a.*?href=\"(.+?)\".*?\">(.+?)</a>", diff_match_1_items):
                
                playable_item_url = playable_item.group(1)

                playable_item_host = playable_item_url[playable_item_url.rindex('/')+1:playable_item_url.rindex('.')]
                playable_item_host = mediaHost(playable_item_host)
                if (playable_item_host == ''):
                    continue

                playable_item_id = playable_item_url[playable_item_url.rindex('=')+1:]

                hosted_media = urlresolver.HostedMediaFile(host=playable_item_host, media_id=playable_item_id)
                if hosted_media:

                    hosted_url = hosted_media.get_url()
                    if hosted_url:                    
                        playable_item_name = video_name + " - " + playable_item.group(2)                    
                        
                        queries = {'mode' : 'play', 'url': hosted_url, 'title':  playable_item_name, 'historytitle' : title, 'historylink' : sys.argv[0]+sys.argv[2]}
                        contextMenuItems = []
                        from universal import playbackengine    
                        contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, title + ' - ' + playable_item_name, addon.build_plugin_url( queries ) ) ) )
                        
                        addon.add_directory(queries, {'title':  playable_item_name}, contextMenuItems, context_replace=False, img= Paths.defaultVideoIcon)                                          
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    if re.search(r"(?s)<b>Episode.+?([0-9]+?.+?)</b>.*?<p>.+?</p>.*?<p>(.+?)</p>", episode_url_data):
        for diff_match_1 in re.finditer(r"(?s)<b>Episode.+?([0-9]+?.+?)</b>.*?<p>.+?</p>.*?<p>(.+?)</p>", episode_url_data):

            video_name = "Episode " + diff_match_1.group(1)        
            
            diff_match_1_items = diff_match_1.group(2)
            diff_match_1_items = diff_match_1_items.decode('utf8')
            diff_match_1_items = addon.unescape(diff_match_1_items)
            diff_match_1_items = unescape(diff_match_1_items)

            for playable_item in re.finditer(r"<a.*?href=\"(.+?)\".*?\">(.+?)</a>", diff_match_1_items):
                
                playable_item_url = playable_item.group(1)

                playable_item_host = playable_item_url[playable_item_url.rindex('/')+1:playable_item_url.rindex('.')]
                playable_item_host = mediaHost(playable_item_host)
                if (playable_item_host == ''):
                    continue

                playable_item_id = playable_item_url[playable_item_url.rindex('=')+1:]

                hosted_media = urlresolver.HostedMediaFile(host=playable_item_host, media_id=playable_item_id)
                if hosted_media:

                    hosted_url = hosted_media.get_url()
                    if hosted_url:                    
                        playable_item_name = video_name + " - " + playable_item.group(2)                    

                        queries = {'mode' : 'play', 'url': hosted_url, 'title':  playable_item_name, 'historytitle' : title, 'historylink' : sys.argv[0]+sys.argv[2]}
                        contextMenuItems = []
                        from universal import playbackengine    
                        contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, title + ' - ' + playable_item_name, addon.build_plugin_url( queries ) ) ) )                        
                        
                        addon.add_directory(queries, {'title':  playable_item_name}, contextMenuItems, context_replace=False, img= Paths.defaultVideoIcon)                                          
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    if re.search(r"<p><a.*?href=\"(.+?)\".*?\">Watch Online", episode_url_data):
    
        playable_item = re.search(r"<p><a.*?href=\"(.+?)\".*?\">Watch Online", episode_url_data)
        playable_item_url = playable_item.group(1)

        playable_item_host = playable_item_url[playable_item_url.rindex('/')+1:playable_item_url.rindex('.')]
        playable_item_host = mediaHost(playable_item_host)
        if (playable_item_host == ''):
            print 'not supported'
        else:
            playable_item_id = playable_item_url[playable_item_url.rindex('=')+1:]

            hosted_media = urlresolver.HostedMediaFile(host=playable_item_host, media_id=playable_item_id)
            if hosted_media:

                hosted_url = hosted_media.get_url()
                if hosted_url:                    
                
                    queries = {'mode' : 'play', 'url': hosted_url, 'title':  title}
                    contextMenuItems = []
                    from universal import playbackengine    
                    contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, title, addon.build_plugin_url( queries ) ) ) )
                    
                    addon.add_directory(queries, {'title':  title}, contextMenuItems, context_replace=False, img= Paths.defaultVideoIcon)
                    
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    if re.search(r"(?s)links below.*?<p>(.+?)</div>", episode_url_data):            
        for diff_match_2 in re.finditer(r"(?s)links below.*?<p>(.+?)</div>", episode_url_data):            
            
            diff_match_2_items = diff_match_2.group(1)
            diff_match_2_items = diff_match_2_items.decode('utf8')
            diff_match_2_items = addon.unescape(diff_match_2_items)
            diff_match_2_items = unescape(diff_match_2_items)
            
            for playable_item in re.finditer(r"<a.*?href=\"(.+?)\".*?>(.+?)</a>", diff_match_2_items):
                
                playable_item_url = playable_item.group(1)
                playable_item_name = playable_item.group(2)

                addon.add_directory({'mode' : 'links', 'url': playable_item_url, 'title':  playable_item_name, 'historytitle' : title, 'historylink' : sys.argv[0]+sys.argv[2]}, {'title':  playable_item_name})                                                      
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    
def Play(url, title):
    from universal import playbackengine
    
    item_title = title
    display_name = title
    if historylink:
        item_title = historytitle + ' - ' + title
        display_name = historytitle + ' - ' + title
    
    if queued == 'true':
        resolved_media_url = urlresolver.resolve(url)
        if resolved_media_url:
            
            player = playbackengine.Play(resolved_url=resolved_media_url, addon_id=addon_id, video_type='tvshow', 
                                title=item_title,season='', episode='', year='', watchedCallback=WatchedCallback)
            
            '''
            add to watch history - start
            '''
            wh = watchhistory.WatchHistory(addon_id)
                    
            if historylink:
                wh.add_video_item(display_name, sys.argv[0]+sys.argv[2], img=img, is_playable=True, parent_title=historytitle)
                wh.add_directory(historytitle, historylink, img=img, level='1')
            else:
                wh.add_video_item(display_name, sys.argv[0]+sys.argv[2], img=img, is_playable=True)
            
            '''
            add to watch history - end
            '''                
            
            player.KeepAlive()
    else:
        playbackengine.PlayInPL(display_name, img=img)
        

def ShowResolverSettingsDialog():
    urlresolver.display_settings()
        
if mode == 'main':
    MainMenu()
elif mode == 'Browse':
    Browse(section)
elif mode == 'section':
    GetSection(section)
elif mode == 'links':
    GetLinks(url)
elif mode == 'channels':
    GetChannels()
elif mode == 'shows':
    print 'show'
    GetShows(url)
elif mode == 'episodes':
    GetEpisodes(url)
elif mode == 'play':
    Play(url, title)
elif mode == 'Resolver':
    ShowResolverSettingsDialog()
elif mode == 'universalsettings':    
    from universal import _common
    _common.addon.show_settings()