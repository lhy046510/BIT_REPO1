screensaver.clock
=================

An very basic screensaver for XBMC that display's current time
