XBMC add-on for LinuxGameCast
=========

This is the source code for an XBMC add-on. The add-on can be used
to access content from the [LinuxGameCast](http://www.linuxgamecast.com/).
This add-on has been tested on XBMC v13 (Gotham).
