# -*- encoding: utf-8 -*- 
"""
 Plugin for accessing trailers on http://cztrailery.cz/
"""

import sys
from xbmcPluginInterface import *

def run():
    from cztraileryPlugin import CZTraileryPlugin
    iface = XBMCPluginInterface("plugin.video.xbmc-czech.cztrailery")
    plugin = CZTraileryPlugin( iface )
    plugin.call( *sys.argv )


if __name__ == '__main__':
    run()

