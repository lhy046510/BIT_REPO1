#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import urllib,urllib2,re,xbmcplugin,xbmcgui,sys,xbmc,xbmcaddon,xbmcvfs
import os,base64
# -*- coding: iso-8859-9 -*-

__settings__ = xbmcaddon.Addon(id='plugin.image.mansetler')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)
import xbmctools
l_check=xbmctools.inside()
if l_check:
        pass
else:
        xbmctools.hata()
        sys.exit()
######################@yigitki ve @xmaxell katkilarindan dolayi Drascoma tesekkur ederiz ... #########################


#!/usr/bin/python
# -*- coding: utf-8 -*-
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets & xmaxell
# Turkiye, E-mail: yenihandy@gmail.com

addon_id = 'plugin.image.mansetler'
selfAddon = xbmcaddon.Addon(id=addon_id)
addonfolder = selfAddon.getAddonInfo('path')
artfolder = '/resources/icons/'




def CATEGORIES():
        url='http://www.haberler.com/gazete_mansetleri.asp'
        link = get_url(url)
        match=re.compile('title=".*?" ><img src="(.*?)_o.jpg(.*?)" alt="(.*?)"  width="180" height="270"/>').findall(link)
        #http://img.haberler.com/gazete/zaman-gazetesi/bugun_o.jpg?12_00
        print match
        
        for a,b,title in match:
                
                
                thumbnail=a+'.jpg'+b
                thumbnail = urllib.unquote(thumbnail)
                #thumbanil=thumbnail.replace('_o.jpg','.jpg')
                print'aaa1',thumbnail
                addLink('[B]' + title + '[/B]',thumbnail,thumbnail)
        xbmc.executebuiltin("Container.SetViewMode(500)")


 
############################################################################################################################

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultImage.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
        liz.setInfo( type='image', infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', addonfolder + artfolder + 'fanart.jpg')
        liz.setInfo( type="Video", infoLabels={ "Title": name })
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
       
elif mode==1:
        print ""
        jornal_list(url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))
