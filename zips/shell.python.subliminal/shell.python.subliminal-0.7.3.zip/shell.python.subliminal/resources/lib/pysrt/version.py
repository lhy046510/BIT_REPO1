VERSION = (0, 5, 1)
VERSION_STRING = '.'.join(str(i) for i in VERSION)
