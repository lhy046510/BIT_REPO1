﻿# -*- coding: UTF-8 -*-

import os, sys, re, xbmc, xbmcgui, string, time, urllib, urllib2,codecs
from utilities import languageTranslate, log

from chardet.universaldetector import UniversalDetector


MIN_SUB_SIZE = 10*1024
EXTS= ["srt", "sub", "ass", "smi", "ssa", "txt" ]
#====================================================================================================================
# Functions
#====================================================================================================================

def getSubtitlesEncode(file_path):
    u = UniversalDetector()
    for line in open(file_path, 'rb'):
        u.feed(line)
    u.close()
    result = u.result
    if result['encoding']:
        return result['encoding']
    else:
        return '%s: no result' % file_path

def getStringEncode(_str):
    u = UniversalDetector()
    u.feed(_str)
    u.close()
    result = u.result
    if result['encoding']:
        return result['encoding']
    else:
        return '%s: no result' % _str

def EncodeToUTF8(filename,source_encoding):
    content = codecs.open(filename, 'r').read()

    content = content.decode(source_encoding,'ignore') #.encode(source_encoding)

    codecs.open(filename, 'w', encoding='utf-8').write(content)

def to_subscene_lang(language):
    if language == "Chinese":            return "Chinese BG code"
    elif language == "PortugueseBrazil": return "Brazillian Portuguese"
    elif language == "SerbianLatin":     return "Serbian"
    elif language == "Ukrainian":        return "Ukranian"
    else:                                return language

def Calc_File_Hash(a):
    def b(j):
        g = ""
        for i in range(len(j)):
            h=ord(j[i])
            if (h+47>=126):
                g += chr(ord(" ") + (h+47) % 126)
            else:
                g += chr(h+47)
        return g
    def d(g):
        h=""
        for i in range(len(g)):
            h+=g[len(g)-i-1]
        return h
    def c(j,h,g,f):
        p = len(j)
        return j[p-f+g-h:p-f+g] +j[p-f:p-f+g-h]+j[p-f+g:p]+j[0:p-f]
    if len(a) >32:
        charString =a[1:len(a)]
        result = {
            'o': lambda : b(c(charString, 8, 17, 27)),
            'n': lambda : b(d(c(charString, 6, 15, 17))),
            'm': lambda : d(c(charString, 6, 11, 17)),
            'l': lambda : d(b(c(charString, 6, 12, 17))),
            'k': lambda : c(charString, 14, 17, 24),
            'j': lambda : c(b(d(charString)), 11, 17, 27),
            'i': lambda : c(d(b(charString)), 5, 7, 24),
            'h': lambda : c(b(charString), 12, 22, 30),
            'g': lambda : c(d(charString), 11, 15, 21),
            'f': lambda : c(charString, 14, 17, 24),
            'e': lambda : c(charString, 4, 7, 22),
            'd': lambda : d(b(charString)),
            'c': lambda : b(d(charString)),
            'b': lambda : d(charString),
            'a': lambda : b(charString)
        }[a[0]]()
        return result
    return a

def get_Sub(sid):
    url ='http://shooter.cn/files/file3.php?hash=duei7chy7gj59fjew73hdwh213f&fileid=' + sid
    httpdata =urllib2.urlopen(url).read()
    subURL = 'http://file0.shooter.cn' + Calc_File_Hash(httpdata)
    return subURL


def search_Sub(keyword,subtitles_list,title,language):
    languageshort = languageTranslate(language,0,2)
    url = 'http://www.shooter.cn/search/%s/' % urllib.quote_plus(keyword)
    data =urllib2.urlopen(url).read().decode('utf-8')
    match = re.compile(r'<span class="sublist_box_title_l">.{100,230}>(.{10,150})</a></span>.{90,120}return local_downfile\(this,(\d+)\);" title="(.{1,12})KB">', re.DOTALL).findall(data)
    if len(match) > 0:
        for name,sid,size in match:
            if float(size)>10:
                subtitles_list.append({'rating': '0', 'movie':  title, 'filename': name, 'sync': False, 'sid': sid, 'language_flag': 'flags/' + languageshort + '.gif', 'language_name': language})
			
def search_subtitles( file_original_path, title, tvshow, year, season, episode, set_temp, rar, lang1, lang2, lang3, stack ): #standard input
    subtitles_list = []
    msg = ""
    
    search_string, year2= xbmc.getCleanMovieTitle(title)
    print "SEARCH:::::" + search_string
    search_Sub(search_string,subtitles_list,title,lang1)
	
    return subtitles_list, "", msg #standard output


def download_subtitles (subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id): #standard input
    sid = subtitles_list[pos][ "sid" ]
    language = subtitles_list[pos][ "language_name" ]
    downloadlink = get_Sub(sid)
    if downloadlink:
        xbmc.executebuiltin((u"Notification(%s,%s,%i)" % (u'新射手字幕', u'正在连接到射手网，并读取数据 ', 1000)).encode("utf-8")) 
        content =urllib2.urlopen(downloadlink).read()
        if content is not None:
            xbmc.executebuiltin((u"Notification(%s,%s,%i)" % (u'新射手字幕', u'读取成功，正在分析字幕 ', 1000)).encode("utf-8")) 
            header = content[:4]
            filename = "Shooter"
            if header == 'Rar!':
                local_tmp_file = os.path.join(tmp_sub_dir, filename+".rar")
                packed = True
            elif header == 'PK':
                local_tmp_file = os.path.join(tmp_sub_dir, filename+".zip")
                packed = True
            else: # never found/downloaded an unpacked subtitles file, but just to be sure ...
                local_tmp_file = os.path.join(tmp_sub_dir, "asia-team.srt") # assume unpacked sub file is an '.srt'
                subs_file = local_tmp_file
                packed = False
            log( __name__ ,"%s Saving subtitles to '%s'" % ("", local_tmp_file))
            try:
                local_file_handle = open(local_tmp_file, "wb")
                local_file_handle.write(content)
                local_file_handle.close()
                xbmc.executebuiltin((u"Notification(%s,%s,%i)" % (u'新射手字幕', u'正在保存字幕到本地 ', 1000)).encode("utf-8")) 
                print "SUBTITLE:::DownLoad " + local_tmp_file +" Succeed!"
            except:
                log( __name__ ,"%s Failed to save subtitle to %s" % ("", local_tmp_file))
                xbmc.executebuiltin((u"Notification(%s,%s,%i)" % (u'新射手字幕', u'下载字幕失败', 1000)).encode("utf-8")) 
            if packed:
                files = os.listdir(tmp_sub_dir)
                init_filecount = len(files)
                filecount = init_filecount
                max_mtime = 0
                # determine the newest file from tmp_sub_dir
                for file in files:
                    if (string.split(file,'.')[-1] in EXTS):
                        if isinstance(file, unicode):
                            joinpath = os.path.join(tmp_sub_dir, file)
                        else:#print file.decode('gbk')
                            joinpath = os.path.join(str(tmp_sub_dir), file)
                        mtime = os.stat(joinpath).st_mtime
                        if mtime > max_mtime:
                            max_mtime =  mtime
                init_max_mtime = max_mtime
                time.sleep(2)  # wait 2 seconds so that the unpacked files are at least 1 second newer
                pDialog = xbmcgui.DialogProgress()
                ret = pDialog.create('XBMC', u'解压字幕。')
                xbmc.executebuiltin("XBMC.Extract(" + local_tmp_file + "," + tmp_sub_dir +")")
                
                waittime  = 0
                unpacked_subs = []
                while (filecount == init_filecount) and (waittime < 20): # nothing yet extracted
                    time.sleep(1)  # wait 1 second to let the builtin function 'XBMC.extract' unpack
                    pDialog.update( waittime*5, u"解压中...")
                    if pDialog.iscanceled():
                        return False, language, "" 
                    files = os.listdir(tmp_sub_dir)
                    filecount = len(files)
                    waittime  = waittime + 1
                pDialog.close()
                if waittime == 20:
                    log( __name__ ,"%s Failed to unpack subtitles in '%s'" % (debug_pretext, tmp_sub_dir))
                    xbmc.executebuiltin((u"Notification(%s,%s,%i)" % (u'新射手字幕', u'解压字幕失败', 1000)).encode("utf-8"))  
                else:
                    for file in files:
                        if (string.split(file,'.')[-1] in EXTS):
                            if isinstance(file, unicode):
                                joinpath = os.path.join(tmp_sub_dir, file)
                            else:#print file.decode('gbk')
                                joinpath = os.path.join(str(tmp_sub_dir), file)
                            mtime = os.stat(joinpath).st_mtime
                            if (mtime > max_mtime):
                                unpacked_subs.append(file)
                    if len(unpacked_subs) == 0: return False, language, ""
                    file = choice_one(unpacked_subs) #open new dialog to select file
                    if isinstance(file, unicode):
                        joinpath = os.path.join(tmp_sub_dir, file)
                    else:#print file.decode('gbk')
                        joinpath = os.path.join(str(tmp_sub_dir), file)
                    subs_file = joinpath
            fileencode = getSubtitlesEncode(subs_file)
            if(fileencode != 'UTF-8'):
                print "SUBTITLE:::Encode to utf8 !"
                EncodeToUTF8(subs_file,fileencode)
            #print subs_file
            return False, language, subs_file #standard output
   
def choice_one(files):
    if len(files) ==1:
        return files[0]
    options = []
    sub_list = []
    Number = 0
    
    for file in files:
        if (string.split(file, '.')[-1] in EXTS):		
            Number = Number + 1
            options.append("%02d) %s" % (Number , file))
            sub_list.append(file)
    choice = xbmcgui.Dialog()
    selection = choice.select(u"选择字幕", options)
    log( __name__ ,"selection=%d" % (selection))
    if selection!= -1:
        return sub_list[selection]
   
def download_subtitles2 (subtitles_list, pos, zip_subs, tmp_sub_dir, sub_folder, session_id): #standard input
    sid = subtitles_list[pos][ "sid" ]
    language = subtitles_list[pos][ "language_name" ]
    downloadlink = get_Sub(sid)
    if downloadlink:
        viewstate = 0
        previouspage = 0
        subtitleid = 0
        typeid = "zip"
        filmid = 0
        postparams = urllib.urlencode( { '__EVENTTARGET': 's$lc$bcr$downloadLink', '__EVENTARGUMENT': '' , '__VIEWSTATE': viewstate, '__PREVIOUSPAGE': previouspage, 'subtitleId': subtitleid, 'typeId': typeid, 'filmId': filmid} )
        class MyOpener(urllib.FancyURLopener):
            version = 'User-Agent=Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3 ( .NET CLR 3.5.30729)'
        my_urlopener = MyOpener()
        response = my_urlopener.open(downloadlink)
        local_tmp_file = os.path.join(tmp_sub_dir, "subscene.xxx")
        subs_file = local_tmp_file
        try:
            if not os.path.exists(tmp_sub_dir):
                os.makedirs(tmp_sub_dir)
            local_file_handle = open(local_tmp_file, "w" + "b")
            local_file_handle.write(response.read())
            local_file_handle.close()
            #Check archive type (rar/zip/else) through the file header (rar=Rar!, zip=PK)
            myfile = open(local_tmp_file, "rb")

            myfile.seek(0)
            if (myfile.read(1) == 'R'):
                typeid = "rar"
                packed = True
                log( __name__ , "Discovered RAR Archive")
            else:
                myfile.seek(0)
                if (myfile.read(1) == 'P'):
                    typeid = "zip"
                    packed = True
                    log( __name__ , "Discovered ZIP Archive")
                else:
                    typeid = "srt"
                    packed = False
                    log( __name__ , "Discovered a non-archive file")
            myfile.close()
            local_tmp_file = os.path.join(tmp_sub_dir, "subscene." + typeid)
            os.rename(os.path.join(tmp_sub_dir, "subscene.xxx"), local_tmp_file)
        except:
            log( __name__ ,"%s Failed to save subtitle to %s" % ("", local_tmp_file))
        if packed:
            files = os.listdir(tmp_sub_dir)
            init_filecount = len(files)
            max_mtime = 0
            filecount = init_filecount
            # determine the newest file from tmp_sub_dir
            for file in files:
                if (string.split(file,'.')[-1] in EXTS):
                    if isinstance(file, unicode):
                        joinpath = os.path.join(tmp_sub_dir, file)
                    else:#print file.decode('gbk')
                        joinpath = os.path.join(str(tmp_sub_dir), file)
                    mtime = os.stat(joinpath).st_mtime
                    if mtime > max_mtime:
                        max_mtime =  mtime
            init_max_mtime = max_mtime
            time.sleep(2)  # wait 2 seconds so that the unpacked files are at least 1 second newer
            xbmc.executebuiltin("XBMC.Extract(" + local_tmp_file + "," + tmp_sub_dir +")")
            waittime  = 0
            while (filecount == init_filecount) and (waittime < 20) and (init_max_mtime == max_mtime): # nothing yet extracted
                time.sleep(1)  # wait 1 second to let the builtin function 'XBMC.extract' unpack
                files = os.listdir(tmp_sub_dir)
                filecount = len(files)
                # determine if there is a newer file created in tmp_sub_dir (marks that the extraction had completed)
                for file in files:
                    if isinstance(file, unicode):
                        joinpath = os.path.join(tmp_sub_dir, file)
                    else:#print file.decode('gbk')
                        joinpath = os.path.join(str(tmp_sub_dir), file)
                    if (string.split(file,'.')[-1] in EXTS):
                        mtime = os.stat(joinpath).st_mtime
                        if (mtime > max_mtime):
                            max_mtime =  mtime
                waittime  = waittime + 1
            if waittime == 20:
                log( __name__ ,"%s Failed to unpack subtitles in '%s'" % ("", tmp_sub_dir))
            else:
                for file in files:
                    if isinstance(file, unicode):
                        joinpath = os.path.join(tmp_sub_dir, file)
                    else:#print file.decode('gbk')
                        joinpath = os.path.join(str(tmp_sub_dir), file)
                    # there could be more subtitle files in tmp_sub_dir, so make sure we get the newly created subtitle file
                    if (string.split(file, '.')[-1] in EXTS) and (os.stat(joinpath).st_size > MIN_SUB_SIZE) : # unpacked file is a newly created subtitle file
                        if (joinpath.lower().find('chs')!= -1 or joinpath.lower().find('zh')!= -1):
                            subs_file = joinpath
                            break
                        else:
                            subs_file = joinpath			
                            						
        fileencode = getSubtitlesEncode(subs_file)
        if(fileencode != 'UTF-8'):
            EncodeToUTF8(subs_file,fileencode)
        #print subs_file
        return False, language, subs_file #standard output        