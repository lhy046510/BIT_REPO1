# -*- coding: utf-8 -*-

"""
    Plugin for streaming video content from www.sport5.co.il
"""
import urllib, re, unicodedata, os, sys
import xbmc, xbmcplugin, xbmcaddon, xbmcgui



##General vars
__plugin__ = "sdarot"
__author__ = "Shai Bentin"

__settings__ = xbmcaddon.Addon(id='plugin.video.sdarot.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')

LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

__base_url__ = 'http://www.sdarot.me/'

from common import *

def CATEGORIES():
    ## get the cookies first
    cookies = getCookies(__base_url__)
    ## get the block containing the list of VOD categories
    page = getData(__base_url__ + 'categories',0,'',cookies)
    matches = re.compile('<div class="category_box"><a href="/(.*?)"><img src="(.*?)".*?<div class="category_info">(.*?)<').findall(page)
    for href, img, name in matches:
        addDir(name, __base_url__ + href, cookies, 1, __base_url__ + img)
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    xbmc.executebuiltin("Container.SetViewMode(500)")# see the image view
    
def EPISODES(url, cookies):
    # receive the block of shows that are a part of this genre
    page = getData(url,0,'',cookies)
    # print page
    blocks = re.compile('<div class="video_box">.*?<a href="/(.*?)"><img src="/(.*?)" title="(.*?)"').findall(page)
    for vidurl, img, title in blocks:
        addVideoLink(title, __base_url__ + vidurl, cookies, 2, __base_url__ + img)
    
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
    xbmc.executebuiltin("Container.SetViewMode(503)")# see the image view
    
def PLAY_MOVIE(url, name, cookies):
    videopage = getData(url, 0, '', cookies) # episode page is cached according to defaults
    # print videopage
    movieId = re.compile('.addVariable\(\'file\', \'(.*?)\'').findall(videopage)
    # print 'MOVIE-ID ' + movieId[0]
    videoUrl = movieId[0]
    listItem = xbmcgui.ListItem(name, 'DefaultFolder.png', 'DefaultFolder.png', path=videoUrl)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    listItem.setInfo(type='Video', infoLabels={ "Title": urllib.unquote(name), "Plot": str(name)})
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    
params = getParams(sys.argv[2])
url=None
name=None
mode=None
module=None
page=None
cookies=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
try:
        page=urllib.unquote_plus(params["page"])
except:
        pass
try:
        cookies=urllib.unquote_plus(params["cookies"])
except:
        pass

if mode==None or url==None or len(url)<1:
    CATEGORIES()

elif mode==1:
    EPISODES(url, cookies)

elif mode==2:
    PLAY_MOVIE(url, name, cookies)
        
else:
    xbmc.log('Error: Unknown mode [%s]' % (str(mode)), xbmc.LOGERROR)

xbmcplugin.setPluginFanart(int(sys.argv[1]),xbmc.translatePath( os.path.join( __PLUGIN_PATH__,"fanart.jpg")))
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)