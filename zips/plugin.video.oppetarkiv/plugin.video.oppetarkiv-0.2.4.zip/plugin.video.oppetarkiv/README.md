# XBMC Öppet Arkiv addon
# 0.2.4
Forked from nielzen/xbmc-svtplay

This addon is used to stream videos from www.oppetarkiv.se

Install from repo
or
Download and "install from zip file" in xbmc.
