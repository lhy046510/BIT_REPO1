﻿# coding=utf-8
#
# <BestRussianTV plugin for XBMC>
# Copyright (C) <2011>  <BestRussianTV>
#
#       This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import httplib, time, datetime
from BeautifulSoup import BeautifulSoup, BeautifulStoneSoup


try:
    # new XBMC 10.05 addons:
    import xbmcaddon
except ImportError:
    # old XBMC - create fake xbmcaddon module with same interface as new XBMC 10.05
    class xbmcaddon:
        """ fake xbmcaddon module """
        __version__ = "(old XBMC)"
        class Addon:
            """ fake xbmcaddon.Addon class """
            def __init__(self, id):
                self.id = id

            def getSetting(self, key):
                return xbmcplugin.getSetting(key)

            def openSettings(self):
                xbmc.openSettings()
            def setSetting(self, key, value):
                return xbmcplugin.setSetting(key, value)

addon = xbmcaddon.Addon("plugin.video.brt")

quality = ['HQ', 'SQ']
q = int(addon.getSetting('quality'))
region = ['EU_RST', 'NA_PST', 'NA_EST','AU_EST']
wZone = ['PA_DLT','UTC-11','NA_HAT','NA_AST','NA_PST','NA_MST','CA_CST','NA_EST','AT_AST','NA_NST','SA_EST','AT_MAT','AT_AZO','EU_GMT','EU_CET','EU_EST','EU_RST','AS_AST','AS_EST','AS_NCT','AS_NST','AS_SGT','AS_JST','AU_EST','AS_MAG','AS_FST','PA_TST']
w = int(addon.getSetting('watchzone'))
offset = [240,-480,-300,600]

re = int(addon.getSetting('region'))

server = ['1','7']
s = int(addon.getSetting('server'))

host = 'ivsmedia.iptv-distribution.net'
proxy = 'ivsmedia.iptv-distribution.net'
port = 80

class LiveChannel:
    def __init__(self, id, name, descr, times):
        self.id = id
        self.name = name
        self.descr = descr
        self.times = times

def LoadTV(sess):
    url = '/handlers/boxee/channelhandler.ashx?sid=' + sess
    conn = httplib.HTTPConnection('ivsmedia.iptv-distribution.net')
    conn.request('GET', url)
    response = conn.getresponse()
    data = response.read()
    soup = BeautifulStoneSoup(data)
    items = soup.findAll("item")
    channels = []
    for item in items:
        sup = BeautifulSoup(item.prettify())
        name = sup('title')[0].text.encode('utf-8')
        id = item.find('link').string.strip()
        descr = sup('description')[0].text.encode('utf-8')
        times = sup('media:category')[0].text.encode('utf-8')
        channels.append(LiveChannel(str(id), str(name), str(descr), str(times)))
    return channels

class Channel:
    def __init__(self, id, name):
        self.id = id
        self.name = name         

def GetClientChannel(SessionID='', type = 'LiveTV'):
    items = []
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientChannels xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + SessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:type>' + type + '</d4p1:type></request></GetClientChannels></s:Body></s:Envelope>'
    soup = BeautifulSoup(Request(req, 'GetClientChannels'))
    try:
        chn = soup('a:channel')
        for i in chn:
            sup = BeautifulSoup(i.prettify())
            id = sup('a:id')[0].text
            name = sup('a:name')[0].text.encode('utf-8')
            items.append(Channel(id,name))
    except:
        pass        
    return items

class Program:
    def __init__(self, name, id, descr, length, cont, startTime,num):
        self.id = id
        self.name = name
        self.descr = descr
        self.length = length
        self.cont = cont
        self.startTime = startTime
        self.num = num
        
class ParseProgram:
    items = []
    tpage = '1'
    def __init__(self, str):
        soup = BeautifulSoup(str)
        try:
            self.tpage = soup("b:totalpages")[0].text
        except:
            self.tpage = "1"
        
        d = soup("a:programguideitem")
        for i in range(len(d)):
            c = d[i]
            sup = BeautifulSoup(c.prettify())
            name = sup("a:name")[0].text.encode('utf-8')
            length = sup("a:length")[0].text
            cont = sup("a:iscontainer")[0].text
            descr = sup("a:description")[0].text.encode('utf-8')
            descr = descr.replace('&#xD;', '')
            id = sup("a:id")[0].text
            startTime = sup("a:starttime")[0].text
            try:
                num = sup("a:episodenum")[0].text + '. '
            except:
                num = '';
            self.items.append(Program(name, id, descr, length, cont, startTime,num))
        
            
class Movie:
    def __init__(self, name, id, descr, length, cont, startTime,num):
        self.id = id
        self.name = name
        self.descr = descr
        self.length = length
        self.cont = cont
        self.startTime = startTime
        self.num = num
        
class ParseMovie:
    items = []
    tpage = '1'
    def __init__(self, str):
        soup = BeautifulSoup(str)
        try:
            self.tpage = soup("b:totalpages")[0].text
        except:
            self.tpage = "1"
        d = soup("a:ondemanditem")
        for i in range(len(d)):
            c = d[i]
            sup = BeautifulSoup(c.prettify())
            name = sup("a:name")[0].text.encode('utf-8')
            length = sup("a:length")[0].text
            cont = sup("a:iscontainer")[0].text
            descr = sup("a:description")[0].text.encode('utf-8')
            descr = descr.replace('&#xD;', '')
            id = sup("a:id")[0].text
            try:
                num = sup("a:episodenum")[0].text + '. '
            except:
                num = '';
            startTime = sup("a:item_date")[0].text
            self.items.append(Movie(name, id, descr, length, cont, startTime,num))

def GetClientProgramGuideByDate(SessionID='', id='', type = 'LiveTV', date='', page='1', items='100', datetill=''):
    if datetill == '':
        datetill = date
    
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientProgramGuide xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + SessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:filter><d4p1:contentType>' + type +'</d4p1:contentType><d4p1:date>' + date + 'T00:00:00</d4p1:date><d4p1:dateTill>' + datetill + 'T23:00:00</d4p1:dateTill>' \
          '</d4p1:filter><d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>' + type + '</d4p1:type><d4p1:requestType>SearchByDateRange</d4p1:requestType><d4p1:channelID>' + id + '</d4p1:channelID>' \
          '<d4p1:streamZone>' + region[re] + '</d4p1:streamZone><d4p1:watchingZone>' + wZone[w] + '</d4p1:watchingZone></request></GetClientProgramGuide></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientProgramGuide')
    return ParseProgram(resp)

def GetClientProgramGuideByGenre(sessionID, id, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientProgramGuide xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:filter><d4p1:contentGenre><d4p1:genreType>ArcplusGenreType</d4p1:genreType><d4p1:id>' + id + '</d4p1:id></d4p1:contentGenre><d4p1:contentType>ArcPlus</d4p1:contentType>' \
          '</d4p1:filter><d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>ArcPlus</d4p1:type><d4p1:requestType>AllItems</d4p1:requestType></request></GetClientProgramGuide></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientProgramGuide')
    return ParseProgram(resp)

def GetClientProgramGuideByTop(sessionID, type, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientProgramGuide xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><type>ArcPlus</type><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>ArcPlus</d4p1:type><d4p1:requestType>' + type + '</d4p1:requestType></request></GetClientProgramGuide></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientProgramGuide')
    return ParseProgram(resp)

def GetClientProgramGuideByName(sessionID, keyword, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientProgramGuide xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:filter><d4p1:contentType>ArcPlus</d4p1:contentType><d4p1:keyWord>'  + keyword.decode('utf-8') + '</d4p1:keyWord></d4p1:filter>' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page +'</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>ArcPlus</d4p1:type><d4p1:requestType>SearchByName</d4p1:requestType></request></GetClientProgramGuide></s:Body></s:Envelope>'
    req = req.encode('utf-8')
    resp = Request(req, 'GetClientProgramGuide')
    return ParseProgram(resp)

def GetClientRelatedProgramGuide(sessionID, id, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientRelatedProgramGuide xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:filter><d4p1:orderBy>movie_date DESC</d4p1:orderBy></d4p1:filter><d4p1:type>ArcPlus</d4p1:type><d4p1:id>' + id + '</d4p1:id><d4p1:relatedType>children</d4p1:relatedType></request>' \
          '</GetClientRelatedProgramGuide></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientRelatedProgramGuide')
    return ParseProgram(resp)


def GetClientOnDemandContentByGenre(sessionID, id, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientOnDemandContent xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID +'</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:filter><d4p1:contentGenre><d4p1:genreType>VodGenreType</d4p1:genreType><d4p1:id>' + id + '</d4p1:id></d4p1:contentGenre><d4p1:contentType>VOD</d4p1:contentType>' \
          '</d4p1:filter><d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items +'</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>VOD</d4p1:type><d4p1:requestType>AllItems</d4p1:requestType></request></GetClientOnDemandContent></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientOnDemandContent')
    return ParseMovie(resp)

def GetClientOnDemandContentByType(sessionID, type, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientOnDemandContent xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>VOD</d4p1:type><d4p1:requestType>' + type + '</d4p1:requestType></request></GetClientOnDemandContent></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientOnDemandContent')
    return ParseMovie(resp)

def GetClientOnDemandContentByDay(sessionID, id, items, page):
    days = ['Today','Yesterday','BeforeYesterday','ThreeDaysAgo','FourDaysAgo','FiveDaysAgo','SixDaysAgo','SevenDaysAgo']
    k = int(id)
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientOnDemandContent xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>VOD</d4p1:type><d4p1:requestType>' + days[k] + '</d4p1:requestType></request></GetClientOnDemandContent></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientOnDemandContent')
    return ParseMovie(resp)

def GetClientOnDemandContentByName(sessionID, keyword, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientOnDemandContent xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:filter><d4p1:contentType>VOD</d4p1:contentType><d4p1:keyWord>'  + keyword.decode('utf-8') + '</d4p1:keyWord></d4p1:filter>' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page +'</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:type>VOD</d4p1:type><d4p1:requestType>SearchByName</d4p1:requestType></request></GetClientOnDemandContent></s:Body></s:Envelope>'
    req = req.encode('utf-8')
    resp = Request(req, 'GetClientOnDemandContent')
    return ParseMovie(resp)


def GetClientRelatedOnDemandContent(sessionID, id, items, page):
    req = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientRelatedOnDemandContent xmlns="http://ivsmedia.iptv-distribution.net">' \
          '<sessionID>' + sessionID + '</sessionID><request xmlns:d4p1="http://schemas.datacontract.org/2004/07/IVS.Content.Data" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">' \
          '<d4p1:paging xmlns:d5p1="http://schemas.datacontract.org/2004/07/IVS.Common"><d5p1:itemsOnPage>' + items + '</d5p1:itemsOnPage><d5p1:pageNumber>' + page + '</d5p1:pageNumber>' \
          '</d4p1:paging><d4p1:filter><d4p1:orderBy>movie_date ASC</d4p1:orderBy></d4p1:filter><d4p1:type>VOD</d4p1:type><d4p1:id>' + id + '</d4p1:id><d4p1:relatedType>children</d4p1:relatedType></request></GetClientRelatedOnDemandContent></s:Body></s:Envelope>'
    resp = Request(req, 'GetClientRelatedOnDemandContent')
    return ParseMovie(resp)


class ObjGenres:
    def __init__(self, code, type, id, count, name, parent):
        self.code = code
        self.type = type
        self.id = id
        self.count = count
        self.name = name
        self.parent = parent
  
def GetClientGenres(str, coun):    
    Items = []
    soup = BeautifulSoup(str)
    d = soup("a:contentgenre")
    for i in range(len(d)):
        if len(d[i]) == 1:
            c = d[i].contents[0]
            sup = BeautifulSoup(c.prettify())
            name = sup("a:name")[0].text.encode('utf-8')
            code = sup("a:code")[0].text
            type = sup("a:genretype")[0].text
            id = sup("a:id")[0].text
            count = sup("a:itemcount")[0].text
            parent = sup("a:parentid")[0].text
        else:
            c = d[i]
            sup = BeautifulSoup(c.prettify())
            name = sup("a:name")[0].text.encode('utf-8')
            code = sup("a:code")[0].text
            type = sup("a:genretype")[0].text
            id = sup("a:id")[0].text
            count = sup("a:itemcount")[0].text
            parent = sup("a:parentid")[0].text            
        if parent == coun:
            Items.append(ObjGenres(code, type, id, count, name, parent))       
    return Items

def GenreRequest(sID, type):
     gtype = ['ArcplusGenreType', 'VodGenreType']
     i = int(type)
     req = \
        '<?xml version="1.0" encoding="utf-8"?>' \
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><GetClientContentGenres xmlns="http://ivsmedia.iptv-distribution.net"><sessionID>{sessionID}</sessionID><type>{GTYPE}</type></GetClientContentGenres></s:Body></s:Envelope>'
     req = req.replace('{sessionID}', sID).replace('{GTYPE}',gtype[i])        
     conn = httplib.HTTPConnection(proxy, port)
     conn.request('POST', '/ContentService.svc/soap', req, {
            'Host': host,                                          
            'SOAPAction': 'http://' + host + '/ContentService/GetClientContentGenres',
            'Content-Type': 'text/xml; charset=utf-8'
     })
     response = conn.getresponse()
     return response.read()



def Request(str, action):
    conn = httplib.HTTPConnection(proxy, port)
    conn.request('POST', '/ContentService.svc/soap', str, {
           'Host': host,
           'SOAPAction': 'http://' + host + '/ContentService/' + action,
           'Content-Type': 'text/xml; charset=utf-8'
          
           })                                            
    response = conn.getresponse()
    data = response.read()
    
    return data



