# coding=utf-8
#
# <BestRussianTV plugin for XBMC>
# Copyright (C) <2012>  <BestRussianTV>
#
#       This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
# -*- coding: utf-8 -*-
import os
import sys, datetime, time, calendar, thread, threading
import xbmc, xbmcgui, xbmcplugin, urllib
import MediaService, ClientService, ContentService, RusKeyboard
from BeautifulSoup import BeautifulSoup

try:
    # new XBMC 10.05 addons:
    import xbmcaddon
except ImportError:
    # old XBMC - create fake xbmcaddon module with same interface as new XBMC 10.05
    class xbmcaddon:
        """ fake xbmcaddon module """
        __version__ = "(old XBMC)"
        class Addon:
            """ fake xbmcaddon.Addon class """
            def __init__(self, id):
                self.id = id

            def getSetting(self, key):
                return xbmcplugin.getSetting(key)

            def openSettings(self):
                xbmc.openSettings()
            def setSetting(self, key, value):
                return xbmcplugin.setSetting(key, value)

addon = xbmcaddon.Addon("plugin.video.brt")
Username = addon.getSetting("username")
Password = addon.getSetting("password")
iconpath = os.path.join(xbmc.translatePath(addon.getAddonInfo('path')), 'icon')

def addItem(name = '', mode = '', isFolder = False, id='', description = '', icon = '', page = '1', rating = 0, duration = '', year = '', month = '', day = '', date = '', type = '', keyword = '', stream = ''):
    url = sys.argv[0] + '?name=' + urllib.quote_plus(name) + '&mode=' + mode + '&id=' + id + '&page=' + page + '&year=' + year + '&month=' + month + '&day=' + day + '&icon=' + urllib.quote_plus(icon) + '&type=' + type + '&keyword=' + keyword + '&date=' + date + '&stream=' + urllib.quote_plus(stream) 
    if description != '':
        url = url + '&description=' + urllib.quote_plus(description)
    if icon == '':
        if isFolder == True:
            liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png")
        else:
            liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png")
    else:
        liz = xbmcgui.ListItem(name, thumbnailImage = icon)
    liz.setInfo(type="Video", infoLabels={ "Title": name, "Plot": description, "Rating": rating, "Duration": duration })
    return xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = url, listitem = liz, isFolder = isFolder)

if addon.getSetting('imageTemp') == '':
    imageUrl = MediaService.MediaImageUrlTemplate()
    addon.setSetting('imageTemp', imageUrl)

def getImage(id, t):
    imageUrl = addon.getSetting('imageTemp')
    imageUrl = imageUrl.replace('{0}',id).replace('{1}',t).replace('&amp;n={2}','').replace('&amp;', '&')
    return imageUrl

def loop(seconds):
    while xbmc.Player().isPlaying()==False:
            time.sleep(1)
    xbmc.Player().seekTime(seconds)
            
    
def SessionID():
    if Username != "" and Password != "":
        try:
            x =  ClientService.Login(Username, Password)
        except:
            xbmcgui.Dialog().ok("BRTV", "Нет соединения с сервером", "")
        if x != "":
            return x
        else:
            xbmcgui.Dialog().ok("BRTV", "Неверный Логин или Пароль", "")
            addon.openSettings()
            xbmc.executebuiltin('XBMC.Resolution(' + addon.getSetting('resolution') + ')')            
            x =  ClientService.Login(addon.getSetting("username"), addon.getSetting("password"))
            if x !='':
                return x
            else:
                xbmcgui.Dialog().ok("BRTV", "Неверный Логин или Пароль", "")   
    else:
        xbmcgui.Dialog().ok("BRTV", "Введите Логин и Пароль", "")
        addon.openSettings()            
        xbmc.executebuiltin('XBMC.Resolution(' + addon.getSetting('resolution') + ')')
        xbmc.executebuiltin('XBMC.Container.Refresh()') 
        x =  ClientService.Login(Username, Password)
        return x   

def GetInHMS(seconds):
    hours = seconds / 3600
    seconds -= 3600*hours
    minutes = seconds / 60
    seconds -= 60*minutes
    ti = "%02d:%02d:%02d" % (hours, minutes, seconds)
    ti = str(ti) 
    return ti

def dayweek(y, m, d):
    return datetime.date(y, m, d).weekday()

def timeplay(n):
    if ('.' in  n):
        n = n[:19] 
    t = time.strptime(n, "%Y-%m-%dT%H:%M:%S")
    t = time.strftime("%Y-%m-%d %H:%M", t)   
    return t

def timeplayT(n):
    if ('.' in  n):
        n = n[:19] 
    t = time.strptime(n, "%Y-%m-%dT%H:%M:%S")
    t = time.strftime("%H:%M", t)   
    return t

def timeplayY(n):
    if ('.' in  n):
        n = n[:19] 
    t = time.strptime(n, "%Y-%m-%dT%H:%M:%S")
    t = time.strftime("%Y", t)   
    return t

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?','')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

params = get_params()
name = ''
mode = None
id = ''
page = '1'
year = ''
month = ''
day = ''
icon = ''
date = ''
type = ''
keyword = ''
description = ''
stream = ''
try:    name = urllib.unquote_plus(params["name"])
except: pass
try:    description = urllib.unquote_plus(params["description"])
except: pass
try:    stream = urllib.unquote_plus(params["stream"])
except: pass
try:    mode = params["mode"]
except: pass
try:    id = params["id"]
except: pass
try:    page = params['page']
except: pass
try:    year = params['year']
except: pass
try:    month = params['month']
except: pass
try:    day = params['day']
except: pass
try:    date = params['date']
except: pass
try:    type = params['type']
except: pass
try:    keyword = params['keyword']
except: pass
try:    icon = urllib.unquote_plus(params['icon'])
except: pass

daysofweek = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
months = ["Январь","Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август" ,"Сентябрь" ,"Октябрь" ,"Ноябрь" ,"Декабрь"]
monthday = ["Января","Февраля", "Марта", "Апреля", "Мая", "Июня", "Июля", "Августа" ,"Сентября" ,"Октября" ,"Ноября" ,"Декабря"]

try:
    if mode == None or mode == "":
        list = ""
        addon.setSetting('chlist', list)    
        addon.setSetting('imageTemp', '')
        addItem('Прямой эфир', 'LiveTV', True, icon=os.path.join(iconpath, 'icon_tv_live.png'))
        addItem('Архив', 'archive', True, icon=os.path.join(iconpath, 'icon_tv_archive.png'))
        addItem("Видеотека", "vod", True, icon=os.path.join(iconpath, 'icon_movies.png'))
        addItem('Телетека', 'ArcPlus', True, icon=os.path.join(iconpath, 'icon_teleteka.png'))
        addItem("Радио", "radio", True, icon=os.path.join(iconpath, 'icon_radio.png'))
        addItem('Поиск', 'Search', True)
        addItem("Настройки", "setting", False, "")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "setting": 
        addon.openSettings()
        ClientService.SetSett(SessionID())
        xbmc.executebuiltin('XBMC.Resolution(' + addon.getSetting('resolution') + ')')

    elif mode == 'LiveTV': 
        channels = ContentService.LoadTV(SessionID()) #+++++
        for channel in channels:
            icon = getImage(channel.id, '4')
            name = channel.name + '  ' + channel.times + '  ' + channel.descr
            addItem(name, 'LiveStream', False, channel.id, channel.descr, icon)   
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    elif mode == 'LiveStream':    
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        video = MediaService.GetClientStreamUri(SessionID(), 'LiveTV' ,id)
        if video.startswith('http://'):
            video = urllib.unquote(video)
            video = video.replace('http://','mms://').replace('&amp;','&') + '&MSWMExt=.asf'
        else:
            video = urllib.unquote(video)
            video = video.replace('&amp;','&')
        cat = description.replace('\n', ". ")
        cat = name  + ". " + cat
        icon = getImage(id, '4')
        listitem = xbmcgui.ListItem(cat, thumbnailImage=icon)
        listitem.setInfo('video', {'title' : cat})
        playlist.add(url=video, listitem=listitem, index=7)
        xbmc.Player().play(playlist)
    
    elif mode == 'ArcPlus':
        addon.setSetting("GenreXml","")
        addItem('Каналы', 'ArcPlusCh', True)
        addItem('Жанры', 'ArcPlusGenre', True)
        addItem('Лучшее', 'ArcBest', True)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    elif mode == 'ArcPlusCh':
        channels = ContentService.GetClientChannel(SessionID(), 'ArcPlus')
        for channel in channels:
            icon = getImage(channel.id, '4')
            addItem(channel.name, 'ArcTimes', True, channel.id, icon = icon)
        xbmcplugin.endOfDirectory(int(sys.argv[1])) #+++

    elif mode == 'ArcTimes':
        today = datetime.date.today() 
        addItem('Сегодня', 'ArcDay', True, id, icon = icon, year=str(today.year), month=str(today.month), day=str(today.day))
        addItem('За неделю', 'ArcWeek', True, id, icon = icon)
        addItem('За месяц', 'ArcMonth', True, id, icon = icon)
        for i in range(2009, today.year + 1):
            addItem(str(i) + " год", "ArcYear", True, id, "", icon, year=str(i))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'ArcWeek':
        today = datetime.date.today()
        for i in range (0, 7):
            day1 = today - datetime.timedelta(days=i)
            daten = daysofweek[dayweek(day1.year, day1.month, day1.day)]
            addItem(daten + ", " + str(day1.day) + " " + monthday[(int(day1.month)-1)], "ArcDay", True, id, "", icon,  year=str(day1.year), month=str(day1.month), day=str(day1.day))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'ArcMonth':
        today = datetime.date.today()
        for i in range (0, 30):
            day1 = today - datetime.timedelta(days=i)
            daten = daysofweek[dayweek(day1.year, day1.month, day1.day)]
            addItem(daten + ", " + str(day1.day) + " " + monthday[(int(day1.month)-1)], "ArcDay", True, id, "", icon,  year=str(day1.year), month=str(day1.month), day=str(day1.day))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    elif mode ==  'ArcDay':
        date = datetime.date(int(year), int(month), int(day))
        channels = ContentService.GetClientProgramGuideByDate(SessionID(), id, 'ArcPlus', date.strftime("%Y-%m-%d"))
        for channel in channels.items:
            t = timeplayT(channel.startTime)
            icon = getImage(channel.id, '16')
            addItem(t + ' ' + channel.name, "ArcPlusPlay", False, channel.id, channel.descr, icon = icon, duration=GetInHMS(int(channel.length)))
        xbmcplugin.endOfDirectory(int(sys.argv[1])) #++++
       
    elif mode== 'ArcYear':
        today = datetime.date.today()
        if year == str(today.year):
            for i in range(0, today.month):
                addItem(months[i] + ", " + year, "ArcMonth", True, id, "", icon, year=year, month=str(i+1))     
        else:
            for i in range(0,12):
                addItem(months[i] + ", " + year, "ArcMonth", True, id, "", icon, year=year, month=str(i+1))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'ArcMonth':
        today = datetime.date.today()
        if month == str(today.month):
            if year == str(today.year):
                for i in range(1, today.day + 1):
                    daten = daysofweek[dayweek(today.year, today.month, i)]
                    year = str(today.year)
                    month = str(today.month)
                    addItem(daten + ", " + str(i) + " " + monthday[(int(month)-1)], "ArcDay", True, id, "", icon, year=year, month=month, day=str(i))
            else:
                lastday = calendar.monthrange(int(year), int(month))[1]
                for i in range(1, lastday + 1):
                    daten = daysofweek[dayweek(int(year), int(month), i)]
                    addItem(daten + ", " + str(i) + " " + monthday[(int(month)-1)], "ArcDay", True, id, "", icon, year=year, month=month, day=str(i))
        else:
            lastday = calendar.monthrange(int(year), int(month))[1]
            for i in range(1, lastday + 1):
                daten = daysofweek[dayweek(int(year), int(month), i)]
                addItem(daten + ", " + str(i) + " " + monthday[(int(month)-1)], "ArcDay", True, id, "", icon, year=year, month=month, day=str(i))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    elif mode == 'ArcPlusGenre':
        channels = ContentService.GetClientGenres(ContentService.GenreRequest(SessionID(), 0),"0")
        for channel in channels:
                addItem(channel.name, "ArcPlusGenreSub", True, channel.id)       
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    elif mode == 'ArcPlusGenreSub':
        channels = ContentService.GetClientGenres(ContentService.GenreRequest(SessionID(), 0), id)
        if len(channels) == 0:
            channels = ContentService.GetClientProgramGuideByGenre(SessionID(), id, '40', page)
            for channel in channels.items:
                icon = getImage(channel.id, '16')
                t = timeplay(channel.startTime)
                if channel.cont == 'true':
                    addItem(channel.name, "ArcPlusGenreMovie", True, channel.id, channel.descr, icon = icon, page = '1')
                else:
                    addItem(t + ' ' + channel.name, "ArcPlusPlay", False, channel.id, channel.descr, icon = icon, duration=GetInHMS(int(channel.length)))
            if int(channels.tpage) > int(page):
                page = str(int(page) + 1)
                addItem("...Следующая страница...","ArcPlusGenreSub",True, id, page=page)
            if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
                addItem("На главную", "", True, "0")
        else: 
            for channel in channels:
                addItem(channel.name, "ArcPlusGenreSub", True, channel.id)       
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'ArcPlusGenreMovie':
        channels = ContentService.GetClientRelatedProgramGuide(SessionID(), id, '40', page)
        for channel in channels.items:
                t = timeplay(channel.startTime)
                icon = getImage(channel.id, '16')
                addItem(t + ' ' + str(channel.num) + channel.name, "ArcPlusPlay", False, channel.id, channel.descr, icon = icon, duration=GetInHMS(int(channel.length)))
        if int(channels.tpage) > int(page):
                page = str(int(page) + 1)
                addItem("...Следующая страница...","ArcPlusGenreMovie",True, id, page=page)
        xbmcplugin.endOfDirectory(int(sys.argv[1])) #+++

    elif mode == 'ArcBest':
        channels = []
        if type == "":
            addItem("За неделю", "ArcBest", True, "", type = "week")
            addItem("За месяц", "ArcBest", True, "", type = "month")
            addItem("За все время", "ArcBest", True, "", type = "all")
        elif type == "week":
            rr = ContentService.GetClientProgramGuideByTop(SessionID(),'TopHundredWatchedWeek','100', '1')
            channels = rr.items
        elif type == "month":
            rr = ContentService.GetClientProgramGuideByTop(SessionID(),'TopHundredWatchedMonth','100', '1')
            channels = rr.items
        elif type == "all":
            rr = ContentService.GetClientProgramGuideByTop(SessionID(),'TopHundredWatched','100', '1')
            channels = rr.items        
        for channel in channels:
            t = timeplay(channel.startTime)
            icon = getImage(channel.id, '16')
            if id == channel.id:
                addItem(t + " " + channel.name, "ArcPlusPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
            else:
                if channel.cont == "true":
                    addItem(channel.name, "ArcPlusGenreMovie", True, channel.id, channel.descr, icon)
                else:
                    addItem(t + " " + channel.name, "ArcPlusPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'ArcPlusPlay':
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        video = MediaService.GetClientStreamUri(SessionID(), 'ArcPlus' ,id)
        if video.startswith('http://'):
            video = urllib.unquote(video)
            video = video.replace('http://','mms://').replace('&amp;','&') + '&MSWMExt=.asf'
        cat = description.replace('\n', ". ")
        cat = '"' + name + '"' + ". " + cat
        icon = getImage(id, '16')
        listitem = xbmcgui.ListItem(name, thumbnailImage=icon)
        listitem.setInfo('video', {'title' : cat})
        playlist.add(url=video, listitem=listitem, index=7)
        xbmc.Player().play(playlist) #+++

    elif mode == "archive":
        channels = ContentService.GetClientChannel(SessionID(), type = 'LiveTV')
        for channel in channels:  
            icon = getImage(channel.id, '7') 
            addItem(channel.name, "archchannel", True, channel.id, "", icon) 
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "archchannel":
        for d in range(0, 14):
            dt = datetime.date.today() - datetime.timedelta(days = d)
            addItem(dt.strftime("%Y-%m-%d, ") + daysofweek[dt.weekday()], "archprograms", True, id=id, icon=icon, date=dt.strftime("%Y-%m-%d"))
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "archprograms":
        channels = ContentService.GetClientProgramGuideByDate(SessionID(), id, 'LiveTV', date)
        for channel in channels.items:
            t = timeplayT(channel.startTime)
            icon = getImage(channel.id, '4')
            addItem(t + ' ' + channel.name, "archplay", False, channel.id ,icon=icon, description=channel.descr)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "archplay":
        video = MediaService.GetArcStreamUri(SessionID(), id)
        soup = BeautifulSoup(video)
        starttime = []
        pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        pl.clear()   
        for entry in soup('entry'):
            sup = BeautifulSoup(entry.prettify())
            starttime.append(sup.find('starttime').attrs[0][1])
            pl.add(sup.find('ref').attrs[0][1])
        start = []
        start = starttime[0].split(':')
        seconds = 0
        if len(start) == 3:
            seconds = int(start[2]) + (int(start[1])*60) + (int(start[0])*3600)
        elif len(start) == 2:
            seconds = int(start[1]) + (int(start[0])*60)
        xbmc.Player().play(pl)
        xbmc.Player().seekTime(seconds)

    elif mode == "Search":
        addItem("Телетека", "key", False, "", type="0")
        addItem("Видеотека", "key", False, "", type="1")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "key":
        keyboard = RusKeyboard.Key()
        keyboard.type = type
        keyboard.urlpath = sys.argv[0]
        keyboard.doModal()
        del keyboard

    elif mode == "search1":
        if type == '0':
            channels = ContentService.GetClientProgramGuideByName(SessionID(), keyword, '40', page)
        else:
            channels = ContentService.GetClientOnDemandContentByName(SessionID(), keyword, '40', page) 
        for channel in channels.items:
            if type == '0':
                icon = getImage(id, '16')
                t = timeplay(channel.startTime)
                addItem(t + " " + channel.name, "ArcPlusPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
            else:
                icon = getImage(id, '1') 
                t = ''
                if id == channel.id:
                    addItem(t + " " + channel.name, "VodPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
                else:
                    if channel.cont == "true":
                        addItem(channel.name, "GetRelVOD", True, channel.id, channel.descr, icon)
                    else:
                            addItem(t + " " + channel.name, "VodPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
        if int(channels.tpage) > int(page):
            p = int(page) + 1
            addItem("...Следующая страница...","search1",True, "0", page=str(p), keyword=keyword, type=type)
        if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
            addItem("На главную", "", True, "0")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
  
    elif mode == 'VodPlay':
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        video = MediaService.GetClientStreamUri(SessionID(), 'VOD' ,id)
        if video.startswith('http://'):
            video = urllib.unquote(video)
            video = video.replace('http://','mms://').replace('&amp;','&') + '&MSWMExt=.asf'
        cat = description.replace('\n', ". ")
        cat = '"' + name + '"' + ". " + cat
        icon = getImage(id, '1')
        print video
        listitem = xbmcgui.ListItem(cat, thumbnailImage=icon)
        listitem.setInfo('video', {'title' : cat})
        playlist.add(url=video, listitem=listitem, index=7)
        xbmc.Player().play(playlist) 
        
    elif mode == "vod":
        addItem("Добавления за неделю", "vodlastweek", True, "")
        addItem("Жанры", "vodgenres", True, "")
        addItem("Поступления", "vodnewest", True, "")
        addItem("Топ 100", "vodtop100", True, "")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "vodlastweek":
        addItem("Сегодня", "vodbyday", True, "0")
        addItem("1 день назад", "vodbyday", True, "1")
        addItem("2 дня назад", "vodbyday", True, "2")
        addItem("3 дня назад", "vodbyday", True, "3")
        addItem("4 дня назад", "vodbyday", True, "4")
        addItem("5 дней назад", "vodbyday", True, "5")
        addItem("6 дней назад", "vodbyday", True, "6")
        addItem("7 дней назад", "vodbyday", True, "7")
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == "vodbyday":
        channels = ContentService.GetClientOnDemandContentByDay(SessionID(), id, '40', page)
        for channel in channels.items:
            t = timeplayY(channel.startTime)
            addItem(channel.name + ', ' + t + 'г.', "VodPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
        if int(channels.tpage) > int(page):
            p = int(page) + 1
            addItem("...Следующая страница...","vodbyday", True, "0", page=str(p), keyword=keyword, type=type)
        if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
            addItem("На главную", "", True, "0")    
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'vodgenres':
        channels = ContentService.GetClientGenres(ContentService.GenreRequest(SessionID(), 1),"0")
        for channel in channels:
            addItem(channel.name, "vodsubgenres", True, channel.id)       
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
    elif mode == 'vodsubgenres':
        channels = ContentService.GetClientGenres(ContentService.GenreRequest(SessionID(), 1), id)
        if len(channels) == 0:
            channels = ContentService.GetClientOnDemandContentByGenre(SessionID(), id, '40', page)
            for channel in channels.items:
                icon = getImage(channel.id, '1')
                t = timeplayY(channel.startTime)
                if channel.cont == 'true':
                    addItem(channel.name + ', ' + t + 'г.', "GetRelVOD", True, channel.id, channel.descr, icon = icon, page = '1')
                else:
                    addItem(channel.name + ', ' + t + 'г.', "VodPlay", False, channel.id, channel.descr, icon = icon, duration=GetInHMS(int(channel.length)))
            if int(channels.tpage) > int(page):
                page = str(int(page) + 1)
                addItem("...Следующая страница...","vodsubgenres",True, id, page=page)
            if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
                addItem("На главную", "", True, "0")
        else: 
            for channel in channels:
                addItem(channel.name, "vodsubgenres", True, channel.id)       
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'GetRelVOD':
        channels = ContentService.GetClientRelatedOnDemandContent(SessionID(), id, '40', page)
        for channel in channels.items:
            print channel.num
            addItem(str(channel.num)+channel.name, "VodPlay", False, channel.id, channel.descr, icon, duration=GetInHMS(int(channel.length)))
        if int(channels.tpage) > int(page):
            p = int(page) + 1
            addItem("...Следующая страница...","GetRelVOD",True, "0", page=str(p), keyword=keyword, type=type)
        if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
            addItem("На главную", "", True, "0")    
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'vodnewest':
        channels = ContentService.GetClientOnDemandContentByType(SessionID(), 'JustAdded', '40', page)
        for channel in channels.items:
            t = timeplayY(channel.startTime)
            if channel.cont == 'true':
                addItem(channel.name + ', ' + t + 'г.', "GetRelVOD", True, channel.id, channel.descr, icon = icon, page = '1')
            else:
                addItem(channel.name + ', ' + t + 'г.', "VodPlay", False, channel.id, channel.descr, icon = icon, duration=GetInHMS(int(channel.length)))
        if int(channels.tpage) > int(page):
            p = int(page) + 1
            addItem("...Следующая страница...","vodnewest",True, "0", page=str(p), keyword=keyword, type=type)
        if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
            addItem("На главную", "", True, "0")    
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    elif mode == 'vodtop100':
        channels = ContentService.GetClientOnDemandContentByType(SessionID(), 'TopHundredWatched', '40', page)
        for channel in channels.items:
            t = timeplayY(channel.startTime)
            if channel.cont == 'true':
                addItem(channel.name + ', ' + t + 'г.', "GetRelVOD", True, channel.id, channel.descr, icon = icon, page = '1')
            else:
                addItem(channel.name + ', ' + t + 'г.', "VodPlay", False, channel.id, channel.descr, icon = icon, duration=GetInHMS(int(channel.length)))
        if int(channels.tpage) > int(page):
            p = int(page) + 1
            addItem("...Следующая страница...","vodtop100",True, "0", page=str(p), keyword=keyword, type=type)
        if int(channels.tpage) == int(page) or int(channels.tpage) > int(page):
            addItem("На главную", "", True, "0")    
        xbmcplugin.endOfDirectory(int(sys.argv[1]))    

    elif mode == 'radio': 
        channels = ContentService.GetClientChannel(SessionID(), 'Radio')
        for channel in channels:
            icon = getImage(channel.id, '7')
            addItem(channel.name, 'radioplay', False, channel.id)   
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    elif mode == 'radioplay':    
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        video = MediaService.GetClientStreamUri(SessionID(), 'Radio' ,id)
        if video.startswith('http://'):
            video = urllib.unquote(video)
            video = video.replace('http://','mms://').replace('&amp;','&') + '&MSWMExt=.asf'
        else:
            video = urllib.unquote(video)
            video = video.replace('&amp;','&')
        cat = name
        icon = getImage(id, '4')
        listitem = xbmcgui.ListItem(cat, thumbnailImage=icon)
        listitem.setInfo('video', {'title' : cat})
        playlist.add(url=video, listitem=listitem, index=7)
        xbmc.Player().play(playlist)

except:
    xbmcgui.Dialog().ok("BRTV", "Нет соединения с сервером", "")   
