#
from BeautifulSoup import BeautifulSoup
import xbmc, xbmcgui, xbmcplugin, urllib2, urllib, re, string, sys, os, traceback, xbmcaddon
#from subprocess import call
import glob

__plugin__ = 'nes'
__author__ = 'jacker <xbmc@causal.ca>'
__url__ = 'http://www.causal.ca'
__svn_url__ = "https://svn.causal.ca:8888/aur/xbmc/"
__date__ = '02-20-2013'
__version__ = '1.1'
__XBMC_Revision__ = xbmc.getInfoLabel('System.BuildVersion')
__settings__ = xbmcaddon.Addon( id = 'plugin.video.nes' )

# debug level
logfile = __settings__.getSetting("log_file")
if(logfile == ""):
	debug = 0
else:
	debug = 1
	logfile = '>> '+logfile

#
##
#

def rompath():
	path = __settings__.getSetting("rom_dir")
	if debug > 0:
		os.system('echo " rompath='+path+'" '+logfile)
	return path

def fullpath(img):
	return os.path.join(__settings__.getAddonInfo( 'path' ), img)

def getfanart(name, path):
	return getimage(name+'.fanart', path)

def getimage(name, path):
	exts = ['.jpg', '.png', '.gif']
	for ext in exts:
		img = path+'/'+name+ext
		if(os.path.isfile(img)):
			return img
	return ''

def open_url(url):
	req = urllib2.Request(url)
	content = urllib2.urlopen(req)
	data = content.read()
	content.close()
	return data

#
##
#

def addLink(name, url, mode, thumbnail, plot, fanart, isDir):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": plot } )
	if(len(fanart) > 0):
		liz.setProperty('fanart_image', fanart)
	if isDir:
		ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	else:
		liz.setProperty('IsPlayable','true')
		ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz)
	return ok

def build_main():
	mode = 1
	path = rompath()
	roms = sorted(glob.glob(path+'/*nes'))
	xbmcplugin.setPluginFanart(handle=int(sys.argv[1]),image=fullpath('fanart.jpg'))
	for rom in roms:
		i = rom.rfind('/')
		name = rom[i+1:len(rom)-4]
		if debug > 1:
			os.system("echo 'roms="+rom+"' "+logfile)
			os.system("echo '  "+name+"' "+logfile)
		romimage = getimage(name, path)
		romart = getfanart(name, path)
		url = 'aprx://nes:'+rom
#		name = name.replace('_', ' ')
		addLink(name, url, mode, romimage, '', romart, False)

def build_play(name, url):
	liz=xbmcgui.ListItem(path=url)
	return xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)

#
##
#

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

#
# Main
if debug > 0:
	os.system("echo 'argv="+sys.argv[2]+"' "+logfile)

params=get_params()
url=None
name=None
mode=None
try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass

#
##
#

if mode==None or url==None or len(url)<1:
	build_main()
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True)
elif mode > 0:
	build_play(name, url)

#
