
XBMC Filmarkivet addon
----------------------

By Anders Karlsson (pugo@pugo.org)

This addon adds the possiblilty to watch films on Filmarkivet, an archive of
historical Swedish films, provided by the Swedish Film Institute.

The addon is loosely based on the the NRK addon by takoi.
