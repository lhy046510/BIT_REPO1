import xbmc,urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon
import os,base64
# -*- coding: iso-8859-9 -*-

__settings__ = xbmcaddon.Addon(id='plugin.video.happyfeetsosahne')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)
import xbmctools
l_check=xbmctools.inside()
if l_check:
        pass
else:
        xbmctools.hata()
        sys.exit()
######################@yigitki ve @xmaxell katkilarindan dolayi Drascoma tesekkur ederiz ... #########################

def CATEGORIES():
        addDir('[COLOR blue] <<< Bilgilendirme >>>[/COLOR]','Info',7,'http://happyfeets.net78.net/HFOTV/addon.png')     
        url='http://www.osahne.com/'
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()      
        response.close()
        match=re.compile('<li class=".*?"><a href="(.*?)" title=".*?">(.*?)</a></li>').findall(link)
        for url,name in match:
            url='http://www.osahne.com'+url
            addDir('[COLOR orange][B]-->'+name+'[/B][/COLOR]',url,20,'http://www.livestream.com/filestore/logos/osahne-small.jpg')
        addDir('[COLOR yellow]>>> Daha Fazla Kategori <<<[/COLOR]','http://www.osahne.com/',40,'http://www.livestream.com/filestore/logos/osahne-small.jpg')

def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('').findall(link)
        for thumbnail,url,name in match:
                addDir(name,url,2,thumbnail)

def liste(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb1',"i").replace('\xc3\xb6',"O").replace('\xc3\xbc',"u").replace('\xc5\x9f',"s").replace('\xc3\xa7',"c").replace('\xe2\x80\x93',"").replace('\xc4\xb0',"i").replace('&#8211;'," ").replace('&#8211;'," ").replace('\xc5\x9e',"S")#.replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<li class=".*?">\n\t\t\t\t\t<a href="(.*?)" title=".*?">\n\t\t\t\t\t\t<figure>\n\t\t\t\t\t\t\t<span class=".*?">\n\t\t\t\t\t\t\t\t<span>\n\t\t\t\t\t\t\t\t\t<span>\n\t\t\t\t\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)" title=".*?" />').findall(link)
        for url,thumbnail,name in match:
            url='http://www.osahne.com'+url
            addDir('[COLOR pink][B]-->'+name+'[/B][/COLOR]',url,30,thumbnail)

        sayfalama=re.compile('<div class="paging minOval">&nbsp;<strong>.*?</strong>&nbsp;<a href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in sayfalama:
            url='http://www.osahne.com'+url
            addDir('[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',url,20,'')

def daha(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb1',"i").replace('\xc3\xb6',"O").replace('\xc3\xbc',"u").replace('\xc5\x9f',"s").replace('\xc3\xa7',"c").replace('\xe2\x80\x93',"").replace('\xc4\xb0',"i").replace('&#8211;'," ").replace('&#8211;'," ").replace('\xc5\x9e',"S")#.replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<li><a style=".*?" href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
            url='http://www.osahne.com'+url
            addDir('[COLOR orange][B]-->'+name+'[/B][/COLOR]',url,20,'http://www.livestream.com/filestore/logos/osahne-small.jpg')

def Youtube(url):
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()

                you_match=re.compile('<iframe width=".*?" height=".*?" src="\/\/www.youtube.com\/embed\/(.*?)\?rel\=0&wmode\=transparent&autoplay\=1&showinfo\=0&modestbranding\=0" frameborder=".*?" allowfullscreen></iframe>').findall(link)
                print you_match
                for code in you_match:
                        yt=('plugin://plugin.video.youtube/?action=play_video&videoid='+str(code))
                        addLink('~~izle~~',yt,'')
                        playList.add(yt)
                xbmcPlayer.play(playList)
                if not xbmcPlayer.isPlayingVideo():
                        d = xbmcgui.Dialog()
                        d.ok('Sunucu Hatasi', 'Aranan Video Bulunamadi.','Baska Video Deneyiniz.')
                
def INFO(url):
  try:
        CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "Serverdan Kaldirilmamissa Hepsi Acilir.","Herkese iyi Kullanimlar.")
  except:
        
        pass 
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        index(url)

elif mode==7:
        print ""+url
        INFO(url)

elif mode==20:
        print ""+url
        liste(url)

elif mode==40:
        print ""+url
        daha(url)

elif mode==30:
        print ""+url
        Youtube(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
