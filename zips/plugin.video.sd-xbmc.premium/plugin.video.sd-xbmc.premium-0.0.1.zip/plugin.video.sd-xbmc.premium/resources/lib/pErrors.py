# -*- coding: utf-8 -*-
import os, string
import urllib, urllib2, re, sys, math
import xbmcgui, xbmc, xbmcaddon, xbmcplugin
import pLog

scriptID   = sys.modules[ "__main__" ].scriptID
t = sys.modules[ "__main__" ].language
sdp = xbmcaddon.Addon(scriptID)

GUI_PATH = os.path.join( sdp.getAddonInfo('path'), "gui" )
sys.path.append( GUI_PATH )

import msg

log = pLog.pLog()
dbg = sdp.getSetting('debug')

ERRORS = [
    [ 'HTTP Error 403: Forbidden', t(55900).encode('utf-8'), t(55901).encode('utf-8') ],
    [ 'urlopen error [Errno -2]', t(55900).encode('utf-8'), t(55902).encode('utf-8') ],
    [ 'No JSON object could be decoded', t(55903).encode('utf-8'), t(55904).encode('utf-8') ],
    [ '\'NoneType\' object has no attribute', t(55900).encode('utf-8'), t(55905).encode('utf-8') ],
    [ 'global name', t(55900).encode('utf-8'), t(55906).encode('utf-8') ],
    [ 'cannot concatenate', t(55900).encode('utf-8'), t(55906).encode('utf-8') ],
    [ 'expected string or buffer', t(55900).encode('utf-8'), t(55906).encode('utf-8') ],
    [ 'Expecting property name:', t(55900).encode('utf-8'), t(55906).encode('utf-8') ],
    [ 'urlopen error timed out', t(55900).encode('utf-8'), t(55907).encode('utf-8') ],
    [ '[Errno 2]', t(55900).encode('utf-8'), t(55906).encode('utf-8') ],
    [ '[Errno 10035]', t(55900).encode('utf-8'), t(55906).encode('utf-8') ],
    [ 'xml.parsers.expat.ExpatError', t(55900).encode('utf-8'), t(55908).encode('utf-8')],
    [ 'must be string or read-only character buffer', t(55900).encode('utf-8'), t(55909).encode('utf-8') ],
    [ 'not a valid non-string sequence or mapping object', t(55900).encode('utf-8'), t(55909).encode('utf-8') ],
]

class Exception:
    def __init__(self):
        pass
    
    def getError(self, error):
        title = ''
        content = ''
        d = msg.Windows()
        if dbg == 'true':
            log.info('Errors - getError()')
        for i in range(len(ERRORS)):
            log.debug('Errors - getError()[for] ' + ERRORS[i][0] + ' = ' + error)
            #if error == ERRORS[i][0]:
            #    log.info('Errors - getError()[for] ' + ERRORS[i][0] + ' = ' + error)
            #    title = ERRORS[i][1]
            #    content = ERRORS[i][2]
            #    break
            if ERRORS[i][0] in error:
                log.debug('Errors - getError()[for] ' + ERRORS[i][0] + ' = ' + error)
                title = ERRORS[i][1]
                content1 = ERRORS[i][2]
                content2 = error
                break
            elif (i + 1) == len(ERRORS):
                title = t(55900).encode('utf-8')
                content1 = t(55906).encode('utf-8')
                content2 = error
        d.Error(title, content1, content2)                     
