# -*- coding: utf-8 -*-
import re, sys, os
import xbmcaddon, xbmcgui, xbmcplugin, xbmc
import traceback
import hashlib

#scriptID = sys.modules[ "__main__" ].scriptID
#scriptname   = sys.modules[ "__main__" ].scriptname
scriptID = "plugin.video.sd-xbmc.premium"
scriptname = "SD-XBMC Premium Movies Content"
sdp = xbmcaddon.Addon(scriptID)
language = sdp.getLocalizedString
t = sys.modules[ "__main__" ].language

import pLog, pCommon, pErrors, msg

log = pLog.pLog()
filename = sdp.getAddonInfo('path') + os.sep + 'password'

adult = sdp.getSetting('adult')


class Adult:
    def __init__(self):
        self.msg = msg.Windows()
    
    def checkPassword(self):
        pass1 = self.passInputText("", t(55012).encode('utf-8'))
        pass2 = open(filename, "r").read().strip()
        if pass1 == pass2:
            return True
        else:
            return False
    
    def savePassword(self, hash):
        try:
            f = open(filename, 'w')
            f.write(hash)
            f.close
            return True
        except:
            return False
    
    def Update(self):
        log.info('Adult getSetting:' + str(adult))
        if adult == 'false':
            try:
                self.savePassword(self.passInputText("", t(55012).encode('utf-8')))
                sdp.setSetting(id = 'adult', value = 'true')
                self.msg.Info(t(55201).encode('utf-8'), t(55010).encode('utf-8'))
            except:
                pass
        elif adult == 'true':
            if os.path.isfile(filename):
                if self.checkPassword():
                    try:
                        sdp.setSetting(id = 'adult', value = 'false')
                        self.msg.Info(t(55201).encode('utf-8'), t(55011).encode('utf-8'))
                    except:
                        pass
                else:
                    self.msg.Error(t(55201).encode('utf-8'), t(55009).encode('utf-8'))
        
    def passInputText(self, hash, title):
        text = None
        k = xbmc.Keyboard(hash, title)
        k.setHiddenInput(True)
        k.doModal()
        if (k.isConfirmed()):
            text = k.getText()
            m = hashlib.md5()
            m.update(text)
            hash = m.hexdigest()
        return hash


if __name__ == "__main__":
    Adult().Update()