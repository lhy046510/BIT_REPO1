# -*- coding: utf-8 -*-
import re, sys, os, cgi
import urllib, urllib2, urlparse
import pLog

log = pLog.pLog()

scriptID = sys.modules[ "__main__" ].scriptID
scriptname = "Polish Live TV"

class Parser:
    def __init__(self):
        pass

    def getParam(self, params, name):
        try:
            return params[name]
        except:
            return None

    def getIntParam (self, params, name):
        try:
            param = self.getParam(params, name)
            return int(param)
        except:
            return None
    
    def getBoolParam (self, params, name):
        try:
            param = self.getParam(params,name)
            return 'True' == param
        except:
            return None
	
    def getParams(self, paramstring = sys.argv[2]):
	param = {}
        if len(paramstring) >= 2:
            params = paramstring.replace('?', '')
	    param = dict(urlparse.parse_qsl(params))
	return param

    def debugParams(self, params, mode=False):
	if mode == True:
	    for name, val in params.items():
		log.info(str(name) + ': ' + str(val))
		
    def setParam(self, params, add=False):
	param = urllib.urlencode(params)
	if add == False:
	    return "?"+param
	else:
	    return param
