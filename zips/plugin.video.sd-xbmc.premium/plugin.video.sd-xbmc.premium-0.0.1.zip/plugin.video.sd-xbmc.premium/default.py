# -*- coding: utf-8 -*-
import sys, os, string
import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import urllib
import random

scriptID = "plugin.video.sd-xbmc.premium"
scriptname = "SD-XBMC Premium Movies Content"
sdp = xbmcaddon.Addon()
language = sdp.getLocalizedString
t = sys.modules[ "__main__" ].language
dbg = sdp.getSetting('default_debug') in ("true")

BASE_RESOURCE_PATH = os.path.join( sdp.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
GUI_PATH = os.path.join( sdp.getAddonInfo('path'), "gui" )
sys.path.append( GUI_PATH )

import pLog, pSettings, pParser, api, search, msg, main

log = pLog.pLog()

#main_url = 'http://api.xbmc-premium.org'
main_url = 'http://api.sd-xbmc.org'

username = sdp.getSetting('username')
page = sdp.getSetting('page')
show_title = sdp.getSetting('show_title')
sort = sdp.getSetting('sort')
adult_search = sdp.getSetting('adult_search')


class SDPremium:
    def __init__(self):
        log.info('Starting SD-XBMC Premium plugin ')
        self.settings = pSettings.SDSettings()
        self.parser = pParser.Parser()
    
    def Switcher(self):
        params = self.parser.getParams()
        #mode = self.parser.getIntParam(params, "mode")
        type = self.parser.getParam(params, "type")
        title = self.parser.getParam(params, "title")
        name = self.parser.getParam(params, "name")
        url = self.parser.getParam(params, 'url')
        self.parser.debugParams(params, dbg)
        if type == None and name == None:
            self.CATEGORIES()
        if type == 'genre' and name != '' and url != '':
            m = api.Menu()
            m.addGenries(urllib.unquote_plus(self.quote_uri(url)))
        if type == 'movie' and name != '' and url != '':
            m = api.Menu()
            m.addMovies(urllib.unquote_plus(self.quote_uri(url)))
        if type == 'serial' and name != '' and url != '':
            m = api.Menu()
            m.addSerials(urllib.unquote_plus(self.quote_uri(url)))
        if type == 'season' and name != '' and url != '':
            m = api.Menu()
            m.addSeasons(urllib.unquote_plus(self.quote_uri(url)))
        if type == 'search' and name != '':
            a = api.API()
            api_json = a.getJSONData('%s/k=search&q=getData' % (main_url))
            s = search.WindowSearch("search.xml", sdp.getAddonInfo('path'), "Default")
            s.setAPISearchData(api_json)
            s.doModal()
            search_dict = s.getDICTSearchData()
            print 'dict: ' + str(s.getDICTSearchData())
            del s
            if search_dict['action'] == 'search':
                m = api.Menu()
                url_search = '%s/k=search&q=movies&title=%s' % (main_url, urllib.quote_plus(search_dict['value']))
                if search_dict['service'] != '':
                    url_search += '&service=%s' % (urllib.quote_plus(search_dict['service']))
                if search_dict['kind'] != '':
                    url_search += '&kind=%s' % (urllib.quote_plus(search_dict['kind']))
                if search_dict['quality'] != '':
                    url_search += '&quality=%s' % (urllib.quote_plus(search_dict['quality']))
                if search_dict['language'] != '':
                    url_search += '&language=%s' % (urllib.quote_plus(search_dict['language']))
                if search_dict['sort'] == 'watched':
                    url_search += '&sort=watched'
                elif search_dict['sort'] == 'last':
                    url_search += '&sort=last'
                elif search_dict['sort'] == 'asc':
                    url_search += '&sort=asc'
                elif search_dict['sort'] == 'desc':
                    url_search += '&sort=desc'
                else:
                    if sort == 'ascending':
                        url_search += '&sort=asc'
                    elif sort == 'descending':
                        url_search += '&sort=desc'
                    elif sort == 'last added':
                        url_search += '&sort=last'
                    elif sort == 'watch':
                        url_search += '&sort=watch'
                url_search += '&page=0,%s&show_title=%s&adult_search=%s&user=%s' % (page, show_title, adult_search, username)
                print 'out_url: ' + url_search
                m.addMovies(url_search)
        #    text = self.searchInputText()
        #    if text != None:
        #        url = 'http://api.sd-xbmc.org/k=search&q=movies&title=%s' % (text)
        #        m = api.Menu()
        #        m.addMovies(url)
        #if type == 'play' and url != '':
        #    player = api.Player()
        #    player.LOAD_AND_PLAY_VIDEO(urllib.unquote_plus(url), title)
        #    #a = api.ArraysAPI()
        #    #log.info('json: ' + a.setPlayer(url))
        if type == 'report' and url != '':
            report = api.ReportLink()
            report.update(urllib.unquote_plus(url))
            log.info('url report: ' + urllib.unquote_plus(url))
        if type == 'settings':
            self.settings.showSettings()
        if type == 'gui':
            gui = main.Main("main.xml", sdp.getAddonInfo('path'), "Default")
            gui.doModal()
            del gui
    
    def searchInputText(self):
        text = None
        k = xbmc.Keyboard()
        k.doModal()
        if (k.isConfirmed()):
            text = k.getText()
        return text
    
    def quote_uri(self, url):
        urlTab = url.split("?")
        url_address = urlTab[0]
        uri = urllib.quote_plus(urlTab[1])
        return '%s?%s' % (url_address, uri)
    
    def CATEGORIES(self):
        data = api.ArraysAPI()
        tab = data.setCategories()
        log.info('tab: ' + str(tab))
        log.info('length: ' + str(len(tab)))
        for i in range(len(tab)):
            self.addDir(tab[i][1]['name'], 'genre', tab[i][2]['url'], tab[i][1]['image'], False, False)
            #log.info('k: ' + str(tab[i][0]))
        self.addDir('Wyszukaj', 'search', '', '', False, False)
        self.addDir('Ustawienia', 'settings', '', '', False, False)
        self.addDir('Nowe gui', 'gui', '', '', False, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    
    def addDir(self, name, type, url, icon, autoplay, isPlayable = True):
        u = '%s?type=%s&url=%s' % (sys.argv[0], type, urllib.quote_plus(url))
        #u = sys.argv[0] + "?mode=" + str(mode)
        #icon = os.path.join( __addon__.getAddonInfo('path'), "img/" ) + icon
        log.info('u: ' + str(u))
        if autoplay or icon == '':
            icon= "DefaultVideo.png"
        liz = xbmcgui.ListItem(name, iconImage = icon, thumbnailImage = icon)
        if autoplay and isPlayable:
            liz.setProperty("IsPlayable", "true")
        liz.setInfo( type = "Video", infoLabels = { "Title": name } )
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem=liz, isFolder= not autoplay)
    
    def uuid_generator(self, size=6, chars=string.ascii_uppercase + string.digits):
        return ''.join(random.choice(chars) for x in range(size))    
    
run = SDPremium()
f = open(sdp.getAddonInfo('path') + os.sep + 'uuid', "w")
f.write(run.uuid_generator(40))
f.close()
run.Switcher()