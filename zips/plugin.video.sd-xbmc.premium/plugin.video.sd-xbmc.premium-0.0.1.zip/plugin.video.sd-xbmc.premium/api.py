# -*- coding: utf-8 -*-
import re, sys, os
import xbmcaddon, xbmcgui, xbmcplugin, xbmc
import simplejson as json
import traceback
import urllib

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
sdp = xbmcaddon.Addon(scriptID)
language = sdp.getLocalizedString
t = sys.modules[ "__main__" ].language

BASE_RESOURCE_PATH = os.path.join( sdp.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
GUI_PATH = os.path.join( sdp.getAddonInfo('path'), "gui" )
sys.path.append( GUI_PATH )

import pLog, pCommon, pErrors, msg

log = pLog.pLog()

main_url = 'http://api.sd-xbmc.org'
l_categories = main_url + '/?k=list&q=categories'
#l_genries = main_url + '/?k=list&q=genries'

username = sdp.getSetting('username')
password = sdp.getSetting('password')
page = sdp.getSetting('page')
show_title = sdp.getSetting('show_title')
sort = sdp.getSetting('sort')
adult = sdp.getSetting('adult')


class API:
    def __init__(self):
        self.common = pCommon.common()
        self.exception = pErrors.Exception()
    
    def getJSONData(self, url):
        js = {"msg":"Error"}
        query_data = { 'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True }
        try:
            response = self.common.getURLRequestData(query_data)
        except Exception, exception:
            traceback.print_exc()
            self.exception.getError(str(exception))
            response = None
        log.info('result: %s' % (response))
        if response != None:
            try:
                js = json.loads(response)
            except:
                js = response
        #log.info('json: %s' % (str(js)))
        return js
    

class ArraysAPI:
    def __init__(self):
        self.common = pCommon.common()
        self.exception = pErrors.Exception()
     
    def setCategories(self):
        api = API().getJSONData(l_categories)
        #log.info('api: %s' % (str(api['categories'])))
        return api['categories']
    
    def setGenries(self, url):
        api = API().getJSONData(url)
        #log.info('api: %s' % (str(api['categories'])))
        return api['genries']
    
    def setSerials(self, url):
        api = API().getJSONData(url)
        return api['serials']
  
    def setSeasons(self, url):
        api = API().getJSONData(url)
        return api['seasons']
  
    def setMovies(self, url):
        api = API().getJSONData(url)
        #log.info('api: %s' % (str(api['categories'])))
        return api['movies']
    
    def setPage(self, url):
        api = API().getJSONData(url)
        return api['page']
    
    def setAdult(self, url):
        api = API().getJSONData(url)
        return api['adult_protection']
    
    def setPlayer(self, url):
        api = API().getJSONData(url)
        #log.info('api: %s' % (str(api['categories'])))
        return api   
    
    
class Menu:
    def __init__(self):
        self.common = pCommon.common()
        self.hash = pCommon.BaseCryptHash()
        self.exception = pErrors.Exception()
        self.context = pCommon.ContextMenu()
        self.msg = msg.Windows()
        
    def addGenries(self, url):
        data = ArraysAPI()
        json = data.setGenries(url)
        for i in range(len(json)):
            n_url = '%s&page=0,%s&user=%s' % (json[i][2]['url'], page, username)
            if 'q=serials' in n_url:
                self.addDir(json[i][1]['name'], 'serial', n_url, '', False, False)
            else:
                self.addDir(json[i][1]['name'], 'movie', n_url, '', False, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def addMovies(self, url):
        if not 'show_title' in url:
            if show_title == 'national' or show_title == 'both':
                url = url + '&show_title=national'
            elif show_title == 'original':
                url = url + '&show_title=original'
        if not 'sort' in url:
            if sort == 'ascending':
                url = url + '&sort=asc'
            elif sort == 'descending':
                url = url + '&sort=desc'
            elif sort == 'last added':
                url = url + '&sort=last'
            elif sort == 'watch':
                url = url + '&sort=watch'
        if not 'page' in url:
            url = '%s&page=0,%s' % (url, page)
        if adult == 'true':
            url = url + '&adult_protect=true'
        else:
            url = url + '&adult_protect=false'
        log.info('addMovies url link: %s' % (url))
        data = ArraysAPI()
        adult_json = data.setAdult(url)
        dict = { 'page_item': 'None' }
        if adult_json == "true" and adult == "true":
            import pAdult
            chkpass = pAdult.Adult().checkPassword()
            if chkpass:
                json = data.setMovies(url)
                try:
                    dict = data.setPage(url)
                except:
                    pass
            else:
                self.msg.Error(t(55201).encode('utf-8'), t(55009).encode('utf-8'))
                json = {}
        else:
            json = data.setMovies(url)
            try:
                dict = data.setPage(url)
            except:
                pass
        for i in range(len(json)):
            n_url = '%s&hash=%s' % (json[i][3]['url'], self.hash.encode(username, password, 'external', self.getUUID()))
            title = ''
            title_national = json[i][1]['title']
            title_original = json[i][1]['title_orig']
            title_suffix = ' [COLOR green](' + json[i][6]['quality'] + ', ' + json[i][6]['language'] + ')[/COLOR]'
            if json[i][6]['type'].startswith('3D'):
                title_type = ' [COLOR blue][' + json[i][6]['type'] + '][/COLOR]'
                title_suffix = title_suffix + title_type
            #print 'title original: ' + title_original
            if show_title == 'national':
                title = '%s %s' % (title_national, title_suffix)
            elif show_title == 'original':
                if title_original != '' or title_original != None:
                    title = '%s %s' % (title_original, title_suffix)
                else:
                    title = '%s %s' % (title_national, title_suffix)
            elif show_title == 'both':
                if title_original != '' or title_original != None:
                    if title_original != title_national:
                        title = '%s / %s %s' % (title_national, title_original, title_suffix)
                    else:
                        title = '%s %s' % (title_national, title_suffix)
                else:
                    title = '%s %s' % (title_national, title_suffix)
            else:
                title = title = '%s %s' % (title_national, title_suffix)
            if json[i][7]['status'] == '1':
                title = '%s - [COLOR red]%s[/COLOR]' % (title, t(55200))
            #self.addDir(json[i][1]['title'] + ' [COLOR green](' + json[i][5]['service'] + ')[/COLOR]', 'play', n_url, json[i][4]['image'], False, False)
            self.addLink(title, json[i][4]['image'], n_url, json[i][2]['description'], json[i][0]['id_movie'])
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        if dict['page_item'] != 'None':
            g_url = ''
            if dict['type'] == 'list':
                g_url = '%s/?k=list&q=movies&id_category=%s&id_genre=%s&page=%s,%s' % (main_url, dict['id_category'], dict['id_genre'], dict['page_item'], page)
            elif dict['type'] == 'search':
                g_url = '%s&page=%s,%s' % (dict['page_url'], dict['page_item'], page)
            self.addDir('[COLOR red] >> ' + t(55005).encode('utf-8') + ' >>[/COLOR]', 'movie', g_url, '', False, False)            
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
    def addSerials(self, url):
        if not 'show_title' in url:
            if show_title == 'national' or show_title == 'both':
                url = url + '&show_title=national'
            elif show_title == 'original':
                url = url + '&show_title=original'
        if not 'sort' in url:
            if sort == 'ascending':
                url = url + '&sort=asc'
            elif sort == 'descending':
                url = url + '&sort=desc'
            elif sort == 'last added':
                url = url + '&sort=last'
            elif sort == 'watch':
                url = url + '&sort=watch'
        if adult == 'true':
            url = url + '&adult_protect=true'
        else:
            url = url + '&adult_protect=false'
        log.info('addSerials url link: %s' % (url))
        data = ArraysAPI()
        adult_json = data.setAdult(url)
        dict = { 'page_item': 'None' }
        if adult_json == "true" and adult == "true":
            import pAdult
            chkpass = pAdult.Adult().checkPassword()
            if chkpass:
                json = data.setSerials(url)
                try:
                    dict = data.setPage(url)
                except:
                    pass
            else:
                self.msg.Error(t(55201).encode('utf-8'), t(55009).encode('utf-8'))
                json = {}
        else:
            json = data.setSerials(url)
            try:
                dict = data.setPage(url)
            except:
                pass
        for i in range(len(json)):
            n_url = '%s&user=%s' % (json[i][2]['url'], username)
            title = ''
            title_national = json[i][0]['title']
            title_original = json[i][0]['title_orig']
            has_season = json[i][0]['has_season']
            #print 'title original: ' + title_original
            if show_title == 'national':
                title = title_national
            elif show_title == 'original':
                if title_original != '' or title_original != None:
                    title = title_original
                else:
                    title = title_national
            elif show_title == 'both':
                if title_original != '' or title_original != None:
                    if title_original != title_national:
                        title = '%s / %s' % (title_national, title_original)
                    else:
                        title = title_national
                else:
                    title = title_national
            else:
                title = title_national
            if has_season == 'true':
                self.addDirSerial(title, 'season', n_url, json[i][3]['image'] , json[i][1]['description'], False, False)
            else:
                self.addDirSerial(title, 'movie', n_url, json[i][3]['image'] , json[i][1]['description'], False, False)
            xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        if dict['page_item'] != 'None':
            g_url = ''
            if dict['type'] == 'list':
                g_url = '%s/?k=list&q=serials&id_category=%s&id_genre=%s&page=%s,%s' % (main_url, dict['id_category'], dict['id_genre'], dict['page_item'], page)
            elif dict['type'] == 'search':
                g_url = '%s&page=%s,%s' % (dict['page_url'], dict['page_item'], page)
            self.addDir('[COLOR red] >> ' + t(55005).encode('utf-8') + ' >>[/COLOR]', 'movie', g_url, '', False, False)            
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    def addSeasons(self, url):
        data = ArraysAPI()
        json = data.setSeasons(url)
        for i in range(len(json)):
            n_url = '%s&page=0,%s&user=%s' % (json[i]['url'], page, username)
            self.addDir('Sezon ' + str(json[i]['season']), 'movie', n_url, '', False, False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
    def addDir(self, name, type, url, icon, autoplay, isPlayable = True):
        u = '%s?type=%s&url=%s' % (sys.argv[0], type, urllib.quote_plus(url))
        #u = sys.argv[0] + "?mode=" + str(mode)
        #icon = os.path.join( __addon__.getAddonInfo('path'), "img/" ) + icon
        log.info('u: ' + str(u))
        if autoplay or icon == '':
            icon= "DefaultVideo.png"
        liz = xbmcgui.ListItem(name, iconImage = icon, thumbnailImage = icon)
        if autoplay and isPlayable:
            liz.setProperty("IsPlayable", "true")
        liz.setInfo( type = "Video", infoLabels = { "Title": name } )
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem=liz, isFolder= not autoplay)    

    def addDirSerial(self, name, type, url, icon, desc, autoplay, isPlayable = False):
        u = '%s?type=%s&url=%s' % (sys.argv[0], type, urllib.quote_plus(url))
        #u = sys.argv[0] + "?mode=" + str(mode)
        #icon = os.path.join( __addon__.getAddonInfo('path'), "img/" ) + icon
        log.info('u: ' + str(u))
        if autoplay or icon == '':
            icon= "DefaultVideo.png"
        liz = xbmcgui.ListItem(name, iconImage = icon, thumbnailImage = icon)
        if autoplay and isPlayable:
            liz.setProperty("IsPlayable", "false")
        liz.setInfo( type = "Video", infoLabels = { "Title": name, "Plot": desc } )
        xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem=liz, isFolder= not autoplay)    
    
    def addLink(self, title, iconimage, url, desc, id_movie):
        u= url
        cm_url = '%s/?key=report&q=movie&id_movie=%s' % (main_url, id_movie)
        cm = self.context.addReportLink(t(55100).encode('utf-8'), cm_url, username, password)
        liz=xbmcgui.ListItem(title, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty("IsPlayable", "true")
        liz.setInfo( type="Video", infoLabels={ "Title": title,
                                               "Plot": desc,
                                               "Genre": "Film/Serial",
                                               "PlotOutline": desc,} )
        liz.addContextMenuItems(cm, replaceItems=False)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        
    def getUUID(self):
        uuid = 'None'
        try:
            f = open(sdp.getAddonInfo('path') + os.sep + 'uuid', "r")
            uuid = f.read().strip()
            f.close()
        except:
            pass
        return uuid

       
class ReportLink:
    def __init__(self):
        self.msg = msg.Windows()
    
    def update(self, url):
        try:
            api_json = API().getJSONData(url)
            if api_json['report'] == 'updated':
                self.msg.Info(t(55201).encode('utf-8'), t(55203).encode('utf-8'))
            else:
                self.msg.Error(t(55202).encode('utf-8'), t(55204).encode('utf-8'))
        except:
            self.msg.Error(t(55202).encode('utf-8'), t(55205).encode('utf-8'))
        