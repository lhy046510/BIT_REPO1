# -*- coding: utf-8 -*-
import xbmc, xbmcgui, sys, re, os
import xbmcplugin, xbmcaddon

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
sdp = xbmcaddon.Addon(scriptID)
language = sdp.getLocalizedString
t = sys.modules[ "__main__" ].language

MESSAGE_ACTION_OK = 110
MESSAGE_EXIT = 111
MESSAGE_TITLE = 101
MESSAGE_LINE1 = 102
MESSAGE_LINE2 = 103
MESSAGE_LINE3 = 104


class MessageDialog(xbmcgui.WindowXMLDialog):
    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback = True):
        pass
    
    def setTableText(self, tab):
        self.tabText = tab
        
    def getTableText(self):
        return self.tabText
    
    def onInit(self):
        self.loadTexts()
    
    def onAction(self, action):
        if action == 1010:
            self.close()
    
    def onClick(self, controlID):
        if controlID == MESSAGE_ACTION_OK or controlID == MESSAGE_EXIT:
            self.onAction(1010)
    
    def onFocus(self, controlID):
        pass

    def loadTexts(self):
        self.getControl(MESSAGE_TITLE).setLabel(str(self.getTableText()['title']))
        self.getControl(MESSAGE_LINE1).setLabel(str(self.getTableText()['text1']))
        #if self.getTableText()['text2'] != "" and self.getTableText()['text3'] != "":
        self.getControl(MESSAGE_LINE2).setLabel(str(self.getTableText()['text2']))
        self.getControl(MESSAGE_LINE3).setLabel(str(self.getTableText()['text3']))
    

class Windows:
    def __init__(self):
        pass
    
    def Warning(self, title = '', text1 = '', text2 = '', text3 = ''):
        msg = MessageDialog("msg-warning.xml", sdp.getAddonInfo('path'), "Default")
        tabText = { 'title': title, 'text1': text1, 'text2': text2, 'text3': text3 }
        msg.setTableText(tabText)
        msg.doModal()
        del msg
        
    def Error(self, title = '', text1 = '', text2 = '', text3 = ''):
        msg = MessageDialog("msg-error.xml", sdp.getAddonInfo('path'), "Default")
        tabText = { 'title': title, 'text1': text1, 'text2': text2, 'text3': text3 }
        msg.setTableText(tabText)
        msg.doModal()
        del msg

    def Info(self, title = '', text1 = '', text2 = '', text3 = ''):
        msg = MessageDialog("msg-info.xml", sdp.getAddonInfo('path'), "Default")
        tabText = { 'title': title, 'text1': text1, 'text2': text2, 'text3': text3 }
        msg.setTableText(tabText)
        msg.doModal()
        del msg