# -*- coding: utf-8 -*-

import xbmc, xbmcgui

ID_VALUE = 112
ID_SERVICE = 114
ID_QUALITY = 116
ID_LANGUAGE = 118
ID_KIND = 120
ID_CANCEL = 121
ID_SEARCH = 122
ID_SORT = 123


class WindowSearch(xbmcgui.WindowXMLDialog):
    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback = True):
        self.dict_search = {'value':'', 'service':'', 'quality':'', 'language':'', 'kind':'', 'sort':''}
        self.api = {}
        self.sort = ['rosnąco', 'malejąco', 'najczęściej oglądane', 'ostatnio dodane']
    
    def setAPISearchData(self, api = {}):
        self.api = api
    
    def getDICTSearchData(self):
        return self.dict_search
    
    def onInit(self):
        pass
    
    def onAction(self, action):
        if action == 'exit':
            self.dict_search['value'] = ''
            self.dict_search['service'] = ''
            self.dict_search['quality'] = ''
            self.dict_search['language'] = ''
            self.dict_search['kind'] = ''
            self.dict_search['sort'] = ''
            self.dict_search['action'] = 'cancel'
            self.close()
        elif action == 'search':
            self.dict_search['value'] = self.getControl(ID_VALUE).getLabel()
            #self.dict_search['service'] = self.getControl(ID_SERVICE).getLabel()
            self.dict_search['quality'] = self.getControl(ID_QUALITY).getLabel()
            self.dict_search['language'] = self.getControl(ID_LANGUAGE).getLabel()
            self.dict_search['kind'] = self.getControl(ID_KIND).getLabel()
            self.dict_search['action'] = 'search'
            self.close()
        elif action == 'enter_value':
            text = self.searchInputText()
            if text != None:
                self.getControl(ID_VALUE).setLabel(text)
        elif action == 'set_service':
            d = xbmcgui.Dialog()
            item = d.select('Wybór serwisu', self.api['services'])
            if item >= 0:
                self.getControl(ID_SERVICE).setLabel(self.getNameFromID(item, self.api['services']))
        elif action == 'set_quality':
            d = xbmcgui.Dialog()
            item = d.select('Wybór jakości', self.api['quality'])
            if item >= 0:
                self.getControl(ID_QUALITY).setLabel(self.getNameFromID(item, self.api['quality']))
        elif action == 'set_language':
            d = xbmcgui.Dialog()
            item = d.select('Wybór tłumaczenia', self.api['language'])
            if item >= 0:
                self.getControl(ID_LANGUAGE).setLabel(self.getNameFromID(item, self.api['language']))
        elif action == 'set_kind':
            d = xbmcgui.Dialog()
            item = d.select('Wybór rodzaju filmu', self.api['kind'])
            if item >= 0:
                self.getControl(ID_KIND).setLabel(self.getNameFromID(item, self.api['kind']))
        elif action == 'set_sort':
            d = xbmcgui.Dialog()
            item = d.select('Wybór sortowania', self.sort)
            if item >= 0:
                self.getControl(ID_SORT).setLabel(self.getNameFromID(item, self.sort))
                if item == 0:
                    self.dict_search['sort'] = 'asc'
                elif item == 1:
                    self.dict_search['sort'] = 'desc'
                elif item == 2:
                    self.dict_search['sort'] = 'watched'
                elif item == 3:
                    self.dict_search['sort'] = 'last'
                else:
                    self.dict_search['sort'] = ''
    
    def onClick(self, controlID):
        if controlID == ID_CANCEL:
            self.onAction('exit')
        elif controlID == ID_SEARCH:
            self.onAction('search')
        elif controlID == ID_VALUE:
            self.onAction('enter_value')
        elif controlID == ID_SEARCH:
            self.onAction('search')
        elif controlID == ID_SERVICE:
            self.onAction('set_service')
        elif controlID == ID_QUALITY:
            self.onAction('set_quality')
        elif controlID == ID_LANGUAGE:
            self.onAction('set_language')
        elif controlID == ID_KIND:
            self.onAction('set_kind')
        elif controlID == ID_SORT:
            self.onAction('set_sort')
    
    def onFocus(self, controlID):
        pass
    
    def searchInputText(self):
        text = None
        k = xbmc.Keyboard()
        k.doModal()
        if (k.isConfirmed()):
            text = k.getText()
        return text
    
    def getNameFromID(self, id, table = []):
        result = ''
        for i in range(len(table)):
            if i == id:
                result = table[i]
                break
        return result
    