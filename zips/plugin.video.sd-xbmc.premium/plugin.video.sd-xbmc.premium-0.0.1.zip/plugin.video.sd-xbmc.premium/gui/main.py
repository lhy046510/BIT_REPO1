# -*- coding: utf-8 -*-
import re, sys, os
import xbmcaddon, xbmcgui, xbmcplugin, xbmc
import simplejson as json
import traceback
import urllib

scriptID = sys.modules[ "__main__" ].scriptID
scriptname   = sys.modules[ "__main__" ].scriptname
sdp = xbmcaddon.Addon(scriptID)
language = sdp.getLocalizedString
t = sys.modules[ "__main__" ].language

BASE_RESOURCE_PATH = os.path.join( sdp.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )

import pLog, pSettings, pParser, api, search, msg, main

log = pLog.pLog()

#main_url = 'http://api.xbmc-premium.org'
main_url = 'http://api.sd-xbmc.org'

page = sdp.getSetting('page')
show_title = sdp.getSetting('show_title')
sort = sdp.getSetting('sort')
adult_search = sdp.getSetting('adult_search')

IMAGE_BG = 102
IMAGE_BG1 = 103
IMAGE_LOGO = 104
IMAGE_THUMB = 105
IMAGE_RATING = 126
LABEL_URLLBL = 106
LABEL_VERSION = 107
LABEL_INFOTEXT = 108
LABEL_DLINFOTEXT = 109
LABEL_LOADING = 110
LABEL_LISTPOS = 111
LIST_LIST1 = 112   
IMAGE_DLLOGO = 118
LABEL_DT = 119
LIST_LIST2 = 120
TEXT_BOX_LIST2 = 121 
LIST_LIST3 = 122
TEXT_BOX_LIST3 = 123
BUTTON_LEFT = 125
LIST_LIST4 = 127
BUTTON_RATE = 128
LIST_LIST5 = 129
BUTTON_RIGHT = 130


class Main(xbmcgui.WindowXML):
    def __init__(self, strXMLname, strFallbackPath, strDefaultName, forceFallback = True):
        pass
       
    def onInit(self):
        list2 = self.getControl(LIST_LIST2)
        list2.setVisible(False)
        list3 = self.getControl(LIST_LIST3)
        item = xbmcgui.ListItem("Exit") 
        list3.addItem(item)
        self.generateCategoriesListItem()
    
    def onAction(self, action):
        pass
    
    def onClick(self, controlID):
        pass
    
    def onFocus(self, controlID):
        pass
    
    def generateCategoriesListItem(self):
        list = self.getControl(LIST_LIST1)
        list.reset()
        data = api.ArraysAPI()
        tab = data.setCategories()
        log.info('tab: ' + str(tab))
        log.info('length: ' + str(len(tab)))
        for i in range(len(tab)):
            #image - tab[i][1]['image']
            u = '%s?type=%s&url=%s' % (sys.argv[0], 'genre', urllib.quote_plus(tab[i][2]['url']))
            listItem = xbmcgui.ListItem(label = tab[i][1]['name'], label2 = '', iconImage = tab[i][1]['image'], thumbnailImage = tab[i][1]['image'], path = u)
            list.addItem(listItem)