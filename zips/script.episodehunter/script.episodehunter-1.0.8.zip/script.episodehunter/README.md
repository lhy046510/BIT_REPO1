EpisodeHunter
=============

Plugin for XBMC.
Automatic scrobble what you are watching to [episodehunter.tv](http://episodehunter.tv)

You are required to have a EpisodeHunter account for this plugin.
Register on [episodehunter.tv](http://episodehunter.tv)

This plugin is under beta testing.
No more feature is planned.

However, if you have any suggestions or problem, please
visit [episodehunter.uservoice.com](episodehunter.uservoice.com) or
contact us on info@episodehunter.tv
Or create a ticket, here, on github.
