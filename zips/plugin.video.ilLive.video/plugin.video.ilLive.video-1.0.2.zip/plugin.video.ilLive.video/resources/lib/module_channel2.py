# -*- coding: utf-8 -*-

'''
Created on 16/05/2011

@author: shai
'''

__BASE_URL__ = 'http://www-cdn.justin.tv/widgets/live_embed_player.r60f60020e78d37cdff031e42d3ebb034786cb57c.swf?start_volume=0.5&backgroundImage=&channel=marcoisnback&hostname=he.justin.tv&auto_play=true&referer=&userAgent=Mozilla/5.0%20%28Windows%20NT%206.1;%20WOW64;%20rv:2.0.1%29%20Gecko/20100101%20Firefox/4.0.1&start_volume=0.5&backgroundImage=&channel=marcoisnback&hostname=he.justin.tv&auto_play=true'
__NAME__ = 'channel2'
__PATTERN__ = 'class="block w2b fclr1 mrg_t4" href="(.+?)"'

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_channel2:
    
    def __init__(self):
        self.MODES = common.enum(GET_CHANNEL=1)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_CHANNEL):
            self.getChannelStream()
            
    def getChannelStream(self):
        page = common.getData(__BASE_URL__)
        