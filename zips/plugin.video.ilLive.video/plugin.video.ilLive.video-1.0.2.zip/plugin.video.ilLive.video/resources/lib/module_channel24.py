# -*- coding: utf-8 -*-

'''
Created on 22/05/2011

@author: shai
'''

__BASE_URL__ = 'http://switch248-01.castup.net/cunet/gm.asp?ai=385&ar=FameHall_Flash&curettype=1'
__NAME__ = 'channel24'

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_channel24:
    
    def __init__(self):
        self.MODES = common.enum(GET_CHANNEL=1)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_CHANNEL):
            self.getChannelStream()
            
    def getChannelStream(self):
        ## get all the series from an array of series....
        page = common.getData(__BASE_URL__)
        streams = re.compile('rtmpt:(.+?);').findall(page)
        if len(streams) > 0:
            numOfStreams = len(streams)
            url = 'rtmp:' + streams[0] # last stream
            listItem = xbmcgui.ListItem(__NAME__, 'DefaultFolder.png', 'DefaultFolder.png', path=url)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            listItem.setInfo(type='Video', infoLabels={ "Title": urllib.unquote(__NAME__)})
            listItem.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)