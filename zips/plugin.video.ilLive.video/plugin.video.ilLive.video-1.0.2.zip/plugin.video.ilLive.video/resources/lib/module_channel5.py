# -*- coding: utf-8 -*-

'''
Created on 16/05/2011

@author: shai
'''

__USERAGENT__ = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
__NAME__ = 'channel5'
__VIDEO_URL_BASE__ = 'rtmp://82.80.199.140:8080/Live1Repeat/Live1_2'

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_channel5:
    
    def __init__(self):
        self.MODES = common.enum(GET_CHANNEL=1)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_CHANNEL):
            self.getChannelStream()
            
    def getChannelStream(self):
        videoUrl = __VIDEO_URL_BASE__
        listItem = xbmcgui.ListItem(__NAME__, 'DefaultFolder.png', 'DefaultFolder.png', path=videoUrl)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        listItem.setInfo(type='Video', infoLabels={ "Title": __NAME__, "Plot": 'Live!!!'})
        listItem.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)