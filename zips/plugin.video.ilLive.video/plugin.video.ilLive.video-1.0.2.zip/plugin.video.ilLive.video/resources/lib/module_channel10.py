# -*- coding: utf-8 -*-

'''
Created on 16/05/2011

@author: shai
'''

__USERAGENT__ = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
__BASE_URL__ = 'http://10tv.nana10.co.il/'
__NAME__ = 'channel10'
__VIDEO_URL_BASE__ = 'http://switch206-01.castup.net/cunet/gm.asp?ai=386&ar=Live03&ak&cuud=pid48&ticket='

import urllib,urllib2,re,xbmc,xbmcplugin,xbmcgui,os,sys
import common

class manager_channel10:
    
    def __init__(self):
        self.MODES = common.enum(GET_CHANNEL=1)
        
    def work(self, mode, url='', name='', page=''):
        if (mode==self.MODES.GET_CHANNEL):
            self.getChannelStream()
            
    def getChannelStream(self):
        page = common.getData(__BASE_URL__)
        videoId = re.compile('<iframe id="VideoIframe(\d+)"').findall(page)
        if len(videoId) > 0:
            videoUrl = self.getRealVideoLink(videoId[0])
            listItem = xbmcgui.ListItem(__NAME__, 'DefaultFolder.png', 'DefaultFolder.png', path=videoUrl)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
            listItem.setInfo(type='Video', infoLabels={ "Title": __NAME__, "Plot": 'Live!!!'})
            listItem.setProperty('IsPlayable', 'true')
            xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    
    def getCookie(self, url, cookiename):        
        req = urllib2.Request(url)
        req.add_header('User-Agent', __USERAGENT__)
        response = urllib2.urlopen(req)
        cooks = response.headers["set-cookie"].split(";")
        for x in cooks:
            y = x.split("=")
            if (y[0] == cookiename):
                return y[1]
        response.close()
        return "ERROR"
  
    def getRealVideoLink(self, videoId):
        ticket = self.getCookie(__BASE_URL__ + "Video/?VideoID=" + videoId, "CUTicket" + videoId)
        page = common.getData(__VIDEO_URL_BASE__ + ticket, __NAME__ + 'liveStream')
        refs = re.compile('<ref href="(.+?)"').findall(page)
        if len(refs) > 0:
            return refs[0]
        return 'Unknown'