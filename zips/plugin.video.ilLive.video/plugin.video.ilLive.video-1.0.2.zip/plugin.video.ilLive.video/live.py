# -*- coding: utf-8 -*-

"""
    Plugin for live streaming video content from hebrew television channels
"""
import urllib, re, xbmc, xbmcplugin, xbmcaddon, os, sys

LIB_PATH = xbmc.translatePath( os.path.join( os.getcwd(), 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

## General vars
__plugin__ = "ilLive"
__author__ = "Shai Bentin"

__settings__ = xbmcaddon.Addon(id='plugin.video.ilLive.video')
__language__ = __settings__.getLocalizedString

from common import *

def CATEGORIES():

    ## add manual series which are not categorized
    hardcoded = ('channel10', 'channel24', 'channel2news', 'bip')
    translation = (20001, 20002, 20004, 20005)
    i = 0
    for item in hardcoded:
        iconImage = xbmc.translatePath(os.path.join(os.getcwd(), 'cache', 'images', item + '.png'))
        addVideoLink(__language__(translation[i]), item, 1, iconImage, item)
        i += 1

    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

params = getParams(sys.argv[2])
url=None
name=None
mode=None
module=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
try:
        page=urllib.unquote_plus(params["page"])
except:
        pass
    
if mode==None or url==None or len(url)<1:
        CATEGORIES()

else:
        manager = getattr(__import__('module_' + module.lower()), 'manager_' + module)()
        manager.work(mode, url, name, page)        

xbmcplugin.setPluginFanart(int(sys.argv[1]),xbmc.translatePath( os.path.join( os.getcwd(),"fanart.jpg") ))
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)