Al Jazeera Addon for XBMC
========================

### Summary ###
This is a plugin for [XBMC](http://xbmc.org) that enables watching videos and
the live stream from <http://english.aljazeera.net>.

### Setup/Installation ###
The plugin should be available in the official XBMC addon repository. You can
install it within XBMC.

Contact: <xbmc@jonathanbeluch.com> or [jbel](http://forum.xbmc.org/member.php?u=46729) on <http://forum.xbmc.org>.
