# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,base64,os
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

__settings__ = xbmcaddon.Addon(id='plugin.video.ddizi')
__language__ = __settings__.getLocalizedString

#------------------eklenecek kısım------------------
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources'))
sys.path.append(folders)

import araclar


web="http://ddizi.net"
l_check=araclar.inside(__settings__,folders)
if l_check:
        print "ok"
        pass
else:
        araclar.hata()
        sys.exit()
        
def main(web):
        araclar.addDir('Yeniler',web,"yeni",1,"")
        div_list=["Yerli Diziler","Eski Diziler","Yabanci Diziler","Tv Showlar"]
        for x in range(0,4):
                name=div_list[x]
                url=str(x)
                araclar.addDir(name,url,"",2,"")
                

def yeni(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="dizi-box"><a href="(.*?)"><img src="(.*?)" width="120" height="90" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(name,url,thumbnail,6,"")
def panel(url):
        link=araclar.get_url(web)
        soup=BS(link.decode('utf-8','ignore'))
        div = soup.findAll("div",{"class":"blok-liste"})
        for li in div[int(url)].findAll('li'):#-------------dizi anasayfalari bulur
                url= li.a['href']
                name = li.a.text
                name=name.encode("utf-8")
                araclar.addDir(name,url,"",3,"") 
def kategoriler(url):                    
        data=araclar.get_url(url)
        match=re.compile('<div class="dizi-box2"><a title="(.*?)" href="(.*?)"><img src="(.*?)"').findall(data)#-----dizi bolumleri bulur
        for name,url,thumbnail in match:
                araclar.addDir(name,url,thumbnail,6,"")
                
        veri=data.strip(' \t\n\r').replace(" ","")
        page=re.compile('class="active"><ahref=".*?">.*?</a></li>\r\n<li><ahref="(.*?)"').findall(veri)# ----- sonraki sayfa
        if page:
                url=page[0]
                araclar.addDir('Sonraki Sayfa',url,"next",3,"")

def resolver(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
        playList.clear()
        
        value=[]
        tablist=[]
        urllist=[]
        sayfa=araclar.get_url(url)
        data=sayfa.strip(' \t\n\r').replace(" ","")
        tek=re.compile('<a href="(.*?)">Tek Part</a>').findall(sayfa)
        if tek:
                url=tek[0].replace('rel="nofollow',"").replace('"',"").replace('rel=""rel="nofollow',"")
                tablist.append("http://www.ddizi.net"+url)
        parts=re.compile('<ahref="/izle/(.*?)">.*?.Par\xc3\xa7a</a>').findall(data)
        if parts:
                for url in parts:
                        url=url.replace('rel="nofollow',"").replace('"',"").replace('rel=""rel="nofollow',"")
                        link="http://www.ddizi.net/izle/"+url
                        tablist.append(link)
        print tablist
        #---------------ALT FONKSIYON SAYFA TARAR --------------------------
        def sub_scan(url):
                
                data=araclar.get_url(url)
                #-----------------------------------------------------------------------
                xml=re.compile('settingsFile: "(.*?)"').findall(data)
                if xml:
                        veri=araclar.get_url(xml[0])
                        veri2=veri.strip(' \t\n\r').replace(" ","")
                        links=re.compile('videoPathvalue="(.*?)"').findall(veri2)
                        i=0
                        for url in links:
                                urllist.append(('Part '+str(i),url))
                                i+=1
                        
                        
                #------------------------------------------------------------------------
                adres=re.compile('encodeURIComponent\(\'(.*?)\'').findall(data)
                if adres:
                        urllist.append(('Part ',adres[0]))
                        

                        
                #-----------------------------------------------------------------------

                vk=re.compile('iframe src="http://vk.com(.*?)"').findall(data)
                if vk:
                        urllist.append(("Vk Server","http://vk.com"+vk[0]))
                        
                
                return urllist
        #---------------burdan devam ediyor ----------------
        if len(tablist)>0:
                for url in tablist:
                        sonuc=sub_scan(url)
                
        else:
                dialog = xbmcgui.Dialog()
                i = dialog.ok(name,"Site uyarısı","Film henuz yuklenmedi","Yayınlandıktan sonra yüklenecektir.")
                
                sonuc=sub_scan(url)

      
                        
        for x in sonuc:
                name=x[0]
                url=x[1]
                if "youtube" in str(url):
                        code=url.replace("http://www.youtube.com/watch?v=","")
                        url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)
                playList.add(url)
                araclar.addLink(name,url,"")
        xbmcPlayer.play(playList)


def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

        
              
params=get_params()
url=None
thumbnail=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        thumbnail=urllib.unquote_plus(params["thumbnail"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "thumbnail: "+str(thumbnail)
if mode==None or url==None or len(url)<1:
        print ""
        main(web)
elif mode==1:
        print ""+url
        yeni(url)        
elif mode==2:
        print ""+url
        panel(url)
elif mode==3:
        print ""+url
        kategoriler(url)
elif mode==6:
        print ""+url
        resolver(name,url)



xbmcplugin.endOfDirectory(int(sys.argv[1]))

