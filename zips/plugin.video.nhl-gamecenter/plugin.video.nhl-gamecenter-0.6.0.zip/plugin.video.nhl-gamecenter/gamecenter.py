import xbmcplugin, xbmcgui, xbmcaddon
import re, os, time
import urllib, urllib2, httplib2
import thumbnailgenerator
from xml.dom.minidom import Document, parse, parseString
from datetime import datetime, date, timedelta, tzinfo
from dateutil import tz, parser
import time, threading

#############################################################################

#Set root path
ROOTDIR = xbmcaddon.Addon(id='plugin.video.nhl-gamecenter').getAddonInfo('path')

#Settings
settings = xbmcaddon.Addon(id='plugin.video.nhl-gamecenter')

#Main settings
USERNAME = settings.getSetting(id="username")
PASSWORD = settings.getSetting(id="password")
QUALITY = int(settings.getSetting(id="quality"))
USERAGENT = urllib.quote(settings.getSetting(id="useragent"))

SHOWDIALOGQUALITY = 'true'
if QUALITY != 5:
    SHOWDIALOGQUALITY = 'false'

#Visual settings
TEAMNAME = int(settings.getSetting(id="team_names"))
HIDELIVEGAMES = settings.getSetting(id="hide_live_games")
USETHUMBNAILS = settings.getSetting(id="use_thumbnails")
USEADDONICON = settings.getSetting(id="use_addon_icon")

if (USEADDONICON == 'true') and (USETHUMBNAILS == 'true'):
    ICON = os.path.join(ROOTDIR, "icon.png")
else:
    ICON = ''
    
thumbnail = ["square","cover","169"]
background = ["black","ice","transparent"]

THUMBFORMAT = thumbnail[int(settings.getSetting(id="thumb_format"))]
THUMBFORMATOSD = thumbnail[int(settings.getSetting(id="thumb_format_osd"))]
BACKGROUND = background[int(settings.getSetting(id="background"))]
BACKGROUNDOSD = background[int(settings.getSetting(id="background_osd"))]
GENERATETHUMBNAILS = settings.getSetting(id="generate_thumbnails")
DELETETHUMBNAILS = settings.getSetting(id="delete_thumbnails")
SHOWHADIALOG = "false" #settings.getSetting(id="showhadialog")
SHOWHADIALOGLIVE = "false"#settings.getSetting(id="showhadialoglive")
ALTERNATIVEVS = settings.getSetting(id="alternativevs")



#XBMC version
xbmc_version = float(re.findall(r'\d{2}\.\d{1}', xbmc.getInfoLabel("System.BuildVersion"))[0])
    
#Localisation
local_string = xbmcaddon.Addon(id='plugin.video.nhl-gamecenter').getLocalizedString

#Content type
#xbmcplugin.setContent(int(sys.argv[1]), 'episodes')


#TEAM NAMES
############################################################################

def getTeams():
    allTeams = {}
    infile = open(os.path.join(ROOTDIR, 'teams'),'r')
    lines = infile.readlines()

    for i in lines:

        short = ''
        teamnames = []
        
        for idx,item in enumerate(i.split(',')):
            if idx == 0:
                short = item.strip()
            else:
                teamnames.append(item.strip())
                
        allTeams.setdefault(short, teamnames)

    return allTeams


#LOGIN & XML DOWNLOAD
############################################################################   

def saveFile(filename,content):
    #Save File
    fileObj = open(os.path.join(ROOTDIR, filename),"w")
    fileObj.write(content)
    fileObj.close()
    #print filename + ' saved'


def login():
    #Login
    print 'Logging in...'
    
    http = httplib2.Http()
    http.disable_ssl_certificate_validation=True

    url = 'https://gamecenter.nhl.com/nhlgc/secure/login'
    body = {'username': USERNAME, 'password': PASSWORD}
    headers = {'Content-type': 'application/x-www-form-urlencoded'}
    response, content = http.request(url, 'POST', headers=headers, body=urllib.urlencode(body))

    #Save Cookies
    saveFile("cookies",response['set-cookie'])


def downloadXMLData(url,values,filename,classic):

    http = httplib2.Http()
    http.disable_ssl_certificate_validation=True
    
    for i in range(1, 3):
        print "Download: " + str(i) + ". try"
        
	#Load Cookies
        try:
            cookies = open(os.path.join(ROOTDIR, "cookies")).readline()
        except IOError:
            login()
            cookies = open(os.path.join(ROOTDIR, "cookies")).readline()
            
        #Header for XML Request
        headers = { 'Host' : 'gamecenter.nhl.com',
                    'User-Agent' : 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)',
                    'Accept' : '*/*',
                    'Referer' : 'http://gamecenter.nhl.com/nhlgc/console.jsp',
                    'Accept-Language' : 'de-de',
                    'Accept-Encoding' : 'gzip, deflate',
                    'Cookie' : cookies,
                    'Connection' : 'keep-alive',
                    'Content-Type' : 'application/x-www-form-urlencoded'}
        
        #Download the XML
        if classic == 'true':
            valuesencoded = urllib.urlencode(values).replace('.','%2E').replace('_','%5F').replace('-','%2D')
            response, content = http.request(url, 'POST', headers=headers, body=valuesencoded)
        else:
            response, content = http.request(url, 'POST', headers=headers, body=urllib.urlencode(values))
            
        downloadedXML = content.strip()
        
        #Try to login again if XML not accessible
        if "<code>noaccess</code>" in downloadedXML:
            print "No access to XML file"
            login()
            continue
        else:
            print "Download successful"

            #Save the XML
            saveFile(filename,downloadedXML)
            break
    else:
        print "Login failed. Check your login credentials."

        #Save the XML
        saveFile(filename,downloadedXML)


#THUMBNAILS
############################################################################

def updateThumbs():
    #Show progressbar
    i = 0
    steps = 0.0
    progress = xbmcgui.DialogProgress()
    
    if DELETETHUMBNAILS == 'true':
        steps = steps + 1
    if GENERATETHUMBNAILS == 'true':
        steps = steps + 1
    if (THUMBFORMAT != THUMBFORMATOSD) or (BACKGROUND != BACKGROUNDOSD):
        steps = steps + 1
    
    progress.create(local_string(31300), '')
    percent = int( ( i / steps ) * 100)
    message = local_string(31350)
    progress.update( percent, "", message, "" )
    i = i + 1
    print percent, steps
    
    #Delete thumbnails
    if DELETETHUMBNAILS == 'true':
        thumbnailgenerator.deleteThumbnails(ROOTDIR)

        #Reset setting
        settings.setSetting(id='delete_thumbnails', value='false')

        #Update progressbar
        percent = int( ( i / steps ) * 100)
        message = local_string(31350)
        progress.update( percent, "", message, "" )
        i = i + 1
        print percent, steps

    #Create thumbnails
    if GENERATETHUMBNAILS == 'true':
        thumbnailgenerator.createThumbnails(ROOTDIR,THUMBFORMAT,BACKGROUND)

        #Update progress
        percent = int( ( i / steps ) * 100)
        message = local_string(31350)
        progress.update( percent, "", message, "" )
        i = i + 1
        print percent, steps
    
        if (THUMBFORMAT != THUMBFORMATOSD) or (BACKGROUND != BACKGROUNDOSD):
            thumbnailgenerator.createThumbnails(ROOTDIR,THUMBFORMATOSD,BACKGROUNDOSD)

            #Update progress
            percent = int( ( i / steps ) * 100)
            message = local_string(31350)
            progress.update( percent, "", message, "" )
            i = i + 1
            print percent, steps
    
        #Reset setting
        settings.setSetting(id='generate_thumbnails', value='false')

    #Close progressbar
    progress.close()
    

#XBMC INTERFACE  
############################################################################

def CATEGORIES():
    
    #Delete or generate the thumbnails
    if (DELETETHUMBNAILS == 'true') or (GENERATETHUMBNAILS == 'true'):
        updateThumbs()
    
    #Login if cookies aren't set
    try:
       open(os.path.join(ROOTDIR, "cookies"))
    except IOError:
       login()

    #Check if the cookie has expired and log in again if necesseray
    for element in  open(os.path.join(ROOTDIR, "cookies")).read().split(";"):
        if "Expires=" in element:
            expirationDate = element.replace("Expires=","")
            now = parser.parse(expirationDate).replace(tzinfo=None)
            td = now-datetime.utcnow()
            if (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10.0**6 < 0:
                login()
                break
          
    if (USERNAME in open(os.path.join(ROOTDIR, "cookies")).read()) and USERNAME != '':
        #Show categories
        if HIDELIVEGAMES == 'false' and ("|gcl" in open(os.path.join(ROOTDIR, "cookies")).read()):
            addDir(local_string(31100),'/live',8,ICON)
        addDir(local_string(31150),'/lastnight',10,ICON)
        addDir(local_string(31140),'/highlights',1,ICON)
        addDir(local_string(31110),'/condensed',1,ICON)
        addDir(local_string(31120),'/archive',1,ICON)
        #addDir(local_string(31130),'/classic',10,ICON)
    else:
        os.remove(os.path.join(ROOTDIR, "cookies"))
        print "cookies removed"
        
        dialog = xbmcgui.Dialog()
        dialog.ok('Login failed', 'Check your login credentials')
        xbmcplugin.endOfDirectory(handle = int(sys.argv[1]),succeeded=False)
        return None


def YEAR(url):
    #Download the xml file
    downloadXMLData('http://gamecenter.nhl.com/nhlgc/servlets/allarchives',{'date' : 'true', 'isFlex' : 'true'},"xml/archive.xml",'false')

    #Get available seasons
    xmlPath = os.path.join(ROOTDIR, "xml/archive.xml")
    xml = parse(xmlPath)
    seasons = xml.getElementsByTagName("season")

    for season in reversed(seasons):
        print season.attributes["id"].value
        if (season.attributes["id"].value == "2007"):#Links don't work
            break
        elif (season.attributes["id"].value == "2008"):#Links don't work
            break
        elif (season.attributes["id"].value == "2009"):#Links don't work
            break
        else:
            addDir( season.attributes["id"].value + ' - ' + str(int(season.attributes["id"].value) + 1),url+'/'+season.attributes["id"].value,2,ICON)


def MONTH(url,name):
    #Get available Months
    xmlPath = os.path.join(ROOTDIR, "xml/archive.xml")
    xml = parse(xmlPath)
    seasons = xml.getElementsByTagName("season")

    firstmonth = ''
    lastmonth = ''
    
    for season in seasons:
        if season.attributes["id"].value == name[:-7]:
            dates = season.getElementsByTagName("g")
            if len(dates[0].childNodes[0].nodeValue)>10: #Fix for alternative date format
                firstmonth = dates[0].childNodes[0].nodeValue[5:7]
                lastmonth = dates[len(dates)-1].childNodes[0].nodeValue[5:7]
            else:
                firstmonth = dates[0].childNodes[0].nodeValue[:2]
                lastmonth = dates[len(dates)-1].childNodes[0].nodeValue[:2]

            
    #Add directories
    i = int(lastmonth)

    while i >= 1:
        if i==1:
            addDir(local_string(31201),url+'/01',3,ICON)
        elif i==2:
            addDir(local_string(31202),url+'/02',3,ICON)
        elif i==3:
            addDir(local_string(31203),url+'/03',3,ICON)
        elif i==4:
            addDir(local_string(31204),url+'/04',3,ICON)
        elif i==5:
            addDir(local_string(31205),url+'/05',3,ICON)
        elif i==6:
            addDir(local_string(31206),url+'/06',3,ICON)
        elif i==7:
            addDir(local_string(31207),url+'/07',3,ICON)
        elif i==8:
            addDir(local_string(31208),url+'/08',3,ICON)
        elif i==9:
            addDir(local_string(31209),url+'/09',3,ICON)
        elif i==10:
            addDir(local_string(31210),url+'/10',3,ICON)
        elif i==11:
            addDir(local_string(31211),url+'/11',3,ICON)
        elif i==12:
            addDir(local_string(31212),url+'/12',3,ICON)
            

        if i == int(firstmonth):
            break
        
        i = i - 1

        if i==0:
            i = 12


def GAMES(url,name):
    
    #Split the url
    splittedURL = url.split("/")
    typeOfVideo = splittedURL[1]
    year = splittedURL[2]
    month = splittedURL[3]
    
    #Download the xml file
    if typeOfVideo == 'condensed' or int(year) >= 2012:
        #Download the xml file
        values = {'season' : year, 'isFlex' : 'true', 'month' : month, 'condensed' : 'true'}
        downloadXMLData('http://gamecenter.nhl.com/nhlgc/servlets/archives',values,"xml/condensed.xml",'false')
        xmlPath = os.path.join(ROOTDIR, "xml/condensed.xml")
    else:
        #Download the xml file
        values = {'season' : year, 'isFlex' : 'true', 'month' : month}
        downloadXMLData('http://gamecenter.nhl.com/nhlgc/servlets/archives',values,"xml/games.xml",'false')
        xmlPath = os.path.join(ROOTDIR, "xml/games.xml")

    #Parse the xml file
    xml = parse(xmlPath)
    games = xml.getElementsByTagName("game")

    #Get available games
    for game in games:
        gid = game.getElementsByTagName("gid")[0].childNodes[0].nodeValue
        date = game.getElementsByTagName("date")[0].childNodes[0].nodeValue
        homeTeam = game.getElementsByTagName("homeTeam")[0].childNodes[0].nodeValue
        awayTeam = game.getElementsByTagName("awayTeam")[0].childNodes[0].nodeValue

        #Versus string
        versus = 31400
        if ALTERNATIVEVS == 'true':
            versus = 31401

        #Localize the date
        date2 = date[:10]
        date = datetime.fromtimestamp(time.mktime(time.strptime(date2,"%Y-%m-%d"))).strftime(xbmc.getRegion('dateshort'))

        #Get teamnames
        teams = getTeams()
        
        #Game title
        name = date + ': ' + teams[awayTeam][TEAMNAME] + " " + local_string(versus) + " " + teams[homeTeam][TEAMNAME]

        #Icon path
        iconPath =''
        if USETHUMBNAILS == 'true':
            iconPath = os.path.join(ROOTDIR, "resources/images/" + THUMBFORMAT + "_" + BACKGROUND + "/"+ awayTeam + "vs" + homeTeam + ".png")

        #Add directories
        if SHOWHADIALOG == 'true':
            addDir2(name,url+"/"+gid,4,iconPath)
        else:
            addDir(name,url+"/"+gid,4,iconPath)
        

def VIDEOLINKS(url,name):
    
    #Split the url
    splittedURL = url.split("/")
    typeOfVideo = splittedURL[1]
    year = splittedURL[2]
    month = splittedURL[3]
    gameid = splittedURL[4]

    #Load the xml file
    if typeOfVideo == 'condensed' or int(year) >= 2012:
        xmlPath = os.path.join(ROOTDIR, "xml/condensed.xml")
    else:
        xmlPath = os.path.join(ROOTDIR, "xml/games.xml")

    xml = parse(xmlPath)
    games = xml.getElementsByTagName("game")

    #Video URLs
    home_url = ''
    away_url = ''

    #Videotitle
    videotitle = ''

    #Icon path
    iconPath = ''

    #Show home and away feed for chosen game
    for game in games:
        gid = game.getElementsByTagName("gid")[0].childNodes[0].nodeValue
        date = game.getElementsByTagName("date")[0].childNodes[0].nodeValue
        homeTeam = game.getElementsByTagName("homeTeam")[0].childNodes[0].nodeValue
        awayTeam = game.getElementsByTagName("awayTeam")[0].childNodes[0].nodeValue
        
        if int(gid) == int(gameid):
            playPathPart1 = game.getElementsByTagName("program")[0].getElementsByTagName("publishPoint")[0].childNodes[0].nodeValue[37:][:-49]
            playPathPart2 = game.getElementsByTagName("program")[0].getElementsByTagName("publishPoint")[0].childNodes[0].nodeValue[-45:]
            
            #Versus string
            versus = 31400
            if ALTERNATIVEVS == 'true':
                versus = 31401

            #Localize the date
            date2 = date[:10]
            date = datetime.fromtimestamp(time.mktime(time.strptime(date2,"%Y-%m-%d"))).strftime(xbmc.getRegion('dateshort'))

            #Get teamnames
            teams = getTeams()
        
            #Set videotitle
            videotitle = date + ': ' + teams[awayTeam][TEAMNAME] + " " + local_string(versus) + " " + teams[homeTeam][TEAMNAME]

            #Set icon path
            if USETHUMBNAILS == 'true':
                iconPath = os.path.join(ROOTDIR, "resources/images/" + THUMBFORMATOSD + "_" + BACKGROUNDOSD + "/"+ awayTeam + "vs" + homeTeam + ".png")
            
            #Get correct type of video
            if typeOfVideo == 'lastnight':
                availableFeeds = [local_string(31500),local_string(31501),local_string(31502)]
                dialog = xbmcgui.Dialog()
                ret = dialog.select(local_string(31310), availableFeeds)
                if ret == 0:
                    typeOfVideo = "highlights"
                elif ret == 1:
                    typeOfVideo = "condensed"
                else:
                    typeOfVideo = "archive"
            
            #Quality Dialog
            if SHOWDIALOGQUALITY == 'true':
                availableFeeds = [local_string(31360),local_string(31361),local_string(31362),local_string(31363),local_string(31364)]
                dialog = xbmcgui.Dialog()
                ret = dialog.select(local_string(31311), availableFeeds)
                if ret == 0:
                    quality = ""
                elif ret == 1:
                    quality = "_4500"
                    if int(year) >= 2012:
                        quality = "_4500"
                    else:
                        quality = "_3000"
                elif ret == 2:
                        quality = "_3000"
                elif ret == 3:
                    quality = "_1600"
                elif ret == 4:
                    quality = "_800"
            else:
                if QUALITY == 4:
                    quality = ""
                elif QUALITY == 3:
                    quality = "_4500"
                    if int(year) >= 2012:
                        quality = "_4500"
                    else:
                        quality = "_3000"
                elif QUALITY == 2:
                    quality = "_3000"
                elif QUALITY == 1:
                    quality = "_1600"
                else:
                    quality = "_800"
            
            print playPathPart1[4:] 
            http_url = "http://nhl.cdn.neulion.net/" + playPathPart1[4:] + "/v1/playlist" + quality + ".m3u8"
            http_url = http_url.replace('/pc/', '/ced/')

            #Fix for 2012-2013 season
            if int(year) >= 2012:
                http_url = http_url.replace('http://nhl.cdn.neulion.net/', 'http://nlds150.cdnak.neulion.com/')
                http_url = http_url.replace('s/nhlmobile/vod/nhl/', 'nlds_vod/nhl/vod/')
                http_url = http_url.replace('/v1/playlist', '')
                http_url = http_url.replace('.m3u8', '_ced.mp4.m3u8')

                #Fix for early games in the season
                http_url = http_url.replace('condensed_ced', 'condensed_1_ced')
                http_url = http_url.replace('condensed_4500', 'condensed_1_4500')
                http_url = http_url.replace('condensed_3000', 'condensed_1_3000')
                http_url = http_url.replace('condensed_1600', 'condensed_1_1600')
                http_url = http_url.replace('condensed_800', 'condensed_1_800')

                #Fix for some streams
                http_url = http_url.replace('s/as3/', '')
                
                if typeOfVideo == 'archive':
                    http_url = http_url.replace('condensed', 'whole')
                    http_url = http_url.replace('_ced.mp4', '_ipad.mp4')
                elif typeOfVideo == 'highlights':
                    http_url = http_url.replace('condensed', 'continuous')


            home_url = http_url
            
            http_url = http_url.replace('_h_', '_a_')
            away_url = http_url

            #print http_url

        
    if SHOWHADIALOG == 'true':
        #'Choose a feed' dialog box
        dialog = xbmcgui.Dialog()
        ret = dialog.yesno(local_string(31300), local_string(31310),'','',local_string(31320),local_string(31330))
        if ret == 0:
            print "HOME"
            liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconPath)
            liz.setInfo( type="Video", infoLabels={ "Title": videotitle } )
            xbmc.Player(xbmc.PLAYER_CORE_AUTO).play(home_url,liz)                
        else:
            print "AWAY"
            liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconPath)
            liz.setInfo( type="Video", infoLabels={ "Title": videotitle } )
            xbmc.Player(xbmc.PLAYER_CORE_AUTO).play(away_url,liz)
    else:
        #'Choose a feed' directory
        addLink("Home",home_url,videotitle,iconPath)
        addLink("Away",away_url,videotitle,iconPath)
    

def LIVE(url,name):
    #Download live.xml
    url2 = 'http://cedrss.neulion.com/nhlgc/archives/?live=true&user=' + USERNAME + '&pass=' + PASSWORD
    response = urllib2.urlopen(url2)
    downloadedXML = response.read()

    #Save the xml file
    saveFile("xml/live.xml",downloadedXML)

    #Load the xml file
    xmlPath = os.path.join(ROOTDIR, "xml/live.xml")
    xml = parse(xmlPath)
    games = xml.getElementsByTagName('item')

    #Get teamnames
    teams = getTeams()
        
    #Invert teams dictionary
    teams2 = {}
    for team in teams.keys():
        teams2[teams[team][4]] = team
        
    for game in games:
        #Setup variables
        awayTeam = ''
        homeTeam = ''
        date = ''
        live = ''
        live2 = ''
        
        for element in game.getElementsByTagName('boxee:property'):
            if element.attributes["name"].value == 'custom:awayName':
               awayTeam = teams2[element.childNodes[0].nodeValue]

            if element.attributes["name"].value == 'custom:homeName':
               homeTeam = teams2[element.childNodes[0].nodeValue]

            if element.attributes["name"].value == 'custom:gameState' and element.childNodes:
               live = element.childNodes[0].nodeValue

            if element.attributes["name"].value == 'custom:result' and element.childNodes:
               live2 = element.childNodes[0].nodeValue
               
            if element.attributes["name"].value == 'custom:startTime':
               date = element.childNodes[0].nodeValue


        #Game title
        title = game.getElementsByTagName('description')[0].childNodes[0].nodeValue

        #Get start time
        gameStarted = re.findall(r'\d{2}\S\d{2}\S\d{4}\s\d{2}\S\d{2}', title)
        c = time.strptime(date,"%m/%d/%Y %H:%M:%S")

        if not gameStarted:
            #Displayed titlestring
            if live == 'FINAL' or live2 == 'FINAL':
                title = live + ': ' + teams[awayTeam][TEAMNAME] + " " + local_string(31400) + " " + teams[homeTeam][TEAMNAME]
            else:
                title = live + ' - ' + live2 + ': ' + teams[awayTeam][TEAMNAME] + " " + local_string(31400) + " " + teams[homeTeam][TEAMNAME]
        else:
            #Convert the time to the local timezone
            date = datetime.fromtimestamp(time.mktime(c))
            date = date.replace(tzinfo=tz.gettz('America/New_York'))
            datelocal = date.astimezone(tz.tzlocal()).strftime(xbmc.getRegion('dateshort')+' '+xbmc.getRegion('time').replace('%H%H','%H').replace(':%S',''))

            #Versus string
            versus = 31400
            if ALTERNATIVEVS == 'true':
                versus = 31401
            
            #Displayed titlestring
            title = datelocal + ': ' + teams[awayTeam][TEAMNAME] + " " + local_string(versus) + " " + teams[homeTeam][TEAMNAME]
            
            
        #Icon path
        iconPath =''
        if USETHUMBNAILS == 'true':
            iconPath = os.path.join(ROOTDIR, "resources/images/" + THUMBFORMAT + "_" + BACKGROUND + "/"+ awayTeam + "vs" + homeTeam + ".png")
            
        #Add game
        if SHOWHADIALOGLIVE == 'true':
            addDir2(title,url + game.getElementsByTagName('description')[0].childNodes[0].nodeValue,9,iconPath)
        else:
            addDir(title,url + game.getElementsByTagName('description')[0].childNodes[0].nodeValue,9,iconPath)
        

def LIVELINKS(url,name):    
    #Load the xml file
    xmlPath = os.path.join(ROOTDIR, "xml/live.xml")
    xml = parse(xmlPath)
    games = xml.getElementsByTagName('item')

    #Video URLs
    home_url = ''
    away_url = ''
    
    #Videotitle
    videotitle = name

    #Icon path
    iconPath = ''

    #Get teamnames
    teams = getTeams()
        
    #Invert teams dictionary
    teams2 = {}
    for team in teams.keys():
        teams2[teams[team][4]] = team
    
    if "|gcl" in open(os.path.join(ROOTDIR, "cookies")).read():
        for game in games:
            if game.getElementsByTagName('description')[0].childNodes[0].nodeValue == url[5:]:
                #Quality settings
                if int(settings.getSetting( id="quality")) == 4:
                    quality = "_4500_ced."
                elif int(settings.getSetting( id="quality")) == 3:
                    quality = "_4500_ced."
                elif int(settings.getSetting( id="quality")) == 2:
                    quality = "_3000_ced."
                elif int(settings.getSetting( id="quality")) == 1:
                    quality = "_1600_ced."
                else:
                    quality = "_800_ced."

                #Get teamlogos
                awayTeam = ''
                homeTeam = ''
            
                for element in game.getElementsByTagName('boxee:property'):
                    if element.attributes["name"].value == 'custom:awayName':
                       awayTeam = teams2[element.childNodes[0].nodeValue]

                    if element.attributes["name"].value == 'custom:homeName':
                       homeTeam = teams2[element.childNodes[0].nodeValue]
                   
                #Set icon path
                if USETHUMBNAILS == 'true':
                    iconPath = os.path.join(ROOTDIR, "resources/images/" + THUMBFORMATOSD + "_" + BACKGROUNDOSD + "/"+ awayTeam + "vs" + homeTeam + ".png")
            
                #Home/away feeds
                for element in game.getElementsByTagName('boxee:property'):
                    #Home feed
                    if element.attributes["name"].value == 'custom:home-video-stream':
                        http_url = element.childNodes[0].nodeValue
                        if SHOWDIALOGQUALITY != 'true':
                            http_url = element.childNodes[0].nodeValue.replace('_ced.', quality)
                        home_url = http_url
                    #Away feed
                    if element.attributes["name"].value == 'custom:away-video-stream':
                        http_url = element.childNodes[0].nodeValue
                        if SHOWDIALOGQUALITY != 'true':
                            http_url = element.childNodes[0].nodeValue.replace('_ced.', quality)
                        away_url = http_url


        #'Choose a feed' dialog box
        if (home_url != '') or (away_url != ''):
           
            if SHOWDIALOGQUALITY == 'true':
                availableFeeds = [local_string(31360),local_string(31361),local_string(31362),local_string(31363),local_string(31364)]
                dialog = xbmcgui.Dialog()
                ret = dialog.select(local_string(31310), availableFeeds)
                if ret == 0:
                    home_url = home_url.replace('_ced.', '_4500_ced.')
                    away_url = away_url.replace('_ced.', '_4500_ced.')
                elif ret == 1:
                    home_url = home_url.replace('_ced.', '_4500_ced.')
                    away_url = away_url.replace('_ced.', '_4500_ced.')
                elif ret == 2:
                    home_url = home_url.replace('_ced.', '_3000_ced.')
                    away_url = away_url.replace('_ced.', '_3000_ced.')
                elif ret == 3:
                    home_url = home_url.replace('_ced.', '_1600_ced.')
                    away_url = away_url.replace('_ced.', '_1600_ced.')
                elif ret == 4:
                    home_url = home_url.replace('_ced.', '_800_ced.')
                    away_url = away_url.replace('_ced.', '_800_ced.')
        
            if SHOWHADIALOGLIVE == 'true':#always true
                dialog = xbmcgui.Dialog()
                ret = dialog.yesno(local_string(31300), local_string(31310),'','',local_string(31320),local_string(31330))
                if ret == 0:
                    print "HOME"
                    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconPath)
                    liz.setInfo( type="Video", infoLabels={ "Title": videotitle } )
                    xbmc.Player(xbmc.PLAYER_CORE_AUTO).play(home_url + "|User-Agent=" + USERAGENT,liz)
            
                else:
                    print "AWAY"
                    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconPath)
                    liz.setInfo( type="Video", infoLabels={ "Title": videotitle } )
                    xbmc.Player(xbmc.PLAYER_CORE_AUTO).play(away_url + "|User-Agent=" + USERAGENT,liz)
            else:
                addLink('Home',home_url + "|User-Agent=" + USERAGENT,videotitle,iconPath)
                addLink('Away',away_url + "|User-Agent=" + USERAGENT,videotitle,iconPath)  
                
        else:
            dialog = xbmcgui.Dialog()
            if name[:5] == 'FINAL':
                ret = dialog.ok(local_string(31300), local_string(31370))
            else:
                ret = dialog.ok(local_string(31300), local_string(31380))
    else:
        dialog = xbmcgui.Dialog()
        ret = dialog.ok(local_string(31300), local_string(31390))



def LASTNIGHT(url,name):
    
    #Get date of last night
    d=datetime.now()-timedelta(days=1)
    typeOfVideo = 'archived'
    year = str(int(d.strftime("%Y"))-1)
    month = d.strftime("%m")

    #Download the xml file
    if typeOfVideo == 'condensed' or int(year) >= 2012:
        #Download the xml file
        values = {'season' : year, 'isFlex' : 'true', 'month' : month, 'condensed' : 'true'}
        downloadXMLData('http://gamecenter.nhl.com/nhlgc/servlets/archives',values,"xml/condensed.xml",'false')
        xmlPath = os.path.join(ROOTDIR, "xml/condensed.xml")
    else:
        #Download the xml file
        values = {'season' : year, 'isFlex' : 'true', 'month' : month}
        downloadXMLData('http://gamecenter.nhl.com/nhlgc/servlets/archives',values,"xml/games.xml",'false')
        xmlPath = os.path.join(ROOTDIR, "xml/games.xml")

    #Parse the xml file
    xml = parse(xmlPath)
    games = xml.getElementsByTagName("game")
    
    #Get the last day when games were played
    lastMatchDay = ''
    lastMatchDaySet = 'false'
    
    #Get available games
    for game in games:
        gid = game.getElementsByTagName("gid")[0].childNodes[0].nodeValue
        date = game.getElementsByTagName("date")[0].childNodes[0].nodeValue
        homeTeam = game.getElementsByTagName("homeTeam")[0].childNodes[0].nodeValue
        awayTeam = game.getElementsByTagName("awayTeam")[0].childNodes[0].nodeValue

        #Versus string
        versus = 31400
        if ALTERNATIVEVS == 'true':
            versus = 31401

        #Localize the date
        date2 = date[:10]
        date = datetime.fromtimestamp(time.mktime(time.strptime(date2,"%Y-%m-%d"))).strftime(xbmc.getRegion('dateshort'))
        
        #
        if lastMatchDaySet == 'false':
            lastMatchDay = datetime.fromtimestamp(time.mktime(time.strptime(date2,"%Y-%m-%d"))).strftime('%d')
            lastMatchDaySet = 'true'
        
        if lastMatchDay != datetime.fromtimestamp(time.mktime(time.strptime(date2,"%Y-%m-%d"))).strftime('%d'):
            break
        
        #Get teamnames
        teams = getTeams()
        
        #Game title
        name = date + ': ' + teams[awayTeam][TEAMNAME] + " " + local_string(versus) + " " + teams[homeTeam][TEAMNAME]

        #Icon path
        iconPath =''
        if USETHUMBNAILS == 'true':
            iconPath = os.path.join(ROOTDIR, "resources/images/" + THUMBFORMAT + "_" + BACKGROUND + "/"+ awayTeam + "vs" + homeTeam + ".png")

        #Add directories
        #/condensed/2013/01/9959
        if SHOWHADIALOG == 'true':
            addDir2(name,url+"/"+year+"/"+month+"/"+gid,4,iconPath)
        else:
            addDir(name,url+"/"+year+"/"+month+"/"+gid,4,iconPath)
            

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
            params=sys.argv[2]
            cleanedparams=params.replace('?','')
            if (params[len(params)-1]=='/'):
                    params=params[0:len(params)-2]
            pairsofparams=cleanedparams.split('&')
            param={}
            for i in range(len(pairsofparams)):
                    splitparams={}
                    splitparams=pairsofparams[i].split('=')
                    if (len(splitparams))==2:
                            param[splitparams[0]]=splitparams[1]
                            
    return param


def addLink(name,url,title,iconimage):
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": title } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
    return ok

def addDir(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def addDir2(name,url,mode,iconimage):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

             
params=get_params()
url=None
name=None
mode=None

try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
    print ""
    CATEGORIES()
   
elif mode==1:
    print ""+url
    YEAR(url)

elif mode==2:
    print ""+url
    MONTH(url,name)        

elif mode==3:
    print ""+url
    GAMES(url,name)

elif mode==4:
    print ""+url
    VIDEOLINKS(url,name)

elif mode==8:
    print ""+url
    LIVE(url,name)

elif mode==9:
    print ""+url
    LIVELINKS(url,name)
    
elif mode==10:
    print ""+url
    LASTNIGHT(url,name)


xbmcplugin.endOfDirectory(int(sys.argv[1]))