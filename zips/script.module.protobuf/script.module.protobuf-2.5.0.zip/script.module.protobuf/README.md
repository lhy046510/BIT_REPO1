xbmc-protobuf
=============

protobuf packed for XBMC