#!/usr/bin/python
# -*- coding: utf-8 -*-
##┌──────────────────────────────────────
##│  XBMC.DMM v0.0.2 (2014/06/10)
##│  Copyright (c) Inpane
##│  plugin.video.dmm
##│  http://xbmc.inpane.com/
##│  info@inpane.com
##└──────────────────────────────────────
##
## [ 更新履歴 ]
## 2014/06/10 -> v0.0.2
##  addon.xmlを変更
##
## 2013/04/17 -> v0.0.1
##  テスト版公開
##
##==============================================================================
## 設定値をここに記載する。
import sys, os, string

__dmm_url__     = 'http://www.dmm.com'
__anime_url__   = __dmm_url__ + '/iphone/digital/anime/-/list/=/sort=price_asc/'
__cinema_url__  = __dmm_url__ + '/iphone/digital/cinema/-/list/=/sort=price_asc/'
__video_url__   = __dmm_url__ + '/iphone/digital/video/-/list/=/sort=price_asc/'
__stream_uri1__ = '/digital/-/proxy/=/product_id='
__stream_uri2__ = '/shop=gvideoi/transfer_type=stream/rate=0'
__anime_tit__   = 'アニメ'
__cinema_tit__  = '映画・ドラマ'
__video_tit__   = 'バラエティ'

#-------------------------------------------------------------------------------
import re
import httplib, urllib, urllib2, cookielib
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
from HTMLParser import HTMLParser, HTMLParseError

#-------------------------------------------------------------------------------
__addon_id__ = 'plugin.video.dmm'
__settings__ = xbmcaddon.Addon(__addon_id__)

try:    __xbmc_version__ = xbmc.getInfoLabel('System.BuildVersion')
except: __xbmc_version__ = 'Unknown'
class AppURLopener(urllib.FancyURLopener):
	version = 'XBMC/' + __xbmc_version__ + ' - Download and play (' + os.name + ')'
urllib._urlopener = AppURLopener()

IN  = {}
OUT = {}

#-------------------------------------------------------------------------------
def getParams():
	ParamDict = {}
	try:
		#print "getParams() argv=", sys.argv
		if sys.argv[2] : ParamPairs = sys.argv[2][1:].split( "&" )
		for ParamsPair in ParamPairs : 
			ParamSplits = ParamsPair.split('=')
			if (len(ParamSplits)) == 2 : ParamDict[ParamSplits[0]] = ParamSplits[1]
	except : pass
	return ParamDict

#-------------------------------------------------------------------------------
def MenuList():
	MakeListRow(__anime_tit__,  __anime_url__ )
	MakeListRow(__cinema_tit__, __cinema_url__)
	MakeListRow(__video_tit__,  __video_url__ )
	xbmcplugin.endOfDirectory(handle = OUT[ 'handle' ], succeeded = True)


#-------------------------------------------------------------------------------
def MakeListRow(tit, url):
	url = 'plugin://' + __addon_id__ + '?ope=list&url=%s' % urllib.quote(url)
	li  = xbmcgui.ListItem( tit )
	ok  = xbmcplugin.addDirectoryItem(OUT[ 'handle' ], url, listitem = li, isFolder = True, totalItems = 1)

#-------------------------------------------------------------------------------
class ListHTMLParser(HTMLParser):
	def __init__(self):
		HTMLParser.__init__(self)
		self.flb_works_flg = 0
		self.flb_works_a_flg        = 0
		self.flb_works_thum_flg     = 0
		self.flb_works_txt_flg      = 0
		self.flb_works_txt_tit_flg  = 0
		self.flb_works_txt_cast_flg = 0
		self.flb_works_txt_prc_flg  = 0
		self.btn_prev_flg           = 0
		self.btn_next_flg           = 0
		self.flb_works_row      = 0
		self.tmp_item = {}
		self.tmp_item[self.flb_works_row] = {}
		self.next_url = ''

	#-- スタートタグ -----------------------------------------------------------
	def handle_starttag(self, tag, attrs):
		attrs = dict(attrs) # タプルだと扱いにくいので辞書にする

		if 'div' == tag and 'class' in attrs:

			# flb_works 動画リンク(フラグON)
			if re.match('(flb\-works)', attrs['class']): 
				self.flb_works_flg = 1
				self.tmp_item[self.flb_works_row] = {}

			# btn_prev 戻るリンク(フラグON)
			if re.match('(btn\-prev)', attrs['class']): self.btn_prev_flg = 1

			# btn_next 次へリンク(フラグON)
			if re.match('(btn\-next)', attrs['class']): self.btn_next_flg = 1


		if 'a' == tag and self.flb_works_flg == 1:
			self.flb_works_a_flg += 1

			# サムネイル(フラグON)
			if self.flb_works_a_flg == 1: 
				self.flb_works_thum_flg = 1
				# 動画ID(★データ)
				m = re.search(".*\/cid=(.*)\/.*", attrs['href'])
				self.tmp_item[self.flb_works_row]['cid'] = m.group(1)

			# テキスト(フラグON)
			elif self.flb_works_a_flg == 2: self.flb_works_txt_flg = 1

		# サムネイルURL(★データ)
		if 'img' == tag and self.flb_works_thum_flg == 1 and 'src' in attrs: 
			#print '-->', attrs['src']
			self.tmp_item[self.flb_works_row]['thum'] = attrs['src']

		# テキストタイトル(フラグON)
		if 'dt' == tag and self.flb_works_txt_flg == 1: self.flb_works_txt_tit_flg = 1

		# テキストキャスト(フラグON)
		if 'dd' == tag and self.flb_works_txt_flg == 1 and 'class' in attrs: 
			if re.match('(cast)', attrs['class']): self.flb_works_txt_cast_flg = 1

		# テキスト価格(フラグON)
		if 'em' == tag and self.flb_works_txt_flg == 1: self.flb_works_txt_prc_flg  = 1

		# 戻るURL(★データ)
		#if 'a' == tag and self.btn_prev_flg == 1 and 'href' in attrs: print u'戻る', attrs['href']

		# 次へURL(★データ)
		if 'a' == tag and self.btn_next_flg == 1 and 'href' in attrs: self.next_url = attrs['href']
		

	#-- データ -----------------------------------------------------------------
	def handle_data(self, data):

		# テキストタイトル(★データ)
		if self.flb_works_txt_tit_flg == 1: 
			#print data
			self.tmp_item[self.flb_works_row]['tit'] = data

		# テキストキャスト(★データ)
		if self.flb_works_txt_cast_flg == 1: 
			#print data
			if 'cast' not in self.tmp_item[self.flb_works_row]: self.tmp_item[self.flb_works_row]['cast'] = data
			else: self.tmp_item[self.flb_works_row]['cast'] = self.tmp_item[self.flb_works_row]['cast'] + ' ' + data


		# テキスト価格(★データ)
		if self.flb_works_txt_prc_flg == 1: 
			self.tmp_item[self.flb_works_row]['prc'] = data

	#-- エンドタグ -------------------------------------------------------------
	def handle_endtag(self, tag):

		if 'a' == tag and self.flb_works_flg == 1:
			# サムネイルURL(フラグOFF)
			if self.flb_works_a_flg == 1: 
				self.flb_works_thum_flg = 0

			# テキスト(フラグOFF)
			if self.flb_works_a_flg == 2: 
				self.flb_works_txt_flg = 0 # テキスト(フラグOFF)
				self.flb_works_flg     = 0
				self.flb_works_a_flg   = 0
				self.flb_works_row    += 1

		# テキストタイトル(フラグOFF)
		if 'dt' == tag and self.flb_works_txt_tit_flg == 1: self.flb_works_txt_tit_flg = 0

		# テキストキャスト(フラグOFF)
		if 'dd' == tag and self.flb_works_txt_cast_flg == 1: self.flb_works_txt_cast_flg = 0

		# テキスト価格(フラグOFF)
		if 'em' == tag and self.flb_works_txt_prc_flg == 1: self.flb_works_txt_prc_flg = 0

		# 戻るリンク(フラグOFF)
		if 'div' == tag and self.btn_prev_flg == 1: self.btn_prev_flg = 0

		# 次へリンク(フラグOFF)
		if 'div' == tag and self.btn_next_flg == 1: self.btn_next_flg = 0

#-------------------------------------------------------------------------------
def WebList(url):
	result = urllib.urlopen(url)
	buffer = result.read().decode('euc-jp').encode('utf-8')
	parser = ListHTMLParser()
	parser.feed(buffer)
	parser.close()

	item = {}
	item_row = 0
	next_flg = 1
	for key in parser.tmp_item: 
		#print parser.tmp_item[key]['cid']
		if re.match('(無料)', parser.tmp_item[key]['prc']):
			item[item_row] = {}
			item[item_row]['tit' ] = parser.tmp_item[key]['tit' ]
			item[item_row]['cast'] = parser.tmp_item[key]['cast']
			item[item_row]['prc' ] = parser.tmp_item[key]['prc' ]
			item[item_row]['thum'] = parser.tmp_item[key]['thum']
			item[item_row]['cid' ] = parser.tmp_item[key]['cid' ]
			item_row += 1
		else: next_flg = 0

	item_num = 0
	for key in item: 
		url = __dmm_url__ + __stream_uri1__ + item[key]['cid'] + __stream_uri2__
		url = 'plugin://' + __addon_id__ + '?ope=play&url=%s' % urllib.quote(url)
		#print url
		li  = xbmcgui.ListItem( item[key]['tit'], iconImage=item[key]['thum'], thumbnailImage=item[key]['thum'] )
		li.setInfo( type = 'video', infoLabels = { 'title': item[key]['tit'],'cast': item[key]['cast']  } )
		item_num = key + 1
		ok  = xbmcplugin.addDirectoryItem(OUT[ 'handle' ], url, listitem = li, isFolder = False, totalItems = item_num)

	item_num += 1
	if next_flg and parser.next_url != '': 
		url = 'plugin://' + __addon_id__ + '?ope=list&url=%s' % urllib.quote(__dmm_url__ + parser.next_url)
		li  = xbmcgui.ListItem( '次のページへ' )
		ok  = xbmcplugin.addDirectoryItem(OUT[ 'handle' ], url, listitem = li, isFolder = True, totalItems = item_num)

	xbmcplugin.endOfDirectory(handle = OUT[ 'handle' ], succeeded = True)
	#xbmcplugin.endOfDirectory(handle = OUT[ 'handle' ], succeeded = False)

#-------------------------------------------------------------------------------
def main():

	global IN
	global OUT
	IN = getParams()

	IN[ 'handle' ] = int(sys.argv[1])
	OUT[ 'handle' ] = IN[ 'handle' ]

	if   IN.has_key('ope') and IN['ope'] == "list": WebList(urllib.unquote(IN['url']))
	elif IN.has_key('ope') and IN['ope'] == "play":
		xbmcplugin.endOfDirectory(handle = OUT[ 'handle' ], succeeded = False)

		Player = xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER)
		Player.play(urllib.unquote(IN['url']))

	else : MenuList()

#-------------------------------------------------------------------------------
if __name__  == '__main__': main()
