# coding: utf-8

import time
import json
import urllib
import hashlib
import xbmc, xbmcgui, xbmcaddon

addon = xbmcaddon.Addon("plugin.video.115")

def build_url(address, query):
    return "%s?%s" % (address, urllib.urlencode(query))

def icon(filename):
    return "%s/resources/media/icon/%s" % (addon.getAddonInfo("path"), filename)

def info(message):
    xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % ("信息", message, icon("info.png")))

def warning(message):
    xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % ("警告", message, icon("warning.png")))

def error(message):
    xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % ("错误", message, icon("error.png")))

if __name__ == '__main__':
    authcode = addon.getSetting("authcode")

    if authcode == "":
        info("未登录，不用注销")
    else:
        current    = long(time.time())
        token      = hashlib.md5("%d%swobo123456" % (current, authcode)).hexdigest()
        logout_url = build_url("http://vendor.115.com/api/bindclient",
            {"authcode": authcode, "vendor": "wobo", "time": current, "token": token})

        try:
            result = json.loads(urllib.urlopen(logout_url).read())

            if result["state"] or xbmcgui.Dialog().yesno("注销失败",
                                                        u"错误信息：" + result["error"], "\n",
                                                         "是否强制注销？"):
                addon.setSetting("authcode", "")
                info("注销成功")
        except:
            error("异常")

