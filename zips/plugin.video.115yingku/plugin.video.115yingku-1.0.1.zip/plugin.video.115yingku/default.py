# coding: utf-8

import os
import sys
import time
import json
from   uuid import getnode, uuid1
import urllib
import urllib2
import hashlib
import urlparse
import platform
import traceback
import distutils.dir_util
import xbmc, xbmcgui, xbmcaddon, xbmcplugin

base_url   = sys.argv[0]
handle     = long(sys.argv[1])
args       = dict(urlparse.parse_qsl(sys.argv[2].lstrip('?')))
addon      = xbmcaddon.Addon()
dialog     = xbmcgui.Dialog()
authcode   = addon.getSetting("authcode")
media_dir  = "%s/resources/media" % addon.getAddonInfo("path")
user_agent = "Mozilla/5.0 (XBMC %s; %s; %s)"% (xbmc.getInfoLabel("System.BuildVersion"),
                                               platform.platform(), addon.getAddonInfo("version"))

def mkdir(path):
    if os.path.exists(path): return os.path.isdir(path)
    try: distutils.dir_util.mkpath(path)
    except: return False
    return True

def getdevice():
    node = getnode()
    while node < 1e11: node *= 10
    return node

def buildurl(address, query):
    return "%s?%s" % (address, urllib.urlencode(query))

def readurl(url):
    return urllib2.urlopen(urllib2.Request(url, headers={"User-Agent": user_agent})).read()

def readjson(url):
    return json.loads(readurl(url))

def icon(filename):
    return "%s/icon/%s" % (media_dir, filename)

def info(message):
    xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % ("信息", message, icon("info.png")))

def warning(message):
    xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % ("警告", message, icon("warning.png")))

def error(message):
    xbmc.executebuiltin("Notification(%s,%s,3000,%s)" % ("错误", message, icon("error.png")))

def kb_input(heading, default, hidden_input=False):
    kb = xbmc.Keyboard()
    kb.setHeading(heading)
    kb.setDefault(default)
    kb.setHiddenInput(hidden_input)
    kb.doModal()

    return kb.isConfirmed() and kb.getText() or ""

def writefile(filepath, content):
    open(filepath, "w").write(content)

def do_except():
    error("异常")
    xbmc.log(traceback.format_exc())

def download(url, savepath, use_cache=True):
    if not use_cache or not os.path.exists(savepath):
        if not mkdir(os.path.dirname(savepath)):
            return ""
        else:
            try: open(savepath, "wb").write(readurl(url))
            except: return ""
    return savepath

def colortext(color, content):
    return "[COLOR %s]%s[/COLOR]" % (color, content)

def on_index():
    xbmcplugin.setContent(handle, 'movies')

    if addon.getSetting("authcode") == "":
        xbmcplugin.addDirectoryItem(handle, buildurl(base_url, {"action": "login"}),
                                    xbmcgui.ListItem("选择这里进行登录..."), True)
    else:
        on_movie()

    xbmcplugin.endOfDirectory(handle)

def on_login():
    selected = 0
    if xbmc.__version__ >= "2.1.0":
        selected = dialog.select("请选择登录类型", ["用户名登录", "二维码登录"])

    if selected == 0:
        username = kb_input("请输入用户名", addon.getSetting("username"))
        password = username and kb_input("请输入密码", addon.getSetting("password"), True) or ""

        if username and password:
            password_sha1 = hashlib.sha1(password).hexdigest()
            device, current = getdevice(), long(time.time())
            token = hashlib.md5("%s%swobo%d123456%d" \
                                % (username, password_sha1, device, current)) .hexdigest()
            login_url = buildurl("http://vendor.115.com/api/login",
                {"type": "pwdlogin", "action": "login", "vendor": "wobo",
                 "user_id": username, "password": password_sha1,
                 "device": device, "time": current, "token": token})

            try:
                response = readjson(login_url)
                if not response["state"]:
                    error(response["error"])
                elif response["data"]["status"] != 0:
                    addon.setSetting("username", username)
                    addon.setSetting("password", password)
                    addon.setSetting("authcode", response["data"]["authcode"])
                    info("登录成功")
            except:
                do_except()
        else:
            error("无效的用户名或者密码")
    elif selected == 1:
        uuid, device, current = uuid1().hex, getdevice(), long(time.time())
        token = hashlib.md5("%swobo%d123456%d" % (uuid, device, current)).hexdigest()
        generate_url = buildurl("http://vendor.115.com/api/login",
            {"type": "qrcode", "action": "generate", "uuid": uuid,
             "vendor": "wobo", "device": device, "time": current, "token": token})

        qr_code_image = download(generate_url, "%s/images/qr_code.png" % media_dir, False)
        if not qr_code_image:
            error("获取二维码失败")
            return

        window = xbmcgui.Window()
        window.setCoordinateResolution(0)
        qr_code = xbmcgui.ControlImage(0, 0, 450, 450, qr_code_image)
        qr_code.setPosition((1920 - qr_code.getWidth()) / 2, (1080 - qr_code.getHeight()) / 2)
        window.addControl(qr_code)
        window.show()

        start_time = time.time()
        while time.time() - start_time < 120:
            time.sleep(1)

            current = long(time.time())
            token = hashlib.md5("%swobo%d123456%d" % (uuid, device, current)).hexdigest()
            check_url = buildurl("http://vendor.115.com/api/login",
                {"type": "qrcode", "action": "check", "uuid": uuid,
                 "vendor": "wobo", "device": device, "time": current, "token": token})

            try:
                response = readjson(check_url)
                if not response["state"]:
                    error(response["error"])
                    break
                elif response["data"]["status"] == -1:
                    error("扫描失败")
                    break
                elif response["data"]["status"] == 1:
                    info("已扫描，等待手机确认登录")
                elif response["data"]["status"] == 2:
                    current = long(time.time())
                    token = hashlib.md5("wobo%d123456%d" % (device, current)).hexdigest()
                    check_url = buildurl("http://vendor.115.com/api/login",
                        {"type": "bind", "action": "check", "vendor": "wobo",
                         "device": device, "time": current, "token": token})
                    response = readjson(check_url)
                    if not response["state"]:
                        error(response["error"])
                    elif response["data"]["status"] == 1:
                        addon.setSetting("authcode", response["data"]["authcode"])
                        info("登录成功")
                    else:
                        error("登录失败")
                    break
            except:
                do_except()
                break
        else:
            error("登录超时")

        window.close()
    else:
        error("登录失败")

def getFilters(subtype=args.get("subtype", 0)):
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    genres_url = buildurl("http://vendor.115.com/api/movies/genres",
        {"authcode": authcode, "vendor": "wobo",
         "time": current, "token": token, "subtype": subtype})

    try:
        response = readjson(genres_url)
        if response["state"]:
            return {"频道": response["data"][0], "类型": response["data"][1],
                    "地区": response["data"][2], "年份": response["data"][3]}
    except:
        pass

    return None

def on_movie():
    filters = getFilters()
    if filters is None:
        error("获取频道数据失败")
    else:
        xbmcplugin.setContent(handle, 'movies')
        xbmcplugin.addDirectoryItem(handle, buildurl(base_url, {"action": "filter"}),
                xbmcgui.ListItem(colortext("FFFF0000", "【点击这里进行筛选】")), True)
        xbmcplugin.addDirectoryItem(handle, buildurl(base_url, {"action": "keyword"}),
                xbmcgui.ListItem(colortext("FF00FF00", "【点击这里进行搜索】")), True)
        for channel in filters.get("频道", []):
            xbmcplugin.addDirectoryItem(
                handle, buildurl(base_url,
                    {"action": "list", "subtype": channel[0], "offset": 0, "update": 0}),
                xbmcgui.ListItem(channel[1]), True)
        xbmcplugin.endOfDirectory(handle)

def on_filter():
    filters = getFilters()
    if filters is None:
        error("获取频道数据失败")
    else:
        subtype_values = [i[0] for i in filters["频道"]]
        subtype_descs  = [i[1] for i in filters["频道"]]
        selected = dialog.select("频道", subtype_descs)
        if selected != -1:
            args["subtype"] = subtype_values[selected]
            filters = getFilters(args["subtype"])
            for english, chinese in [("genre", "类型"), ("country", "地区"), ("year", "年份")]:
                selected = dialog.select(chinese, [t[1] for t in filters[chinese]])
                if selected == -1:
                    break
                else:
                    args[english] = [t[0] for t in filters[chinese]][selected]
            else:
                on_list(filters)

def on_keyword():
    keyword = kb_input("请输入搜索关键字(汉字拼音首字母)", args.get("keyword", ""))
    if keyword:
        args["keyword"] = keyword
        on_search()

def getMovieInfo(mid):
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    movie_url = buildurl("http://vendor.115.com/api/movies/movie",
        {"authcode": authcode, "vendor": "wobo", "mid": mid, "time": current, "token": token})

    try:
        response = readjson(movie_url)
        if response["state"]:
            return response["data"]
    except:
        do_except()

    return None

def listMovies(head, movies_data, perpage, buildurl_params):
    movies = movies_data["data"]
    if not movies:
        info("未找到匹配的影片")
    else:
        xbmcplugin.setContent(handle, 'movies')

        if head is not None:
            xbmcplugin.addDirectoryItem(handle, head["url"], head["listitem"], True)

        index = 0
        for movie in movies:
            index += 1
            mid = long(movie["mid"])
            li = xbmcgui.ListItem(u"%d. %s" % (index, movie["title"]), iconImage=movie["poster"])
            mi = getMovieInfo(mid)
            if mi is not None:
                li.setInfo("video",
                    {"genre": mi["genre"], "year": mi["release_dates"], "plot": mi["summary"],
                     "cast": mi["casts"].split(","), "director": mi["directors"],
                     "title": mi["title"], "rating": mi["rating"]})
            xbmcplugin.addDirectoryItem(handle,
                buildurl(base_url, {"action": "apart", "mid": mid}), li, True)

        offset = long(args.get("offset", 0))
        count  = long(movies_data["count"])
        pages  = [{"offset": offset - perpage, "label": "** 上一页 **"},
                  {"offset": offset + perpage, "label": "** 下一页 **"}]
        for page in pages:
            if  page["offset"] < 0 and page["offset"] + perpage > 0:
                page["offset"] = 0

            if 0 <= page["offset"] and page["offset"] < count:
                buildurl_params["offset"] = page["offset"]
                xbmcplugin.addDirectoryItem(handle,
                    buildurl(base_url, buildurl_params), xbmcgui.ListItem(page["label"]), True)

        xbmcplugin.endOfDirectory(handle, updateListing=int(args.get("update", "0")))

def page(data):
    offset  = float(data["offset"])
    count   = float(data["count"])
    perpage = float(data["page_size"])

    return u"第%d/%d页" % (offset // perpage + 1, (count - 1) // perpage + 1)

def getKeywordLabel(keyword):
    return colortext("FFFF0000", u"关键字：") + colortext("FF00FF00", keyword)

def on_search():
    perpage = [10, 20, 50, 100, 150, 200][long(addon.getSetting("perpage"))]
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    search_url = buildurl("http://vendor.115.com/api/movies/search",
        {"authcode": authcode, "vendor": "wobo", "limit": perpage, "time": current,
         "offset": args.get("offset", 0), "keyword": args.get("keyword", ""), "token": token})

    try:
        response = readjson(search_url)
        if not response["state"]:
            error(response["error"])
        else:
            head = {
                "url": buildurl(base_url,
                    {"action": "keyword", "keyword": args.get("keyword", ""), "update": 1}),
                "listitem": xbmcgui.ListItem(u"%s【%s】（点此重新搜索）" \
                    % (page(response["data"]), getKeywordLabel(args.get("keyword", "")))), }
            listMovies(head, response["data"], perpage,
                {"action": "search", "keyword": args.get("keyword", ""), "update": 1})
    except:
        do_except()

def getFilterLabel(filters):
    return "%s/%s/%s/%s" % (
        colortext("FFFF0000", dict(filters.get("频道", []))[args.get("subtype", "0")]),
        colortext("FF00FF00", dict(filters.get("类型", []))[args.get("genre",   "0")]),
        colortext("FFFF00FF", dict(filters.get("地区", []))[args.get("country", "0")]),
        colortext("FFFFFF00", dict(filters.get("年份", []))[args.get("year",    "0")]))

def on_list(filters=None):
    perpage = [10, 20, 50, 100, 150, 200][long(addon.getSetting("perpage"))]
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    list_url = buildurl("http://vendor.115.com/api/movies/list",
        {"authcode": authcode, "vendor": "wobo", "limit": perpage,
         "offset": args.get("offset", 0), "subtype": args.get("subtype", 0),
         "year": args.get("year", 0), "country": args.get("country", 0),
         "genre": args.get("genre", 0), "order": 0, "time": current, "token": token})

    try:
        response = readjson(list_url)
        if not response["state"]:
            error(response["error"])
        else:
            if filters is None:
                filters = getFilters()
            if filters is not None:
                head = {
                    "url": buildurl(base_url, {"action": "filter", "update": 1}),
                    "listitem": xbmcgui.ListItem(u"%s【%s】（点此重新筛选）" \
                        % (page(response["data"]), getFilterLabel(filters))), }
            else:
                head = None
            listMovies(head, response["data"], perpage,
                {"action": "list", "subtype": args.get("subtype", 0),
                 "year": args.get("year", ""), "country": args.get("country", 0),
                 "genre": args.get("genre", 0), "update": 1})
    except:
        do_except()

def on_music():
    info("稍后推出...")

def on_apart():
    mid = args.get("mid", "")
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    apart_url = buildurl("http://vendor.115.com/api/movies/apart",
        {"authcode": authcode, "vendor": "wobo", "mid": mid, "time": current, "token": token})

    try:
        response = readjson(apart_url)
        if not response["state"]:
            error(response["error"])
        else:
            if len(response["data"]) == 1:
                args["pick_code"] = response["data"][0]["pick_code"]
                on_play()
            else:
                xbmcplugin.setContent(handle, 'movies')
                for episode in response["data"]:
                    xbmcplugin.addDirectoryItem(handle,
                        buildurl(base_url, {"action": "play", "mid": mid,
                                            "pick_code": episode["pick_code"]}),
                        xbmcgui.ListItem(episode["episode_desc"],
                                         iconImage=episode["video_img"]), True)
                xbmcplugin.endOfDirectory(handle)
    except:
        do_except()

def getMovieFiles(mid, pickcode):
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    video_url = buildurl("http://vendor.115.com/api/xbmc",
        {"authcode": authcode, "vendor": "wobo", "pickcode": pickcode,
         "mid": mid, "time": current, "token": token})

    try:
        response = readjson(video_url)
        if response["state"]:
            return response["video"]
    except:
        pass

    return None

def getDefinition(movies):
    definition = [2, 3, 4][long(addon.getSetting("definition"))]
    movies.sort(lambda a, b: a["definition"] - b["definition"])
    for movie in movies:
        if movie["definition"] == definition:
            return movie
    else:
        return movies[-1]

def getSubtitles(mid, pickcode):
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    subtitle_url = buildurl("http://vendor.115.com/api/movies/subtitle",
        {"authcode": authcode, "vendor": "wobo", "mid": mid, "pickcode": pickcode,
         "time": current, "token": token, "limit": 200, "offset": 0})

    try:
        response = readjson(subtitle_url)
        if response["state"]:
            return response["data"]
    except:
        do_except()

    return []

def getSeekTime(mid, pick_code):
    current = long(time.time())
    token = hashlib.md5("%dwobo%s123456%d" % (getdevice(), authcode, current)).hexdigest()
    history_url = buildurl("http://vendor.115.com/api/movies/history",
        {"authcode": authcode, "vendor": "wobo", "mid": mid, "pick_code": pick_code,
         "time": current, "token": token})

    try:
        response = readjson(history_url)
        if response["state"] and isinstance(response["data"], dict):
            return float(response["data"]["view_long"])
    except:
        do_except()

    return 0

def on_play():
    mid = args.get("mid", "")
    pick_code = args.get("pick_code", "")
    movie_files = getMovieFiles(mid, pick_code)
    if movie_files is None:
        error("获取影片信息失败")
    else:
        player = xbmc.Player()
        player.play(getDefinition(movie_files["video_url"])["url"],
                xbmcgui.ListItem(movie_files["file_name"], thumbnailImage=movie_files["poster"]))

        start_time = time.time()
        while not player.isPlaying():
            time.sleep(0.001)
            if time.time() - start_time > 10:
                break
        else:
            while player.getTime() == 0:
                time.sleep(0.001)
            seek_time = getSeekTime(mid, pick_code)
            if seek_time > 0:
                player.seekTime(seek_time)

            for subtitle in getSubtitles(mid, pick_code):
                player.setSubtitles(subtitle["url"])
            else:
                player.setSubtitleStream(0)
                player.disableSubtitles()

def on_test(): pass
def on_invalid(): pass

if __name__ == '__main__':
    reload(sys)
    sys.setdefaultencoding("utf-8")

    if addon.getSetting("proxy_enable") == 'true':
        proxy_ip      = addon.getSetting("proxy_ip")
        proxy_port    = addon.getSetting("proxy_port")
        proxy_address = "http://%s:%s" % (proxy_ip, proxy_port)

        urllib2.install_opener(
            urllib2.build_opener(urllib2.ProxyHandler({"http": proxy_address}),
                                 urllib2.HTTPHandler()))

    eval("on_" + args.get("action", "index"))()
