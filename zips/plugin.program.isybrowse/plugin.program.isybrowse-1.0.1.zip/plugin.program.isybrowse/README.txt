ISY Browser
plugin.program.isybrowse

DESCRIPTION:
ISY Browser is part of the ISY Events add-on set. The ISY Browser allows the devices, scenes, and programs on an ISY controller to be browsed and manipulated.

For more information, please see the Automicus website.

AUTHOR: Automicus (Ryan Kraus)
DATE: 2/2014
EMAIL: automicus@gmail.com
WEBSITE: http://automic.us