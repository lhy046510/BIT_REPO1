# -*- coding: utf-8 -*-

"""
    Plugin for streaming video content from www.kidstv.co.il
"""
import urllib, re, os, sys
import xbmc, xbmcplugin, xbmcaddon, xbmcgui


##General vars
__plugin__ = "childrenChannel"
__author__ = "Shai Bentin"

__settings__ = xbmcaddon.Addon(id='plugin.video.childrenChannel.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')

LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

from common import *

def SERIES():
    page = getData('http://www.kidstv.co.il/vod')
    listOfItems = re.compile('<div class="item-list"><ul>(.*?)</ul>').findall(page)
    if len(listOfItems) > 1:
        matches = re.compile('href="/vod/(.*?)" title="(.*?)"><img src="(.*?)"').findall(listOfItems[1])
    for url, title, image in matches:
        title = clean(title)
        addDir(urllib.unquote(title), 'http://www.kidstv.co.il/vod/' + url, 1, image)
        
    xbmc.executebuiltin("Container.SetViewMode(500)")# see the image view

def SEASONS(url):
    # check to see if there are seasons, if so display the seasons
    page = getData(url, 0)
    block = re.compile('<ul class="vod_season_tabs">(.*?)</ul>').findall(page)
    if len(block) > 0:
        seasons = re.compile('<li><a href="(.*?)".*?>(.+?)<').findall(block[0])
        for href, title in seasons:
            addDir(title, 'http://www.kidstv.co.il' + href, 2)
    else:
        EPISODES(url)
           
def EPISODES(url):
    # receive the episodes for the series
    page = getData(url, 0)
    epiList = re.compile('<ul id="vod_season_items"(.*?)</ul>').findall(page)
    if len(epiList) > 0:
        links = re.compile('<li><a.*?href="(.*?)".*?><img src="(.*?)".*?<div>(.*?)</div></li>').findall(epiList[0])
        for url, image, title in links:
            title = title.replace("<br />", "")
            addVideoLink(title, 'http://www.kidstv.co.il' + url, 3, image) 
       
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    xbmc.executebuiltin("Container.SetViewMode(500)")# see the image view
    
def PLAY_MOVIE(url, name):
    # print 'URL -->' + url
    videopage = getData(url, 0) # episode page cached according to defaults
    level1Url = re.compile('<div class=\'new_video_box.*?src=\'(.*?)\'').findall(videopage)
    level2Url = getData(level1Url[0], 0)
    if len(level2Url) > 0:
        level3Url = re.compile('<link rel="video_src".*?configXmlUrl=(http://.*?)=').findall(level2Url)
        configUrl = getData(level3Url[0], 0)
        smilUrl = re.compile('<playlist><url>(.*?)</url>').findall(configUrl)
        smilData = getData(smilUrl[0])
        serverUrl = re.compile('origin="(.*?)"').findall(smilData)
        movieUrl = re.compile('<video.*?src="(.*?)"').findall(smilData)
        videoLink = serverUrl[0] + ' playpath=' + movieUrl[len(movieUrl)-1]
        listItem = xbmcgui.ListItem(name, 'DefaultFolder.png', 'DefaultFolder.png', path=str(videoLink)) 
        listItem.setInfo(type='Video', infoLabels={ "Title": urllib.unquote(name)})
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)             
   

params = getParams(sys.argv[2])
url=None
name=None
mode=None
module=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
try:
        page=urllib.unquote_plus(params["page"])
except:
        pass
    
if mode==None or url==None or len(url)<1:
    SERIES()

elif mode==1:
    SEASONS(url)
    
elif mode==2:
    EPISODES(url)

elif mode==3:
    PLAY_MOVIE(url, name)

else:
        manager = getattr(__import__('module_' + module.lower()), 'manager_' + module)()
        manager.work(mode, url, name, page)
        

xbmcplugin.setPluginFanart(int(sys.argv[1]),xbmc.translatePath( os.path.join( __PLUGIN_PATH__,"fanart.jpg") ))
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
