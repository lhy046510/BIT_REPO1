# -*- coding: utf-8 -*- 

import os
import sys,traceback, threading
import xbmc,xbmcgui,json,urllib2,re,base64
from xbmcswift2 import Plugin
import xbmcaddon
from BeautifulSoup import BeautifulSoup,Comment,BeautifulStoneSoup
__author__     = "yxblog"
__scriptid__   = "script.vst"
__scriptname__ = "VST全聚合"

__addon__      = xbmcaddon.Addon()
plugin = Plugin()

__cwd__        = __addon__.getAddonInfo('path')
__version__    = __addon__.getAddonInfo('version')
__language__   = __addon__.getLocalizedString

__profile__    = xbmc.translatePath( __addon__.getAddonInfo('profile') )
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) )
THEME = 'Default'
ACTION_MOVE_LEFT      = 1
ACTION_MOVE_RIGHT     = 2
ACTION_MOVE_UP        = 3
ACTION_MOVE_DOWN      = 4
ACTION_PAGE_UP        = 5
ACTION_PAGE_DOWN      = 6
ACTION_SELECT_ITEM    = 7
ACTION_HIGHLIGHT_ITEM = 8
ACTION_PARENT_DIR_OLD = 9
ACTION_PARENT_DIR     = 92
ACTION_PREVIOUS_MENU  = 10
ACTION_SHOW_INFO      = 11
ACTION_PAUSE          = 12
ACTION_STOP           = 13
ACTION_NEXT_ITEM      = 14
ACTION_PREV_ITEM      = 15
ACTION_SHOW_GUI       = 18
ACTION_PLAYER_PLAY    = 79
ACTION_MOUSE_LEFT_CLICK = 100
ACTION_CONTEXT_MENU   = 117
main_type_list=['最新推荐','网络电视','影视分类','我的收藏','我的设置']
sys.path.append (__resource__)
ua1="stagefright/1.2 (Linux;Android 4.0.4)"

class WindowState:
	def __init__(self):
		self.items = None
		self.listIndex = 0
		self.settings = {}

class BaseWindow(xbmcgui.WindowXML):
	def __init__( self, *args, **kwargs):
		self.oldWindow = None
		xbmcgui.WindowXML.__init__( self )
		
	def doClose(self):
		self.session.window = self.oldWindow
		self.close()
		
	def onInit(self):
		self.setSessionWindow()
		
	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def setSessionWindow(self):
		try:
			self.oldWindow = self.session.window
		except:
			self.oldWindow=self
		self.session.window = self
		
	def onAction(self,action):
		if action.getId() == ACTION_PARENT_DIR or action.getId() == ACTION_PREVIOUS_MENU:
			if xbmc.Player().isPlaying():
				xbmc.Player().stop()
			self.doClose()
			return True
		else:
			return False

class MainWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = None
		self.main_type_list_select=0
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		if self.session:
			self.session.window = self
		else:
			try:
				self.session = VstSession(self)
			except:
				ERROR('Unhandled Error')
				self.close()
		if self.getControl( 1001 ).size()==0:
			for item in main_type_list:
				listitem = xbmcgui.ListItem( label=item)
				self.getControl( 1001 ).addItem( listitem )
			self.getControl( 1001 ).getSelectedItem().select(True)
			self.setView(0)
			self.gethot()
			self.setTv()
			self.setMovie()
		self.getFav()
	
	def onClick( self, controlId ):
		if controlId ==1001:
			position = self.getControl( 1001 ).getSelectedPosition()
			self.getControl( 1001 ).getListItem(self.main_type_list_select).select(False)
			self.getControl( 1001 ).getSelectedItem().select(True)
			self.main_type_list_select=position
			self.setView(position)
		if 	controlId==20001:
			position = self.getControl( 20001 ).getSelectedPosition()
			if self.vidoe_list['video'][position].has_key('id'):
				openWindow("info",session=self,data=self.vidoe_list['video'][position])
			else:
				openWindow("zt",session=self,data=self.vidoe_list['video'][position])
		if 	controlId==20021:
			position = self.getControl( 20021 ).getSelectedPosition()
			openWindow("list",session=self,tid=position)
		if  controlId==20031:
			selectId=self.getControl( 20031 ).getSelectedItem().getLabel2()
			openWindow("info",session=self,data=self.fav[selectId])
		if controlId==1002:
			openWindow("search",session=self)
		if controlId==20011:
			position = self.getControl( 20011 ).getSelectedPosition()
			if position==0:
				openWindow("live",session=self)
			if position==1:
				openWindow("back",session=self)

	def onAction(self,action):
		if action.getId() == ACTION_PARENT_DIR or action.getId() == ACTION_PREVIOUS_MENU:
			self.doClose()
			return True
		if action.getId() == ACTION_MOVE_DOWN and self.getFocusId()== 1001:
			if self.main_type_list_select==0:
				self.setFocusId(20001)
				return True
			if self.main_type_list_select==1:
				self.setFocusId(20011)
				return True
			if self.main_type_list_select==2:
				self.setFocusId(20021)
				return True
			if self.main_type_list_select==3:
				self.setFocusId(20031)
				return True
		if action.getId() == ACTION_MOVE_UP and self.getFocusId()== 1002:
			if self.main_type_list_select==0:
				self.setFocusId(20001)
				return True
			if self.main_type_list_select==1:
				self.setFocusId(20011)
				return True
			if self.main_type_list_select==2:
				self.setFocusId(20021)
				return True
			if self.main_type_list_select==3:
				self.setFocusId(20031)
				return True
		return False

	def setView(self,pos):
		for i in range(0,len(main_type_list)):
			self.getControl(2000+i).setVisible(False)
		self.getControl(2000+pos).setVisible(True)
	def gethot(self):
		self.vidoe_list=json.loads(GetHttpData("http://v.52itv.cn/recommend"))
		for item in self.vidoe_list['video']:
			listitem = xbmcgui.ListItem( label=item['title'],thumbnailImage=item['img'])
			self.getControl(20001).addItem(listitem)
	def setTv(self):
			listitem = xbmcgui.ListItem( label='',thumbnailImage="tv_live.png")
			self.getControl(20011).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="tv_back.png")
			self.getControl(20011).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="tv_collection.png")
			self.getControl(20011).addItem(listitem)
	def setMovie(self):
			listitem = xbmcgui.ListItem( label='',thumbnailImage="type_film.png")
			self.getControl(20021).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="type_tv.png")
			self.getControl(20021).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="type_arts.png")
			self.getControl(20021).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="type_cartoon1.png")
			self.getControl(20021).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="type_documentary.png")
			self.getControl(20021).addItem(listitem)
			listitem = xbmcgui.ListItem( label='',thumbnailImage="type_online_edu.png")
			self.getControl(20021).addItem(listitem)
	def getFav(self):
		try:
			self.fav=json.loads(base64.b64decode(__addon__.getSetting('fav')))
		except:
			self.fav={}
			__addon__.setSetting('fav', base64.b64encode(json.dumps(self.fav)))
		self.getControl(20031).reset()
		fav_key=self.fav.keys()
		for item in fav_key:
			listitem = xbmcgui.ListItem( label=self.fav[item]['title'],label2=self.fav[item]['id'],thumbnailImage=self.fav[item]['img'])
			self.getControl(20031).addItem(listitem)
class InfoWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.data = kwargs.get('data')
		self.select_sor=0
		self.initialized = False
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		self.fav_t=json.loads(base64.b64decode(__addon__.getSetting('fav')))
		if self.fav_t.has_key(self.data['id']):
			self.getControl( 120 ).setLabel("取消")
		else:
			self.getControl( 120 ).setLabel("收藏")
		self.data=json.loads(GetHttpData("http://so.52itv.cn/v_info/"+self.data['id']+".json"))
		self.getControl( 1 ).setImage(self.data['img'])
		self.getControl( 2 ).setLabel(self.data['title'])
		self.getControl( 3 ).setLabel("年代:".decode('UTF-8')+self.data['year'])
		self.getControl( 4 ).setLabel(self.data['banben'])		
		self.getControl( 5 ).setLabel("导演:".decode('UTF-8')+self.data['director'])
		self.getControl( 6 ).setLabel("类别:".decode('UTF-8')+self.data['cate'])
		self.getControl( 7 ).setLabel("演员:".decode('UTF-8')+self.data['actor'])
		self.getControl( 8 ).setLabel("地区:".decode('UTF-8')+self.data['area'])
		self.getControl( 9 ).setLabel(self.data['info'])
		for item in self.data['playlist']:
			if item['site']=='weiyun' or item['site']=='video':
				listitem=xbmcgui.ListItem(label='other')
			else:
				listitem=xbmcgui.ListItem(label=item['site'])
			self.getControl(10).addItem(listitem)
		self.getControl( 10 ).getListItem(0).select(True)
		for item in self.data['playlist'][0]['list']:
			listitem=xbmcgui.ListItem(label=item['name'])
			self.getControl(11).addItem(listitem)


	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def onClick( self, controlID ):
		if controlID==10:
			self.getControl( 10 ).getListItem(self.select_sor).select(False)
			self.select_sor = self.getControl( 10 ).getSelectedPosition()
			self.getControl( 10 ).getSelectedItem().select(True)
			self.getControl( 11 ).reset()
			for item in self.data['playlist'][self.select_sor]['list']:
				listitem=xbmcgui.ListItem(label=item['name'])
				self.getControl(11).addItem(listitem)
		if controlID == 11:
			pos=self.getControl( 11 ).getSelectedPosition()
			playVideo(self.data['playlist'][self.select_sor]['list'][pos]['url'],self.data['playlist'][self.select_sor]['site'],self.data['title'],self.data['playlist'][self.select_sor]['list'][pos]['name'])
		if controlID == 120:
			if self.getControl( 120 ).getLabel()=="收藏":
				temp={'id':self.data['id'],'title':self.data['title'],'img':self.data['img']}
				self.fav_t[self.data['id']]=temp
				__addon__.setSetting('fav', base64.b64encode(json.dumps(self.fav_t)))
				self.getControl( 120 ).setLabel("取消")
			else:
				del	self.fav_t[self.data['id']]
				__addon__.setSetting('fav', base64.b64encode(json.dumps(self.fav_t)))
				self.getControl( 120 ).setLabel("收藏")
			
	def onAction(self,action):
		BaseWindow.onAction(self, action)

class ZtWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.data = kwargs.get('data')
		self.initialized = False
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		self.getControl(1).setImage(self.data['logo'])
		print GetHttpData("http://v.52itv.cn/recommend?zid="+self.data['zid'])
		self.data=json.loads(GetHttpData("http://v.52itv.cn/recommend?zid="+self.data['zid']))
		for item in self.data['video']:
			listitem = xbmcgui.ListItem( label=item['title'],thumbnailImage=item['img'])
			self.getControl(2).addItem(listitem)


	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def onClick( self, controlID ):
		if controlID==2:
			position = self.getControl( 2 ).getSelectedPosition()
			openWindow("info",session=self,data=self.data['video'][position])
			
	def onAction(self,action):
		BaseWindow.onAction(self, action)

class BackWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.data = kwargs.get('data')
		self.initialized = False
		self.datas=json.loads(GetHttpData('http://live.91vst.com/tvback.php'))
		self.datal=None
		self.channel=-1
		self.paly_id=-1
		self.paly_date=''
		self.date_id=-1
		self.auto=False
		BaseWindow.__init__( self, *args, **kwargs )

	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		for item in self.datas['tvback']:
			listitem = xbmcgui.ListItem( label=item['channel'],label2=item['vid'])
			self.getControl(11).addItem(listitem)
		if self.getControl(11).size()>0:
			self.channel=0
			self.getControl(14).setLabel(self.datas['tvback'][0]['channel'])
		for item in self.datas['datelist']:
			data_t=item['name'].split(' ')
			if data_t[0]=='星期日'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='sunday')
				self.getControl(12).addItem(listitem)
			elif data_t[0]=='星期一'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='monday')
				self.getControl(12).addItem(listitem)
			elif data_t[0]=='星期二'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='tuesday')
				self.getControl(12).addItem(listitem)
			elif data_t[0]=='星期三'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='wednesday')
				self.getControl(12).addItem(listitem)
			elif data_t[0]=='星期四'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='thursday')
				self.getControl(12).addItem(listitem)
			elif data_t[0]=='星期五'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='friday')
				self.getControl(12).addItem(listitem)
			elif data_t[0]=='星期六'.decode('UTF-8'):
				listitem = xbmcgui.ListItem( label=data_t[1],label2=item['date'],thumbnailImage='saturday')
				self.getControl(12).addItem(listitem)
			else:
				pass
		if self.getControl(12).size()>0:
			self.paly_date=self.datas['datelist'][0]['date']
			self.getControl(12).getListItem(0).select(True)
			self.date_id=0
		self.addlist()
	def addlist(self):
		self.getControl(13).reset()
		self.datal=json.loads(GetHttpData("http://live.91vst.com/tvback.php?date="+self.paly_date+"&vid="+self.datas['tvback'][self.channel]['vid']))
		for item in self.datal['tvback']:
				listitem = xbmcgui.ListItem( label=item['time']+'   '+item['name'])
				self.getControl(13).addItem(listitem)
		#self.play_video()
	def play_video(self,id=-1):
		if id==-1:
			video_url=self.datal['liveurl']
			self.auto=False
		else:
			play_url=json.loads(GetHttpData("http://live.91vst.com/tvback.php?link="+self.datal['tvback'][id]['link']))
			video_url=play_url['play'][0]['url']
			self.getControl(15).setLabel(self.datal['tvback'][id]['time']+'  '+self.datal['tvback'][id]['name'])
			if self.getControl(13).size()-1>id:
				self.auto=True
				self.getControl(16).setLabel(self.datal['tvback'][id+1]['time']+'  '+self.datal['tvback'][id+1]['name'])
			else:
				self.auto=False
				self.getControl(16).setLabel('无下一栏目')

		listitem = xbmcgui.ListItem(self.datal['tvback'][id]['time']+'  '+self.datal['tvback'][id]['name'])
		listitem.setInfo(type="Video", infoLabels={'Title': self.datal['tvback'][id]['time']+'  '+self.datal['tvback'][id]['name']})
		xbmc.Player().play(video_url, listitem, 1)

	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def onClick( self, controlID ):
		if controlID == 13:
			position = self.getControl( 13 ).getSelectedPosition()
			self.play_video(id=position)
		if controlID == 11:
			position = self.getControl( 11 ).getSelectedPosition()
			self.getControl(14).setLabel(self.datas['tvback'][position]['channel'])
			self.channel= position
			self.paly_date=self.datas['datelist'][0]['date']
			self.getControl(12).getListItem(self.date_id).select(False)
			self.getControl(12).getListItem(0).select(True)
			self.date_id=0
			self.getControl(16).setLabel('')
			self.getControl(16).setLabel('')
			self.addlist()
		if controlID == 12:
			position = self.getControl( 12 ).getSelectedPosition()
			self.paly_date=self.datas['datelist'][position]['date']
			self.getControl(12).getListItem(self.date_id).select(False)
			self.getControl(12).getListItem(position).select(True)
			self.date_id=position
			self.addlist()

	def	onPlayBackStopped():
		pass

		
	def onAction(self,action):
		BaseWindow.onAction(self, action)

class LiveWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.data = kwargs.get('data')
		self.initialized = False
		self.select_cat=0
		self.live_list=json.loads(GetHttpData('http://live.91vst.com/list.php?v=top&app=vst'))
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		for item in self.live_list['type']:
			listitem=xbmcgui.ListItem( label=item['name'],label2=item['id'])
			self.getControl(121).addItem(listitem)
		self.LiveAdd()

	def onFocus( self, controlId ):
		self.controlId = controlId

	def onClick( self, controlID ):
		if 	controlID==120:
			item_id=self.getControl( 120 ).getSelectedItem().getLabel2()
			item_title=self.getControl( 120 ).getSelectedItem().getLabel()
			paly_link=self.live_list['live'][int(item_id)]['urllist'].split('#')
			playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
			playlist.clear()
			for x in paly_link:
				listitem = xbmcgui.ListItem(label=item_title)
				playlist.add(url=x+"|User-Agent="+ua1, listitem=listitem, index=7)
			xbmc.Player().play(playlist, self.getControl( 120 ).getSelectedItem(), 1)

	def onAction(self,action):
		BaseWindow.onAction(self, action)
		if action.getId()== ACTION_MOVE_LEFT and self.getFocusId()== 120:
			position = self.getControl( 121 ).getSelectedPosition()
			if position == 0:
				self.getControl( 121 ).selectItem(self.getControl( 121 ).size()-1)
				self.select_cat=self.getControl( 121 ).size()-1
			else:
				self.getControl( 121 ).selectItem(position-1)
				self.select_cat=position-1
			self.LiveAdd()

		if action.getId()== ACTION_MOVE_RIGHT and self.getFocusId()== 120:
			position = self.getControl( 121 ).getSelectedPosition()
			if position == self.getControl( 121 ).size()-1:
				self.getControl( 121 ).selectItem(0)
				self.select_cat=0
			else:
				self.getControl( 121 ).selectItem(position+1)
				self.select_cat=position+1
			self.LiveAdd()

		if action.getId()== ACTION_MOVE_LEFT and self.getFocusId()== 121:
			position = self.getControl( 121 ).getSelectedPosition()
			self.select_cat=position
			self.LiveAdd()
		
		if action.getId()== ACTION_MOVE_RIGHT and self.getFocusId()== 121:
			position = self.getControl( 121 ).getSelectedPosition()
			self.select_cat=position
			self.LiveAdd()

	def LiveAdd(self):
		self.getControl(120).reset()
		cat_id=self.live_list['type'][self.select_cat]['id']
		for i in range (0,len(self.live_list['live'])):
			item=self.live_list['live'][i]
			if item['itemid']==cat_id:
				if item['quality']=='SD':
					pic='live_channel_list_item_sharp_sd.png'
				elif item['quality']=='HD':
					pic='live_channel_list_item_sharp_hd.png'
				else:
					pic='live_channel_list_item_sharp_default.png'
				listitem=xbmcgui.ListItem( label=item['name'],label2=str(i),thumbnailImage=pic)
				self.getControl(120).addItem(listitem)
		self.getControl(120).selectItem(0)

class SearchWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.data = kwargs.get('data')
		self.initialized = False
		self.cid=0
		self.page=1
		self.keystr=''
		self.type=['全部','电影','电视剧','动漫','综艺','纪录片','公开课']
		self.key_list=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','0','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9']
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		self.setinit()
		self.searchAdd()

	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def onClick( self, controlID ):
		print controlID
		if controlID== 21:
			position = self.getControl( 21 ).getSelectedPosition()
			self.getControl( 22 ).setLabel(self.getControl( 22 ).getLabel()+self.getControl( 21 ).getListItem(position).getLabel())
		if controlID== 5:
			self.getControl( 22).setLabel(self.getControl( 22 ).getLabel()[0:len(self.getControl( 22 ).getLabel())-1])
		if controlID== 6:
			self.getControl( 22 ).setLabel('')
		if controlID== 7:
			self.keystr=self.getControl( 22 ).getLabel()
			self.page=1
			self.getControl(8).reset()
			self.searchAdd()
		if controlID== 20:
			self.cid = self.getControl( 20 ).getSelectedPosition()
			self.page=1
			self.getControl(8).reset()
			self.searchAdd()
		if controlID== 8:
			position = self.getControl( 8 ).getSelectedPosition()
			openWindow("info",session=self,data=self.data['video'][position])	

	def onAction(self,action):
		BaseWindow.onAction(self, action)

	def searchAdd(self):
		temp=[]
		if self.cid!=0:
			temp.append('tid='+str(self.cid))
		if self.keystr!='':
			temp.append('wd='+self.keystr)
		temp.append('page='+str(self.page))
		self.data=json.loads(GetHttpData('http://v.52itv.cn/so?data=so&num=60&'+'&'.join(temp)))
		for item in self.data['video']:
			listitem=xbmcgui.ListItem( label=item['title'],thumbnailImage=item['img'])
			self.getControl(8).addItem(listitem)
	def setinit(self):
		for item in self.type:
			listitem=xbmcgui.ListItem( label=item)
			self.getControl(20).addItem(listitem)
		for item in self.key_list:
			listitem=xbmcgui.ListItem( label=item)
			self.getControl(21).addItem(listitem)
		self.getControl(22).setLabel('')

class ListWindow(BaseWindow):
	def __init__( self, *args, **kwargs):
		self.session = kwargs.get('session')
		self.tid = kwargs.get('tid')
		self.cid=1
		self.cattitle=''
		self.page=1
		self.oldpos=0
		self.vod_data=[]
		self.key_data=[]
		self.item=''
		self.item_t=''
		self.area=''
		self.area_t=''
		self.year_t=''
		self.year=''
		self.initialized = False
		BaseWindow.__init__( self, *args, **kwargs )
		
	def onInit(self):
		BaseWindow.onInit(self)
		if self.initialized: return
		self.initialized = True
		self.addpage()
		self.key_data=json.loads(GetHttpData("http://v.52itv.cn/list?tid="+str(self.cid)+"&data=item"))

	def onFocus( self, controlId ):
		self.controlId = controlId
		
	def onClick( self, controlId ):
		if controlId==13:
			position = self.getControl( 13 ).getSelectedPosition()
			openWindow("info",session=self,data=self.vod_data[position])	
		if controlId==14:
			sel=xbmcgui.Dialog().select(u'选择类型'.encode('utf-8'),[s['name'] for s in self.key_data['item']])
			if sel!=-1:
				self.item=self.key_data['item'][sel]['link']
				self.item_t=self.key_data['item'][sel]['name']
			sel=xbmcgui.Dialog().select(u'选择地区'.encode('utf-8'),[s['name'] for s in self.key_data['area']])
			if sel!=-1:
				self.area=self.key_data['area'][sel]['link']
				self.area_t=self.key_data['area'][sel]['name']
			sel=xbmcgui.Dialog().select(u'选择年代'.encode('utf-8'),[s['name'] for s in self.key_data['year']])
			if sel!=-1:
				self.year=self.key_data['year'][sel]['link']
				self.year_t=self.key_data['year'][sel]['name']
			self.getControl( 13 ).reset()
			self.page=1
			self.oldpos=0
			self.vod_data=[]
			self.addpage()
		if controlId==15:
			openWindow("search",session=self)

	def onAction(self,action):
		BaseWindow.onAction(self, action)
		if action.getId() == ACTION_MOVE_DOWN and self.getFocusId()== 13:
			if self.getControl( 13 ).size() - self.getControl( 13 ).getSelectedPosition() <=6:
				self.page+=1
				self.oldpos=self.getControl( 13 ).getSelectedPosition()
				self.addpage()
		
	def addpage(self):
		if self.tid==0:
			self.cid=1
			self.cattitle='电 影'
		elif self.tid==1:
			self.cid=2
			self.cattitle="电视剧"
		elif self.tid==2:
			self.cid=4
			self.cattitle="综 艺"
		elif self.tid==3:
			self.cid=3
			self.cattitle="动 漫"
		elif self.tid==4:
			self.cid=5
			self.cattitle="纪录片"
		else:
			self.cid=6
			self.cattitle="公开课"
		self.getControl(1).setLabel(self.cattitle)
		data=json.loads(GetHttpData("http://so.52itv.cn/list?" + self.getUrl()))
		self.getControl(2).setLabel("共"+str(data['video_count'])+"部")
		for item in data["video"]:
			self.vod_data.append(item)
			listitem=xbmcgui.ListItem( label=item['title'],thumbnailImage=item['img'])
			self.getControl(13).addItem(listitem)
		self.getControl(13).selectItem(self.oldpos)
	
	def getUrl(self):
		temp=[]
		temp1=[]
		if self.item!='':
			temp.append('item='+self.item)
			temp1.append('类型:'+self.item_t.encode('utf-8'))
		if self.area!='':
			temp.append('area='+self.area)
			temp1.append('地区:'+self.area_t.encode('utf-8'))
		if self.year!='':
			temp.append('year='+self.year)
			temp1.append('年代:'+self.year_t.encode('utf-8'))
		temp.append('num=30')
		temp.append('tid='+str(self.cid))
		temp.append("page="+str(self.page))
		self.getControl(5).setLabel('|'.join(temp1))
		return '&'.join(temp)

def openWindow(window_name,session=None,**kwargs):
		windowFile = 'vst-media-%s.xml' % window_name
		if window_name == 'main':
			windowFile = 'vst-media-main.xml'
			windowFilePath = os.path.join(xbmc.translatePath(__addon__.getAddonInfo('path')),'resources','skins',THEME,'720p',windowFile)
			w = MainWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME)
		elif window_name == 'info':
			w = InfoWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		elif window_name == 'list':
			w = ListWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		elif window_name == 'zt':
			w = ZtWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		elif window_name == 'search':
			w = SearchWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		elif window_name == 'live':
			w = LiveWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		elif window_name == 'back':
			w = BackWindow(windowFile , xbmc.translatePath(__addon__.getAddonInfo('path')), THEME,session=session,**kwargs)
		else:
			return #Won't happen :)
		w.doModal()			
		del w

def GetHttpData(url):
    print url
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create('vst全聚合', '正在加载数据，请稍后······')
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = urllib2.urlopen(req)
        httpdata = response.read()
        if response.headers.get('content-encoding', None) == 'gzip':
            httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
        charset = response.headers.getparam('charset')
        response.close()
    except:
        print 'GetHttpData Error: %s' % url
        return ''
    match = re.compile('<meta http-equiv=["]?[Cc]ontent-[Tt]ype["]? content="text/html;[\s]?charset=(.+?)"').findall(httpdata)
    if len(match)>0:
        charset = match[0]
    if charset:
        charset = charset.lower()
        if (charset != 'utf-8') and (charset != 'utf8'):
            httpdata = httpdata.decode(charset, 'ignore').encode('utf8', 'ignore')
    pDialog.close()
    return httpdata

class RedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        pass
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib2.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        infourl.headers = headers
        return infourl

def GetHttpData2(url):
    print url
    opener = urllib2.build_opener(RedirectHandler)
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = opener.open(req)
        httpdata = response.headers.get('Location', None)
        response.close()
    except:
        xbmc.log( "%s: %s (%d) [%s]" % (
            "vst",
            sys.exc_info()[ 2 ].tb_frame,
            sys.exc_info()[ 2 ].tb_lineno,
            sys.exc_info()[ 1 ]
            ), level=xbmc.LOGERROR)
        return ''
    return httpdata

def get_params2(url):
    param = []
    paramstring = url[url.index('?'):len(url)]
    print paramstring
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

def playVideo(url,site,title,title2):
	data=GetHttpData("http://play.91vst.com/?url="+url)
	soup = json.loads(data)
	vod_link=''
	if len(soup['playlinkmap'])<=0:
		plugin.notify('无效视频源', '', delay=2000)
		return
	for item in soup['playlinkmap']:
		if item['qxd']=="3":
			vod_link=item['urllist'][0]['link']
	if vod_link=="":
		vod_link=soup['playlinkmap'][len(soup['playlinkmap'])-1]['urllist'][0]['link']
	if site == 'pptv':
		temp = BeautifulStoneSoup(GetHttpData(vod_link.replace('__','%')))
		vod_link = "http://"+temp.root.server_host.text+"/"+vod_link[vod_link.rfind('/')+1:vod_link.rfind('.m')]+".m3u8?type=m3u8.ipad&k="+temp.root.key.text
		#vod_link = "http://180.96.61.165/"+vod_link[vod_link.rfind('/')+1:vod_link.rfind('.m')]+".m3u8?type=m3u8.ipad&k="+temp.root.key.text
		vod_link=vod_link.replace('__','%')
	elif site == 'qiyi':
		temp = GetHttpData(vod_link)
		vod_sp = temp.split('\n')
		urls=''
		for item in vod_sp:
			if item[0:4]=='http':
				urls = GetHttpData2(item)
				break
		pargm=urls.split('/')
		pargm1=get_params2(urls)
		ukey=pargm1['key']
		uuid=pargm1['uuid']
		ip=pargm[2]
		temp=temp.replace("data.video.iqiyi.com",ip).replace("data.video.qiyi.com",ip).replace("?",'?key='+ukey+'&uuid='+uuid+"&")
		wfile = open(__cwd__+"/b.m3u8", 'w') 
		wfile.write(temp)
		wfile.close() 
		vod_link= __cwd__+"/b.m3u8"
	elif site == 'qqlive':
		temp = BeautifulStoneSoup(GetHttpData(vod_link))
		vod_link = temp.root.vd.vi.url.text
	elif site == 'weiyun':
		vod_link = vod_link.replace('&amp;','&')
	elif site == 'letv':
		vod_link = GetHttpData2(vod_link)
	else:
		pass
	listitem = xbmcgui.ListItem(title+"_"+title2)
	listitem.setInfo(type="Video", infoLabels={'Title': title+"_"+title2})
	xbmc.Player().play(vod_link.replace('&amp;','&'), listitem, 0)

class VstSession:
	def __init__(self,window=None):
		self.window = window
		
	def removeCRLF(self,text):
		return " ".join(text.split())
		
	def makeAscii(self,name):
		return name.encode('ascii','replace')
	
	
		
	def closeWindow(self):
		self.window.doClose()
			
	def clearSetting(self,key):
		__addon__.setSetting(key,'')
		
	def setSetting(self,key,value):
		__addon__.setSetting(key,value and ENCODE(value) or '')
		
	def getSetting(self,key,default=None):
		setting = __addon__.getSetting(key)
		if not setting: return default
		if type(default) == type(0):
			return int(float(setting))
		elif isinstance(default,bool):
			return setting == 'true'
		return setting
	

if __name__ == '__main__':
	openWindow('main')