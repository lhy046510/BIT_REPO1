plugin.video.metv
================


XBMC Addon for MeTV website

Version 1.1.1 Improved bitrate speeds for videos

version 1.0.1 initial release

