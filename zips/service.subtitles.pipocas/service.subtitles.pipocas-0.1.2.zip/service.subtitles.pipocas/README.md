service.subtitles.pipocas
=========================

Pipocas.tv subtitle service plugin for XBMC 13 Gotham or newer. Ported from
the Frodo version.

HiGhLaNdeR
