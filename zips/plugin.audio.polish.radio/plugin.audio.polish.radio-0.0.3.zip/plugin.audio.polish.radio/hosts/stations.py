# -*- coding: utf-8 -*-
import string, sys
import os, simplejson
import xbmcaddon, xbmc

ptv = xbmcaddon.Addon()
scriptID = ptv.getAddonInfo('id')
scriptname = ptv.getAddonInfo('name')

BASE_RESOURCE_PATH = os.path.join( ptv.getAddonInfo('path'), "resources" )
sys.path.append( os.path.join( BASE_RESOURCE_PATH, "lib" ) )
jsonData = os.path.join( ptv.getAddonInfo('path'), "hosts" ) + os.path.sep + "stations.json"

import sdLog, sdParser, sdCommon, sdNavigation

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg
SERVICE = 'stations'

class StreamStations:
    def __init__(self):
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.gui = sdNavigation.sdGUI()
	self.history = sdCommon.history()

    def getJsonData(self):
	json_data = open(jsonData, "r")
	data = simplejson.loads(json_data.read())
	json_data.close()
	data = data['radio']
	return data

    def listsABCMenu(self, table):
	for i in range(len(table)):
	    params = {'service': SERVICE, 'name': 'abc-menu','category': table[i], 'title': table[i]}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsGenreMenu(self, jList):
	genreList = []
	for index, item in enumerate(jList):
	    try:
		for genre in item['genre']:
		    genre = string.capwords(genre)
		    if genre not in genreList:
			genreList.append(genre)
	    except KeyError:
		pass
	genreList = sorted(genreList)
	for genre in genreList:
	    params = {'service': SERVICE, 'name': 'genre-menu','category': genre.encode('UTF-8'), 'title': genre.encode('UTF-8')}
	    self.gui.addDir(params)
	self.gui.endDir(True)

    def listsCityMenu(self, jList):
	cityList = []
	for index, item in enumerate(jList):
	    try:
		for city in item['city']:
		    city = string.capwords(city)
		    if city not in cityList:
			cityList.append(city)
	    except KeyError:
		pass
	cityList = sorted(cityList)
	for city in cityList:
	    params = {'service': SERVICE, 'name': 'city-menu','category': city.encode('UTF-8'), 'title': city.encode('UTF-8')}
	    self.gui.addDir(params)
	self.gui.endDir(True)

    def listsBCMenu(self, jList):
	bcList = []
	for index, item in enumerate(jList):
	    try:
		bc = string.capwords(item['broadcaster'])
		if bc not in bcList:
		    bcList.append(bc)
	    except KeyError:
		pass
	bcList = sorted(bcList)
	for bc in bcList:
	    params = {'service': SERVICE, 'name': 'bc-menu','category': bc.encode('UTF-8'), 'title': bc.encode('UTF-8')}
	    self.gui.addDir(params)
	self.gui.endDir(True)

    def listsHistoryMenu(self, table):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history-menu','category': table[i], 'title': table[i]}
		self.gui.addDir(params)
	self.gui.endDir()

    def filterByABC(self, jList, abc):
	if abc == '0 - 9':
	    return [item for index, item in enumerate(jList) if not item['name'][:1].isalpha()]
	else:
	    return [item for index, item in enumerate(jList) if item['name'][:1].upper() == abc]

    def filterByGenre(self, jList, genre):
	return [item for index, item in enumerate(jList) if 'genre' in item if any(genre.decode('UTF-8') in string.capwords(ig) for ig in item['genre'])]

    def filterByCity(self, jList, city):
	return [item for index, item in enumerate(jList) if 'city' in item if any(city.decode('UTF-8') in string.capwords(ic) for ic in item['city'])]

    def filterByBC(self, jList, bc):
	return [item for index, item in enumerate(jList) if 'broadcaster' in item if bc.decode('UTF-8') == string.capwords(item['broadcaster'])]

    def filterByName(self, jList, name):
	    return [item for index, item in enumerate(jList) if name.decode('UTF-8').lower() in item['name'].lower()]

    def listRadio(self, jList):
	for item in jList:
	    params = {'service': SERVICE, 'title': string.capwords(item['name']).encode('UTF-8'), 'page': item['stream']}
	    if not self.cm.isEmptyDict(item, 'img'):
		params['icon'] = item['img']
	    self.gui.playAudio(params)
	self.gui.endDir(True)

    def handleService(self):
        params = self.parser.getParams()
	mode = self.parser.getIntParam(params, "mode")
        name = self.parser.getParam(params, "name")
	category = self.parser.getParam(params, "category")
        page = self.parser.getTypeParam(params, "page")
	title = self.parser.getParam(params, "title")
	self.parser.debugParams(params, dbg)

	if mode == 100:
	    self.listsABCMenu(self.cm.makeABCList())
	if mode == 101:
	    self.listsGenreMenu(self.getJsonData())
	if mode == 102:
	    self.listsCityMenu(self.getJsonData())
	if mode == 103:
	    self.listsBCMenu(self.getJsonData())
	if mode == 104:
	    text = self.gui.searchInput(SERVICE)
	    jList = self.filterByName(self.getJsonData(), text)
	    self.listRadio(jList)
	if mode == 105:
	    t = self.history.loadHistoryFile(SERVICE)
	    self.listsHistoryMenu(t)
	if name == 'abc-menu':
	    jList = self.filterByABC(self.getJsonData(), category)
	    self.listRadio(jList)
	if name == 'genre-menu':
	    jList = self.filterByGenre(self.getJsonData(), category)
	    self.listRadio(jList)
	if name == 'city-menu':
	    jList = self.filterByCity(self.getJsonData(), category)
	    self.listRadio(jList)
	if name == 'bc-menu':
	    jList = self.filterByBC(self.getJsonData(), category)
	    self.listRadio(jList)
	if name == 'history-menu':
	    jList = self.filterByName(self.getJsonData(), category)
	    self.listRadio(jList)
	if name == 'playSelectedAudio':
	    pl = self.gui.new_playlist()
	    self.gui.add_to_playlist(pl, page)
	    self.gui.LOAD_AND_PLAY_AUDIO(xbmc.PlayList(0), title)