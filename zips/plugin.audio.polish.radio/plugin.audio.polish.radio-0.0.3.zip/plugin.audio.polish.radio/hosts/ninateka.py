# -*- coding: utf-8 -*-
import os, string
import urllib, re, sys
import xbmcaddon, traceback

scriptID = sys.modules[ "__main__" ].scriptID
ptv = xbmcaddon.Addon(scriptID)

BASE_RESOURCE_PATH = os.path.join(ptv.getAddonInfo('path'), "../resources")
sys.path.append(os.path.join(BASE_RESOURCE_PATH, "lib"))
LOGOURL = ptv.getAddonInfo('path') + os.path.sep + "images" + os.path.sep + "ninateka.png"
THUMB_NEXT = os.path.join(ptv.getAddonInfo('path'), "images/") + 'dalej.png'

import sdLog, sdParser, sdCommon, sdNavigation, sdErrors

log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg
dstpath = ptv.getSetting('default_dstpath')

SERVICE = 'ninateka'
MAINURL = 'http://ninateka.pl'
QUERYURL = '/filmy?MediaType=audio&Paid=False'

SERVICE_MENU_TABLE = {
	1:"Audioteka (wg. kategorii)",
	2:"Audioteka (wg. gatunku)",
	3:"Wyszukaj",
	4:"Historia Wyszukiwania"
}

class Ninateka:
    def __init__(self):
	log.info('Loading ' + SERVICE)
	self.parser = sdParser.Parser()
	self.cm = sdCommon.common()
	self.history = sdCommon.history()
	self.exception = sdErrors.Exception()
	self.gui = sdNavigation.sdGUI()

    def setTable(self):
	return SERVICE_MENU_TABLE

    def listsMainMenu(self, table):
	for num, val in table.items():
	    params = {'service': SERVICE, 'name': 'main-menu','category': val, 'title': val, 'icon': LOGOURL}
	    self.gui.addDir(params)
	self.gui.endDir()

    def listsCategoryMenu(self, url):
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('li data-codename=".+?"><a href="/filmy/(.+?)">(.+?)</a></li>').findall(data)
	if len(r)>0:
	    for i in range(len(r)):
		params = {'service': SERVICE, 'category': r[i][0], 'name': 'catset', 'title': string.capwords(r[i][1]), 'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir(True)

    def listsGenreMenu(self, url):
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<select id="CategoryCodenames" .+?wszystkie gatunki</option>(.+?)</select>', re.DOTALL).findall(data)
	if len(r)>0:
	    r2 = re.compile('<option value="(.+?)">(.+?)</option>').findall(r[0])
	    if len(r2)>0:
		for i in range(len(r2)):
		    params = {'service': SERVICE, 'category': r2[i][0], 'name': 'genset', 'title': string.capwords(self.cm.html_entity_decode(r2[i][1])), 'icon': LOGOURL}
		    self.gui.addDir(params)
	self.gui.endDir(True)

    def listsAudio(self, url, page):
	query_data = {'url': url+page, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	r = re.compile('<a href="(.+?)" class="image is_audio">\r\n.+?<img.+?alt="(.+?)" src="(.+?).m=crop.+?" />').findall(data)
	if len(r)>0:
	    for i in range(len(r)):
		params = {'service': SERVICE, 'dstpath': dstpath, 'title': self.cm.html_entity_decode(r[i][1]).strip().replace("|","-"), 'page': MAINURL + r[i][0], 'icon': r[i][2]}
		self.gui.playAudio(params)
	    if 'class="nextPage">Następna &raquo;</a>' in data or 'class="lastPage">Ostatnia &raquo;</a>' in data:
		params = {'service': SERVICE, 'category': url, 'name': 'nextpage', 'title': 'Następna strona', 'page': str(int(page)+1), 'icon': THUMB_NEXT}
		self.gui.addDir(params)
	self.gui.endDir()

    def listsHistory(self, table):
	for i in range(len(table)):
	    if table[i] <> '':
		params = {'service': SERVICE, 'name': 'history', 'title': table[i],'icon': LOGOURL}
		self.gui.addDir(params)
	self.gui.endDir()

    def getAudioLink(self,url):
	audioID = ''
	query_data = {'url': url, 'use_host': False, 'use_cookie': False, 'use_post': False, 'return_data': True}
	try:
	    data = self.cm.getURLRequestData(query_data)
	except Exception, exception:
	    traceback.print_exc()
	    self.exception.getError(str(exception))
	    exit()
	match = re.compile('"file":"(.+?)"',).findall(data)
	if len(match) > 0:
	    audioID = match[0]
	return audioID

    def handleService(self):
	params = self.parser.getParams()
	name = self.parser.getParam(params, "name")
	title = self.parser.getParam(params, "title")
	category = self.parser.getParam(params, "category")
	page = self.parser.getParam(params, "page")
	icon = self.parser.getParam(params, "icon")
	link = self.parser.getParam(params, "url")
	service = self.parser.getParam(params, "service")
	action = self.parser.getParam(params, "action")
	path = self.parser.getParam(params, "path")

	self.parser.debugParams(params, dbg)

	if str(page)=='None' or page=='': page = '1'
	#MAIN MENU
	if name == None:
	    self.listsMainMenu(SERVICE_MENU_TABLE)
	#KATEGORIE
	if category == self.setTable()[1]:
	    self.listsCategoryMenu(MAINURL+"/strona/dostepnosc")
	#GATUNKI
	if category == self.setTable()[2]:
	    self.listsGenreMenu(MAINURL+"/filmy")
	#LISTA FILMÓW
	if name == 'genset' or name == 'catset':
	    url = MAINURL+QUERYURL+"&CategoryCodenames="+category+"&page="
	    self.listsAudio(url, page)

	if name == 'nextpage':
	    self.listsAudio(category, page)
	#WYSZUKAJ
	if category == self.setTable()[3]:
	    text = self.gui.searchInput(SERVICE)
	    url = MAINURL+QUERYURL+"&SearchQuery="+urllib.quote(text)+"&page="
	    self.listsAudio(url, page)
	#HISTORIA WYSZUKIWANIA
	if category == self.setTable()[4]:
	    t = self.history.loadHistoryFile(SERVICE)
	    self.listsHistory(t)

	if name == 'history':
	    url = MAINURL+QUERYURL+"&SearchQuery="+title+"&page="
	    self.listsAudio(url, page)
	#ODTWÓRZ AUDIO
	if name == 'playSelectedAudio':
	    link = self.getAudioLink(page)
	    self.gui.LOAD_AND_PLAY_AUDIO(link, title)