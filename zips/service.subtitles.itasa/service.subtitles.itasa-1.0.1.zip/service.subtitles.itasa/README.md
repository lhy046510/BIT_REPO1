service.subtitles.itasa
==========================

italiansubs.net subtitle service plugin for XBMC

Forum threads: 
http://forum.xbmc.org/showthread.php?tid=188074
http://www.italiansubs.net/forum/itasanews/xbmc-itasa-subtitle-downloader/