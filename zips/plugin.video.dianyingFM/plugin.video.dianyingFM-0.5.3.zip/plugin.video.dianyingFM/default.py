﻿# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, urllib2, urllib, re, string, sys, os, gzip, StringIO, json
from urlparse import parse_qsl
try:
    from ChineseKeyboard import Keyboard
except:
    from xbmc import Keyboard  
    pass
import platform
print platform.platform


########################################################################
########################################################################
# Plugin constants 
__addonname__ = "电影FM(dianying.fm)"
__addonid__ = "plugin.video.dianyingFM"
__addon__ = xbmcaddon.Addon(id=__addonid__)
__addonicon__ = os.path.join( __addon__.getAddonInfo('path'), 'icon.png' )
M3U8 = __addon__.getSetting('M3U8')

DEFAULT_CATLIST ={"sort": "", "filter": "", "catall": "", "key": "", "year": "", "genre": "", "region": "", "show": "", "class": ""}

UserAgent = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'

TYPE_LIST = [{'title':u'频道','arg':'class','values':[['不限',''],[u'电影','movie'],[u'电视剧','tv']]},
{'title':u'年份','arg':'year','values':[['不限',''],['2013','2013'],['2012','2012'],['2011','2011'],['2010','2010'],['2009','2009'],['2008','2008'],['2007','2007'],['2006','2006'],['2005','2005'],['2004','2004'],['2003','2003'],['2002','2002'],['2001','2001'],['2000','2000'],['90年代','90s'],['80年代','80s'],['70年代','70s'],['60年代','60s'],['50年代','50s']]},
{'title':u'地区','arg':'region','values':[['不限',''],['大陆',u'中国大陆'],['香港',u'香港'],['台湾',u'台湾'],['美国',u'美国'],['日本',u'日本'],['韩国',u'韩国'],['法国',u'法国'],['英国',u'英国'],['印度',u'印度'],['德国',u'德国'],['加拿大',u'加拿大'],['伊朗',u'伊朗'],['泰国',u'泰国'],['俄罗斯',u'俄罗斯'],['意大利',u'意大利'],['瑞典',u'瑞典'],['澳洲',u'澳洲'],['丹麦',u'丹麦'],['土耳其',u'土耳其'],['荷兰',u'荷兰'],['巴西',u'巴西'],['波兰',u'波兰']]},
{'title':u'类型','arg':'genre','values':[['不限',''],['喜剧',u'喜剧'],['爱情',u'爱情'],['动作',u'动作'],['科幻',u'科幻'],['惊悚',u'惊悚'],['纪录',u'纪录片'],['恐怖',u'恐怖'],['短片',u'短片'],['剧情',u'剧情'],['动画',u'动画'],['冒险',u'冒险'],['家庭',u'家庭'],['悬疑',u'悬疑'],['犯罪',u'犯罪'],['奇幻',u'奇幻'],['战争',u'战争'],['音乐',u'音乐'],['西部',u'西部'],['历史',u'历史'],['传记',u'传记'],['运动',u'运动'],['儿童',u'儿童'],['同性',u'同性'],['黑色',u'黑色电影']]},
{'title':u'排序','arg':'sort','values':[['默认排序',''],[u'按IMDB评分排序','imdb_rank'],[u'按豆瓣评分排序','douban_rank'],[u'按上映日期排序','first_release_date']]},
]

def GetHttpData(url):
    print "getHttpData: " + url
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = urllib2.urlopen(req)
        httpdata = response.read()
        if response.headers.get('content-encoding', None) == 'gzip':
            httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
        charset = response.headers.getparam('charset')
        response.close()
    except:
        print 'GetHttpData Error: %s' % url
        return ''
    match = re.compile('<meta http-equiv=["]?[Cc]ontent-[Tt]ype["]? content="text/html;[\s]?charset=(.+?)"').findall(httpdata)
    if len(match)>0:
        charset = match[0]
    if charset:
        charset = charset.lower()
        if (charset != 'utf-8') and (charset != 'utf8'):
            httpdata = httpdata.decode(charset, 'ignore').encode('utf8', 'ignore')
    return httpdata

def searchDict(dlist,idx):
    for i in range(0,len(dlist)):
        if dlist[i][1] == idx:
            return dlist[i][0]
    return ''


    
def rootList():
    totalItems = 7
	
    u = sys.argv[0]+"?mode=10&argString=" + GetArgString(DEFAULT_CATLIST) +"&page=1"
    li = xbmcgui.ListItem('【[COLOR FFFF0000]点此输入关键字搜索[/COLOR]】')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)
    
    u = sys.argv[0]+"?mode=1&method=hot_id_items&argString=e30=&page=1"
    li = xbmcgui.ListItem('热门电影排行')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)

    u = sys.argv[0]+"?mode=1&method=category&argString=" +GetArgString(DEFAULT_CATLIST)  + "&page=1"
    li = xbmcgui.ListItem('影片分类浏览')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)

    u = sys.argv[0]+"?mode=20"
    li = xbmcgui.ListItem('精品获奖影片（推荐）')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)

    u = sys.argv[0]+"?mode=1&method=category&argString=" +GetArgString(DEFAULT_CATLIST,**{'class':'tv','region':u'美国','sort':'douban_rank'})   + "&page=1"
    li = xbmcgui.ListItem('[COLOR FF00FF00]美剧[/COLOR]豆瓣排行')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)	

    if(__addon__.getSetting('ADV') == 'true'):
        u = sys.argv[0]+"?mode=100"
        li = xbmcgui.ListItem('大家都在看')
        xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True,totalItems)

	
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def getCatList(argString):
    hh = json.loads(argString.decode('base64'))
    return hh

def GetArgString(catList,**args):
    for x in args:
        catList[x] = args[x]
    return json.dumps(catList).encode('base64').replace('\n','').replace(' ','')

def searchKey(argString):
    catList = getCatList(argString)
    kb = Keyboard('','请输入搜索内容')
    xbmc.sleep( 1500 )
    kb.doModal()
    if (kb.isConfirmed()):
        keyword = kb.getText()
        if keyword !='':
            argString = GetArgString(catList,key=keyword)
            getMovieList('category',argString,1)
    else: return
	
def performChange(argString):
    catList = getCatList(argString)
    dialog = xbmcgui.Dialog()
    change = False
    for item in TYPE_LIST:
        sel = dialog.select(item['title'], [x[0] for x in item['values']])
        if sel != -1:
            cat = item['values'][sel][1]
            if (catList[item['arg']] != item['values'][sel][1]):
                catList[item['arg']] = item['values'][sel][1]
                change = True
    if change:
        argString = GetArgString(catList)
        getMovieList('category',argString,1)

def TopMovies():
    u = sys.argv[0]+"?mode=1&method=imdb250&argString=e30=&page=1"
    li = xbmcgui.ListItem('IMDB250（评价最高的250部电影）')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)

    u = sys.argv[0]+"?mode=1&method=oscar&argString=eyJ5ZWFyIjogIiJ9&page=1"
    li = xbmcgui.ListItem('历届奥斯卡')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)

    u = sys.argv[0]+"?mode=1&method=cannes&argString=e30=&page=1"
    li = xbmcgui.ListItem('戛纳电影节')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)

    u = sys.argv[0]+"?mode=1&method=jinji&argString=e30=&page=1"
    li = xbmcgui.ListItem('历届金鸡奖')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)

    u = sys.argv[0]+"?mode=1&method=jinma&argString=e30=&page=1"
    li = xbmcgui.ListItem('历届金马奖')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)
	
    u = sys.argv[0]+"?mode=1&method=jinxiang&argString=e30=&page=1"
    li = xbmcgui.ListItem('历届金像奖')
    xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))
		
def getMovieList(method,argString,page):
    url = 'http://dianying.fm/reflect/' + method + '/' + argString + '/' + str(page)
    print url
    httpdata = GetHttpData(url)
    r = json.loads(httpdata)
    movieData = r['html'].replace('\n','')
    match = re.compile(r'<li>(.+?)</li>', re.DOTALL).findall(movieData)    
    if (method=='category'):
        catList = getCatList(argString)
        if (catList['genre'] == ''):
            catList['genre'] =u'全部类型'
        if (catList['region'] == ''):
            catList['region'] =u'全部地区'
        if (catList['year'] == ''):
            catList['year'] =u'全部年份'
        if (catList['sort'] == ''):
            catList['sort'] =u'默认排序'
        else:
            catList['sort'] =searchDict(TYPE_LIST[4]['values'],catList['sort'])
        if (catList['class'] != ''):
            catList['class'] =searchDict(TYPE_LIST[0]['values'],catList['class'])
        if (catList['key'] != ''):
            searchKey = u'搜索：“' + catList['key'] + u'” （点击更换关键字：片名、主演、导演均可）'
            u = sys.argv[0]+"?mode=10&argString="  + argString 
            li = xbmcgui.ListItem( searchKey  )
            xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True) 
		
        u = sys.argv[0]+"?mode=4&argString="  + argString 
        li = xbmcgui.ListItem(u"[COLOR FF0000FF]%s[/COLOR]【[COLOR FFFF0000]%s[/COLOR]】/【[COLOR FF00FF00]%s[/COLOR]】/【[COLOR FFFFFF00]%s[/COLOR]】/【[COLOR FF00FFFF]%s[/COLOR]】（点击切换）" % (catList['class'],catList['year'],catList['region'] ,catList['genre'] ,catList['sort']) )
		
        xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)     
    if (page >1):
        u = sys.argv[0]+"?mode=1&method=" +method +"&argString=" + argString +"&page="+ str(page - 1)
        li = xbmcgui.ListItem('...[COLOR FF00FF00]上一页[/COLOR]')
        xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)        
    
    for itemdata in match:
        print itemdata.encode("utf-8")
        match1 = re.compile(r'<img alt="(.+?)" src="(.+?)"></div><div class="z-movie-playmask"></div></a></div><div class="x-movie-desc pull-left"><p>(.*?)<a target="_blank" href="(.+?)">.+?</a><span class="muted">(.*?)\((.*?)\)</span>', re.DOTALL).search(itemdata)  #title，缩略图，title1，movie      
        match2 = re.compile(r'</span><span class="badge" style="color: green; font-weight: bold;">(.+?)</span>', re.DOTALL).search(itemdata)  #rank
        match3 = re.compile(ur'类型：</span>(.+?)</td></tr>', re.DOTALL).search(itemdata)  #类型
        match4 = re.compile(ur'主演：</span>(.+?)</td></tr>', re.DOTALL).search(itemdata)  #主演
        match5 = re.compile(r'data-id="(.+?)"', re.DOTALL).search(itemdata)  # data-id
        
        DouBanRank = u"无"
        if match2:
            DouBanRank = match2.group(1) 
        
        genre = ""
        if match3:
            genre = match3.group(1)      
        
        li = xbmcgui.ListItem( u'%s%s(%s) 【%s】' % (match1.group(3),match1.group(1),match1.group(6) ,DouBanRank) , iconImage = '', thumbnailImage = match1.group(2))
        u = sys.argv[0]+"?mode=2&movieurl=" +urllib.quote_plus(match1.group(4)) +"&name=" + urllib.quote_plus(match1.group(1).encode('utf-8'))
        li.setInfo(type="Video",infoLabels={"Title":match1.group(1),"Year":match1.group(6),"Director":"此处是导演","Plot":"此处是剧情简介","Writer":"此处是编剧","Rating":DouBanRank,'Genre':genre})
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, True)
        
        # print match1.group(1),match1.group(2),match1.group(3),match1.group(4),match1.group(5),match1.group(6) #title，thumb，title1，movieurl , TV,Year
        # print match2.group(1)  #rank
        # print match3.group(1)#类型
        # print match4.group(1)#主演
	
    if r['more']:
        u = sys.argv[0]+"?mode=1&method=" +method +"&argString=" + argString +"&page=" + str(page +1)
        li = xbmcgui.ListItem('...[COLOR FF00FF00]下一页[/COLOR]')
        xbmcplugin.addDirectoryItem(int(sys.argv[1]),u,li,True)
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    xbmc.executebuiltin('Container.SetViewMode(508)')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
 
def get_ed2k_file_name(ed2k):
    match = re.compile(r'\|file\|(.+?)\|', re.DOTALL).findall(ed2k)
    if (len(match)!= 0):
        return match[0]
    else:
        return ed2k

def get_Thumb(gcid):
    url = 'http://i.vod.xunlei.com/req_screenshot?req_list=%s' % gcid.upper()
    r = json.loads(urllib.unquote_plus(urllib2.urlopen(url).read()))
    thumb =''
    try:
        thumb = r['resp']['screenshot_list'][0]['smallshot_url']
    except:
        pass
    return thumb
    
def Watching():
    showNum = int(float(__addon__.getSetting('showNum')))
    url = 'http://api.kcplayer.com/InterFace/Watching/GetData.ashx?s=0&e=' + str(showNum)
    req = urllib2.Request(url)
    req.add_header('KCApp', 'True')
    response = urllib2.urlopen(req)
    httpdata = response.read()
    r = json.loads(httpdata)
    for i in range(len(r)):
        file = r[i]['Url'].encode('utf-8')
        try:
            thumb = get_Thumb(r[i]['Gcid'])
        except:
            thumb=""
        if file.find('bt://') != -1:
            li = xbmcgui.ListItem( u'未命名', iconImage = '', thumbnailImage = thumb)
            u = 'plugin://script.thunder.player/bt/'+ urllib.quote_plus(file)
            xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False)
        elif file.find('ed2k://') != -1:
            li = xbmcgui.ListItem( get_ed2k_file_name(file), iconImage = '', thumbnailImage = thumb)
            u = 'plugin://script.thunder.player/ed2k/' + urllib.quote_plus(file) + '/?name=' + get_ed2k_file_name(file)
            xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False)
        elif file.find('magnet:?') != -1:
            li = xbmcgui.ListItem( u'未命名', iconImage = '', thumbnailImage = thumb)
            u = 'plugin://script.thunder.player/bt/' + urllib.quote_plus(file[20:60])
            xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False)
        else:
            li = xbmcgui.ListItem( file, iconImage = '', thumbnailImage = thumb)
            u = 'plugin://script.thunder.player/ed2k/' + urllib.quote_plus(file) + '/?name=' + file
            xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	
def getMovie(movieurl,name):
    url = 'http://dianying.fm' + movieurl
    httpdata = urllib2.urlopen(url).read().replace('\n','')
    match = re.compile(r'filename="(.+?)" url="magnet:\?xt=urn:btih:(.+?)"', re.DOTALL).findall(httpdata)
    totalItems =len(match)
    for title,Mag in match:
        li = xbmcgui.ListItem( title, iconImage = '', thumbnailImage = '')
        u = 'plugin://script.thunder.player/bt/' + Mag[0:40] + '/?name=' +  urllib.quote_plus(name)
        if M3U8 == 'true':
            u = u+ '&type=m3u8'
        xbmcplugin.addDirectoryItem(int(sys.argv[1]), u, li, False, totalItems)      
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


params = dict(parse_qsl(sys.argv[2].lstrip('?')))
mode = None
method = ''
argString = ''
page = 0
movieurl =''
name = ''


try:
    page = int(params["page"])
except:
    pass
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    method = urllib.unquote_plus(params["method"])
except:
    pass
try:
    movieurl = urllib.unquote_plus(params["movieurl"])
except:
    pass
try:
    argString = urllib.unquote_plus(params["argString"])
except:
    pass
try:
    mode = int(params["mode"])
except:
    pass
	
if mode == None:
    rootList()
elif mode == 1:
    getMovieList(method,argString,page)
elif mode == 2:
    getMovie(movieurl,name)
elif mode == 4:
    performChange(argString)
elif mode == 10:
    searchKey(argString)
elif mode == 20:
    TopMovies()
elif mode == 100:
    Watching()

