plugin.video.conectate
======================

This XBMC Add-On provides access to videos and shows from Conectate.gob.ar

Features
* Conectate.gob.ar support for all channels: Encuentro, PakaPaka, Ronda, Conectar Igualdad
* Section support for "Pelicula" , "Especial", "Serie", "Micro"
* Page support 
* HD/SD format selected by add-on setting (fallback to SD if HD not available)
* Subtitles support


