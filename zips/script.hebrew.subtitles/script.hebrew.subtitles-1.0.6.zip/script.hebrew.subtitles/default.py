# -*- coding: utf-8 -*- 

"""
    Plugin for fetching subtitles in Hebrew and English
    
    @author: sbentin
"""

import sys, os, xbmc, xbmcaddon


__settings__           = xbmcaddon.Addon(id='script.hebrew.subtitles')
__language__           = __settings__.getLocalizedString
__PLUGIN_PATH__        = __settings__.getAddonInfo('path')
__DEBUG__              = __settings__.getSetting('DEBUG') == 'true'

__scriptname__ = "Hebrew Subtitles"

BASE_RESOURCE_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'lib' ) )
sys.path.append (BASE_RESOURCE_PATH)
import common

if (__name__ == "__main__"):
    if __DEBUG__:
        common.log(__name__, "Working in Debug Mode")
    if not xbmc.getCondVisibility('Player.Paused') : 
        xbmc.Player().pause() #Pause if not paused        
    import gui
    ui = gui.GUI("script-hebrew-subtitles.xml" , __PLUGIN_PATH__ , "Default")
    ui.doModal()
    del ui
    if xbmc.getCondVisibility('Player.Paused'): 
        xbmc.Player().pause()      # if Paused, un-pause
    sys.modules.clear()