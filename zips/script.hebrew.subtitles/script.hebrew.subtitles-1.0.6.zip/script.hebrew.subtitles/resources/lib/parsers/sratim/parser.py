# -*- coding: utf-8 -*-

'''
Created on 14/06/2011

@author: sbentin
'''
import re, urllib2
import xbmcaddon

__settings__           = xbmcaddon.Addon(id='script.hebrew.subtitles')
__language__           = __settings__.getLocalizedString
__PLUGIN_PATH__        = __settings__.getAddonInfo('path')
__DEBUG__ = __settings__.getSetting("DEBUG") == "true"

BASE_URL = "http://www.sratim.co.il/"
MOVIE_SEARCH_PATTERN = '12px;"><a href="view.php\?id=([0-9]*).*?"'
TV_SEARCH_PATTERN = '<div style=""><a href=\"viewseries.php\?id=(\d+).*?"'
SUBTITLE_LIST_PATTERN = 'downloadsubtitle.php\?id=(\d+)".*?title="(.*?)".*?<td>.*?title="(.*?)"'
TV_SEASON_PATTERN = '<a href="#!s=(\d+)&e=\d*" id="seasonlink.*?>(\d+)<'
TV_EPISODE_PATTERN = '<a href="(#!s=\d+&e=\d*)" id="episodelink.*?>(\d+)<'

from common import *

def getSubtitles(fileName, title, originalTitle, tvShow, season, episode, year, isTvShow, progressControl, maxPercent): 
    subtitleList = []
    if isTvShow:
        searchString = tvShow.replace(" ", "+")
        percentStep = int(maxPercent / 3)
    else:
        if originalTitle != None and len(originalTitle) > 0:
            searchString = originalTitle.replace(" ", "+")
        else:
            searchString = title.replace(" ", "+")
        percentStep = int(maxPercent / 2)
        
    if len(searchString) <= 0:
        progressControl.setPercent(progressControl.getPercent() + maxPercent)
        return subtitleList, __language__(800) # missing title
    
    # Retrieve the search results (html)
    searchResults = getData(BASE_URL + "browse.php\?q=" + searchString)
    # Search most likely timed out, no results
    if (not searchResults):
        progressControl.setPercent(progressControl.getPercent() + maxPercent)
        return subtitleList, __language__(801)
    progressControl.setPercent(progressControl.getPercent() + percentStep)
    if isTvShow:
        # Find sratim's subtitle page IDs
        subtitleIDs = re.findall(TV_SEARCH_PATTERN, searchResults)
        # Go over all the subtitle pages and add results to our list if season
        # and episode match
        percentStep = percentStep / len(subtitleIDs)
        for sid in subtitleIDs:
            getTvSubtitles(sid, subtitleList, season, episode, fileName, progressControl, percentStep)
    else:
        # Find sratim's subtitle page IDs
        subtitleIDs = re.findall(MOVIE_SEARCH_PATTERN, searchResults)
        percentStep = percentStep / len(subtitleIDs)
        if (percentStep == 0):
            percentStep = 1
        # Go over all the subtitle pages and add results to our list
        for sid in subtitleIDs:
            getMovieSubtitles(sid, subtitleList, fileName, progressControl, percentStep)
    
    progressControl.setPercent(progressControl.getPercent() + maxPercent)
    return subtitleList, ''

def getMovieSubtitles(id, subtitleList, fileName, progressControl, percentStep):
    # get the page with all the subtitles matching this movie id
    page = getData(BASE_URL + "view.php?id=" + id + "&m=subtitles#")
    
    # parse the page for all subtitles.
    foundSubtitles = re.findall(SUBTITLE_LIST_PATTERN, page)
    progressControl.setPercent(progressControl.getPercent() + percentStep)
    for (id, language, title) in foundSubtitles:
        lang = langToCode(language)
        if lang == None:
            return
        sync = False
        if title != None and len(title.lstrip(' ')) > 0 and fileName.capitalize().startswith(title.capitalize()):
            sync = True
            
        if __DEBUG__:
            log(__name__, 'sync --> ' + str(sync))
            log(__name__, 'lang --> ' + str(lang))
            log(__name__, 'fileName --> ' + title)
            log(__name__, 'url --> ' + 'http://www.sratim.co.il/downloadsubtitle.php?id=' + id)
            
        subtitleList.append({'sync':sync, 'lang':lang, 'fileName':urllib2.unquote(title), 'url':'http://www.sratim.co.il/downloadsubtitle.php?id=' + id})
    progressControl.setPercent(progressControl.getPercent() + percentStep)

def getTvSubtitles(id, subtitleList, season, episode, fileName, progressControl, percentStep):
    # get the page with all the subtitles matching this movie id
    page = getData(BASE_URL + "viewseries.php?id=" + id + "&m=subtitles#")
    
    # parse the page for all subtitles.
    seasons = re.findall(TV_SEASON_PATTERN, page)
    progressControl.setPercent(progressControl.getPercent() + percentStep)
    for (url, seasonNumber) in seasons:
        if (int(seasonNumber) == int(season)):
            # look for the correct episode
            seasonPage = getData(BASE_URL + "getajax.php?seasonid=" + str(url))
            episodes = re.compile(TV_EPISODE_PATTERN).findall(seasonPage)
            progressControl.setPercent(progressControl.getPercent() + percentStep)
            for (epiUrl, episodeNumber) in episodes:
                log(__name__, 'episode %s, number %s, url %s' % (episode, episodeNumber, epiUrl))
                if (int(episodeNumber) == int(episode)):
                    subtitlePage = getData(BASE_URL + "viewseries.php?id=" + id + "&m=subtitles" + str(epiUrl))
                    # Create a list of all subtitles found on page
                    foundSubtitles = re.findall(SUBTITLE_LIST_PATTERN, subtitlePage)
                    for (id, language, title) in foundSubtitles:
                        lang = langToCode(language)
                        if lang == None:
                            return
                        sync = False
                        if title != None and len(title.lstrip(' ')) > 0 and fileName.capitalize().startswith(title.capitalize()):
                            sync = True
                            
                        if __DEBUG__:
                            log(__name__, 'sync --> ' + str(sync))
                            log(__name__, 'lang --> ' + str(lang))
                            log(__name__, 'fileName --> ' + title)
                            log(__name__, 'url --> ' + 'http://www.sratim.co.il/downloadsubtitle.php?id=' + id)
                            
                        subtitleList.append({'sync':sync, 'lang':lang, 'fileName':urllib2.unquote(title), 'url':'http://www.sratim.co.il/downloadsubtitle.php?id=' + id})
    progressControl.setPercent(progressControl.getPercent() + percentStep)