# -*- coding: UTF-8 -*-

"""
    Created on 30/05/2011
    
    @author: sbentin
"""
import os, time, urllib, unicodedata, string, shutil
import xbmc, xbmcaddon, xbmcgui 
from common import *

try:
    # check if xbmcvfs library exists. It allows us to save file into smb's, read files from smbs and such
    import xbmcvfs
    VFS = True
    log(__name__, 'Using xbmcvfs!!!')
except:
    VFS = False
    errno, errstr = sys.exc_info()[:2]
    notice(__name__, 'xbmcvfs library not found!!! Error %s: %s' % ( str(errno), str(errstr), ))



__settings__           = sys.modules[ "__main__" ].__settings__
__language__           = sys.modules[ "__main__" ].__language__
__PLUGIN_PATH__        = sys.modules[ "__main__" ].__PLUGIN_PATH__
__DEBUG__              = sys.modules[ "__main__" ].__DEBUG__

__CANCEL__             = (9, 10, 216, 247, 257, 275, 61467, 61448)
__MOUSE__              = (107,)
PARSER_DIR    = os.path.join(__PLUGIN_PATH__, "resources", "lib", "parsers")
__TEMP_SUB_DIR__ = os.path.join(__PLUGIN_PATH__, "resources", "lib", "temp")

THUMBS_UP = 'thumbs.png'
THUMBS_DOWN = 'thumbsDown.png'
  
class GUI( xbmcgui.WindowXMLDialog ):        
    def __init__(self, *args, **kwargs):
        log(__name__, "Starting Initialization...")
        self.multiple = False # true if the video is made of more then one file
        self.isTvShow = False  
        path = urllib.unquote(xbmc.Player().getPlayingFile()) # Full path of the playing video file
        if __DEBUG__:
            log(__name__, 'Received path from xbmc is --> ' + str(path))
        path = path.replace("\\", "/")
        if len(path) > 0:
            if (path.find("http://") > -1):
                # not supported
                notice(__name__, "http streams files are not supported")
                self.exit_script()
                return
                
            if (path.find("stack://") > -1):
                # this movie is made of a combination of files.
                path, stackSecond = path.split(" , ")
                path = path[8:]
                self.secondFile = stackSecond[stackSecond.rfind("/") + 1:path.rfind(".")]
                self.multiple = True
               
            if (path.find("rar://") > -1 ):
                # after the rar there will be a full directory/ drive path to the rar file.
                path = path.replace("rar://","")
                path = path[:path.rfind("/") - 1] # clip the name of the movie from the edge of the file, because it is not the actual file but the file inside the rar, for subtitles we want the actual file
                
            # extract the movie file name for later matching
            self.fileName = path[path.rfind("/") + 1:path.rfind(".")]
        else:
            notice(__name__, "ERROR: no path entry for playing video")
            self.exit_script()
            
        # Directory details
        self.fileDirectory = os.path.dirname(path)
        
        # Movie Details
        try:
            self.originalTitle = unicodedata.normalize('NFKD', unicode(unicode(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"), 'utf-8'))).encode('ascii','ignore')  
        except:
            self.originalTitle = xbmc.getInfoLabel("VideoPlayer.OriginalTitle")
        try :
            self.title = unicodedata.normalize('NFKD', unicode(unicode(xbmc.getInfoLabel("VideoPlayer.Title"), 'utf-8'))).encode('ascii')
        except :
            self.title = None
            
        if self.title == None or len(self.title) == 0:
            # It could be that ascii translation of the string had errors so we try using the string as is with UTF-8
            self.title = xbmc.getInfoLabel("VideoPlayer.Title")
            
        # TV Episode title
        self.tvShow = xbmc.getInfoLabel("VideoPlayer.TVshowtitle")
        self.year      = xbmc.getInfoLabel("VideoPlayer.Year")
        self.season    = str(xbmc.getInfoLabel("VideoPlayer.Season"))
        self.episode   = str(xbmc.getInfoLabel("VideoPlayer.Episode"))
        
        if self.tvShow != None and len(self.tvShow) > 0:
            self.isTvShow = True
            
        if __DEBUG__:
            log(__name__, "Multiple movie files --> %s" % self.multiple)
            log(__name__, "Full path --> %s" % path)
            log(__name__, "File Name --> %s" % self.fileName)
            if (self.multiple):
                log(__name__, "Second File Name --> %s" % self.secondFile)
            log(__name__, "Movie Folder path --> %s" % self.fileDirectory)
            log(__name__, "Original Title is --> %s" % self.originalTitle)
            log(__name__, "Title is --> %s" % self.title)
            log(__name__, "Is Tv Show --> %s" % self.isTvShow)
            log(__name__, "Tv Show Title is --> %s" % self.tvShow)
            log(__name__, "Year is --> %s" % self.year)
            log(__name__, "Season is --> %s" % self.season)
            log(__name__, "Episode is --> %s" % self.episode)
    
    def setupGui(self):
        log(__name__, "Setting up GUI Window...")
        headerControlRTL = self.getControl(113)
        headerControlLTR = self.getControl(114)
        self.getControl(115).setLabel('') # reset status message
        self.getControl(117).setLabel('') # reset status message
        self.getControl(111).setVisible(False)
        self.getControl(120).setVisible(False)
        self.getControl(122).setVisible(False)
        self.getControl(123).setVisible(False)
        # check for existing subtitles, notify user???
        sub_exts = ["srt", "sub", "txt", "idx", "ssa", "ass" ]
        for sub_ext in sub_exts:
            if __DEBUG__:
                log(__name__, self.fileDirectory + "/" + self.fileName + "." + sub_ext)
            if VFS:
                if xbmcvfs.exists(self.fileDirectory + "/" + self.fileName + "." + sub_ext):
                    dialog = xbmcgui.Dialog()
                    cont = dialog.yesno('',__language__(30000),__language__(30001))
                    if (cont):
                        break
                    else:
                        self.exit_script()
                        return
            else :
                # no smb support
                self.fileDirectory = self.fileDirectory.lstrip("smb:") # normal os.path does not handle smb's
                if os.path.isfile(self.fileDirectory + "/" + self.fileName + "." + sub_ext):
                    dialog = xbmcgui.Dialog()
                    cont = dialog.yesno('',__language__(30000),__language__(30001))
                    if (cont):
                        break
                    else:
                        self.exit_script()
                        return
        # add movie name to search title
        searchTitle = (unicodedata.normalize('NFKD', (__language__(611))).encode('utf-8') % (self.title))    
        headerControlRTL.setLabel(searchTitle)
        headerControlLTR.setLabel(searchTitle)
        
        # no make the search panel visible
        self.getControl(111).setVisible(True)
        
        # parse
        self.subtitleList = self.runParsers()
        
        # show list of files.
        if self.subtitleList:
            # change the top message to the file name of the video to make it easy to match
            headerControlRTL.setLabel(self.fileName);
            headerControlLTR.setLabel(self.fileName);
            self.getControl(116).setImage(THUMBS_UP)
            self.getControl(120).reset()
            idx = 0
            selected = False
            for item in self.subtitleList:
                flagIcon = getFlag(item['lang'])
                lang = __language__(item['lang'])
                sync = item['sync']
                listitem = xbmcgui.ListItem(label=lang, label2=item['fileName'], thumbnailImage=flagIcon)
                if sync:
                    listitem.setProperty("sync", "true")
                    self.getControl(120).selectItem(idx)
                    selected = True
                else:
                    listitem.setProperty("sync", "false")
                    if not selected:
                        self.getControl(120).selectItem(0)
                self.getControl(120).addItem(listitem)
                idx = idx + 1
                
            self.getControl(120).setVisible(True)
            self.setFocusId(120)
            
        else:
            self.getControl(116).setImage(THUMBS_DOWN) 
             
    def runParsers(self):
        subtitleList = []
        progressControl = self.getControl(112)
        progressControl.setPercent(0) # reset progress control
        parserList = os.listdir(PARSER_DIR)
        parsers = [None] * len(parserList)
        activeParsers = 0
        for name in parserList:
            if (os.path.isdir(os.path.join(PARSER_DIR, name)) and int(__settings__.getSetting(name)) < 3):
                parsers[int(__settings__.getSetting(name))] = name
                activeParsers = activeParsers + 1
        if activeParsers == 0:
            progressControl.setPercent(100)
            return subtitleList
             
        percentRange = 100 / activeParsers
        for name in parsers:
            if name != None:
                # this is a parser, lets load it....
                exec ("from parsers.%s import parser as Parser" % (name))
                logoImage = self.getControl(116)
                logoImage.setImage(os.path.join(PARSER_DIR, name, 'logo.png'))
                runningParser = Parser
                msg = ""
                subs = []
                try:
                    subs, msg = runningParser.getSubtitles(self.fileName, self.title, self.originalTitle, self.tvShow, self.season, self.episode, self.year, self.isTvShow, progressControl, percentRange)
                except:
                    errno, errstr = sys.exc_info()[:2]
                    msg = "Error %s: %s" % ( str(errno), str(errstr), )
                if msg:
                    self.getControl(115).setLabel(msg)
                    self.getControl(117).setLabel(msg)
                    
                if len(subs) > 0:
                    for item in subs:
                        subtitleList.append(item)
                    if (int(__settings__.getSetting('ROTATE')) == 1):
                        break
                
        if len(subtitleList) > 0:
            self.getControl(115).setLabel(__language__(615)) # end with success finding relevant subtitle files
            self.getControl(117).setLabel(__language__(615)) # end with success finding relevant subtitle files
        else:
            self.getControl(115).setLabel(__language__(614)) # end with no relevant subtitle files
            self.getControl(117).setLabel(__language__(614)) # end with success finding relevant subtitle files
        
        # show the keyboard icon to enable the user to manually search again    
        if xbmc.getLanguage().lower() == 'hebrew':
            self.getControl(123).setVisible(True)
            self.setFocusId(123)
        else:
            self.getControl(122).setVisible(True)
            self.setFocusId(122)
            
        progressControl.setPercent(100)
        return subtitleList
    
    def download(self, url):
        if not os.path.exists(__TEMP_SUB_DIR__):
            os.makedirs(__TEMP_SUB_DIR__)
        
        # get the file and save it to temp dir
        page = getData(url, False)
        downloadedFilePath = os.path.join(__TEMP_SUB_DIR__, "downloaded.zip")
        try:
            f = open(downloadedFilePath, 'wb')
            f.write(page)
            f.close()
        except:
            pass # TODO add an error message here
        
        notAZip = True
        # see if it is a zip file
        try:
            xbmc.executebuiltin('XBMC.Extract("%s","%s")' % (downloadedFilePath, __TEMP_SUB_DIR__))
            time.sleep(10)
            notAZip = False
        except:
            # probably not a zip file
            notAZip = True
        
        #xbmc.sleep(20) # allow the operation to end    
        if notAZip:
            pass
        else:
            files = os.listdir(__TEMP_SUB_DIR__)
            for file in files:
                ext = string.split(file,'.')[-1]
                if (ext in ['srt','sub','idx']):
                    # this is our subtitle file, move it to the right place
                    subtitleToAdd = self.copyFile(__TEMP_SUB_DIR__ + "\\" + file, ext)
                    file_list = []
                    if (ext == 'srt'):
                        xbmc.Player().setSubtitles(subtitleToAdd)
                        break
                    elif (ext in ['idx','sub']):
                        file_list.append(subtitleToAdd)
                        if (len(file_list) == 2):
                            xbmc.Player().setSubtitles(file_list)
                            break
        
        # remove the file now that we do not need it anymore.
        self.removeFiles(__TEMP_SUB_DIR__)
        
        # since xbmc remembers screens we want to fix it so next time it will start as 0%
        progressControl = self.getControl(112)
        progressControl.setPercent(0) # reset progress control          
        self.exit_script()
    
    def keyboard(self):
        if self.isTvShow:
            kb = xbmc.Keyboard("%s" % (self.tvShow), __language__(30002), False)
        else:
            if self.originalTitle:
                kb = xbmc.Keyboard("%s" % (self.originalTitle), __language__(30002), False)
            else:
                kb = xbmc.Keyboard("%s" % (self.title), __language__(30002), False)
        text = self.fileName
        kb.doModal()
        if (kb.isConfirmed()):
            text, self.year = xbmc.getCleanMovieTitle(kb.getText())
        
            if self.isTvShow:
                self.tvShow = text
                log(__name__ , "Manual/Keyboard Entry: Title:[%s], Year: [%s]" % (self.tvShow, self.year,))
            else:
                self.title = text
                self.originalTitle = text
                log(__name__ , "Manual/Keyboard Entry: Title:[%s], Year: [%s]" % (self.title, self.year,))
            
            self.setupGui()
        
    def copyFile(self, fileToCopy, ext):
        targetPath =  self.fileDirectory + "/" + self.fileName + "." + ext
        if VFS:
            log( __name__ ,"Using VFS to copy %s to %s" % (fileToCopy, targetPath))
            xbmcvfs.copy(fileToCopy, targetPath)            
        else:  
            log( __name__ ,"Using shutil to copy %s to %s" % (fileToCopy, targetPath))            
            shutil.copyfile(fileToCopy, targetPath)            
        return targetPath
    
    def removeFiles( self, directory):
        try:
            for root, dirs, files in os.walk(directory, topdown=False):
                for items in dirs:
                    shutil.rmtree(os.path.join(root, items), ignore_errors=True, onerror=None)
                for name in files:
                    os.remove(os.path.join(root, name))
        except:
            try:
                for root, dirs, files in os.walk(directory, topdown=False):
                    for items in dirs:
                        shutil.rmtree(os.path.join(root, items).decode("utf-8"), ignore_errors=True, onerror=None)
                    for name in files:
                        os.remove(os.path.join(root, name).decode("utf-8"))
            except:
                pass
         
    def onInit(self):
        self.setupGui()

    def exit_script(self, restart=False):
        self.close()

    def onFocus(self, controlId):
        pass

    def onAction(self, action):
        if __DEBUG__:
            if not action.getId() in __MOUSE__:
                log(__name__, 'control action --> ' + str(action.getId()))
        if action.getId() == 1:
            # pressed the left keyboard key or left arrow on remote.
            if self.getFocusId() == 120:
                # the list of movies is in focus
                if xbmc.getCondVisibility('Control.IsVisible(123)'):
                    self.setFocusId(123)
                elif xbmc.getCondVisibility('Control.IsVisible(122)'):
                    self.setFocusId(122)
                else :
                    self.setFocusId(120) # Don't loose focus.
        if action.getId() in __CANCEL__:
            self.exit_script()
      
    def onClick(self, controlID):
        if __DEBUG__:
            log(__name__, 'OnClick --> ' + str(controlID))
        if controlID == 120:
            selected = self.getControl(120).getSelectedPosition()
            selectedItem = self.subtitleList[selected]
            if __DEBUG__:
                log(__name__, 'Downloading --> ' + selectedItem['url'])
            dowloadingMsg = __language__(616) % (selectedItem['fileName'])
            self.getControl(115).setLabel(dowloadingMsg)
            self.getControl(117).setLabel(dowloadingMsg)
            self.download(selectedItem['url'])
        elif controlID == 122 or controlID == 123:
            self.keyboard()
        elif controlID == 132:
            __settings__.openSettings()