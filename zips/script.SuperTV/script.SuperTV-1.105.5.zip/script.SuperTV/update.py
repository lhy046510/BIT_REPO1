#!/usr/bin/env python
# -*- coding: utf-8 -*-
from default import BASE
from resources.lib.epg import updateEPG;updateEPG(BASE)
