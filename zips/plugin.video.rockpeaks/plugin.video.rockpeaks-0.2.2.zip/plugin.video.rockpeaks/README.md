xbmc-rockpeaks
==============

XBMC add-on for playing live music videos from RockPeaks.
