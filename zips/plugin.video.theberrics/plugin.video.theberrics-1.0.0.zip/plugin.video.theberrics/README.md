xbmc :: plugin.video.theberrics
===============================

XBMC video addon that allows browsing and watching videos from theberrics.com

The Berrics is a privately owned, indoor skatepark owned by professional 
skateboarders Steve Berra and Eric Koston. It is also a website providing 
content filmed in the skatepark, as well other skateboard-related media.

Supported Channels
------------------
* All Eyes On
* Bangin!
* Battle Commander
* Bombaklats
* DIY or DIE
* Established
* First Try Fridays
* General Ops
* Highlights
* News
* Off the Grid
* Process
* Recruit
* Shoot All Skaters
* Street League
* Thrashin' Thursdays
* Trajectory
* Trickipedia
* United Nations
* VHS
* Wednesdays with Reda

Supported Versions of XBMC
--------------------------
* Frodo
* Gotham
