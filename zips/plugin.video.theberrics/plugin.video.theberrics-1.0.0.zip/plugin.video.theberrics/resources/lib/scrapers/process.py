from base import ThumbnailScraper


class ProcessScraper(ThumbnailScraper):
    url = 'http://theberrics.com/process'
