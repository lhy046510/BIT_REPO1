from base import ThumbnailScraper


class HighlightsScraper(ThumbnailScraper):
    url = 'http://theberrics.com/highlights'
