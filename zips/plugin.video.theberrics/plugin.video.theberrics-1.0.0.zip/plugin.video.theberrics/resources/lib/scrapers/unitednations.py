from base import MenuItemScraper


class UnitedNationsScraper(MenuItemScraper):
    url = 'http://theberrics.com/united-nations'
