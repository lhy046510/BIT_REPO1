from base import ThumbnailScraper


class ThrashinThursdaysScraper(ThumbnailScraper):
    url = 'http://theberrics.com/thrashin-thursdays'
