from base import ThumbnailScraper


class WednesdaysWithRedaScraper(ThumbnailScraper):
    url = 'http://theberrics.com/wednesdays-with-reda'
