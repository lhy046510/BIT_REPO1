from base import ThumbnailScraper


class FirstTryFridaysScraper(ThumbnailScraper):
    url = 'http://theberrics.com/first-try-fridays'
