from base import ThumbnailScraper


class DiyOrDieScraper(ThumbnailScraper):
    url = 'http://theberrics.com/diy-or-die'
