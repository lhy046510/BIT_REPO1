from base import ThumbnailScraper


class OffTheGridScraper(ThumbnailScraper):
    url = 'http://theberrics.com/off-the-grid'
