from base import ThumbnailScraper


class StreetLeagueScraper(ThumbnailScraper):
    url = 'http://theberrics.com/street-league'
