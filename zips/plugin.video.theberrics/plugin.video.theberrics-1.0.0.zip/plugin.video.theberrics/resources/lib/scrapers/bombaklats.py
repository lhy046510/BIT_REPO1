from base import ThumbnailScraper


class BombaklatsScraper(ThumbnailScraper):
    url = 'http://theberrics.com/bombaklats'
