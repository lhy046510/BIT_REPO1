from base import ThumbnailScraper


class BanginScraper(ThumbnailScraper):
    url = 'http://theberrics.com/bangin'
