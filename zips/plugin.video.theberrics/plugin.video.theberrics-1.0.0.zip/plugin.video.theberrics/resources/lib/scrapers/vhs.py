from base import ThumbnailScraper


class VhsScraper(ThumbnailScraper):
    url = 'http://theberrics.com/vhs'
