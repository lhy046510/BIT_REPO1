from base import MenuItemScraper


class RecruitScraper(MenuItemScraper):
    url = 'http://theberrics.com/recruit'
