from base import ThumbnailScraper


class ShootAllSkatersScraper(ThumbnailScraper):
    url = 'http://theberrics.com/shoot-all-skaters'
