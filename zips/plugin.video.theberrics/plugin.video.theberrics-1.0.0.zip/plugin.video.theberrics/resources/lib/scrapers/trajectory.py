from base import ThumbnailScraper


class TrajectoryScraper(ThumbnailScraper):
    url = 'http://theberrics.com/trajectory'
