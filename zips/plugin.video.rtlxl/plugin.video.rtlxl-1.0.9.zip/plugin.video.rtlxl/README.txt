plugin.video.rtlxl
==================

RTLXL for XBMC

Install
-------
Download the repo as zip (or go to downloads in https://bitbucket.org/Opvolger/plugin.video.rtlxl/downloads)

if you download de git-repo rename de zip file to plugin.video.rtlxl-xxxx.zip where xxxx = versionnumber.

Install the plugin in XBMC. And ready to go!


Work in progress
----------------
I work with hg, and will push (by a new stable version) and pull (if there is a pull request that I like)

My work (unstable) https://bitbucket.org/Opvolger/plugin.video.rtlxl (hg repo).

My git version https://github.com/Opvolger/plugin.video.rtlxl (git repo)
