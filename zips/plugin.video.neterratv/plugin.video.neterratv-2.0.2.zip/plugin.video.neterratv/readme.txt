Readme for XMBC neterratv plugin created mr.olix@gmail.com

I created this addon to watch NeterraTV on my jailbreak AppleTV 2. 
Before I used to stream from my IPad via Airplay but the quality was that good I always had to fight
with my daughter over IPad. I have also tested the on my Win7 machine. I didn't test on any other hardware.

 
How to install:

1. Copy the zip file plugin.video.neterratv-x.x.x.zip to a directory XMBC server has access to 
	e.g. <USERDIR>\AppData\Roaming\XBMC\addons\packages\
2. Run XBMC and go to System -> Add-ons
3. From Add-ons menu select -> Install from zip file
4. Select the zip file plugin.video.neterratv-x.x.x.zip
5. NeterraTV add-on will appear in the video addon list
6. Before you run it you have to provide login information
	For this select the addon in the list and the PC use right mouse button 
	on AppleTV long press Menu on the remote control

