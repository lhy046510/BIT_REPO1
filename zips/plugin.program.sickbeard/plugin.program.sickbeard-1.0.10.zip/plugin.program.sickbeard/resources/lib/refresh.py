import xbmc

xbmc.executebuiltin('Container.Refresh')