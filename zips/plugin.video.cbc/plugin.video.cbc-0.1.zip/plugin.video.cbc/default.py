
import xbmc, xbmcgui, xbmcplugin, urllib2, urllib, re, string, sys, os, traceback, xbmcaddon

__plugin__ = 'CBC'
__author__ = 'jacker <jacker@causal.ca>'
__url__ = 'http://www.causal.ca'
__svn_url__ = "https://www.causal.ca:8888/aur/xbmc/"
__date__ = '01-22-2011'
__version__ = '0.1'
__XBMC_Revision__ = xbmc.getInfoLabel('System.BuildVersion')
__settings__ = xbmcaddon.Addon( id = 'plugin.video.cbc' )

iconimg = os.path.join( __settings__.getAddonInfo( 'path' ), 'icon.png' )
georgeimg = os.path.join( __settings__.getAddonInfo( 'path' ), 'thehour.png' )
rickimg = os.path.join( __settings__.getAddonInfo( 'path' ), 'rickmercer.jpg' )

def INDEX():
	addLink('All Videos','http://www.cbc.ca/video',iconimg)
	addLink('George Stroumboulopoulos Tonight','http://www.cbc.ca/video/#/Shows/George_Stroumboulopoulos_Tonight',georgeimg)
	addLink('The Rick Mercer Report','http://www.cbc.ca/video/#/Shows/The_Rick_Mercer_Report',rickimg)
	addLink('Live Sports','http://www.cbc.ca/video/#/Sports/Live_Streaming',iconimg)
	addLink('Curling','http://www.cbc.ca/video/#/Sports/Curling',iconimg)
	addLink('News','http://www.cbc.ca/video/#/News',iconimg)
#	addDir('CBC Videos','http://www.cbc.ca/video',1,'')

#def VIDEO(url):
#	addLink('FFOX CBC Video',url,'')

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def addLink(name,url,thumbnail):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

def addDir(name,url,mode,thumbnail):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=thumbnail)
	liz.setInfo( type="Video", infoLabels={ "Title": name } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok

# Main
params=get_params()
url=None
name=None
mode=None
try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
if mode==None or url==None or len(url)<1:
	print "categories"
	INDEX()
#elif mode==1:
#	print "PAGE"
#	VIDEO(url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
#
