XBMC 13 Gotham addon for titlovi.com
=========================

Titlovi.com subtitle addon for gotham.
Search and download subtitles from Titlovi.com, for movies and tv series.
And if you wish, convert serbian latin to cyrillic

Supported languages: English, Bosnian, Macedonian, Croatian, Serbian and Slovenian

Requirements:
To use this add on first you need to install lat2cyr module which can be found here:

https://github.com/mikimac/script.module.lat2cyr

Options:

For serbian language if you have selected options automatic conversion it will convert downloaded subtitle to utf8 cyrillic characters.
