****************************
:mod:`cherrypy.lib.encoding`
****************************

.. automodule:: cherrypy.lib.encoding

Classes
=======

.. autoclass:: ResponseEncoder
   :members:

Functions
=========

.. autofunction:: decode

.. autofunction:: compress

.. autofunction:: decompress

.. autofunction:: gzip
