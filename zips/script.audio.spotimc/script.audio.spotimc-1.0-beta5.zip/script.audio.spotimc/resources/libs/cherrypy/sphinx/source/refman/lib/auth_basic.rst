******************************
:mod:`cherrypy.lib.auth_basic`
******************************

.. automodule:: cherrypy.lib.auth_basic

Functions
=========

.. autofunction:: checkpassword_dict

.. autofunction:: basic_auth
