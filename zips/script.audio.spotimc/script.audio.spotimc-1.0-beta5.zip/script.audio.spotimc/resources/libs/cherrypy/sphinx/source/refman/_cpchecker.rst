**************************
:mod:`cherrypy._cpchecker`
**************************

.. automodule:: cherrypy._cpchecker

Classes
=======

.. autoclass:: Checker
   :members:

