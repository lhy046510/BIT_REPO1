******************************
:mod:`cherrypy.lib.xmlrpcutil`
******************************

.. automodule:: cherrypy.lib.xmlrpcutil

Functions
=========

.. autofunction:: process_body

.. autofunction:: patched_path

.. autofunction:: respond

.. autofunction:: on_error

