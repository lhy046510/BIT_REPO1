****************************
:mod:`cherrypy.lib.profiler`
****************************

.. automodule:: cherrypy.lib.profiler

Classes
=======

.. autoclass:: Profiler
   :members:

.. autoclass:: ProfileAggregator
   :members:

.. autoclass:: make_app
   :members:

Functions
=========

.. autofunction:: new_func_strip_path

.. autofunction:: serve
