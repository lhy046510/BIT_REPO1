Divxplanet XBMC Subtitle Addon
======================

this is an unofficial addon

until it's accepted by the official XMBC community, you can install it as below:

* compress the service.subtitles.divxplanet folder as zip file
* install the zip file in XBMC using : _System > Settings > Add-Ons > Install from zip file
