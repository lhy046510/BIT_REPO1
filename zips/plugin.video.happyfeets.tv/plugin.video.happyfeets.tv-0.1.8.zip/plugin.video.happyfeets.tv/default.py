# -*- coding: utf-8 -*-
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon
import os,base64
# -*- coding: iso-8859-9 -*-

__settings__ = xbmcaddon.Addon(id='plugin.video.happyfeets.tv')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)
import xbmctools
l_check=xbmctools.inside()
if l_check:
        pass
else:
        xbmctools.hata()
        sys.exit()
######################@yigitki ve @xmaxell katkilarindan dolayi Drascoma tesekkur ederiz ... #########################

# created by Happyfeets

def CATEGORIES():
        addDir('[COLOR blue] <<< Bilgilendirme >>>[/COLOR]','Info',7,'http://happyfeets.net78.net/HFOTV/addon.png')      
        addDir( '[COLOR orange]>>> TV / Radyo Hemen Bul ~~[/COLOR][COLOR red]>>>>[/COLOR][COLOR turquoise] GETIR [/COLOR][COLOR red]<<<<[/COLOR]','http://www.turkweb.tv/',10,'http://urlji.com/hfsuperara')
        addDir('[COLOR pink]>>> TV izle ~~[/COLOR][COLOR red]>>>>[/COLOR][COLOR turquoise] Alfabetik[/COLOR] & [COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]','http://happyfeets.net78.net/HFOTV/tvler.xml',4,'http://www.canlitvradyo.org/wp-content/themes/canlitv/images/logo.png')       
        addDir('[COLOR yellow]>>> Radyo Dinle ~~[/COLOR][COLOR red]>>>>[/COLOR][COLOR turquoise] Alfabetik[/COLOR] & [COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]','http://happyfeets.net78.net/HFOTV/radyolar.xml',9,'http://www.canlitvradyo.org/wp-content/themes/canlitv/images/logo.png')                
        addDir('[COLOR orange]>>> TURK SINEMASI izle ~~[/COLOR]','http://www.tv-fm.com/HD-sinema-Turk-izle_ULUSAL_2204.html',6,'http://www.tv-fm.com/picture/logo/2204.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-1 ~~[/COLOR]','http://www.tv-fm.com/hd-sinema-salon-1_ULUSAL_2221.html',6,'http://www.tv-fm.com/picture/logo/2221.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-2 ~~[/COLOR]','http://tv-fm.com/hd-sinema-salon-2_ULUSAL_2222.html',6,'http://tv-fm.com/picture/logo/2222.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-3 ~~[/COLOR]','http://tv-fm.com/hd-sinema-salon-3_ULUSAL_2223.html',6,'http://tv-fm.com/picture/logo/2223.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-4 ~~[/COLOR]','http://tv-fm.com/hd-sinema-salon4_ULUSAL_222.html',6,'http://tv-fm.com/picture/logo/2224.jpg')        
        addDir('[COLOR orange]>>> Sinema Salon-5 ~~[/COLOR]','http://tv-fm.com/hd-sinema-salon-5_ULUSAL_2225.html',6,'http://tv-fm.com/picture/logo/2225.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-6 ~~[/COLOR]','http://tv-fm.com/hd-sinema-salon-6_ULUSAL_2226.html',6,'http://tv-fm.com/picture/logo/2226.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-7 ~~[/COLOR]','http://www.tv-fm.com/Kanal-M--izle_ULUSAL_2182.html',6,'http://tv-fm.com/picture/logo/2226.jpg')
        addDir('[COLOR orange]>>> Sinema Salon-8 ~~[/COLOR]','http://www.tv-fm.com/HD-Sinema-Yabanci_ULUSAL_2220.html',6,'http://www.tv-fm.com/picture/logo/2220.jpg')
        addDir('[COLOR orange]>>> Cizgi Film tv ~~[/COLOR]','http://tv-fm.com/cizgi-film-tv-izle_ULUSAL_2190.html',6,'http://tv-fm.com/picture/logo/2190.jpg')                

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/230008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link

def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://canlitv.com/index.php?ara='+query+'&tur=tum&kat=&kdil=&kulke=&gonder=Kanal+Ara')
            tvler(url)

def tvler(url):
        link=get_url(url)
        match=re.compile('<a href="(.*?)" class="kanal">(.*?)</a>\r\n ').findall(link)
        for url,name in match:
                url='http://canlitv.com/index.php'+url
                addDir('[COLOR orange][B]>>'+name+'[/B][/COLOR]',url,2,'http://www.netindir.gen.tr/wp-content/uploads/2012/05/tv1.png')

        sayfalama=re.compile('<a href="(.*?)" onclick=".*?" class=".*?">(.*?)</a>').findall(link)
        for url,name in sayfalama:
                name=name.replace('&raquo;','')
                url='http://canlitv.com/index.php'+url
                addDir('[COLOR purple][B]>>SAYFA-' +name+'[/B][/COLOR]',url,4,'')

def alttv(url):
        link=get_url(url)
        match=re.compile('<br/>\n(.*?)\=(.*?)<br/>').findall(link)
        for name,url in match:
                addDir('[COLOR orange][B]>>'+name+'[/B][/COLOR]',url,8,'http://www.netindir.gen.tr/wp-content/uploads/2012/05/tv1.png')

def sinema(url):
        link=get_url(url)
        match=re.compile('<td align=".*?" style=".*?"><a href="(.*?)">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<img border=".*?" src="(.*?)" hspace=".*?" vspace=".*?" width=".*?" height=".*?" style=".*?"></a></td>\n\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<td align=".*?" style=".*?"><a href=".*?"><font face=".*?" style=".*?" color="#FFFFFF">(.*?)</font></td>').findall(link)
        for url,thumbnail,name in match:
                url='http://tv-fm.com/'+url
                thumbnail='http://tv-fm.com/'+thumbnail
                addDir('[COLOR orange][B]>>'+name+'[/B][/COLOR]',url,6,thumbnail)

def altradyo(url):
        link=get_url(url)
        match=re.compile('<br/>\n(.*?)\=(.*?)<br/>').findall(link)
        for name,url in match:
                addDir('[COLOR orange][B]>>'+name+'[/B][/COLOR]',url,8,'http://iphoneradyo.com/wp-content/uploads/2013/09/RADYO_sade.png')

def VideoLinks(url):            
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                
                link=get_url(url)
                match=re.compile('<source src="(.*?)" type="video/mp4">').findall(link)
                for url in match:
                        xbmcPlayer = xbmc.Player()
                        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                        playList.clear()
                        addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

def VIDEOLINKS(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def VideoLinks2(url):            
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                
                link=get_url(url)
                match=re.compile('<MediaSource>(.*?)</MediaSource>').findall(link)
                for url in match:
                        xbmcPlayer = xbmc.Player()
                        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                        playList.clear()
                        addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)
                
def INFO(url):
  try:
        CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "Ses Var Goruntu Yok ise Yayini Durdurup Tekrar Acin .","Herkese iyi Kullanimlar.")
  except:
        
        pass 
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        index(url)

elif mode==2:
        print ""+url
        VideoLinks(url)

elif mode==3:
        print ""+url
        tvler(url)

elif mode==4:
        print ""+url
        alttv(url)

elif mode==5:
        print ""+url
        sinema(url)

elif mode==6:
        print ""+url
        VideoLinks2(url)

elif mode==7:
        print ""+url
        INFO(url)

elif mode==8:
        print ""+url
        VIDEOLINKS(name,url)

elif mode==9:
        print ""+url
        altradyo(url)

elif mode==10:
        print ""+url
        Search()

xbmcplugin.endOfDirectory(int(sys.argv[1]))
