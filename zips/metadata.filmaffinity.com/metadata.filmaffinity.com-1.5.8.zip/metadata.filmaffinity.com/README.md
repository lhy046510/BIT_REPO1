metadata.filmaffinity.com
=========================

Scraper de filmaffinity para XBMC

Scraper que usa la versión española de Filmaffinity para descargar información de películas en español, ayudándose de varias páginas para ampliar la información.

Gracias a XBMCSPAIN por el soporte y ayudas, sin vosotros esto sería más complicado aún.

BÚSQUEDA AVANZADA DE GOOGLE PARA RESOLVER LOS POSIBLES ERRORES DE LA BÚSQUEDA PRINCIPAL

Se trata de una opción avanzada ya que, aunque resulta ligeramente mejor que la búsqueda principal, en caso de utilizarla sobre una cantidad importante de elementos (varias decenas) Google acaba por detectar un tráfico anómalo, colapsa, y solicita un captcha que desde el scraper no se puede rellenar. La solución pasaría por resolver el captcha desde un navegador de internet, o esperar unos minutos a que Google tuviera a bien de levantar la restricción.

Para bibliotecas grandes, se recomienda actualizar la biblioteca antes sin usar esta opción. Si la búsqueda por defecto obtuviera errores, habría que resolverlos manualmente activando esta opción e inspeccionando visualmente la biblioteca elemento a elemento. Llegado el caso, se recomienda eliminar los errores encontrados y actualizar biblioteca, o ir actualizándolos uno a uno a medida que se vayan encontrando durante la inspección.

El tipo de error más común será el de información adicional mal descargada (bien no descargada o bien descargada de otra película), por lo que se recomienda inspeccionar la biblioteca con una opción que permita visualizar el fanart, ya que será mucho más rápido. El otro error posible sería no encontrar información alguna de la película, en cuyo caso saltará aún más a la vista el error.
