'''
    B-Movies (http://www.bmovies.com/) XBMC Plugin
    Copyright (C) 2013 the-one @ XBMC.org / XBMCHUB.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.		
'''

import os
import string
import sys
import re
import xbmc, xbmcaddon, xbmcplugin, xbmcgui

from t0mm0.common.addon import Addon
from t0mm0.common.net import Net

from metahandler import metahandlers

net = Net()
addon_id = 'plugin.video.bmovies'
addon = Addon(addon_id, sys.argv)

#Common Cache
import xbmcvfs
dbg = False # Set to false if you don't want debugging

#Common Cache
try:
  import StorageServer
except:
  import storageserverdummy as StorageServer
cache = StorageServer.StorageServer('plugin.video.bmovies')

   
################### Global Constants #################################

#URLS
BASEURL = 'http://www.bmovies.com'

def AddSysPath(path):
    if path not in sys.path:
        sys.path.append(path)

#PATHS
AddonPath = addon.get_path()
IconPath = os.path.join(AddonPath, 'icons')


from universal import favorites, watchhistory
fav = favorites.Favorites(addon_id, sys.argv)
wh = watchhistory.WatchHistory(addon_id)

#VARIABLES
VideoType_Movies = 'movie'
VideoType_TV = 'tvshow'
VideoType_Season = 'season'
VideoType_Episode = 'episode'
VideoType_Link = 'link'

main_menu_items = [ 
    ('Horror', '/horror?page=0', 'horror.png'),
    ('Kung Fu', '/kung-fu?page=0', 'kungfu.png' ),
    ('Sci Fi', '/sci-fi?page=0', 'scifi.png'),
    ('Western', '/western?page=0', 'western.png'),
    ('Indie', '/content/free-b-indie-movie-streaming?page=0', 'bindie.png')
    ]

play = addon.queries.get('play', '')    
mode = addon.queries['mode']
url = addon.queries.get('url', '')
title = addon.queries.get('title', '')
img = addon.queries.get('img', '')
fanart = addon.queries.get('fanart', '')
section = addon.queries.get('section', '')
page = addon.queries.get('page', '')
video_type = addon.queries.get('video_type', '')
name = addon.queries.get('name', '')
imdb_id = addon.queries.get('imdb_id', '')
genre = addon.queries.get('genre', '')
duration = addon.queries.get('duration', '')
plot = addon.queries.get('plot', '')
season = addon.queries.get('season', '')
episode = addon.queries.get('episode', '')
year = addon.queries.get('year', '')
queued = addon.queries.get('queued', '')

#################### Addon Settings ##################################

#Helper function to convert strings to boolean values
def str2bool(v):
  return v.lower() in ("yes", "true", "t", "1")
  
meta_setting = str2bool(addon.get_setting('use-meta'))

metaget=metahandlers.MetaData()

def WatchedCallback():
    metaget.change_watched(video_type, title, imdb_id, season=season, episode=episode, year=year, watched=7)
    xbmc.executebuiltin("Container.Refresh")
    
#################### Helper Functions ##################################

def unescape(text):
        try:            
            rep = {"&nbsp;": " ",
                   "\n": "",
                   "\t": "",   
                   "%3a": ":",
                   "%3A":":",
                   "%2f":"/",
                   "%2F":"/",
                   "%3f":"?",
                   "%3F":"?",
                   "%26":"&",
                   "%3d":"=",
                   "%3D":"=",
                   "%2C":",",
                   "%2c":","
                   }
            for s, r in rep.items():
                text = text.replace(s, r)
				
            # remove html comments
            text = re.sub(r"<!--.+?-->", "", text)    
				
        except TypeError:
            pass

        return text

def Notify(typeq, title, message, times, line2='', line3=''):
     if title == '':
          title='B-Movies'
     if typeq == 'small':
          if times == '':
               times='5000'
          smallicon= os.path.join(IconPath, 'icon.png')
          xbmc.executebuiltin("XBMC.Notification("+title+","+message+","+times+","+smallicon+")")
     elif typeq == 'big':
          dialog = xbmcgui.Dialog()
          dialog.ok(' '+title+' ', ' '+message+' ', line2, line3)
     else:
          dialog = xbmcgui.Dialog()
          dialog.ok(' '+title+' ', ' '+message+' ')
		
def add_video_directory(mode, video_type, link, vidtitle, vidname, imdb='', genre='', duration='', plot='', year='', season_num=0, totalitems=0, favourite=False, img=''):

    meta = get_metadata(video_type, vidtitle, year=year, imdb=imdb, genre=genre, duration=duration, plot=plot, season_num=season_num, img=img)
    contextMenuItems = add_contextmenu(meta_setting, video_type, link, vidtitle, vidname, favourite, watched=meta['overlay'], imdb=meta['imdb_id'], year=year, season_num=season_num, img=img, genre=genre, duration=duration, plot=plot)

    meta['title'] = vidname
    addon.add_directory({'mode': mode, 'url': link, 'video_type': VideoType_Season, 'imdb_id': meta['imdb_id'], 'genre':meta['genre'], 'duration':meta['duration'], 'plot':meta['plot'], 'title': vidtitle, 'name': vidname, 'year' : meta['year'], 'season': season_num, 'img': meta['cover_url'], 'fanart': meta['backdrop_url']}, meta, contextMenuItems, context_replace=True, img=meta['cover_url'], fanart=meta['backdrop_url'], total_items=totalitems)


def add_video_item(video_type, section, link, vidtitle, vidname, year='', imdb='', genre='', duration='', plot='', season_num=0, episode_num=0, totalitems=0, favourite=False, img='', add_as_dir=True):

    meta = get_metadata(video_type, vidtitle, vidname, year, imdb=imdb, genre=genre, duration=duration, plot=plot, season_num=season_num, episode_num=episode_num, img=img)
    
    contextMenuItem = None
    if video_type == VideoType_Movies:
        contextMenuItems = add_contextmenu(meta_setting, video_type, link, vidtitle, meta['title'], favourite, watched=meta['overlay'], imdb=meta['imdb_id'], year=meta['year'], img=img, genre=genre, duration=duration, plot=plot)
    else:
        contextMenuItems = add_contextmenu(meta_setting, video_type, link, vidtitle, meta['title'], favourite, watched=meta['overlay'], imdb=meta['imdb_id'], season_num=season_num, episode_num=episode_num, img=img, genre=genre, duration=duration, plot=plot)
    
    if video_type == VideoType_Movies:
        queries = {'url': link, 'video_type': video_type, 'imdb_id': meta['imdb_id'], 'genre':meta['genre'], 'duration':meta['duration'], 'plot':meta['plot'], 'title': vidtitle, 'name': vidname, 'year' : meta['year'], 'img': meta['cover_url'], 'fanart': meta['backdrop_url']}
        if add_as_dir == True:  
            queries['mode'] = 'links'            
        else:
            queries['play'] = 'true'
        
        from universal import playbackengine    
        contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, vidtitle, addon.build_plugin_url( queries ) ) ) )
        
        addon.add_directory(queries, meta, contextMenuItems, context_replace=True, img=meta['cover_url'], fanart=meta['backdrop_url'], total_items=totalitems)
    elif video_type == VideoType_Episode:
        season_episode = 'Season: ' + str(season_num) + ' Episode: ' + str(episode_num)        
        if meta_setting:
            pretitle = vidtitle + ' - ' + season_episode
            if meta['title']:
                meta['title'] = pretitle + ' - ' + meta['title']
            else:
                meta['title'] = pretitle
        else:
            meta['title'] = meta['title'] + ' - ' + season_episode
            
        queries = {'url': link, 'video_type': video_type, 'imdb_id': meta['imdb_id'], 'genre':meta['genre'], 'duration':meta['duration'], 'plot':meta['plot'], 'title': meta['title'], 'name': vidname, 'year' : meta['year'], 'season': season_num, 'episode' : episode_num, 'img': meta['cover_url'], 'fanart': meta['backdrop_url']}
        if add_as_dir == True:  
            queries['mode'] = 'links'            
        else:
            queries['play'] = 'true'
        
        from universal import playbackengine    
        contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, vidtitle, addon.build_plugin_url( queries ) ) ) )
        
        addon.add_directory(queries, meta, contextMenuItems, context_replace=True, img=meta['cover_url'], fanart=meta['backdrop_url'], total_items=totalitems)

def add_video_link(link, vidtitle, vidname, img='', fanart='', totalitems=0):
    
    contextMenuItems = add_contextmenu(False, VideoType_Link, link, vidtitle, vidtitle, False)        
    
    addon.add_directory({'play' : 'true', 'url': link, 'video_type': VideoType_Link, 'title': vidtitle, 'name': vidname, 'year' : year, 'img': img}, {'title' : vidname}, contextMenuItems, context_replace=True, img=img, fanart=fanart, total_items=totalitems)
    
def setView(content, viewType):
    
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
    # set sort methods - probably we don't need all of them
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )        

#################### Favorites related functions ##################################
          
def Favorites(video_type):
    favs = fav.get_my_favorites()
    
    for item in favs:
    
        item = dict(item)
        
        infolabels = item['infolabels']        
        video_type = infolabels['video_type']
        
        meta = infolabels
        meta['cover_url'] = item['image_url']
        meta['backdrop_url'] = item['fanart_url']
        contextMenuItems = None
        if(infolabels.get('supports_meta', 'false') == 'true'):
            meta = get_metadata(infolabels['video_type'], item['title'].encode('utf8'), year=infolabels.get('year',''), imdb=infolabels.get('imdb_id',''), genre=infolabels.get('genre',''), duration=infolabels.get('duration',''), plot=infolabels.get('plot',''), season_num=infolabels.get('season',''), episode_num=infolabels.get('episode',''), img=infolabels.get('img',''))
            if video_type == VideoType_Movies:
                contextMenuItems = add_contextmenu(meta_setting, video_type, '', item['title'].encode('utf8').title(), meta['title'], 'true', watched=meta['overlay'], imdb=meta['imdb_id'], year=meta['year'], img=img, genre=genre, duration=duration, plot=plot)
            else:
                contextMenuItems = add_contextmenu(meta_setting, video_type, '', item['title'].encode('utf8').title(), meta['title'], 'true', watched=meta['overlay'], imdb=meta['imdb_id'], genre=infolabels.get('genre',''), duration=infolabels.get('duration',''), plot=infolabels.get('plot',''), season_num=infolabels.get('season',''), episode_num=infolabels.get('episode',''), img=infolabels.get('img',''))            
        
        listitem = xbmcgui.ListItem(item['title'].title(), iconImage=meta['cover_url'], thumbnailImage=meta['cover_url'])
        if contextMenuItems:
                listitem.addContextMenuItems(contextMenuItems, replaceItems=True)        
                
        listitem.setInfo(type="video", infoLabels=meta)
        
        listitem.setProperty('fanart_image', meta['backdrop_url'])
        listitem.setProperty('IsPlayable', item['isplayable'])
                
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=item['url']+'&favorite=true',isFolder=str2bool(item['isfolder']),listitem=listitem)
    
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
                                      
    setView('movies', 'movie-view')

def add_favorite():
    saved_favs = cache.get('favorites_' + video_type)
    favs = []

    if saved_favs:
        favs = eval(saved_favs)
        if favs:
            if (title, name, imdb_id, season, episode, url, img, genre, duration, plot) in favs:
                Notify('small', 'Favorite Already Exists', name.title() + ' already exists in your B-Movies favorites','')
                return

    favs.append((title, name, imdb_id, season, episode, url, img, genre, duration, plot))
    cache.set('favorites_' + video_type, str(favs))
    Notify('small', 'Added to favorites', name.title() + ' added to your B-Movies favorites','')


def remove_favorite():
    saved_favs = cache.get('favorites_' + video_type)
    if saved_favs:
        favs = eval(saved_favs)
        try:
            favs.remove((title, name, imdb_id, season, episode, url, img, genre, duration, plot))
        except:
            pass
        
        cache.set('favorites_' + video_type, str(favs))
        xbmc.executebuiltin("XBMC.Container.Refresh")
 
#################### Meta-Data related functions ##################################

def refresh_movie(vidtitle, year=''):

    #global metaget
    #if not metaget:
    #    metaget=metahandlers.MetaData()
        
    search_meta = metaget.search_movies(vidtitle)
    
    if search_meta:
        movie_list = []
        for movie in search_meta:
            movie_list.append(movie['title'] + ' (' + str(movie['year']) + ')')
        dialog = xbmcgui.Dialog()
        index = dialog.select('Choose', movie_list)
        
        if index > -1:
            new_imdb_id = search_meta[index]['imdb_id']
            new_tmdb_id = search_meta[index]['tmdb_id']       
            meta = metaget.update_meta('movie', vidtitle, imdb_id=imdb_id, new_imdb_id=new_imdb_id, new_tmdb_id=new_tmdb_id, year=year)   
            xbmc.executebuiltin("Container.Refresh")
    else:
        msg = ['No matches found']
        addon.show_ok_dialog(msg, 'Refresh Results')


def episode_refresh(vidname, imdb, season_num, episode_num):
    #refresh info for an episode   
    #global metaget
    #if not metaget:
    #    metaget=metahandlers.MetaData()
        
    metaget.update_episode_meta(vidname, imdb, season_num, episode_num)
    xbmc.executebuiltin("XBMC.Container.Refresh")


def season_refresh(vidname, imdb, season_num):

    #global metaget
    #if not metaget:
    #    metaget=metahandlers.MetaData()          	
        
    metaget.update_season(vidname, imdb, season_num)
    xbmc.executebuiltin("XBMC.Container.Refresh")

def get_metadata(video_type, vidtitle, vidname='', year='', imdb='', genre='', duration='', plot='', season_list=None, season_num=0, episode_num=0, img=''):    
    meta = {}
    
    if meta_setting:
        #Get Meta settings
        movie_poster = addon.get_setting('movie-poster')
        movie_fanart = addon.get_setting('movie-fanart')
        
        tv_banners = 'false' #addon.get_setting('tv-banners')
        tv_posters = 'false' #addon.get_setting('tv-posters')
        tv_fanart = 'false' #addon.get_setting('tv-fanart')
            
        #if not metaget:
        #    metaget=metahandlers.MetaData()
    
        if video_type in (VideoType_Movies, VideoType_TV):
            meta = metaget.get_meta(video_type, vidtitle, year=year)
            
        if video_type == VideoType_Season:
            returnlist = True
            if not season_list:
                season_list = []
                season_list.append(season_num)
                returnlist = False
            meta = metaget.get_seasons(vidtitle, imdb, season_list)
            if not returnlist:
                meta = meta[0]
    
        if video_type == VideoType_Episode:
            meta=metaget.get_episode_meta(vidname, imdb, season_num, episode_num)
    
        #Check for and blank out covers if option disabled
        if video_type==VideoType_Movies and movie_poster == 'false':
            meta['cover_url'] = ''
        elif video_type==VideoType_TV and tv_banners == 'false':
            meta['cover_url'] = ''
            
        #Check for banners vs posters setting    
        if video_type == VideoType_TV and tv_banners == 'true' and tv_posters == 'false':
            meta['cover_url'] = meta['banner_url']
        
        #Check for and blank out fanart if option disabled
        if video_type==VideoType_Movies and movie_fanart == 'false':
            meta['backdrop_url'] = ''
        elif video_type in (VideoType_TV, VideoType_Episode) and tv_fanart == 'false':
            meta['backdrop_url'] = ''
        
        if meta.get('title', '') == '':
            meta['title'] = vidname
        if meta.get('cover_url', '') == '':
            meta['cover_url'] = img
        if meta.get('imdb_id', '') == '':
            meta['imdb_id'] = imdb
        if meta.get('backdrop_url', '') == '':
            meta['backdrop_url'] = ''
        if meta.get('year', '') == '':
            meta['year'] = year
        if meta.get('overlay', '') == '':
            meta['overlay'] = 0
        if meta.get('genre', '') == '':
            meta['genre'] = genre
        if meta.get('duration', '') == '' or meta.get('duration', '') == '0':            
            meta['duration'] = duration
        if meta.get('plot', '') == '':
            meta['plot'] = plot        
        
    else:
        
        meta['title'] = vidname
        meta['cover_url'] = img
        meta['imdb_id'] = imdb
        meta['backdrop_url'] = ''
        meta['year'] = year
        meta['overlay'] = 0
        meta['genre'] = genre
        meta['duration'] = duration
        meta['plot'] = plot
        if video_type in (VideoType_TV, VideoType_Episode):
            meta['TVShowTitle'] = vidtitle                    

    return meta
    
#################### Context-Menu related functions ##################################

def add_contextmenu(use_meta, video_type, link, vidtitle, vidname, favourite, watched='', imdb='', genre='', duration='', plot='', year='', season_num=0, episode_num=0, img=''):
    
    contextMenuItems = []
    
    if video_type == VideoType_Link:
        return contextMenuItems
    
    contextMenuItems.append(('Show Information', 'XBMC.Action(Info)'))

    #Check if we are listing items in the Favorites list
    if favourite:
        contextMenuItems.append(('Delete from Favorites', fav.delete_item(vidtitle, section_title='Movies')))
    else:        
        infolabels = {
            'supports_meta' : 'true',
            'video_type' : video_type,
            'name' : vidname,
            'imdb_id' : imdb,
            'season' : season_num,
            'episode' : episode_num,
            'genre' : genre,
            'duration' : duration,
            'plot' : plot
            }
        p_url = fav.build_url({'play' : 'true', 'url': link, 'video_type': video_type, 'imdb_id': imdb, 'genre':genre, 'duration':duration, 'plot':plot, 'title': vidtitle, 'name': vidname, 'year' : year, 'img': img, 'fanart':''})
        contextMenuItems.append(('Add to Favorites', fav.add_video_item(vidtitle, p_url, section_title='Movies', img=img, infolabels=infolabels)))
        
    #Meta is turned on so enable extra context menu options
    if use_meta:
        if watched == 6:
            watched_mark = 'Mark as Watched'
        else:
            watched_mark = 'Mark as Unwatched'

        contextMenuItems.append((watched_mark, 'XBMC.RunPlugin(%s?mode=watch_mark&video_type=%s&title=%s&imdb_id=%s&season=%s&episode=%s)' % (sys.argv[0], video_type, vidtitle.decode('utf8', 'ignore'), imdb, season_num, episode_num)))
        contextMenuItems.append(('Refresh Metadata', 'XBMC.RunPlugin(%s?mode=refresh_meta&video_type=%s&title=%s&year=%s&season=%s&episode=%s)' % (sys.argv[0], video_type, vidtitle, year, season_num, episode_num)))
        
        #if video_type == VideoType_Movies:
            #contextMenuItems.append(('Search for trailer', 'XBMC.RunPlugin(%s?mode=trailer_search&vidname=%s&url=%s)' % (sys.argv[0], title, link)))                        

    return contextMenuItems
    

#################### Main Functions ##################################        

def MainMenu():
    
    for (menu_title, menu_link, menu_icon) in main_menu_items:
        addon.add_directory({'mode': 'browse', 'url' : BASEURL + menu_link, 'video_type' : VideoType_Movies }, {'title': menu_title}, img=os.path.join(IconPath, menu_icon))       
        
    #addon.add_directory({'mode': 'favorites', 'video_type' : VideoType_Movies }, {'title': 'Favorites'} )
    fav.add_my_fav_directory()
    #wh.add_my_history_directory()
    addon.add_directory({'mode': 'search', 'video_type' : VideoType_Movies }, {'title': 'Search'} )
    
    setView(None, 'default-view')
        
def Browse(url):    
    content = net.http_GET(url).content
    content = content.encode('utf8', 'ignore')        
    
    movies = re.search(r"(?s)<h2 class=\"title\">All(.+?)\"pager\"", content)
    if movies:
        movies = movies.group(1)
        movies = addon.unescape(movies)
        movies = unescape(movies)
        
        movie = re.compile(r"<a.+?href=\"(.+?)\".*?<img.+?src=\"(.+?)\".+?views-field-title.+?<a.+?>(.+?)</a>.+?views-field-field-genre-value.+?<span.+?>(.+?)</span>.+?views-field-field-date-value.+?<span.+?>(.+?)</span>.+?views-field-field-run-time-value.+?<span.+?>(.+?)</span>.+?views-field-field-teaser-value.+?<p>(.+?)</p>.+?</a>").findall(movies)        
        for movie_link, movie_img, movie_name, movie_genre, movie_year, movie_time, movie_plot in movie:
            movie_duration = re.search(r"([0-9]{0,1})[\:\.]{1}([0-9]{1,2})", movie_time)
            if movie_duration:
                hr = movie_duration.group(1)
                mn = movie_duration.group(2)
                if not hr:
                    hr =  '0'
                if not mn:
                    mn = '0'
                movie_duration = str((int(hr) * 60) + int(mn))
            else:
                movie_duration = movie_time

            add_video_item(video_type, video_type, movie_link, movie_name, movie_name, year=movie_year, imdb=imdb_id, genre=movie_genre, duration=movie_duration, plot=movie_plot, totalitems=len(movies), img=movie_img, add_as_dir=False)
            
    next_page = re.search(r"Go to last page", content)
    if next_page:
        main_url = url[:url.index('?')]
        current_page = url[url.index('?page=')+6:]
        next_page_url = main_url + '?page=' + str(int(current_page)+1)
        addon.add_directory({'mode': 'browse', 'url' : next_page_url, 'video_type' : video_type }, {'title': 'Next Page >>'} )       
        
    setView('movies', 'movie-view')
        
def GoogleSearch(query):
    search_url = ''
    if '&start=' in query:       
        search_url = query        
    else:
        query = re.sub(' ', '+', query)
        search_url = 'http://www.google.com/search?q=' + query + '+site:bmovies.com/movie&start=0'
        
    content = net.http_GET(search_url).content
    content = content.encode('utf8', 'ignore')    
    content = content.decode('ascii', 'ignore')    
    content = content.lower()

    search_item_count = 0
    search_results = re.compile(r"(?s)<h3 class=\"r\">(.+?)</h3>").findall(content)    
    for sr in search_results:        
        isr = re.search(r"<a.+?href=\"http://www.bmovies.com(/movie/.+?)\".+?event\)\">(.*?<em>.+?)\|", sr)
        
        if isr:
            movie_title = isr.group(2)
            movie_title = addon.unescape(movie_title)
            movie_title = unescape(movie_title)
            movie_title = re.sub(r"<.+?>", "", movie_title)
            
            movie_url = isr.group(1)
            movie_url = re.sub(r"<.+?>", "", movie_url)
            
            if '?page=' in movie_url:
                continue
            
            search_item_count = search_item_count + 1
            
            meta_content = net.http_GET(BASEURL + movie_url).content
            meta_content = meta_content.encode('utf8', 'ignore')
            meta_content = meta_content.decode('ascii', 'ignore')    
            meta_content = addon.unescape(meta_content)
            meta_content = unescape(meta_content)
            
            meta_data_items = re.search(r"<h2>.+?</h2>.+?field-field-genre.+?field-item odd\">(.+?)<.+?field-field-date.+?field-item odd\">(.+?)<.+?field-field-run-time.+?field-item odd\">(.+?)<", meta_content)
            
            movie_genre = meta_data_items.group(1)
            movie_year = meta_data_items.group(2)
            movie_time = meta_data_items.group(3)  
            
            movie_plot = re.search(r"<meta name=\"description\" content=\"(.+?)\"", meta_content)
            if movie_plot:
                movie_plot = movie_plot.group(1)
            
            movie_duration = re.search(r"([0-9]{0,1})[\:\.]{1}([0-9]{1,2})", movie_time)
            if movie_duration:
                hr = movie_duration.group(1)
                mn = movie_duration.group(2)
                if not hr:
                    hr =  '0'
                if not mn:
                    mn = '0'
                movie_duration = str((int(hr) * 60) + int(mn))
            else:
                movie_duration = movie_time
                        
            add_video_item(video_type, video_type, movie_url, movie_title.title(), movie_title.title(), year=movie_year, imdb=imdb_id, genre=movie_genre, duration=movie_duration, plot=movie_plot, totalitems=len(search_results), add_as_dir=False)
    
    if search_item_count >= 7:
        start = int(search_url[search_url.index('&start=')+7:]) + 10
        search_url = search_url[:search_url.index('&start=')] + '&start=' + str(start)
        addon.add_directory({'mode': 'googlesearch', 'url' : search_url, 'video_type' : video_type }, {'title': 'Next Page >>'} )       
    
    setView('movies', 'movie-view')
        
def ShowSearchDialog():
    last_search = addon.load_data('search')
    if not last_search: last_search = ''
    keyboard = xbmc.Keyboard()
    keyboard.setHeading('Search')
    keyboard.setDefault(last_search)
    keyboard.doModal()
    if (keyboard.isConfirmed()):
        query = keyboard.getText()
        addon.save_data('search',query)
        GoogleSearch(query)
    else:
        return     

def Play(url):  

    from universal import playbackengine
    
    item_title = title
    display_name = title
    if video_type != VideoType_Movies:
        item_title = show
                
    if queued == 'true':
        movie_url = BASEURL + url

        content = net.http_GET(movie_url).content
        content = content.encode('utf8', 'ignore')
        
        playable_content = re.search(r"(?s)jwplayer\((.+?)\}\)", content).group(1)    
        playable_url = ''
        
        rtmp = re.search(r"'(rtmp://.+?)bmovies/'", playable_content)
        if rtmp:
            rtmp = rtmp.group(1)
            flv = re.search(r"file'.+?'(.+?).flv'", playable_content).group(1)
            swf = re.search(r"'(http://.+?\.swf)'", playable_content).group(1)
            playable_url = rtmp + ' playpath=bmovies/' + flv + ' pageUrl=' + movie_url + ' swfUrl=' + swf
        else:
            mp4 = re.search(r"'(http://.+?\.mp4)'", playable_content)
            if mp4:
                playable_url = playable_url.group(1)
        
        if playable_url:
            
            player = playbackengine.Play(resolved_url=playable_url, addon_id=addon_id, video_type='movie', 
                        title=item_title,season=season, episode=episode, year=year, watchedCallback=WatchedCallback)
            
            '''
            Add to watch history - start
            '''        
            # add the following info labels if you want to enable support for metadata for you history items
            infolabels = { 'supports_meta' : 'true', 'video_type':video_type, 'name':title, 'imdb_id':imdb_id, 'season':season, 'episode':episode, 'year':year }          
            wh.add_video_item(title, sys.argv[0]+sys.argv[2], infolabels=infolabels, img=img, fanart=fanart, is_playable=True)
            '''
            Add to watch history - end
            '''

            player.KeepAlive()
    else: 
    
        playbackengine.PlayInPL(display_name, img=img)

if play:
    Play(url)
        
if mode == 'main': 
    MainMenu()
elif mode == 'browse':
    Browse(url)
elif mode == 'search':
    ShowSearchDialog()
elif mode == 'googlesearch':
    GoogleSearch(url)
elif mode == 'metahandlersettings':
    import metahandler
    metahandler.display_settings()
elif mode == 'favorites':
    Favorites(video_type)
elif mode == 'add_fav':
    add_favorite()
elif mode == 'del_fav':
    remove_favorite()
elif mode == 'refresh_meta':
    if video_type == VideoType_Movies:
        refresh_movie(title)
    elif video_type == VideoType_TV:
        Notify('small', 'Refresh TV Show', 'Feature not yet implemented','')
    elif video_type == VideoType_Season:
        season_refresh(title, imdb_id, season)
    elif video_type == VideoType_Episode:
        episode_refresh(title, imdb_id, season, episode)
elif mode == 'watch_mark':  
    metaget.change_watched(video_type, title, imdb_id, season=season, episode=episode)
    xbmc.executebuiltin("Container.Refresh")
elif mode == 'universalsettings':        
    from universal import _common
    _common.addon.show_settings()

if not play and mode != 'metahandlersettings' and mode != 'universalsettings':
    addon.end_of_directory()
