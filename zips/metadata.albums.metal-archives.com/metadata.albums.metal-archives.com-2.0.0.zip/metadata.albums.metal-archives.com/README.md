metadata.albums.metal-archives.com
==================================

XBMC scraper for fetch album metadata from www.metal-archives.com
