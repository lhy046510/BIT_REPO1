import urllib,urllib2,sys,re,urlresolver,os

path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
sys.path += [path]

import Addon

def get_shows():
    req = urllib2.Request("http://www.watchseries-online.eu/2005/07/index.html")
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    content=response.read()
    response.close()

    match=re.compile('<li><a href="(.+?category.+?)">(.+?)</a></li>').findall(content)

    match.pop(0)

    return match

def PLAY(name, url):
    req = urllib2.Request(url)

    response = urllib2.urlopen(req)
    content=response.read()
    response.close()

    match=re.compile("href='([^']+)'>Click Here to Play</a>").findall(content)

    if not match:
        return

    print match[0]
    hmf = urlresolver.HostedMediaFile(match[0])

    try:
        Addon.playLink(name, hmf.resolve(), '')
    except:
        pass
    else:
        pass

def INDEX():
    Addon.addDir('search', '', '', 'search', '')
    Addon.addDir('#', '', '', 'alphabet', '')
    for ascii_number in range(65, 91):
        letter = chr(ascii_number)
        Addon.addDir(letter, '', '', 'alphabet', '')  

def SEARCH():
    query = Addon.query('find show')

    shows = get_shows()

    for show in shows:
        match=re.compile(query, re.IGNORECASE).findall(show[1])
        if match:
            Addon.addDir(show[1], show[0], '', 'show', '')  

def ALPHABET(name):
    shows = get_shows()

    display_shows = []

    for show in shows:
        if show[1][0:1].upper() == name:
            display_shows.append(show)

        if name == '#':
            for i in range(0,9):
                if show[1].startswith(str(i)):
                    display_shows.append(show)
   
    for show in display_shows:
        Addon.addDir(show[1], show[0], '', 'show', '')  

def EPISODE(url, name):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    content=response.read()
    response.close()

    match=re.compile('(http[^"]+\?l=.+?)">(.+?)</a>', re.MULTILINE).findall(content)

    for item in match:
        if item[1] == 'Watch This':
            continue
        print item[0]
        Addon.addDir (item[1], item[0], '', 'play', '', False)
#        hostedMediaFile = urlresolver.HostedMediaFile(url=item[0])

#        if hostedMediaFile:
#            Addon.addDir (hostedMediaFile._host, item[0], '', 'play', '', False)

def get_episodes(url):
    episodes = []

    while True:
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        content=response.read()
        response.close()

        content=content.replace('\n', '')
        content=content.replace('\r', '')

        match=re.compile('<a href="([^"]+)" rel="bookmark" title=".+?">(.+?)</a>', re.MULTILINE).findall(content)

        for episode in match:
            name = episode[1]
            name = re.sub(r'(\d+)&#215;(\d+)', r'\1x\2', name)
            name = re.sub(r'(\d+)X(\d+)', r'\1x\2', name)
            name = re.sub(r'(\d+)..(\d+)', r'\1x\2', name)
            name = re.sub(r'&#\d+;', r'', name)
            name = re.sub(r'&#8x7+;', r'', name)
            name = re.sub(r'&#8x1+;', r'', name)

            url = episode[0]
            episodes.append([url, name])

        match=re.compile('<a href="([^"]+)" class="next">', re.MULTILINE).findall(content)

        if match:
            url = match[0]
            continue

        break

    episodes.reverse()

    return episodes 

def SHOW(url):
    episodes = get_episodes(url)

    seasons = {}

    unknown = False
   
    for episode in episodes:
        episode_url = episode[0]
        episode_name = episode[1]

        match=re.compile('(\d+)x').findall(episode_name)

        if match:
            seasons[match[0]] = 1
        else:
            unknown = True

    for season in sorted(seasons.iterkeys()):
        Addon.addDir('Season '+season, url, '', 'season', '')

    if unknown:
        Addon.addDir('Unknown Season', url, '', 'season', '')
        
def SEASON(url, name):
    episodes = get_episodes(url)

    match=re.compile('Season (\d+)').findall(name)
    
    season = 0
    if match:
        season = match[0]

    for episode in episodes:
        episode_name = episode[1]
        episode_url = episode[0]
        match=re.compile('(\d+)x').findall(episode_name)

        if match:
            if match[0] == season:
                Addon.addDir(episode[1], episode[0], '', 'episode', '')

        elif season == 0:
            Addon.addDir(episode[1], episode[0], '', 'episode', '')
            print episode[0]
        else:
            print "this should never happen :)"

params=Addon.getParams()
url = None
name = None
iconimage = None
mode = None
ID = None

try:
    url = params["url"]
except:
    pass
try:
    name = params["name"]
except:
    pass
try:
    iconimage = params["iconimage"]
except:
    pass
try:
    mode = params["mode"]
except:
    pass
try:
    ID = params["ID"]
except:
    pass

print "Mode: " + str(mode)
print "URL: " + str(url)
print "id: " + str(ID)
print "Name: " + str(name)
print "IconImage: " + str(iconimage)

if mode == None:
    INDEX()

elif mode == 'search':
    SEARCH()

elif mode == 'alphabet':
    ALPHABET(name)

elif mode == 'season':
    SEASON(url, name)

elif mode == 'episode':
    EPISODE(url, name)
      
elif mode == 'show':
    SHOW(url)

elif mode == 'play':
    PLAY(name, url)

Addon.end()
