import sys,re,urllib
import xbmc,xbmcgui,xbmcaddon,xbmcplugin

plugin = xbmcaddon.Addon(id=re.compile("plugin://(.+?)/").findall(sys.argv[0])[0])
host = plugin.getSetting('host')
port = plugin.getSetting('port')

def query (text):
    kb = xbmc.Keyboard('', text, False)
    kb.doModal()
    if not (kb.isConfirmed()):
        return

    return kb.getText()

def dialog (text):
    dialog = xbmcgui.Dialog()
    ok = dialog.ok('XBMC', text)

def getParams():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=urllib.unquote_plus(splitparams[1])

    return param

def addDir(name,url,ID,mode,iconimage,folder=True):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&ID="+urllib.quote_plus(ID)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name} )
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=folder)
    return ok

def addLink(name,url,iconimage):
    ok=True

    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Audio", infoLabels={ "Title": name} )
    liz.setProperty("IsPlayable","true")
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
    return ok

def playLink(name,url,iconimage):
    ok=True

    liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    liz.setInfo( type="Audio", infoLabels={ "Title": name} )
    liz.setProperty("IsPlayable","true")
    xbmc.Player().play(url, liz)
    return ok

def end():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))
