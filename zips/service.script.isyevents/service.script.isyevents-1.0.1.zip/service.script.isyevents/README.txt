ISY Events Engine
service.script.isyevents

DESCRIPTION:
ISY Events Engine is part of the ISY Events add-on set. The ISY Events Engine allows actions to be performed when events occur on the XBMC machine.

This add-on requires the ISY Browser add-on. This can be found here:
https://github.com/automicus/XBMC-ISY-Browser

For more information, please see the Automicus website.

AUTHOR: Automicus (Ryan Kraus)
DATE: 2/2014
EMAIL: automicus@gmail.com
WEBSITE: http://automic.us