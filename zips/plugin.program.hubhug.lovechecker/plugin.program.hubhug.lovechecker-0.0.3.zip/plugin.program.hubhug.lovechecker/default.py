# ###  - By TheHighway ### #
# ########################################################## #

import xbmc,xbmcgui,urllib,urllib2,os,sys,logging,array,re,time,datetime,random,string,StringIO,xbmcplugin,xbmcaddon
from config import Config as Config
import common as Common
from common import *
import common

class MyWindow(xbmcgui.Window):
	##
	button={}
	def __init__(self):
		self.scr={}; self.scr['L']=0; self.scr['T']=0; self.scr['W']=1280; self.scr['H']=720; 
		self.makePageItems()
	def makePageItems(self):
		tOffset=40; w0=1; self.b1=artp("black1"); self.background=(xbmc.translatePath(Config.fanart)); self.background=artj("backdrop"); 
		self.b3=artp("black1");		# Bar Background
		self.b2=artj("bgph1");		# Bar Forground
		self.texture=artp("fire_button-focus"); focus=artp("purple_button-focus"); nofocus=artp("pink_button-focus"); 
		## ### ##
		self.BG=xbmcgui.ControlImage(self.scr['L'],self.scr['T'],self.scr['W'],self.scr['H'],self.background,aspectRatio=0); self.addControl(self.BG)
		self.BG.setAnimations([('WindowOpen','effect=fade time=2000 start=0')])
		w=32; h=32; self.imgHeart=xbmcgui.ControlImage((self.scr['W']/2)-(w/2),(self.scr['H']/2)-(h/2)-20,w,h,artp("tlrheart"),aspectRatio=0); self.addControl(self.imgHeart); 
		## ### ##
		zz=["XBMCHUB","Your","HUB-HUG"]; w=1000; h=50; l=15; t=700; self.LabTitleText=Config.name; self.LabTitle=xbmcgui.ControlLabel(l,t,w,h,'','font30','0xFFFF0000',angle=90); self.addControl(self.LabTitle)
		for z in zz:
			if z+" " in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace(z+" ","[COLOR deepskyblue][B][I]"+z+"[/I][/B][/COLOR]  ")
		if "Highway" in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace("Highway","[COLOR tan]Highway[/COLOR]")
		self.LabTitle.setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0-(l+10)))]); self.LabTitle.setLabel(self.LabTitleText); 
		## ### ##
		self.YN="Your Name"; self.TN="Crush"; self.YNs=""+self.YN; self.TNs=""+self.TN; 
		try: self.YNs=""+SettingG("ynm"); #deb("YourName",self.YNs); 
		except:pass
		## ### ##
		w=200; h=32; l=50; t=200; 
		self.txtYourNameBG=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtYourNameBG)
		self.txtYourNameBGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtYourNameBGL)
		self.txtYourNameL=xbmcgui.ControlLabel(l,t-tOffset,w,h,self.YN,'font14','0xFF000000',alignment=2); self.addControl(self.txtYourNameL)
		self.txtYourName=xbmcgui.ControlEdit(l,t,w,h,label="",font='font14',textColor="0xFF00BFFF",focusTexture=focus,noFocusTexture=nofocus)
		self.txtYourName.setPosition(l,t); self.txtYourName.setWidth(w); self.txtYourName.setHeight(h); self.addControl(self.txtYourName); 
		## ### ## 
		w=200; h=32; l=50; t=t+10+h+tOffset; #l=self.scr['W']-(self.scr['W']/3); t=(self.scr['H']/2)-(h/2); 
		self.txtTheirNameBG=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtTheirNameBG)
		#self.txtTheirName=xbmcgui.ControlButton(l,t,w,h,self.TNs,textColor="0xFFFF1493",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.txtTheirName)
		self.txtTheirNameBGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtTheirNameBGL)
		self.txtTheirNameL=xbmcgui.ControlLabel(l,t-tOffset,w,h,self.TN+" #1",'font14','0xFF000000',alignment=2); self.addControl(self.txtTheirNameL)
		self.txtTheirName=xbmcgui.ControlEdit(l,t,w,h,label="",font='font14',textColor="0xFFFF1493",focusTexture=focus,noFocusTexture=nofocus)
		self.txtTheirName.setPosition(l,t); self.txtTheirName.setWidth(w); self.txtTheirName.setHeight(h); self.addControl(self.txtTheirName); 
		w2=901; self.txtTheirNameBar1BG=xbmcgui.ControlImage(l+w+10,t,w2,h,self.b3,aspectRatio=0); self.addControl(self.txtTheirNameBar1BG)
		self.txtTheirNameBar1=xbmcgui.ControlImage(l+w+10,t+3,w0,h-6,self.b2,aspectRatio=0); self.addControl(self.txtTheirNameBar1)
		l=(l+w+10)+(w2)+10; w=80; self.txtResultBGL=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtResultBGL)
		self.txtResultL=xbmcgui.ControlLabel(l,t,w,h,"?? %",'font14','0xFF00BFFF',alignment=2); self.addControl(self.txtResultL)
		## ### ## 
		w=200; h=32; l=50; t=t+10+h+tOffset; #l=self.scr['W']-(self.scr['W']/3); t=(self.scr['H']/2)-(h/2); 
		self.txtTheirName2BG=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtTheirName2BG)
		#self.txtTheirName2=xbmcgui.ControlButton(l,t,w,h,self.TNs,textColor="0xFFFF1493",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.txtTheirName2)
		self.txtTheirName2BGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtTheirName2BGL)
		self.txtTheirName2L=xbmcgui.ControlLabel(l,t-tOffset,w,h,self.TN+" #2",'font14','0xFF000000',alignment=2); self.addControl(self.txtTheirName2L)
		self.txtTheirName2=xbmcgui.ControlEdit(l,t,w,h,label="",font='font14',textColor="0xFFFF1493",focusTexture=focus,noFocusTexture=nofocus)
		self.txtTheirName2.setPosition(l,t); self.txtTheirName2.setWidth(w); self.txtTheirName2.setHeight(h); self.addControl(self.txtTheirName2); 
		w2=901; self.txtTheirNameBar2BG=xbmcgui.ControlImage(l+w+10,t,w2,h,self.b3,aspectRatio=0); self.addControl(self.txtTheirNameBar2BG)
		self.txtTheirNameBar2=xbmcgui.ControlImage(l+w+10,t+3,w0,h-6,self.b2,aspectRatio=0); self.addControl(self.txtTheirNameBar2)
		l=(l+w+10)+(w2)+10; w=80; self.txtResult2BGL=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtResult2BGL)
		self.txtResult2L=xbmcgui.ControlLabel(l,t,w,h,"?? %",'font14','0xFF00BFFF',alignment=2); self.addControl(self.txtResult2L)
		## ### ## 
		w=200; h=32; l=50; t=t+10+h+tOffset; #l=self.scr['W']-(self.scr['W']/3); t=(self.scr['H']/2)-(h/2); 
		self.txtTheirName3BG=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtTheirName3BG)
		#self.txtTheirName3=xbmcgui.ControlButton(l,t,w,h,self.TNs,textColor="0xFFFF1493",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.txtTheirName3)
		self.txtTheirName3BGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtTheirName3BGL)
		self.txtTheirName3L=xbmcgui.ControlLabel(l,t-tOffset,w,h,self.TN+" #3",'font14','0xFF000000',alignment=2); self.addControl(self.txtTheirName3L)
		self.txtTheirName3=xbmcgui.ControlEdit(l,t,w,h,label="",font='font14',textColor="0xFFFF1493",focusTexture=focus,noFocusTexture=nofocus)
		self.txtTheirName3.setPosition(l,t); self.txtTheirName3.setWidth(w); self.txtTheirName3.setHeight(h); self.addControl(self.txtTheirName3); 
		w2=901; self.txtTheirNameBar3BG=xbmcgui.ControlImage(l+w+10,t,w2,h,self.b3,aspectRatio=0); self.addControl(self.txtTheirNameBar3BG)
		self.txtTheirNameBar3=xbmcgui.ControlImage(l+w+10,t+3,w0,h-6,self.b2,aspectRatio=0); self.addControl(self.txtTheirNameBar3)
		l=(l+w+10)+(w2)+10; w=80; self.txtResult3BGL=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtResult3BGL)
		self.txtResult3L=xbmcgui.ControlLabel(l,t,w,h,"?? %",'font14','0xFF00BFFF',alignment=2); self.addControl(self.txtResult3L)
		## ### ##
		w=135; h=32; l=30; t=70; 
		self.button[0]=xbmcgui.ControlButton(l,t,w,h,"Exit",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[0])
		self.button[0].setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0-l)+','+str(0-h-10))])
		w=200; h=32; l=(self.scr['W']/2)-(w/2); t=self.scr['H']-(self.scr['H']/4); 
		self.button[1]=xbmcgui.ControlButton(l,t,w,h,"Test your love",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[1])
		self.button[1].setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0)+','+str(self.scr['H']-t+10))])
		## ### ## Movements
		self.button[0].controlUp(self.button[1]); self.button[0].controlDown(self.txtYourName); self.button[0].controlLeft(self.button[1]); self.button[0].controlRight(self.txtYourName); 
		self.txtYourName.controlUp(self.button[0]); self.txtYourName.controlDown(self.txtTheirName); self.txtYourName.controlLeft(self.button[0]); self.txtYourName.controlRight(self.txtTheirName); 
		self.txtTheirName.controlUp(self.txtYourName); self.txtTheirName.controlDown(self.txtTheirName2); self.txtTheirName.controlLeft(self.txtYourName); self.txtTheirName.controlRight(self.txtTheirName2); 
		self.txtTheirName2.controlUp(self.txtTheirName); self.txtTheirName2.controlDown(self.txtTheirName3); self.txtTheirName2.controlLeft(self.txtTheirName); self.txtTheirName2.controlRight(self.txtTheirName3); 
		self.txtTheirName3.controlUp(self.txtTheirName2); self.txtTheirName3.controlDown(self.button[1]); self.txtTheirName3.controlLeft(self.txtTheirName2); self.txtTheirName3.controlRight(self.button[1]); 
		self.button[1].controlUp(self.txtTheirName3); self.button[1].controlDown(self.button[0]); self.button[1].controlLeft(self.txtTheirName3); self.button[1].controlRight(self.button[0]); 
		## ### ## Focus
		self.setFocus(self.button[0])
	def onAction(self,action):
		if   action == Config.ACTION_PREVIOUS_MENU: self.CloseWindow1st()
		elif action == Config.ACTION_NAV_BACK: self.CloseWindow1st()
	def onControl(self,control):
		if   control==self.button[0]: self.CloseWindow1st()
		elif control==self.button[1]: 
			try:
				FormData={"name":self.txtYourName.getText(),"crush1":self.txtTheirName.getText(),"crush2":self.txtTheirName2.getText(),"crush3":self.txtTheirName3.getText()}
				html=nolines(postURL2("http://www.lovecalculator.be/quick.php",form_data=FormData)); #print html
				s='<tr><td align=right><b>(.*?)</b></td><td align=center width=\d+>\s*'; 
				s+='<img src="lheart.png" alt="(.*?)" width=\d+ height=\d+ border=\d+></td>\s*'; 
				s+='<td align=left><b>(.*?)</b></td></tr><tr><td align=center colspan=\d+>\s*'; 
				s+='<img src="/sec/score.png.percent=(.*?)" alt="\d+" height=\d+ width=\d+></td></tr'; 
				if len(html)==0: return
				r=re.compile(s).findall(html); debob(r); 
				if len(r) > 0:
					myname1,altmsg1,mycrush1,percent1=r[0]; percent1=int(percent1); w=int(float(percent1)/100*900+1); deb(str(percent1),str(w)); 
					#deb(str(percent1),str(int(float(percent1)))); #deb(str(percent1),str(int(float(percent1)/100))); #deb(str(percent1),str(int(float(percent1)/100*900))); #deb(str(percent1),str(int(float(percent1)/100*900+1))); 
					self.txtTheirNameBar1.setWidth(w); self.txtResultL.setLabel( str(percent1)+" %"); self.txtTheirNameBar1.setImage(self.b2); self.txtTheirNameBar1.setVisible(True); 
				if len(r) > 1:
					myname1,altmsg1,mycrush1,percent1=r[1]; percent1=int(percent1); w=int(float(percent1)/100*900+1); deb(str(percent1),str(w)); 
					self.txtTheirNameBar2.setWidth(w); self.txtResult2L.setLabel(str(percent1)+" %"); self.txtTheirNameBar2.setImage(self.b2); self.txtTheirNameBar2.setVisible(True); 
				if len(r) > 2:
					myname1,altmsg1,mycrush1,percent1=r[2]; percent1=int(percent1); w=int(float(percent1)/100*900+1); deb(str(percent1),str(w)); 
					self.txtTheirNameBar3.setWidth(w); self.txtResult3L.setLabel(str(percent1)+" %"); self.txtTheirNameBar3.setImage(self.b2); self.txtTheirNameBar3.setVisible(True); 
			except: pass
	def CloseWindow1st(self):
		#try: zz=[self.CtrlList,self.RepoThumbnail,self.RepoFanart2,self.RepoFanart,self.LabCurrentRepo,self.LabTitle,self.button[0],self.TVS,self.TVSBGB,self.BGB]
		#except: zz=[]
		#for z in zz:
		#	try: self.removeControl(z); del z
		#	except: pass
		self.close()
## ################################################## ##
## ################################################## ##
## Start of program
TempWindow=MyWindow(); TempWindow.doModal(); del TempWindow
## ################################################## ##
## ################################################## ##
