# -*- coding: utf-8 -*-

"""
    Plugin for streaming video content from www.sport5.co.il
"""
import urllib, re, xbmc, xbmcplugin, xbmcaddon, xbmcgui, unicodedata, os, sys



##General vars
__plugin__ = "sport5"
__author__ = "Shai Bentin"

__image_path__ = 'http://ilvideo.googlecode.com/svn/trunk/'
__settings__ = xbmcaddon.Addon(id='plugin.video.sport5.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')

LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

__base_url__ = 'http://www.sport5.co.il'

from common import *

def CATEGORIES():
    ## get the block containing the list of VOD categories
    page = getData(__base_url__)
    matches = re.compile('VOD.*?<div class="links_list">.*<div class="middle_col">\s*<div>\s*<div id="ucHeader_rptUpperBarMenu_ucUpperBarInner_0').findall(page)
    if len(matches) > 0:
        categories = re.compile('<a href=\'(.*?)\'>(.*?)<').findall(matches[0])
        for href, name in categories:
           addDir(name, href, 1)
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
    xbmc.executebuiltin("Container.SetViewMode(500)")# see the image view

def TYPE_LOCATE(url):
    if url.find('lobbyvideobranded') > -1:
        manager = getattr(__import__('module_branded'), 'manager_branded')()
        manager.episodes(url)
    elif url.find('lobbyvideo') > -1:
        manager = getattr(__import__('module_lobby'), 'manager_lobby')()
        manager.episodes(url)
    elif url.find('expanded') > -1:
        manager = getattr(__import__('module_expanded'), 'manager_expanded')()
        manager.series(url)
    elif url.find('GetSummaryVideos') > -1:
        manager = getattr(__import__('module_expanded'), 'manager_expanded')()
        manager.episodes(url)
    else :
        ## this is the most common so we use it also as default.
        manager = getattr(__import__('module_branded'), 'manager_branded')()
        manager.episodes(url)
   
def PLAY_MOVIE(url, name):
    # videopage = getData(url) # episode page is cached according to defaults
    # print videopage
    # movieId = re.compile('movieId:.*?\'(.*?)\'').findall(videopage)
    print url
    smilUrl = 'http://locator.3dcdn.com/vod/' + url + '/vod.smil'
    smilPage = getData(smilUrl)
    videoLink = re.compile('<video src="(.*?)"').findall(smilPage)
    videoUrl = 'rtmp://de-iptp.d.3dcdn.com:1935/sport5_vod playpath=' + videoLink[len(videoLink)-1] + ' pageUrl=url'
    listItem = xbmcgui.ListItem(name, 'DefaultFolder.png', 'DefaultFolder.png', path=videoUrl)# + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    listItem.setInfo(type='Video', infoLabels={ "Title": urllib.unquote(name), "Plot": str(name)})
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)

params = getParams(sys.argv[2])
url=None
name=None
mode=None
module=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
try:
        page=urllib.unquote_plus(params["page"])
except:
        pass
    
if mode==None or url==None or len(url)<1:
    CATEGORIES()

elif mode==1:
    TYPE_LOCATE(url)

elif mode==2:
    PLAY_MOVIE(url, name)
        
else:
    manager = getattr(__import__('module_' + module.lower()), 'manager_' + module)()
    manager.work(mode, url, name, page)
        


xbmcplugin.setPluginFanart(int(sys.argv[1]),xbmc.translatePath( os.path.join( __PLUGIN_PATH__,"fanart.jpg") ))
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)