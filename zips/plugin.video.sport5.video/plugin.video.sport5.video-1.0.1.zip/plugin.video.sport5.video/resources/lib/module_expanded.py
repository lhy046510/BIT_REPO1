# -*- coding: utf-8 -*-

'''
Created on 23/12/2011
channel 5
@author: shai
'''

__base_url__ = 'http://www.sport5.co.il'
__NAME__ = 'expanded'

import urllib,urllib2,re,os,sys
import xbmcplugin,xbmcgui,xbmcaddon
from common import *

__settings__ = xbmcaddon.Addon(id='plugin.video.sport5.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')

class manager_expanded:
 
    def episodes(self, url):
        # receive the block of shows that are a part of this genre
        page = getData(url)
        print page
        blocks = re.compile('<div id="rptVideos__ct.*?\(\'(.*?)\'.*?<img src="(.*?)".*?_text">(.*?)<').findall(page)
        for videoUrl, imageUrl, title in blocks:
            imageUrl = __base_url__ + imageUrl
            title = title.replace('&nbsp;', ' ').replace('&quot;', '"')
            addVideoLink(title, videoUrl, 2, imageUrl)
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmc.executebuiltin("Container.SetViewMode(503)")# see the image view
        
    def series(self, url):
        # receive the block of shows that are a part of this genre
        page = getData(url)
        select = re.compile('<option value="(.*?)">(.*?)</option>').findall(page)
        for value, title in select:
            if value != '-1':
                addDir(title,  'http://www.sport5.co.il/Shared/Ajax/GetSummaryVideos.aspx?TeamCategoryID=' + value, 1)
        xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')
        xbmc.executebuiltin("Container.SetViewMode(500)")# see the image view
             