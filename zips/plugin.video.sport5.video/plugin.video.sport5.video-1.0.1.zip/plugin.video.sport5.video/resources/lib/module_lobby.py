# -*- coding: utf-8 -*-

'''
Created on 23/12/2011
channel 5
@author: shai
'''

__base_url__ = 'http://www.sport5.co.il'
__NAME__ = 'lobby'

import urllib,urllib2,re,os,sys
import xbmcplugin,xbmcgui,xbmcaddon
from common import *

__settings__ = xbmcaddon.Addon(id='plugin.video.sport5.video')
__language__ = __settings__.getLocalizedString
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')



class manager_lobby:
 
    def episodes(self, url):
        # receive the block of shows that are a part of this genre
        page = getData(url)
        # print page
        blocks = re.compile('med_vid">(.*?class="med_vid_txt">.*?</td>)').findall(page)
        for block in blocks:
            # print 'BLOCK ' + block
            matches = re.compile('background-image:url\((.*?)\).*?play_video_social\(\'(.*?)\'.*?>(.*?)</DIV>.*?class="med_vid_txt">(.*?)</DIV').findall(block)
            for img, vidurl, title, details in matches:
                iconImage = __base_url__ + img
                details = details.replace('&nbsp;',' ').replace('<P>',' ').replace('</P>',' ')
                addVideoLink(title, vidurl, 2, iconImage, details)        
        
        hasNext = re.compile('(linkNext)').findall(page)
        if not hasNext == None and len(hasNext) > 0:
            idx = url.rfind('&PageNum=')
            num = 2
            if (idx != -1):
                # print 'PAGE_NUM %s --> %s --> %s' % (str(idx+9), str(len(url)), url[(idx+9):len(url)])
                num = int(url[(idx+9):len(url)]) + 1
                url = str(url)[:idx]
            addDir(__language__(30001),url + '&PageNum=' + str(num), 1)
        xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
        xbmc.executebuiltin("Container.SetViewMode(503)")# see the image view         