import sys, xbmc, xbmcaddon, xbmcgui, xbmcplugin, urllib2, urllib, re, string,  os, traceback, cookielib
from urllib2 import HTTPRedirectHandler, build_opener

# plugin constants
__version__ = "0.1.0"
__plugin__ = "mc-" + __version__
__author__ = "lin.spb.ru"
__svn_url__ = ""
__settings__ = xbmcaddon.Addon(id='plugin.audio.montecarlo')
__dbg__ = __settings__.getSetting( "debug" ) == "true"
__lc__ = ""

	
if (__name__ == "__main__" ):
    if __dbg__:
        print __plugin__ + " ARGV: " + repr(sys.argv)
    else:
        print __plugin__

playList = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
playList.clear()
playList.add('http://stream4.radiostyle.ru:8004/rmc') 
xbmc.Player().play(playList)
