This is an XBMC Video Plugin for streaming content from ThePakTV forums
http://www.thepaktv.me/forums