import sys
import time
import xbmc
import xbmcaddon
import source as src

print "script.tvguide external ARGV: " + repr(sys.argv)


# TODO:
'''
19:34:04 <@Matador> I want what the people want
19:34:15 <@Matador> if nothing scheduled on a channel, should be able to go down and select it
19:34:25 <@Matador> last check, it skipped down to only events
'''

#res = xbmc.executebuiltin("XBMC.RunPlugin(plugin://plugin.video.mystreamstv.beta/default.py?action=login", True)
#res = xbmc.executebuiltin("XBMC.RunScript(/home/tobias/Aptana Studio 3 Workspace/mystreamstvxbmc/plugin/default.py?action=login", True)
#res = xbmc.executebuiltin("XBMC.PlayMedia(plugin://plugin.video.mystreamstv.beta/default.py?action=login", True)
#print "script.tvguide external ARGV login3: " + repr(res)

main_addon = xbmcaddon.Addon(id = 'script.smoothstreams')
smoothstreams_settings = xbmcaddon.Addon(id='plugin.video.mystreamstv.beta')

main_addon.setSetting('source', 'XMLTV')
main_addon.setSetting('xmltv.uri', 'http://cdn.smoothstreams.tv/schedule/feed.xml')


def getChanUrl(params={}):
    get = params.get

    servers = ["dEU.SmoothStreams.tv", "dNA.SmoothStreams.tv", "dSG.SmoothStreams.tv"]
    server = servers[int(smoothstreams_settings.getSetting("server"))]

    if smoothstreams_settings.getSetting("high_def") == "true":
        quality = "q1"  # HD - 2800k                                                                                                                       
    elif True:
        quality = "q2"  # LD - 1250k                                                                                                                       
    else:
        quality = "q3"  # Mobile - 400k ( Not in settings)                                                                                                 

    chan = get("chan")
    uname = smoothstreams_settings.getSetting("SUserN")
    pword = smoothstreams_settings.getSetting("SPassW")

    if smoothstreams_settings.getSetting("service") == "1":
        stream_port = "2935"
    elif smoothstreams_settings.getSetting("service") == "3":
        stream_port = "3935"
    else:
        stream_port = "29350"
        
    if smoothstreams_settings.getSetting("server_type") == "0":
        stream_type = "rtmp"
        chan_template = "%s://%s:%s/view?u=%s&p=%s/ch%s%s.stream"
        url = chan_template % (stream_type, server, stream_port, uname, pword, chan, quality)
    else:
        stream_type = "rtsp"
        chan_template = "%s://%s:%s/view/ch%s%s.stream?u=%s&p=%s"
        url = chan_template % (stream_type, server, stream_port, chan, quality, uname, pword)

    channel_name = {}
    playing_now = {}
    playing_next = {}
    
    name = "#" + chan

    if chan in channel_name:
        name += " - " + channel_name[chan].decode("utf-8")
        
    if chan in playing_now:
        name += " - Now: " + playing_now[chan].decode("utf-8")

    if chan in playing_next:
        if chan not in playing_now or playing_next[chan] != playing_now[chan]:
            name += " - Next: " + playing_next[chan].decode("utf-8")

    return url

url = getChanUrl({"chan": "%s"})
#print "BLAAAAAAAAAAAAAA url: " + repr(url)
main_addon.setSetting('xmltv.uri.plugin_play', url)
