## Lyrics module

import os
import xbmc
from codecs import BOM_UTF8
import re
from resources.lib.scraper import Scraper
# only need this for xbox and smb:// paths
if ( os.environ.get( "OS", "n/a" ) == "xbox" ):
    import base64

# needs to be global as song and prefetched_song are two instances
prefetched_lyrics = dict()


class Lyrics:
    """
        Fetches, cleans and saves lyrics.
    """

    def __init__( self, Addon, prefetch ):
        # set our Addon class
        self.Addon = Addon
        # our we prefetching
        self.prefetch = prefetch
        # regex's
        self.regex_clean_info = re.compile( "\[[a-z]+?:.*\]\s" )
        self.regex_split_lrc_lyrics = re.compile( "\[([0-9]+):([0-9]+(?:\.[0-9]+)?)\](.*)" )
        self.regex_timestamp_lrc_lyrics = re.compile( "\[offset:([+-]*[0-9]+)\]" )
        self.regex_website = re.compile( "\[we:(.+)\]" )
        # initialize our Scraper class
        self.scraper = Scraper( self.Addon, prefetch=self.prefetch )

    def get_lyrics( self, song, songlist ):
        try:
            # needs to be global as song and prefetched_song are two instances
            global prefetched_lyrics
            # set key
            cachename = xbmc.getCacheThumbName( song.artist + song.title )
            # if prefetched lyrics are found set them
            if ( prefetched_lyrics.has_key( cachename ) ):
                # FIXME: deleting them loses the prefetched song when skipping backwards
                if ( not self.prefetch ):
                    # loop thru and set all attributes
                    for key, value in prefetched_lyrics[ cachename ].iteritems():
                        setattr( song, key, value )
                    # delete prefetched lyrics as they should be cached now
                    del prefetched_lyrics[ cachename ]
                # prefetched lyrics are already cleaned
                return
            # if embedded lyrics are found set them
            elif ( xbmc.getInfoLabel( "MusicPlayer.Offset(%d).Lyrics" % ( self.prefetch, ) ) ):
                song.lyrics = unicode( xbmc.getInfoLabel( "MusicPlayer.Offset(%d).Lyrics" % ( self.prefetch, ) ), "UTF-8", "replace" )
                song.message = self.Addon.getLocalizedString( 30861 )
            # if cached lyrics are found set them
            else:
                # use httpapi for smb:// paths if xbox, with hack for change in xbmc so older revisions still work
                if ( song.lyrics_path.startswith( "smb://" ) and os.environ.get( "OS", "n/a" ) == "xbox" ):
                    song.lyrics = unicode( base64.standard_b64decode( xbmc.executehttpapi( "FileDownload(%s,bare)" % ( song.lyrics_path, ) ).split( "\r\n\r\n" )[ -1 ].strip( BOM_UTF8 ) ), "UTF-8" )
                else:
                    song.lyrics = unicode( open( song.lyrics_path, "r" ).read().strip( BOM_UTF8 ), "UTF-8" )
                # set cached message
                song.message = self.Addon.getLocalizedString( 30862 )
        except Exception, e:
            # no lyrics found, so fetch lyrics from internet
            self.scraper.fetch_lyrics( song, songlist )
            # if the search was successful save lyrics
            if ( song.status ):
                self.save_lyrics( song )
        # we need to clean lyrics in case they are lrc tagged
        self._clean_lyrics( song )
        # store lyrics only if prefetch, we only store for the fetched message.
        if ( self.prefetch and song.status ):
            prefetched_lyrics[ cachename ] = {
                "message": song.message,
                "website": song.website,
                "status": song.status,
                "lyrics": song.lyrics,
                "lyric_tags": song.lyric_tags,
                "lrc_lyrics": song.lrc_lyrics,
                "prefetched": self.prefetch
            }

    def _clean_lyrics( self, song ):
        # nothing to clean?
        if ( song.lyrics is None or not song.status ): return
        # default to lrc lyrics
        lrc_lyrics = True
        # get website
        if ( song.website is None ):
            try:
                song.website = self.regex_website.search( song.lyrics ).group( 1 )
            except:
                song.website = ""
        # eliminate info block
        song.lyrics = self.regex_clean_info.sub( "", song.lyrics )
        # separate lyrics and time stamps
        lyrics = self.regex_split_lrc_lyrics.findall( song.lyrics )
        # auto tag lyrics if not tagged and user preference
        if ( not lyrics and self.Addon.getSetting( "enable_karaoke_mode" ) == "true" and self.Addon.getSetting( "autoscroll_lyrics" ) == "true" ):
            # split lines
            lines = song.lyrics.strip().splitlines()
            # get offset
            offset = int( float( self.Addon.getSetting( "autoscroll_lyrics_delay" ) ) )
            # get total time
            total_time = int( xbmc.getInfoLabel( "MusicPlayer.Offset(%d).Duration" % ( self.prefetch, ) ).split( ":" )[ 0 ] ) * 60 + int( xbmc.getInfoLabel( "MusicPlayer.Offset(%d).Duration" % ( self.prefetch, ) ).split( ":" )[ 1 ] ) - ( offset * 2 )
            # we set the same amount of time per lyric, what do you expect?
            lyric_time = float( total_time ) / len( lines )
            # enumerate thru and set each tagged lyric
            lyrics = [ divmod( ( count + 1 ) * lyric_time + offset, 60 ) + ( lyric, ) for count, lyric in enumerate( lines ) ]
            # these are non lrc lyrics
            lrc_lyrics = False
        # format lyrics
        if ( lyrics ):
            # set lyric type
            song.lrc_lyrics = lrc_lyrics
            # get any timestamp adjustment
            try:
                offset = float( self.regex_timestamp_lrc_lyrics.search( song.lyrics ).group( 1 ) ) / 1000
            except:
                offset = 0
            # reset lyrics
            song.lyrics = ""
            # loop thru and set our lyrics
            for lyric in lyrics:
                song.lyric_tags.append( int( lyric[ 0 ] ) * 60 + float( lyric[ 1 ] ) + offset )
                song.lyrics += lyric[ 2 ].strip() + "\n"
        # strip lyrics 
        song.lyrics = song.lyrics.strip()

    def save_lyrics( self, song ):
        try:
            # format lyrics with song info header
            song.lyrics = "[ti:%s]\n[ar:%s]\n[al:%s]\n[re:%s]\n[ve:%s]\n[we:%s]\n[offset:0]\n\n%s" % (
                song.title,
                song.artist,
                song.album,
                self.Addon.getAddonInfo( "Name" ),
                self.Addon.getAddonInfo( "Version" ),
                song.website,
                song.lyrics,
            )
            # use httpapi for smb:// paths if xbox
            if ( song.lyrics_path.startswith( "smb://" ) and os.environ.get( "OS", "n/a" ) == "xbox" ):
                # no way to create dirs for smb:// paths on xbox
                xbmc.executehttpapi( "FileUpload(%s,%s)" % ( song.lyrics_path, base64.standard_b64encode( BOM_UTF8 + song.lyrics.encode( "UTF-8", "replace" ) ), ) )
            else:
                # if the path to the source file does not exist create it
                self._makedirs( os.path.dirname( song.lyrics_path ) )
                # save lyrics
                open( song.lyrics_path, "w" ).write( BOM_UTF8 + song.lyrics.encode( "UTF-8", "replace" ) )
        except Exception, e:
            # log error
            xbmc.log( "Lyrics::save_lyrics (%s)" % ( e, ), xbmc.LOGERROR )
            # set error message
            song.message = self.Addon.getLocalizedString( 30852 ) % ( e, )
            song.status = False

    # FIXME: eliminate this if os.makedirs is wrapped properly
    def _makedirs( self, _path ):
        def _convert_smb_path( _path ):
            # if windows and smb:// convert to a proper format for shutil and os modules
            if ( _path.startswith( "smb://" ) and os.environ.get( "OS", "win32" ) == "win32" ):
                _path = _path.replace( "/", "\\" ).replace( "smb:", "" )
            # return result
            return _path
       # no need to create folders
        if ( os.path.isdir( _path ) ): return
        # temp path
        tmppath = _path
        # loop thru and create each folder
        while ( not os.path.isdir( tmppath ) ):
            try:
                os.mkdir( _convert_smb_path( tmppath ) )
            except:
                tmppath = os.path.dirname( tmppath )
        # call function until path exists
        self._makedirs( _path )
