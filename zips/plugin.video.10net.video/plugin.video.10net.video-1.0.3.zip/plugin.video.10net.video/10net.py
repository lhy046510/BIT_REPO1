# -*- coding: utf-8 -*-

"""
    Plugin for streaming video content from www.10net.co.il
"""
_UserAgent_ =  'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; SLCC1; .NET CLR 2.0.50727; Media Center PC 5.0; .NET CLR 3.0.04506)'

import urllib, urllib2, re, random, os, sys
import xbmc, xbmcplugin, xbmcaddon, xbmcgui

##General vars
__plugin__ = "10net"
__author__ = "Shai Bentin"

__settings__ = xbmcaddon.Addon(id='plugin.video.10net.video')
__language__ = __settings__.getLocalizedString

__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'lib' ) )
sys.path.append (LIB_PATH)

from common import *

def CATEGORIES():  
    matches = getMatches('http://www.10net.co.il/','class="navbutton".*?><a href="(.+?)">(.+?)</a')
    i = len(matches)
    if i > 8:
        i = 8 # I only want the first 6 movie categories nothing more
    for url, name in matches:
        if i == 0:
            break
        addDir(name, url, 1)
        i -= 1
    xbmcplugin.setContent(int(sys.argv[1]), 'tvshows')

def MOVIES(url, name):
    page = getData("http://www.10net.co.il" + url, name)
    showing = re.compile('class="tabview visible">(.+)id="lastview"').findall(page)
    movies = re.compile('class="movie">.*?<a href="(.+?)"><img.*?src="(.+?)" alt.*?<a href.*?>(.+?)<.*?class=.*?>(.*?)<').findall(showing[0])
    if len(movies) > 0:
        for url, image, movieName, details in movies:
            url = "http://www.10net.co.il" + url
            image = "http://www.10net.co.il" + image
            addVideoLink(movieName, url, 2, image, details)
        
        hasnext = re.compile('<<</a><a href="(.*?") class="next">').findall(page)
        next = re.compile('href="(.+?)"').findall(hasnext[0])
        if len(next) > 0:
            nexturl = next[len(next) - 1]
            addDir(name + ' ' + nexturl[len(nexturl) -1], nexturl, 1)
            
        xbmcplugin.setContent(int(sys.argv[1]), 'movies')
        xbmc.executebuiltin("Container.SetViewMode(500)") # see big icons

def PLAY_MOVIE(url, name):   
    page = getData(url, name)
    code = re.compile('<embed.*?v/(.*?)"').findall(page)
    if len(code) > 0:
        getlowurl(code[0], name)
    else:
        # maybe its a videobb video
        videobb = re.compile('<embed.*?src="http://videobb.com/.+?/(.+?)"').findall(page)

        if len(videobb) > 0:
            getURL(videobb[0])
        else :
            dialog = xbmcgui.Dialog()
            dialog.ok("error", "Unable to find movie URL, not MegaVideo and not VideoBB")

def getURL(code):
    controluri = "http://videobb.com/player_control/settings.php?v=%s&em=TRUE&fv=v1.2.72" %code
    
    req = urllib2.Request(controluri)
    req.add_header('User-Agent', _UserAgent_)
    response = urllib2.urlopen(req)
    datajson=response.read()
    response.close()
    
    datajson = datajson.replace("false","False").replace("true","True")
    datajson = datajson.replace("null","None")
    datadict = eval("("+datajson+")")
    
    import base64, decrypt10
    
    secret = decrypt10.decrypt(datadict["settings"]["banner"]["g_ads"]["time"], datadict["settings"]["config"]["rkts"], (113296.5*2))

    devuelve = base64.decodestring(datadict["settings"]["config"]["token1"])
    devuelve = devuelve + '&c=' + secret + '&start=0'
    
    xbmc.log('url is %s' % (devuelve), xbmc.LOGDEBUG)
    listItem = xbmcgui.ListItem('Standard VideoBB File', 'DefaultFolder.png', 'DefaultFolder.png', path=devuelve)# + '|' + _UserAgent_)
    listItem.setInfo(type='Video', infoLabels={ "Title": urllib.unquote(name)})
    listItem.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)

def getlowurl(code, name):
    req = urllib2.Request("http://www.megavideo.com/xml/videolink.php?v="+code)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.14) Gecko/20080404 Firefox/2.0.0.14')
    req.add_header('Referer', 'http://www.megavideo.com/')
    page = urllib2.urlopen(req);response=page.read();page.close()
    errort = re.compile('errortext="(.+?)"').findall(response)
    if len(errort) <= 0:
        xbmc.log('data %s' % (response), xbmc.LOGERROR)
        s = re.compile(' s="(.+?)"').findall(response)
        k1 = re.compile(' k1="(.+?)"').findall(response)
        k2 = re.compile(' k2="(.+?)"').findall(response)
        un = re.compile(' un="(.+?)"').findall(response)
        videoPlayListUrl = "http://www" + s[0] + ".megavideo.com/files/" + decrypt(un[0], k1[0], k2[0]) + "/?.flv"
        listItem = xbmcgui.ListItem('Standard Megavideo File', 'DefaultFolder.png', 'DefaultFolder.png', path=videoPlayListUrl) # + '|' + 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        listItem.setInfo(type='Video', infoLabels={ "Title": urllib.unquote(name)})
        listItem.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    else:
        print errort[0]
        dialog = xbmcgui.Dialog()
        dialog.ok("error", errort[0])
        
params = getParams(sys.argv[2])
url=None
name=None
mode=None
module=None
page=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        module=urllib.unquote_plus(params["module"])
except:
        pass
try:
        page=urllib.unquote_plus(params["page"])
except:
        pass
    
if mode==None or url==None or len(url)<1:
        CATEGORIES()

elif mode == 1:
        MOVIES(url, name)

elif mode == 2:
        PLAY_MOVIE(url, name)
        
else:
        manager = getattr(__import__('module_' + module.lower()), 'manager_' + module)()
        manager.work(mode, url, name, page)

xbmcplugin.setPluginFanart(int(sys.argv[1]),xbmc.translatePath( os.path.join( __PLUGIN_PATH__,"fanart.jpg") ))
xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
