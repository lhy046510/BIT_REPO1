# -*- coding: utf-8 -*-

'''
Created on 15/01/2012

@author: shai
'''

def decrypt(secret, k1, k2):
    tobin = hex2bin(secret)
    length = len(tobin) * 2
    keys = []
    index = 0

    while (index < length * 1.5):
        k1 = ((int(k1) * 82) + 84669) % 48779 
        k2 = ((int(k2) * 32) + 65598) % 115498
        keys.append((int(k1) + int(k2)) % (length / 2))
        index += 1

    index = length

    while (index >= 0):
        val1 = keys[index]
        mod = index % (length / 2)
        val2 = tobin[val1]
        tobin[val1] = tobin[mod]
        tobin[mod] = val2
        index -= 1

    index = 0

    while(index < (length / 2)):
        tobin[index] = int(tobin[index]) ^ int(keys[index + length]) & 1
        index += 1
        decrypted = bin2hex(tobin)
    
    return decrypted

def hex2bin(val):
    bin_array = []
    string = dobin(int(val, 16))[2:].zfill(128)
    for value in string:
        bin_array.append(value)
    return bin_array

def bin2hex(val):
    string = str("")
    for char in val:
        string += str(char)
    return "%x" % int(string, 2)

def dobin(x):
    if x < 0: 
        return '-' + dobin(-x)
    out = []
    if x == 0: 
        out.append('0')
    while x > 0:
        out.append('01'[x & 1])
        x >>= 1
        pass
    try: 
        return '0b' + ''.join(reversed(out))
    except NameError, ne2: 
        out.reverse()
    return '0b' + ''.join(out)