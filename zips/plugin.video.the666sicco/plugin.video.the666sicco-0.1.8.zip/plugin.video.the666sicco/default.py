'''
    The 666 Sicco (http://www.666sicco.hostingsiteforfree.com/) XBMC Plugin
    Copyright (C) 2013 the-one

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.		
'''

import os
import string
import sys
import re
import urlresolver
import xbmc, xbmcaddon, xbmcplugin, xbmcgui

from t0mm0.common.addon import Addon
from t0mm0.common.net import Net

addon_id = 'plugin.video.the666sicco'
addon = Addon(addon_id, sys.argv)

net = Net()

BASEURL = addon.get_setting("srcweb")

#PATHS
AddonPath = addon.get_path()

from universal import watchhistory

main_menu_items = [ 
    ('Moto-GP 2013', 'motogp2013.htm'),
    ('Formula-One 2013', 'formula2013.htm' ),
    ('World Superbike 2013', 'sbk2013.htm'),
    ('British Superbike 2013', 'bsb2013.htm')
    ]

play = addon.queries.get('play', '')    
mode = addon.queries['mode']
url = addon.queries.get('url', '')
title = addon.queries.get('title', '')
img = addon.queries.get('img', '')
typ = addon.queries.get('type', '')
name = addon.queries.get('name', '')
iswatchhistory = addon.queries.get('watchhistory', '')
queued = addon.queries.get('queued', '')

def WatchedCallback():
    print 'Video completed successfully.'
    
def unescape(text):
        try:            
            rep = {"&nbsp;": " ",
                   "\n": "",
                   "\t": "",   
                   "%3a": ":",
                   "%3A":":",
                   "%2f":"/",
                   "%2F":"/",
                   "%3f":"?",
                   "%3F":"?",
                   "%26":"&",
                   "%3d":"=",
                   "%3D":"=",
                   "%2C":",",
                   "%2c":","
                   }
            for s, r in rep.items():
                text = text.replace(s, r)
				
            # remove html comments
            text = re.sub(r"<!--.+?-->", "", text)    
				
        except TypeError:
            pass

        return text



def MainMenu():
    
    content = net.http_GET(BASEURL).content    
    content = unescape(content)
    content = addon.unescape(content)
    
    for item in re.finditer(r"<a.*?href=\"([0-9a-zA-Z]+?\.htm)\".*?>(.+?)</a>", content):
        item_ttl = re.sub(r"<.+?>", "", item.group(2))
        item_url = item.group(1)
        addon.add_directory({'mode': 'browse', 'title': item_ttl, 'url' : BASEURL + item_url }, {'title': item_ttl})       
        
def Browse(url):    
    
    content = net.http_GET(url).content
    content = content.decode('utf8', 'ignore')
    content = addon.unescape(content)
    content = unescape(content)
    
    for item in re.finditer(r"<a.*?href=\"(http://adf.ly/[0-9a-zA-Z]+?)\".*?>(.+?)</a>", content):
        item_ttl = re.sub(r"<.+?>", "", item.group(2))
        item_url = item.group(1)
        
        queries = {'play': 'true', 'title': item_ttl, 'url' : item_url, 'type' : title }
        contextMenuItems = []
        from universal import playbackengine    
        contextMenuItems.insert(0, ('Queue Item', playbackengine.QueueItem(addon_id, item_ttl, addon.build_plugin_url( queries ) ) ) )
        
        addon.add_directory(queries, {'title': item_ttl}, contextMenuItems, context_replace=False)   

def Play(url):    

    from universal import playbackengine
    
    if queued == 'true':
        
        adfly_url = url
        print adfly_url
        content = net.http_GET(adfly_url).content
        
        encoded_url = re.compile("var ysmm = '(.+?)';").findall(content)[0]
        encoded_url_length = len(encoded_url)
        encdd_url_part_1 = ''
        encdd_url_part_2 = ''
        for x in range(0, encoded_url_length):
            enc_char = encoded_url[x]
            if not re.match("[a-zA-Z0-9\+/=]", enc_char):
                break;
            if x % 2 == 0:
                encdd_url_part_1 = encdd_url_part_1 + enc_char
            else:
                encdd_url_part_2 = enc_char + encdd_url_part_2
        encoded_url = encdd_url_part_1 + encdd_url_part_2
        import base64
        googledocs_url = (base64.b64decode(encoded_url))[2:]        
        print googledocs_url
            
        stream_qltys = []
        stream_urls = []
        
        stream_content = net.http_GET(googledocs_url).content    
        streams_map = re.search(r"url_encoded_fmt_stream_map\":\"(.+?),\"", stream_content)
        if streams_map:
            streams_map = streams_map.group(1).decode('unicode_escape')            
            print streams_map
            for stream in re.finditer(r"url=(.+?)&type=.+?&quality=(.+?)[,\"]{1}", streams_map):
                stream_url = stream.group(1).decode()
                stream_url = unescape(stream_url)
                print stream_url
                stream_qlty = stream.group(2).upper()
                if (stream_qlty == 'HD720'):
                    stream_qlty = 'HD-720p'
                elif (stream_qlty == 'LARGE'):
                    stream_qlty = 'SD-480p'
                elif (stream_qlty == 'MEDIUM'):
                    stream_qlty = 'SD-360p'
                    
                stream_qltys.append(stream_qlty)
                stream_urls.append(stream_url)
                
            dialog = xbmcgui.Dialog()
            index = dialog.select('Select Video Quality', stream_qltys)
            
            if index >= 0:
        
                player = playbackengine.Play(resolved_url=stream_urls[index], addon_id=addon_id, video_type='the666sicco', 
                                        title=title,season='', episode='', year='', watchedCallback=WatchedCallback)
                
                '''
                add to watch history - start
                '''    
                wh = watchhistory.WatchHistory(addon_id)

                wh.add_video_item(title, sys.argv[0]+sys.argv[2], img=img, is_playable=True)
                
                '''
                add to watch history - end
                '''                
                
                player.KeepAlive()

    else:
        playbackengine.PlayInPL(title, img=img)

if play:
    Play(url)
        
if mode == 'main': 
    MainMenu()
elif mode == 'browse':
    Browse(url)
elif mode == 'links':
    GetLinks(url)
elif mode == 'universalsettings':    
    from universal import _common
    _common.addon.show_settings()

if not play and mode != 'universalsettings':
    addon.end_of_directory()