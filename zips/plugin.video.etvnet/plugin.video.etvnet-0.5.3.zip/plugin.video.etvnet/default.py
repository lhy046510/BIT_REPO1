import sys, xbmc, xbmcaddon, xbmcgui, xbmcplugin, urllib2, urllib, re, string,  os, traceback, cookielib, time, datetime, shutil
from urllib2 import HTTPRedirectHandler, build_opener
from xml.dom.minidom import parseString
# -*- coding: utf-8 -*-

# (c) Copyright by Dmitry Kozmenko linspb@gmail.com for etvnet.com 2010-2011
# Thanks:
# 	Vlad B email2vlad@gmail.com
# http://linspb.us/python/XBMC/
# http://etvnet.com
# http://xbmc.org


__version__ = "0.5.3"
__plugin__ = "etvnet-" + __version__
__author__ = "linspb@gmail.com"
__svn_url__ = ""
__settings__ = xbmcaddon.Addon(id='plugin.video.etvnet')
__dbg__ = __settings__.getSetting( "debug" ) == "true"
__lc__ = ""

Addon = xbmcaddon.Addon(id='plugin.video.etvnet')
APIURL = 'http://etvnet.com/api/v2.0/'


def getNodeValue(node, tag):
	if node.getElementsByTagName(tag).item(0):
		if node.getElementsByTagName(tag).item(0).firstChild:
			if node.getElementsByTagName(tag).item(0).firstChild.nodeValue:
				return node.getElementsByTagName(tag).item(0).firstChild.nodeValue.encode("utf-8")
			else:
				return node.getElementsByTagName(tag).item(0).firstChild.nodeValue
				
def cleanDateTime (dt):
	newdt = re.compile('^(\d{4})-(\d{2})-(\d{2}).{1}(\d{2}:\d{2})').findall(dt)
	if newdt:
		dt = newdt[0][0] + "/" + newdt[0][1] + "/" + newdt[0][2] + " " + newdt[0][3]
	return dt


def login ():
	uname = __settings__.getSetting( "username" )
	passwd = __settings__.getSetting( "password" )

	if ( uname == "" or passwd == "" ):
		__settings__.openSettings()
		uname = __settings__.getSetting( "username" )
		passwd = __settings__.getSetting( "password" )

	if ( uname == "" or passwd == "" ):
		dialog = xbmcgui.Dialog()
 		dialog.ok('Error', 'You must input login and password!')
		return 0
			
	print "try login: username=" + uname + ", passwd=" + passwd
	data = urllib.urlencode({'username': uname, 'password': passwd})
		
	cj = cookielib.LWPCookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	urllib2.install_opener(opener)	
		
	try:
		con = urllib2.urlopen(APIURL + 'session.xml',data)
		xml = con.read()
		con.close()
		
		#print "XML: " + xml
		dom = parseString(xml)
		dom.normalize()

		sid = getNodeValue(dom, 'sessid')
		__settings__.setSetting( 'sessid', sid )
	
	except urllib2.HTTPError, e:
		err = str(e)
		if '401' in err:
			dialog = xbmcgui.Dialog()
   			dialog.ok('Error', 'Username or password is wrong!')
			__settings__.openSettings()
			return (0);
		if '503' in err:
			dialog = xbmcgui.Dialog()
   			dialog.ok('Error', 'Too many logins!\nPlease try again later!')
			return (0);
		dialog = xbmcgui.Dialog()
 		dialog.ok('Error', "HTTP ERR: " + err)
	except:
		dialog = xbmcgui.Dialog()
 		dialog.ok('Error', "Unknown error :(")
		return (0)
		
	print "sessid set: " + __settings__.getSetting( 'sessid' )
	return (1)
	

def vCache (url, timeout = 1, xml = ''):
	if 'watch' in url:
		return ''

	cachenable = __settings__.getSetting( "cachenable" )
	if not cachenable:
		return ''
	
	cache = os.path.join( xbmc.translatePath( "special://profile/" ), "addon_data", os.path.basename( Addon.getAddonInfo('path')),  "cache", url )
	cache_path = os.path.dirname(cache)
	
	cache.replace ( '\&', '_' )
	cache.replace ( '\?', '_' )
	
	if ( not os.path.isdir( cache_path ) ):
		os.makedirs(cache_path)
		
	if xml == '':
		try:
			date = os.path.getmtime( cache )
			if ( time.time() - ( timeout * 60 * 60 ) ) < date:
				file_object = open ( cache, "r")
				data = file_object.read()
				file_object.close()
				print "Return cache data " + url
				return data
		except:
			return ''
		return ''
		
	else:
		try:
			file_object = open( cache, "w" )
			file_object.write( xml )
			file_object.close()
		except:
			return ''
			    
	return ''
	
		
def get_page (url, type = 'xml', chlogin = 0):
	if type == 'xml':
		cache = vCache (url, 1)
		if not cache == '':
			return cache 
		
	cj = cookielib.LWPCookieJar()
	opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
	if type == 'xml':
		opener.addheaders = [ ("User-agent", "Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10.6; ru; rv:1.9.2.10) Gecko/20100914 Firefox/3.6.10"), 
	                      	  ( "Referer", "http://etvnet.com") ]

	sid =  __settings__.getSetting( 'sessid' )
	opener.addheaders.append(("Cookie", "sessid=" + sid))

	urllib2.install_opener(opener)	

	try:
		dataurl = url
		if ( type == 'xml' ):
			dataurl = APIURL + url
		con = urllib2.urlopen ( dataurl )
		data = con.read()
		con.close()
	
	except urllib2.HTTPError, e:
		err = str(e)
		if '404' in err:
			print "Skip 404 error :("
			return
		if '401' in err:
			print "Try to autologin to eTVnet"
			if login() == 0:
				login()
			if chlogin == 0:
				return get_page (url, type, 1)
			return
		if '503' in err:
			dialog = xbmcgui.Dialog()
   			dialog.ok('Error', 'Too many logins!\nPlease try again later!')
			return (0);
		dialog = xbmcgui.Dialog()
 		dialog.ok('Error', "HTTP ERR: " + err)
	except:	
		if chlogin == 0:
			return get_page (url,type,1)
		return
	
	if type == 'html':
		ri = [ '\n', '\r', '\t', '&nbsp;', '    ', '   ', '  ' ]
		for r in ri:
			data = data.replace ( r, ' ' )
		data = data.replace ( '> ', '>' )
		data = data.replace ( ' <', '<' )
		data = data.replace ( '&quot;', '\'' )
		
	if type == 'xml':
		vCache (url,1, data)
		
	return data


def getthumbnailImage (path):
	try:
		data = get_page (path)
		if not '<children></children>' in data:
			return "DefaultFolder.png"
		image = re.findall("<screenshots_path>(.*?)</screenshots_path>", data)[0]
		return image + 'b01.jpg'
	except:
		print "Unknown error"
	return "DefaultFolder.png"
	

def addmenu (name, url, icon, thumbnail = ''):
	print "Name: " + name + ", url: " + url + ", icon: " + icon
	commands = []
	commands.append(( Addon.getLocalizedString( 30051 ).encode('utf_8'), "XBMC.Action(Info)", ))
	commands.append(( Addon.getLocalizedString( 30052 ).encode('utf_8'), "XBMC.RunScript(...)", ))
	commands.append(( Addon.getLocalizedString( 30053 ).encode('utf_8'), "XBMC.RunScript(...)", ))
	commands.append(( Addon.getLocalizedString( 30054 ).encode('utf_8'), "XBMC.RunScript(...)", ))
	liz = xbmcgui.ListItem(name, iconImage = icon, thumbnailImage = thumbnail)
	liz.addContextMenuItems( commands, 1 )
	xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = "%s?%s" % (sys.argv[0], url), listitem = liz, isFolder = 1)
  

def MainMenu ():
	addmenu ( Addon.getLocalizedString( 30001 ).encode('utf_8'), 'action=recomendation', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30002 ).encode('utf_8'), 'action=url&path=media/bookmarks.xml', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30003 ).encode('utf_8'), 'action=search', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30004 ).encode('utf_8'), 'action=url&path=catalog/xml', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30005 ).encode('utf_8'), 'action=url&path=channel_list.xml&show=channel', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30006 ).encode('utf_8'), 'action=url&path=channel_list.xml', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30007 ).encode('utf_8'), 'action=persons', "DefaultFolder.png")	
	addmenu ( Addon.getLocalizedString( 30008 ).encode('utf_8'), 'action=online', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30009 ).encode('utf_8'), 'action=settings', "DefaultFolder.png")
	addmenu ( Addon.getLocalizedString( 30010 ).encode('utf_8'), 'action=clearcache', "DefaultFolder.png")
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def SubMenu (params):
	path = params.get('path') 

	if params.get('page'):
		page = params.get('page')
	
	if params.get('query'):
		query = params.get('query')

	url = path
	if params.get('page'):
		url = url + '?page=' + str (page)
		if params.get('query'):
			url = url + '&q=' + query
	else:
		if params.get('query'):
			url = url + '?q=' + query
	
	print "URL: " + url

	xml = get_page ( url )
	
	try:
		dom = parseString(xml)
		dom.normalize()
	except:
		print "skip"
		 		
	if 'catalog' in url and dom.getElementsByTagName("categories"):
		ccategories = 0
		categories = dom.getElementsByTagName("categories")
		for cnode in categories:
			if cnode.getElementsByTagName("resource"):
				resource = cnode.getElementsByTagName("resource")
				for node in resource:
					name = getNodeValue(node,'name')
					slug = getNodeValue(node,'slug')
					count = getNodeValue(node,'count')
					addmenu (Addon.getLocalizedString( 30201 ).encode('utf_8') % ( name, count ), 'action=url&path=catalog/' + slug + '.xml', "DefaultFolder.png")
					ccategories = ccategories + 1
		if ccategories > 0:
			xbmcplugin.endOfDirectory(int(sys.argv[1]))	
			return
		 		
	if dom.getElementsByTagName("media"):
		media = dom.getElementsByTagName("media")
		for mnode in media:
			if mnode.getElementsByTagName("bitrates") and getNodeValue(mnode,'id'):
				id = getNodeValue(mnode,'id')
				bitrates = mnode.getElementsByTagName("bitrates")
				playbitnow = 0
				for bitrate in bitrates:
					if bitrate.getElementsByTagName("resource"):
						resource = bitrate.getElementsByTagName("resource")
						for node in resource:
							br = int(node.firstChild.nodeValue.encode("utf-8"))
							if __settings__.getSetting('playnow') == 'true':
								if __settings__.getSetting('playbit') == 'true':
									if br > playbitnow:
										playbitnow = br
								else:
									if br > playbitnow and br < 700:
										playbitnow = br
							else:
								name = Addon.getLocalizedString( 30101 ).encode('utf_8') + ' ' + br + 'Kb'
								addmenu (name, 'action=video&path=media/watch/'+id+'/' + br + '.xml', "DefaultFolder.png")
								name = Addon.getLocalizedString( 30102 ).encode('utf_8') + ' ' + br + 'Kb'
								addmenu (name, 'action=video&path=media/watch/'+id+'/' + br + '.xml&other_server=1', "DefaultFolder.png")
				if playbitnow > 0:
					print "start play id: " + id + ", bit: " + str(playbitnow)
					ShowVideo ( getParameters( 'action=video&path=media/watch/' + id + '/' + str(playbitnow) + '.xml&other_server=1' ) )
				else:
					xbmcplugin.endOfDirectory(int(sys.argv[1]))	
				return		


	if 'channel_list' in path:
		response = dom.getElementsByTagName("resource")
		for node in response:
			name = getNodeValue(node,'name')
			slug = getNodeValue(node,'slug')
			if params.get('show') and params.get('show') == 'channel':
				xml = get_page ('channel/' + slug + '.xml')
				try:
					domtmp = parseString(xml)
					domtmp.normalize()
				except:
					print "Error parse " + slug

				if domtmp.getElementsByTagName("results"):
					resultstmp = domtmp.getElementsByTagName("results")
					for rnodetmp in resultstmp:
						if rnodetmp.getElementsByTagName("resource"):
							resourcetmp = rnodetmp.getElementsByTagName("resource")
							for nodetmp in resourcetmp:
								nametmp= getNodeValue(nodetmp,'name')
								on_air = cleanDateTime(getNodeValue(nodetmp,'on_air'))
								id 	   = getNodeValue(nodetmp,'id')
								title  = on_air + "  " + nametmp + "  '" + name + "'" 
								#icon   = getthumbnailImage ('media/details/' + id + '.xml')
								addmenu (title, 'action=url&path=media/details/' + id + '.xml',"DefaultFolder.png")

								
			else:
				addmenu (name, 'action=url&path=channel/' + slug + '.xml&slug=' + slug, "DefaultFolder.png")
		if params.get('show') and params.get('show') == 'channel':
			#xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_DATE)
			xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
		xbmcplugin.endOfDirectory(int(sys.argv[1]))	
		return		

	if 'bookmarks' in path:
		response = dom.getElementsByTagName("resource")
		for node in response:
			name = getNodeValue(node,'name')
			on_air = cleanDateTime(getNodeValue(node,'on_air'))
			title = on_air + " " + name
			id = getNodeValue(node,'id')
			icon = getthumbnailImage ('media/details/' + id + '.xml')
			addmenu (title, 'action=url&path=media/details/' + id + '.xml', icon)
		xbmcplugin.endOfDirectory(int(sys.argv[1]))	
		return		

	totalpages = 1
	if dom.getElementsByTagName("page_info"):
		page_info = dom.getElementsByTagName("page_info")
		for node in page_info:
			totalpages = getNodeValue(node,'total')	
		
	if dom.getElementsByTagName("categories") and params.get('slug'):
		categories = dom.getElementsByTagName("categories")
		for cnode in categories:
			if cnode.getElementsByTagName("resource"):
				resource = cnode.getElementsByTagName("resource")
				for node in resource:
					name = getNodeValue(node,'name')
					slug = getNodeValue(node,'slug')
					addmenu (name, 'action=url&path=channel/' + params.get('slug') + '/' + slug + '.xml', "DefaultFolder.png")

	num = 0
	
	if dom.getElementsByTagName("results"):
		results = dom.getElementsByTagName("results")
		for rnode in results:
			if rnode.getElementsByTagName("resource"):
				resource = rnode.getElementsByTagName("resource")
				for node in resource:
					if getNodeValue(node,'name'):
						name = getNodeValue(node,'name')
						on_air = cleanDateTime(getNodeValue(node,'on_air'))
						title = on_air + " " + name
						id = getNodeValue(node,'id')
						icon = getthumbnailImage ('media/details/' + id + '.xml')
						addmenu (title, 'action=url&path=media/details/' + id + '.xml', icon)
						num = num + 1

	if dom.getElementsByTagName("children"):
		childrenn = dom.getElementsByTagName("children")
		for cnode in childrenn:
			if cnode.getElementsByTagName("resource"):
				resource = cnode.getElementsByTagName("resource")
				for node in resource:
					name = getNodeValue(node,'name')
					on_air = cleanDateTime(getNodeValue(node,'on_air'))
					title = on_air + " " + name
					id = getNodeValue(node,'id')
					icon = getthumbnailImage ('media/details/' + id + '.xml')
					addmenu (title, 'action=url&path=media/details/' + id + '.xml', icon)
					num = num + 1
					
					
	if num > 29:
		req = path
		if params.get('page'):
			page = params.get('page')
		else:
			page = 1
		req = req + '&page=' + str ( int(page) + 1)
		if params.get('query'):
			req = req + '&query=' + query

		addmenu ('>>>', 'action=url&path=' + req, 'DefaultFolder.png')
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	


def RecomendationMenu(param):
	html = get_page ('http://etvnet.com/','html')
	newhtml = re.compile('<div id="myImageFlow" class="imageflow">(.*?)</div>').findall(html)[0]
	if newhtml:
		items = re.compile('<img src="(.*?)" longdesc=".*?/(\d+)/" width="\d+" height="\d+" alt=".*?" title="(.*?)" />').findall(newhtml)
		if items:
			for item in items:
				title = item[2]
				title = title.replace ( ' - eTVnet', '' )
				addmenu (title, 'action=url&path=media/details/' + item[1] + '.xml', item[0])
	xbmcplugin.endOfDirectory(int(sys.argv[1]))	
	return

class SmartRedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
	links = re.findall("Location: (.*)", str(headers))
	if links:
	    for link in links:
		__settings__.setSetting( 'online', link )
	result = urllib2.HTTPRedirectHandler.http_error_301( self, req, fp, code, msg, headers)
	result.status = code
	return result

    def http_error_302(self, req, fp, code, msg, headers):
	links = re.findall("Location: (.*)", str(headers))
	if links:
	    for link in links:
		__settings__.setSetting( 'online', link )
	result = urllib2.HTTPRedirectHandler.http_error_302( self, req, fp, code, msg, headers)
	result.status = code
	return result


def OnlineRedirect ( url ):
    cj = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

    try:
	request = urllib2.Request('http://etvnet.com' + url)
	opener = urllib2.build_opener(SmartRedirectHandler())
	sid =  __settings__.getSetting( 'sessid' )
	opener.addheaders.append(("Cookie", "sessid=" + sid))
	opener.open(request)
    except:
	print ""

    return

def OnlineMenu(params):
	if params.get('ch'):
		playList = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
		playList.clear()
		listitem = xbmcgui.ListItem('eTVnet')
		ch = params.get('ch')
		if '30399' in ch:
		    playList.add('http://stream4.radiostyle.ru:8004/rmc',listitem) 
		else:
		    link = Addon.getLocalizedString( int(ch)+100 ).encode('utf_8');
		    print "LINK: " + link
		    OnlineRedirect ( link )
		    link =  __settings__.getSetting( 'online' )
		    print "LINK: " + link
		    playList.add(link,listitem) 
		xbmc.Player().play(playList)
		return
					
	for n in range(30301, 30315):
		liz = xbmcgui.ListItem ( Addon.getLocalizedString( n ).encode('utf_8'), iconImage = "DefaultVideo.png" )
 		xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = sys.argv[0] + "?action=online&ch=" + str(n), listitem = liz, isFolder = 1)
 	
	liz = xbmcgui.ListItem ( Addon.getLocalizedString( 30399 ).encode('utf_8'), iconImage = "DefaultVideo.png")
 	xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = sys.argv[0] + "?action=online&ch=30399", listitem = liz, isFolder = 1)

 	xbmcplugin.endOfDirectory(int(sys.argv[1]))	


def ShowVideo(params):
	path = params.get('path')
	print "VP: " + path	
	xml = get_page (path)
	#print xml
	try:
		dom = parseString(xml)
		dom.normalize()
	except:
		dialog = xbmcgui.Dialog()
 		dialog.ok('Error', "XML Parse error!")
 		return

	try:
		playList = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
		playList.clear()
		#m_dvdPlayerVideo.SetMaxDataSize(64*1024*1024)
		listitem = xbmcgui.ListItem('eTVnet')
		if dom.getElementsByTagName("response"):
			response = dom.getElementsByTagName("response")
			for node in response:
				url = getNodeValue(node,'url')
				print "Add original url: " + url
				playList.add(url,listitem) 
		xbmc.Player().play(playList)
	except:
 		return

def getKeyboard(default = '', heading = '', hidden = False):
	kboard = xbmc.Keyboard(default, heading, hidden)
	kboard.doModal()
	if kboard.isConfirmed():
		return urllib.quote_plus(kboard.getText())
	return ''    


def SearchMenu ( params ):
	#search
	if params.get('str'):
		print "find: " + params.get('str')
		return
		
	if params.get('act'):
		act = params.get('act')
		if ( act == 'search' ):
			search_phrase = ''
			search_phrase = getKeyboard(heading = Addon.getLocalizedString( 30003 ).encode('utf_8'))
			if search_phrase == '':
				return -1
			searched = search_phrase
			if __settings__.getSetting( "search" ) and __settings__.getSetting( "search" ) != '':
				searched = __settings__.getSetting( "search" ) + ',' + search_phrase
			__settings__.setSetting( "search", searched )
		if ( act == 'clean' ):
			__settings__.setSetting( "search", '' )
			
	addmenu (Addon.getLocalizedString( 30020 ).encode('utf_8'), 'action=search&act=search', "DefaultFolder.png")
	addmenu (Addon.getLocalizedString( 30021 ).encode('utf_8'), 'action=search&act=clean', "DefaultFolder.png")
	
	searchfor = __settings__.getSetting( "search" )
	searchf = searchfor.split(',')
	for searchstr in searchf:
		addmenu ( '> ' + searchstr, 'action=url&path=media/search.xml&query=' + searchstr, "DefaultFolder.png")
	
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	
	return

def Persons ( params ):
	if params.get ('url'):
		data = get_page ( 'http://etvnet.com' + params.get ('url'), 'html' )
		#result = re.compile('<li><a href="/tv/.*?/(\d*)/">(.*?)</a>(.*?)</li>').findall(data)
		result = re.compile('<td width="50%"><a href=\'(/tv/.*?/\d*/)\'>(.*?)</a>(.*?)</td>').findall(data)
		for r in result:
			addmenu (r[1] + ' ' + r[2], 'action=url&path=media/details/' + r[0] + '.xml', "DefaultFolder.png" )
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		return

	if not params.get ('first_letter'):
		letters = Addon.getLocalizedString( 30901 ).encode('utf_8')
		ll = letters.split(',')
		for l in ll:
			addmenu (l, 'action=persons&first_letter=' + l, "DefaultFolder.png")
		xbmcplugin.endOfDirectory(int(sys.argv[1]))
		return

	l = params.get ('first_letter')
	p = 1
	n = 1
	
	while n:
		data = get_page ( 'http://etvnet.com/encyclopedia/c/person/?page=' + str(p) + '&sort=simple_name&first_letter=' + l + '&dir=asc', 'html' )

		#result = re.compile('<a href="([^"]*)"><img src="([^"]*)" title="([^"]*)" width="[0-9]+" height="[0-9]+" border="0"/><span>[^<]*</span></a>').findall(data)
		result = re.compile('<img class="picture_small" src="([^"]+)" width="[0-9]+" height="[0-9]+" border="[0-9]+"/></a></span>[^<]*<center><span style="[^"]+"><a href=\'([^\']+)\' title="([^"]+)"').findall(data)
		n = 0

		if result:
			n = 1
			for r in result:
				addmenu (r[2], 'action=persons&url=' + r[1], "DefaultFolder.png", r[0] )
		
		p += 1
		
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
	return


def ClearCache ():
	try:
		cache = os.path.join( xbmc.translatePath( "special://profile/" ), "addon_data", os.path.basename( Addon.getAddonInfo('path')),  "cache", '' )
		cache_path = os.path.dirname(cache)
		shutil.rmtree(cache_path)
	except:
		return ''
	
	return ''


# - Main	
def getParameters(parameterString):
	commands = {}
	splitCommands = parameterString[parameterString.find('?')+1:].split('&')
	for command in splitCommands: 
		if (len(command) > 0):
			splitCommand = command.split('=')
			name = splitCommand[0]
			value = splitCommand[1]
			commands[name] = value
	return commands
		
if (__name__ == "__main__" ):
    if __dbg__:
        print __plugin__ + " ARGV: " + repr(sys.argv)
    else:
        print __plugin__

        
    if (not sys.argv[2]):
        MainMenu()
    else:
    	params = getParameters(sys.argv[2])
        action = params.get('action')
        
        print "Action: " + action
        
    	if (action == "online" ):
        	OnlineMenu(params)
        	
    	if (action == "recomendation" ):
        	RecomendationMenu(params)
        	
    	if (action == "search" ):
        	SearchMenu(params)
        	
    	if (action == "settings" ):
        	__settings__.openSettings()
    	
    	if (action == "url" ):
			SubMenu (params)    	

    	if (action == "video" ):
			ShowVideo (params)    	

    	if ( action == "persons" ):
			Persons ( params )	

    	if ( action == "clearcache" ):
			ClearCache ()

