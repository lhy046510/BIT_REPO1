import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon
import os,base64,time
# -*- coding: iso-8859-9 -*- happyfeets

__settings__ = xbmcaddon.Addon(id='plugin.video.happyfeetsyetiskin')
__language__ = __settings__.getLocalizedString
home = __settings__.getAddonInfo('path')
folders = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(folders)
import xbmctools
l_check=xbmctools.inside()
if l_check:
        pass
else:
        xbmctools.hata()
        sys.exit()

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

urll='aHR0cDovL3d3dy5wYXJhZGlzZWhpbGwudHY='
urlll='aHR0cDovL3d3dy5wYXJhZGlzZWhpbGwudHYvZW4vPw=='

def CATEGORIES():
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(1)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        par='aHR0cDovL3d3dy5wYXJhZGlzZWhpbGwudHYvZW4v'      
        addDir('[COLOR red][B]~~ Son Eklenen Filmler ~~[/B][/COLOR]',(base64.b64decode(par)),1,'http://25.media.tumblr.com/ff46e694d9aac78f7d19d247b253310d/tumblr_mui5960h9L1saar67o1_500.jpg')
        ##addDir('[COLOR pink]~~ { Hizlica Kategorilere Goz At  } ~~[/COLOR]',(base64.b64decode(par)),3,'http://www.wmmr.com/Pics/PhotoAlbums/100003/4/PICT0041__900W.Jpeg')
        link=get_url(base64.b64decode(par))
        match=re.compile('<div class="cat_item ccc">\n\t\t\t\t<div class="item_zag clz">\n\t\t\t\t\t<a href=".*?" title=".*?">.*?</a>\n\t\t\t\t</div>\n\t\t\t\t<div class="item_img">\n\t\t\t\t\t<a href="(.*?)" title=".*?">\n\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)">\n\t\t\t\t\t').findall(link)
        for url,thumbnail,name in match:
                url=(base64.b64decode(urll))+url                
                addDir('[COLOR orange][B]>> [COLOR lightblue]'+name+'[/B][/COLOR]',url,4,thumbnail) 

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/230008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb1',"i").replace('\xc3\xb6',"O").replace('\xc3\xbc',"u").replace('\xc5\x9f',"s").replace('\xc3\xa7',"c").replace('\xe2\x80\x93',"").replace('\xc4\xb0',"i").replace('&#8211;'," ").replace('&#8211;'," ").replace('\xc5\x9e',"S")#.replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        return link

def RECENT(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(1)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?">\n\t\t\t\t\t<img src="(.*?)" alt="(.*?)">').findall(link)
        for url,thumbnail,name in match: 
            url=(base64.b64decode(urll))+url            
            addDir('[COLOR orange][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]',url,41,thumbnail)

        sayfalama=re.compile('\n<li><a href="\?(.*?)">(.*?)</a>').findall(link)
        for url,name in sayfalama:
            url=(base64.b64decode(urlll))+url            
            addDir('[COLOR purple][B]>>SAYFA-' +name+'[/B][/COLOR]',url,1,'')

def kategoriler(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(1)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('<div class="cat_item ccc">\n\t\t\t\t<div class="item_zag clz">\n\t\t\t\t\t<a href=".*?" title=".*?">.*?</a>\n\t\t\t\t</div>\n\t\t\t\t<div class="item_img">\n\t\t\t\t\t<a href="(.*?)" title=".*?">\n\t\t\t\t\t\t<img src="(.*?)" alt="(.*?)">\n\t\t\t\t\t').findall(link)
        for url,thumbnail,name in match:
                url=(base64.b64decode(urll))+url                
                addDir('[COLOR orange][B]>>'+name+'[/B][/COLOR]',url,4,thumbnail) 

def kategoriicrerik(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(1)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=get_url(url)
        match=re.compile('\n\t<div class=".*?">\n\t\t<a href="(.*?)" title=".*?">\n\t\t\t<img src="(.*?)" alt="(.*?)">\n\t\t').findall(link)
        for url,thumbnail,name in match:
                url=(base64.b64decode(urll))+url
                addDir('[COLOR orange][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]',url,41,thumbnail)

def ayrisdirma(url):
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(1)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
                epname='part '
                a=0
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()        
                response.close()
                match=re.compile('var films\= "http:\/\/(.*?).flv"').findall(link)
                for url in match:
                        url='http://'+url+'.flv'
                        a= a+1
                        name = epname + ' - '+str(a)
                        #name=name.replace('Part - 1','Tek Part')
                        addDir(name,url,44,'http://37.media.tumblr.com/tumblr_lwfl86OrzK1qg7sdjo1_500.jpg')

##                epname='part '
##                a=0
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()        
                response.close()
                match1=re.compile("http:\/\/(.*?).mp4").findall(link)
                for url in match1:
                        url='http://'+url+'.mp4'
                        a= a+1
                        name = epname + ' - '+str(a)
                        #name=' Server 2 >>'
                        addDir('[COLOR blue][B]>> [COLOR lightblue]Server 2 >> [COLOR lightgreene]'+name+' [/B][/COLOR]',url,44,'http://37.media.tumblr.com/f8b15f5d445ad8e6566577a641de0a9a/tumblr_mnhaumEio61rdlwjwo1_500.jpg')

def VIDEOLINKS(name,url):#44
        import time
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=get_url(base64.b64decode(web))
        time.sleep(1)
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul

        playList.clear()
        addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        CATEGORIES()
       
elif mode==1:
        
        RECENT(url)

elif mode==4:
        
        kategoriicrerik(url)

elif mode==3:
        
        kategoriler(url)

elif mode==7:
        
        VideoLinks(url)

elif mode==41:
        
        ayrisdirma(url)

elif mode==42:
        feleve(url)

elif mode==44:
        VIDEOLINKS(name,url)
        
xbmcplugin.endOfDirectory(int(sys.argv[1]))
