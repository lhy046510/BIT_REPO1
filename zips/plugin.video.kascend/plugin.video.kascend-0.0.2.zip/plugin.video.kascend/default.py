# -*- coding: utf-8 -*-
# default.py
from __future__ import division
import urllib,urllib2,re,xbmcplugin,xbmcgui,subprocess,sys,os,os.path,xbmcaddon,datetime
import json,math,hashlib
from xbmcswift2 import Plugin, CLI_MODE, xbmcaddon,ListItem
from xml.etree import ElementTree
from BeautifulSoup import BeautifulSoup,Comment,BeautifulStoneSoup
try:
    from ChineseKeyboard import Keyboard
except:
    from xbmc import Keyboard  
    pass
# Plugin constants 
__addonid__ = "plugin.video.kascend"
__addon__ = xbmcaddon.Addon(id=__addonid__)
__cwd__ = __addon__.getAddonInfo('path')
#直播 http://video.kascend.com:80/osm-video/osmvideo?apksource=203&appkey=LMVideo&ctid=13&hd=2&method=video.subcategoryitems&pcount=50&pnum=1&token=fa25a146-a1b7-4bbe-8f37-f39bb3b777c9&appsig=376a51873cca89bbbde8647cd6ce0ca3
#直播子类 http://video.kascend.com:80/osm-video/osmvideo?apksource=203&appkey=LMVideo&ctid=13&hd=2&method=video.subcategoryitems&pcount=50&pnum=1&subctid=219&token=fa25a146-a1b7-4bbe-8f37-f39bb3b777c9&appsig=0f0a256cc4acedc02874ee73d0e41fa8
UserAgent = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; Trident/6.0)'
plugin = Plugin()
def GetHttpData(url):
    print url
    #UserAgent = ''
    xbmc.executebuiltin("ShowBusyDialog")
    req = urllib2.Request(url)
    req.add_header('User-Agent', UserAgent)
    response = urllib2.urlopen(req)
    httpdata = response.read()
    if response.headers.get('content-encoding', None) == 'gzip':
        httpdata = gzip.GzipFile(fileobj=StringIO.StringIO(httpdata)).read()
    response.close()
    match = re.compile('encodingt=(.+?)"').findall(httpdata)
    if len(match)<=0:
        match = re.compile('meta charset="(.+?)"').findall(httpdata)
    if len(match)>0:
        charset = match[0].lower()
        if (charset != 'utf-8') and (charset != 'utf8'):
            httpdata = unicode(httpdata, charset).encode('utf8')
    xbmc.executebuiltin('HideBusyDialog')
    return httpdata
class RedirectHandler(urllib2.HTTPRedirectHandler):
    def http_error_301(self, req, fp, code, msg, headers):
        pass
    def http_error_302(self, req, fp, code, msg, headers):
        infourl = urllib2.addinfourl(fp, headers, req.get_full_url())
        infourl.status = code
        infourl.code = code
        infourl.headers = headers
        return infourl

def GetHttpData2(url):
    print url
    opener = urllib2.build_opener(RedirectHandler)
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)')
    try:
        response = opener.open(req)
        httpdata = response.headers.get('Location', None)
        response.close()
    except:
        xbmc.log( "%s: %s (%d) [%s]" % (
            "vst",
            sys.exc_info()[ 2 ].tb_frame,
            sys.exc_info()[ 2 ].tb_lineno,
            sys.exc_info()[ 1 ]
            ), level=xbmc.LOGERROR)
        return ''
    return httpdata

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param    
def get_params2(url):
    param = []
    paramstring = url[url.index('?'):len(url)]
    print paramstring
    if len(paramstring) >= 2:
        params = paramstring
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param
def save_cache(type,strs):
	wfile = open(__addon__.getAddonInfo('path')+"/"+type+".txt", 'w') 
	wfile.write(strs)
	wfile.close()


def read_cache(type):
	try:
		wfile = open(__addon__.getAddonInfo('path')+"/"+type+".txt", 'r') 
		strs=wfile.read()
		wfile.close()
	except:
		strs="<?xml version='1.0' encoding='utf-8'?>"+'<response rc="0" update="20100223"></response>'
	return strs

def login():
	link=GetHttpData('http://auth.kascend.com/osm-user/osmuser?method=auth.login&appkey=LMVideo&imei=00000000000000&mac=08002743dd2c&stayTime=0&apksource=203&appsig=2f46e050e72a71d3242f7d520c0b16d8')
	soup=BeautifulStoneSoup(link)
	if soup.response['rc']=="0":
		save_cache("token",soup.response.token.text)
		return True
	else:
		return False

def get_appsig(str):
	app=str.split("&")
	app.sort()
	return hashlib.md5('1275753600000&'+'&'.join(app)).hexdigest().lower()

def rootlist(tokens):
	link=read_cache("category")
	soup=BeautifulStoneSoup(link)
	if int(soup.response['update'])<int(datetime.datetime.strftime(datetime.datetime.now(),"%Y%m%d")):
		url="apksource=203&appkey=LMVideo&ctid=0&hd=2&iconversion=5&method=video.categorylist&token="+tokens+"&updated=0&versioncode=4"
		link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
		soup=BeautifulStoneSoup(link)
		soup.response['update']=datetime.datetime.strftime(datetime.datetime.now(),"%Y%m%d")
		save_cache("category",str(soup))
	for item in soup.response:
		try:
			if item.ctid.text!='23':
				listitem=xbmcgui.ListItem(item.cttitle.text.encode("UTF-8"),thumbnailImage=item.icon['uri'])
				url=sys.argv[0]+"?mode=list&ctid="+str(item.ctid.text.encode("UTF-8"))
				xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
		except:
			pass
	listitem=xbmcgui.ListItem("搜索视频")
	url=sys.argv[0]+"?mode=search"
	xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.endOfDirectory(int(sys.argv[1]))
def get_list(tokens,ctid,page):
	url="apksource=203&appkey=LMVideo&ctid="+ctid+"&hd=1&method=video.subcategoryitems&pcount=50&pnum="+str(page)+"&token="+tokens
	link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
	soup=BeautifulStoneSoup(link)
	if page>1:
		listitem=xbmcgui.ListItem("上一页")
		url=sys.argv[0]+"?mode=list&ctid="+str(ctid)+"&page="+str(page-1)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if soup.response.tagflag.text=='1':
			listitem=xbmcgui.ListItem("淘-片")
			url=sys.argv[0]+"?mode=select&ctid="+str(ctid)
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	for item in soup.findAll('subcategory'):
		try:
			listitem=xbmcgui.ListItem("[子分类] ".decode('UTF-8')+item['subctname'])
			url=sys.argv[0]+"?mode=sublist&ctid="+str(ctid)+"&subctid="+str(item['subctid'])
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
		except:
			pass
	for item in soup.findAll('item'):
		try:
			listitem=xbmcgui.ListItem(item.itemtitle.text.encode('UTF-8'),thumbnailImage=item.itemthumbnail.text)
			if item.itemtype.text=='1':
				url=sys.argv[0]+"?mode=info&itemid="+str(item.itemid.text)
				listitem.setInfo(type = "Video",infoLabels = {'season':int(item.actualnum.text),'rating':float(item.itemscore.text),'plot':item.summary.text,'episode':int(item.actualnum.text),'genre':item.itemdesc.text})
			elif item.itemtype.text=='0':
				url=sys.argv[0]+"?mode=play_video&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
				listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
			elif item.itemtype.text=='3':
				url=sys.argv[0]+"?mode=play_tv&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
				listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
		except:
			pass
	if page*50<int(soup.response.totalcount.text):
		listitem=xbmcgui.ListItem("下一页")
		url=sys.argv[0]+"?mode=list&ctid="+str(ctid)+"&page="+str(page+1)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_sublist(tokens,ctid,subctid,page):
	url="apksource=203&appkey=LMVideo&ctid="+ctid+"&hd=1&method=video.subcategoryitems&pcount=50&pnum="+str(page)+"&token="+tokens
	if subctid!=None:
		url=url+"&subctid="+subctid
	link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
	soup=BeautifulStoneSoup(link)
	if page>1:
		listitem=xbmcgui.ListItem("上一页")
		url=sys.argv[0]+"?mode=sublist&ctid="+str(ctid)+"&page="+str(page-1)+"&subctid="+subctid
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	for item in soup.findAll('item'):
		try:
			listitem=xbmcgui.ListItem(item.itemtitle.text.encode('UTF-8'),thumbnailImage=item.itemthumbnail.text)
			if item.itemtype.text=='1':
				url=sys.argv[0]+"?mode=info&itemid="+str(item.itemid.text)
				listitem.setInfo(type = "Video",infoLabels = {'season':int(item.actualnum.text),'rating':float(item.itemscore.text),'plot':item.summary.text,'episode':int(item.actualnum.text),'genre':item.itemdesc.text})
			elif item.itemtype.text=='0':
				url=sys.argv[0]+"?mode=play_video&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
				listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
			elif item.itemtype.text=='3':
				url=sys.argv[0]+"?mode=play_tv&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
				listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
		except:
			pass
	if page*50<int(soup.response.totalcount.text):
		listitem=xbmcgui.ListItem("下一页")
		url=sys.argv[0]+"?mode=sublist&ctid="+str(ctid)+"&page="+str(page+1)+"&subctid="+subctid
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_info(tokens,itemid,page):
	url="apksource=203&appkey=LMVideo&hotlinecount=-1&itemid="+itemid+"&hd=1&itemtype=1&method=video.iteminfo&onlyvideo=0&pcount=50&pnum="+str(page)+"&token="+tokens
	link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
	soup=BeautifulSoup(link)
	save_cache("video",link)
	if page>1:
		listitem=xbmcgui.ListItem("上一页")
		url=sys.argv[0]+"?mode=info&itemid="+itemid+"&page="+str(page-1)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	rs=BeautifulSoup(re.compile('<subvideos>(.+?)</subvideos>').findall(link)[0])
	for item in rs.findAll('item'):
		try:
			Image=item.itemthumbnail.text
		except:
			Image=''
		listitem=xbmcgui.ListItem(item.itemtitle.text,thumbnailImage=Image)
		url=sys.argv[0]+"?mode=play_link&itemid="+item.itemid.text
		try:
			listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
		except:
			pass
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if page*50 < int(soup.response.item.actualnum.text):
		listitem=xbmcgui.ListItem("下一页")
		url=sys.argv[0]+"?mode=info&itemid="+itemid+"&page="+str(page+1)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def get_play(itemid):
	link=read_cache('video')
	rs=BeautifulSoup(re.compile('<subvideos>(.+?)</subvideos>').findall(link)[0])
	for item in rs.findAll('item'):
		if item.itemid.text==itemid:
			dialog = xbmcgui.Dialog()
			sel=dialog.select("请选择视频源", [i['optionname'] for i in item.findAll('optionsource')])
			if sel>-1:
				x=0
				for i in item.findAll('optionsource'):
					if x==sel:
						get_play_video(i['optionuri'],i['optionid'],item.itemtitle.text.encode('UTF-8'))
						break
					x=x+1
			
def get_play_tv(optionuri,optionname,name):
	listitem = xbmcgui.ListItem(name)
	listitem.setInfo(type="Video", infoLabels={'Title': name})
	xbmc.Player().play(optionuri.replace('&amp;','&'), listitem, 0)

def get_play_video(optionuri,optionname,name):
	if optionname == '1204':
		str1=optionuri.split('/')
		rs=json.loads(GetHttpData("http://api.funshion.com/ajax/get_web_fsp/"+str1[0]+"/MP4"))
		rs=rs['data']['fsps']['mult'][int(str1[1])-1]['hashid']
		rs=json.loads(GetHttpData("http://jobsfe.funshion.com/query/v1/mp4/"+rs+".json?bits=0"))
		get_play_tv(rs['playlist'][0]['urls'][0],optionname,name)
	elif optionname=='1204':
		rs=BeautifulSoup(GetHttpData("http://vv.video.qq.com/geturl?platform=1&ran=0.2838627&otype=xml&format=2&vid="+optionuri))
		get_play_tv(rs.root.vd.vi.url.text,optionname,name)
	elif optionname=='1013':
		rs=BeautifulSoup(GetHttpData("http://www.letv.com/v_xml/"+optionuri+".xml"))
		patch=json.loads(rs.root.playurl.text)
		get_play_tv(patch['dispatch']['720p'][0],optionname,name)
	elif optionname=='1207'.decode('UTF-8') or optionname=="1011":
		rs=json.loads(GetHttpData("http://v.youku.com/player/getPlayList/VideoIDS/"+optionuri))
		get_play_tv("http://v.youku.com/player/getM3U8/vid/"+rs['data'][0]['videoid']+"/type/hd2/sid/00_00/K/00_00/video.m3u8",optionname,name)
	elif optionname=='1023':
		rs=GetHttpData("http://cache.video.qiyi.com/v/"+optionuri)
		url= re.compile('<videoUrl>(.+?)</videoUrl>').findall(rs)[0]
		link=GetHttpData("http://www.verycd.com/api/v2/base/playlink/get_playinfo?platform=android&url="+url+"&version=2")
		rs=json.loads(link)
 		temp = GetHttpData(rs['video_url'])
		vod_sp = temp.split('\n')
		urls=''
		for item in vod_sp:
			if item[0:4]=='http':
				urls = GetHttpData2(item)
				break
		pargm=urls.split('/')
		pargm1=get_params2(urls)
		ukey=pargm1['key']
		uuid=pargm1['uuid']
		ip=pargm[2]
		temp=temp.replace("data.video.iqiyi.com",ip).replace("data.video.qiyi.com",ip).replace("?",'?key='+ukey+'&uuid='+uuid+"&")
		wfile = open(__cwd__+"/b.m3u8", 'w') 
		wfile.write(temp)
		wfile.close() 
		vod_link= __cwd__+"/b.m3u8"
		get_play_tv(vod_link,optionname,name)
	elif optionname=='1015':
		get_play_tv("http://hot.vrs.sohu.com/ipad"+optionuri+".m3u8?plat=6",optionname,name)
	
	elif optionname=='1017':
		rs=BeautifulSoup(read_cache('video'))
		rs=rs.findAll('optionsource',attrs={'optionuri':optionuri})
		weburl=rs[0]['optionweburi']
		rs=GetHttpData(weburl)
		iid=re.compile('"k"\:(.+?),').findall(rs)[0]
		rs=BeautifulSoup(GetHttpData("http://ct.v2.tudou.com/f?id="+iid))
		get_play_tv(rs.f.text+"|User-Agent="+UserAgent,optionname,name)

	elif optionname=='1205':
		rs=json.loads(GetHttpData('http://vxml.56.com/json/'+optionuri+'/?src=site'))
		lists=[]
		for item in rs['info']['rfiles']:
			if item['type']=='super':
				lists.insert(0,item)
			elif item['type']=='clear':
				lists.insert(1,item)
			else:
				lists.append(item)
		get_play_tv(GetHttpData2(lists[0]['url']),optionname,name)
	elif optionname=='1016':
		rs=json.loads(GetHttpData("http://video.sina.com.cn/interface/video_ids/video_ids.php?v="+optionuri))
		rs=GetHttpData2("http://v.iask.com/v_play_ipad.php?vid="+str(rs['ipad_vid']))
		get_play_tv(rs,optionname,name)
	elif optionname=='1202':
		rs=BeautifulSoup(GetHttpData("http://web-play.pptv.com/webplay3-0-"+optionuri+".xml&ft=1&version=4&type=m3u8.web.pad"))
		sh=rs.findAll('dt',attrs={'ft':'1'})
		print sh
		if len(sh)==1:
			ip=sh[0].sh.text
			skey=sh[0].key.text
			file=rs.findAll('item',attrs={'ft':'1'})
			rid=file[0]['rid'][:32]
		else:
			sh=rs.findAll('dt',attrs={'ft':'0'})
			ip=sh[0].sh.text
			skey=sh[0].key.text
			file=rs.findAll('item',attrs={'ft':'0'})
			rid=file[0]['rid'][:32]
		get_play_tv("http://"+ip+"/"+rid+".m3u8?type=m3u8.web.pad&k="+skey,optionname,name)
	else:
		url = "appkey=LMVideo&method=video.getplayurl&sourceid="+optionname+"&videokey="+optionuri
		rs=BeautifulSoup(GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url)))
		if rs.response['rc']=='0':
			get_play_tv(rs.response.source.uri.text,optionname,name)
		
def get_select(tokens,ctid):
	link=read_cache("select"+ctid)
	soup=BeautifulStoneSoup(link)
	if int(soup.response['update'])<int(datetime.datetime.strftime(datetime.datetime.now(),"%Y%m%d")):
		url="apksource=203&appkey=LMVideo&ctid="+ctid+"&hd=1&method=video.categoryfilterlist&token="+tokens
		link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
		soup=BeautifulStoneSoup(link)
		soup.response['update']=datetime.datetime.strftime(datetime.datetime.now(),"%Y%m%d")
		save_cache("select"+ctid,str(soup))
	op=[]
	for item in soup.findAll('tag'):
		dialog = xbmcgui.Dialog()
		sel=dialog.select("请选择"+item['name'].encode('UTF-8'), [i.propertytitle.text.encode('UTF-8') for i in item.findAll('property')])
		i=0
		if sel>-1:
			for x in item.findAll('property'):
				if i==sel:
					op.append(x.propertyid.text)
					break
				i=i+1
	if len(op)>0:
		get_select_list(tokens,ctid,1,','.join(op))

def get_select_list(tokens,ctid,page,op):
	url="apksource=203&appkey=LMVideo&ctid="+ctid+"&method=video.list&hd=1&orderby=updated&pcount=50&pnum=1&property={"+op+"}&token="+tokens
	link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
	soup=BeautifulStoneSoup(link)
	if page>1:
		listitem=xbmcgui.ListItem("上一页")
		url=sys.argv[0]+"?mode=select_list&ctid="+str(ctid)+"&page="+str(page-1)+"&op="+op
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	for item in soup.findAll('item'):
		listitem=xbmcgui.ListItem(item.itemtitle.text.encode('UTF-8'),thumbnailImage=item.itemthumbnail.text)
		if item.itemtype.text=='1':
			url=sys.argv[0]+"?mode=info&itemid="+str(item.itemid.text)
			listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
		elif item.itemtype.text=='0':
			url=sys.argv[0]+"?mode=play_video&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
			listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
		elif item.itemtype.text=='3':
			url=sys.argv[0]+"?mode=play_tv&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
			listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	if page*50<int(soup.response.totalcount.text):
		listitem=xbmcgui.ListItem("下一页")
		url=sys.argv[0]+"?mode=select_list&ctid="+str(ctid)+"&page="+str(page+1)+"&op="+op
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

def searchKey():
    kb = Keyboard('','请输入搜索内容,可用首拼字母搜索')
    kb.doModal()
    if (kb.isConfirmed()):
        keyword = kb.getText()
        if keyword !='':
			u=sys.argv[0]+"?mode=search_list&url="+urllib.quote_plus(keyword)
			xbmc.executebuiltin('Container.Update(%s)' % u)
    else: return
def search_list(tokens,key,page):
	url="apksource=203&method=video.search&keyword="+urllib.quote_plus(key)+"&pnum="+str(page)+"&pcount=50&appkey=LMVideo&token="+tokens
	link=GetHttpData("http://video.kascend.com/osm-video/osmvideo?"+url+"&appsig="+get_appsig(url))
	soup=BeautifulStoneSoup(link)
	if page>1:
		listitem=xbmcgui.ListItem("上一页")
		url=sys.argv[0]+"?mode=search_list&url="+urllib.quote_plus(key)+"&page="+str(page-1)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	for item in soup.findAll('item'):
		try:
			listitem=xbmcgui.ListItem(item.itemtitle.text.encode('UTF-8'),thumbnailImage=item.itemthumbnail.text)
			if item.itemtype.text=='1':
				url=sys.argv[0]+"?mode=info&itemid="+str(item.itemid.text)
				listitem.setInfo(type = "Video",infoLabels = {'season':int(item.actualnum.text),'rating':float(item.itemscore.text),'plot':item.summary.text,'episode':int(item.actualnum.text),'genre':item.itemdesc.text})
			elif item.itemtype.text=='0':
				url=sys.argv[0]+"?mode=play_video&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
				listitem.setInfo(type = "Video",infoLabels = {'genre':item.itemdesc.text})
			elif item.itemtype.text=='3':
				url=sys.argv[0]+"?mode=play_tv&optionuri="+urllib.quote_plus(item.optionsource['optionuri'])+"&optionname="+item.optionsource['optionid']+"&name="+urllib.quote_plus(item.itemtitle.text.encode('UTF-8'))
				listitem.setInfo(type = "Video",infoLabels = {'plot':item.itemdesc.text})
			xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
		except:
			pass
	if page*50<int(soup.response.totalcount.text):
		listitem=xbmcgui.ListItem("下一页")
		url=sys.argv[0]+"?mode=search_list&url="+urllib.quote_plus(key)+"&page="+str(page+1)
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, listitem, True)
	xbmcplugin.setContent(int(sys.argv[1]), 'movies')
	xbmcplugin.endOfDirectory(int(sys.argv[1]))

params = get_params()
mode = None
url = None
name=''
page = 1
ctid='1'
subctid=None
itemid=None
try:
	tokens=read_cache('token')
except:
	tokens='2f243e96-353d-4e3e-8cfd-0fa03936f170'
try:
    mode = params["mode"]
except:
    pass
try:
    page = int(params["page"])
except:
    pass
try:
    url =urllib.unquote_plus( params["url"])
except:
    pass
try:
    name =urllib.unquote_plus( params["name"])
except:
    pass
try:
    ctid =urllib.unquote_plus( params["ctid"])
except:
    pass
try:
    subctid =urllib.unquote_plus( params["subctid"])
except:
    pass
try:
    itemid =urllib.unquote_plus( params["itemid"])
except:
    pass
try:
    optionuri =urllib.unquote_plus( params["optionuri"])
except:
    optionuri=None
try:
    optionname =urllib.unquote_plus( params["optionname"])
except:
    optionname=None
try:
    op =urllib.unquote_plus( params["op"])
except:
    op=None
if mode == None:
	rootlist(tokens)
	#tests()
elif mode == 'list':
	get_list(tokens,ctid,page)
elif mode == 'sublist':
	get_sublist(tokens,ctid,subctid,page)
elif mode == 'info':
	get_info(tokens,itemid,page)
elif mode == "play_link":
	get_play(itemid)
elif mode == "play_tv":
	get_play_tv(optionuri,optionname,name)
elif mode == "play_video":
	get_play_video(optionuri,optionname,name)
elif mode == "select":
	get_select(tokens,ctid)
elif mode == "select_list":
	get_select(tokens,ctid,page,op)
elif mode == "search":
	searchKey()
elif mode == "search_list":
	search_list(tokens,url,page)