#!/usr/bin/python
# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import os
import sys
import shutil
#import time
#import threading
from NicoVideo import NicoVideo
#plugin constants

#__language__ = sys.modules[ "__main__" ].__language__

__settings__ = xbmcaddon.Addon('plugin.video.nico')

__plugin__ = __settings__.getAddonInfo('name')
__author__ = ""
__version__ = __settings__.getAddonInfo('version')
__dbg__ = __settings__.getSetting( "debug" ) == "true"

print sys.version
print "'%s: ver %s' initialized" % (__plugin__, __version__)
base_cache_path = os.path.join( xbmc.translatePath( "special://masterprofile/" ), "addon_data", os.path.basename( __settings__.getAddonInfo('path') ) )

root_dir = __settings__.getAddonInfo('path')
#root_dir = os.getcwd().replace(";","")
print "root_dir=" + root_dir
main_py = os.path.join(root_dir,'NicoMain.py')

#BaseSetting = os.path.join(base_cache_path,"setting.txt")
Favorite = os.path.join(base_cache_path,"favorite.txt")

hisDatDir = os.path.join(base_cache_path,'history')
tbn_dir = os.path.join(base_cache_path,'thumb')
lvtbn_dir = os.path.join(base_cache_path,'lvthumb')
usericon_dir = os.path.join(base_cache_path,'usericon')
chicon_dir = os.path.join(base_cache_path,'chicon')
coicon_dir = os.path.join(base_cache_path,'coicon')
stream_dir = os.path.join(base_cache_path,'stream')
cache_dir = os.path.join(base_cache_path,'cache')
comment_dir = os.path.join(base_cache_path,'comment')
twittericon_dir = os.path.join(base_cache_path,'twittericon')
debug_dir = os.path.join(base_cache_path,'debug')

if __name__ == "__main__":
	MailAddress = __settings__.getSetting("mailaddress")
	PassWord = __settings__.getSetting("password")
	nicoVideo = NicoVideo()
	logincheck = False
	if not MailAddress or not PassWord:
		__settings__.openSettings()
	else:
		nicoVideo.mailAddress = __settings__.getSetting("mailaddress")
		nicoVideo.passWord = __settings__.getSetting("password")
		nicoVideo.force_overwrite = True
		nicoVideo.save_message_xml = True
		nicoVideo.process_list = False
		nicoVideo.root_dir = base_cache_path

		nicoVideo.loadCookie()
		if nicoVideo.isLogin():
			logincheck = True
		else:
			if nicoVideo.loginNicoVideo():
				logincheck = True
			else:
				xbmcgui.Dialog().ok("エラー","ログインに失敗しました！","メールアドレスとパスワードを確認して下さい")
				__settings__.openSettings()

	if not logincheck:
		nicoVideo.mailAddress = __settings__.getSetting("mailaddress")
		nicoVideo.passWord = __settings__.getSetting("password")
		nicoVideo.force_overwrite = True
		nicoVideo.save_message_xml = True
		nicoVideo.process_list = False
		nicoVideo.root_dir = base_cache_path

		nicoVideo.loadCookie()
		if nicoVideo.isLogin():
			logincheck = True
		else:
			if nicoVideo.loginNicoVideo():
				logincheck = True
			else:
				xbmcgui.Dialog().ok("エラー","ログインに失敗しました！","メールアドレスとパスワードを確認して下さい")

	if logincheck:
		if not os.path.exists(hisDatDir):
			os.makedirs(hisDatDir)
		if not os.path.exists(tbn_dir):
			for i in range(1000):
				os.makedirs(os.path.join(tbn_dir,str(i)))
		if not os.path.exists(lvtbn_dir):
			os.makedirs(lvtbn_dir)
		else:
			list = os.listdir(lvtbn_dir)
			for file in list:
				os.remove(os.path.join(lvtbn_dir,file))
		if not os.path.exists(usericon_dir):
			for i in range(1000):
				os.makedirs(os.path.join(usericon_dir,str(i)))
		if not os.path.exists(chicon_dir):
			os.makedirs(chicon_dir)

		if os.path.exists(coicon_dir):
			shutil.rmtree(coicon_dir)

		if not os.path.exists(coicon_dir):
			os.makedirs(coicon_dir)
#			for i in range(1000):
#				os.makedirs(os.path.join(coicon_dir,str(i)))

		if not os.path.exists(stream_dir):
			os.makedirs(stream_dir)
		if not os.path.exists(debug_dir):
			os.makedirs(debug_dir)
		if not os.path.exists(cache_dir):
			os.makedirs(cache_dir)
		if not os.path.exists(comment_dir):
			for i in range(1000):
				os.makedirs(os.path.join(comment_dir,str(i)))
		if not os.path.exists(twittericon_dir):
			os.makedirs(twittericon_dir)
		if not os.path.exists(Favorite):
			file = open(Favorite, 'w')
			try:
				file.write("Category1:ランキング\n")
				file.write("Category2:おすすめ\n")
				file.write("Category3:その他\n")
				file.write("Category4:カテゴリ４\n")
				file.write("Category5:カテゴリ５\n")
				file.write("Category6:カテゴリ６\n")
				file.write("Category7:カテゴリ７\n")
				file.write("Category8:カテゴリ８\n")
				file.write("Category9:カテゴリ９\n")

				file.write('<cate="%s" url="http://www.nicovideo.jp/mylist/%s">%s</tag>\n' %(1,"7077006","週刊ニコニコランキング一覧"))
				file.write('<cate="%s" url="http://www.nicovideo.jp/mylist/%s">%s</tag>\n' %(1,"2995418","月刊ニコニコランキング+α一覧"))
				file.write('<cate="%s" url="http://www.nicovideo.jp/mylist/%s">%s</tag>\n' %(1,"20900385","ニコニコ技術部ランキングシリーズ"))
				file.write('<cate="%s" url="http://www.nicovideo.jp/watch/%s">%s</tag>\n' %(2,"sm12380946","最強動画環境「XBMC for Windows」デモ"))
				file.write('<cate="%s" url="http://www.nicovideo.jp/watch/%s">%s</tag>\n' %(3,"sm9","新・豪血寺一族 -煩悩解放 - レッツゴー！陰陽師"))
			finally:
				file.close()
			xbmcgui.Dialog().ok("","マイリストや動画を登録する favorite.txt を",Favorite,"に作成しました")

		xbmc.executescript(main_py)
#		xbmcplugin.endOfDirectory(handle = 0,succeeded=True)
#		xbmc.executebuiltin('Action(ParentDir)')

sys.modules.clear()