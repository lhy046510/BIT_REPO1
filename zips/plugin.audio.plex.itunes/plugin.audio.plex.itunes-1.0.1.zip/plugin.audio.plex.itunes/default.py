"""
    iTunes Library via Plex Media Server
    maruchan
"""
import sys
import xbmcaddon

__settings__ = xbmcaddon.Addon(id='plugin.audio.plex.itunes')

if __name__ == "__main__":
    import itunes_main
    itunes_main.Main()

sys.modules.clear()