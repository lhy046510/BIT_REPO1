# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Cavus38_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        url='http://xbmctr.com/livetv/Cavus38_Eklentiler/'
        link=araclar.get_url(url)        
        match=re.compile('<a href=".*?"> (.*?).xml</a></li>\n').findall(link)
        for url in match:
                name=url
                thumbnail='http://xbmctr.com/livetv/Cavus38_Eklentiler/'+url+'.png'
                url='http://xbmctr.com/livetv/Cavus38_Eklentiler/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR lightgreen]'+name+'[/B][/COLOR]', "icerik(name,url)",url,thumbnail)

def icerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
               araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        matchxor=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>').findall(link)
        for name,thumbnail,url in matchxor:
                araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        match2=re.compile('<title><!\[CDATA\[ (.*?) \]\]></title>\n    <link><!\[CDATA\[(.*?)\]\]></link>\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n').findall(link)
        for name,url,thumbnail in match2:
            araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,thumbnail)      

def yeni4(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def UrlResolver_Player(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)

