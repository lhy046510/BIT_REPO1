# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Yorumcu_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

filmler='http://aydindincer.hol.es/iptv2/Filmler.xml'

def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
            
        araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> Filmler [/B][/COLOR]', "icerik2(url)",filmler,'http://aydindincer.hol.es/iptv2/Filmler.png')
        url='aHR0cDovL2F5ZGluZGluY2VyLmhvbC5lcy9pcHR2Mi8='
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<li><a href="(.*?)"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>').findall(link)
        if match >0:
            del match[4]

            for t,url in match:
                name=url
                t='http://aydindincer.hol.es/iptv2/'+t
                url='http://aydindincer.hol.es/iptv2/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,t)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,t,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "canli(name,url)",url,t)

def icerik2(url):
        link=araclar.get_url(url)
        match=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,t,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,t)


def canli(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def UrlResolver_Player(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
