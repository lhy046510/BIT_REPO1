# -*- coding: utf-8 -*-
import xbmcplugin,urlresolver,xbmcgui,cozucu,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,araclar,base64

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="AdemTurk_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        
        url='http://xbmctr.com/livetv/AdemTurk_Eklentileri/'
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?).png"> .*?</a></li>\n').findall(link)
        for url in match:
                name=url
                thumbnail='http://xbmctr.com/livetv/AdemTurk_Eklentileri/'+url+'.png'
                url='http://xbmctr.com/livetv/AdemTurk_Eklentileri/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,thumbnail)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title> (.*?) </title>\r\n    <link>(.*?)</link>\r\n    <thumbnail>(.*?)</thumbnail>\r\n').findall(link)
        for name,url,thumbnail in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "canli(name,url)",url,thumbnail)
        match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        match2=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <link><!\[CDATA\[(.*?)\]\]></link>\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n').findall(link)
        for name,url,thumbnail in match2:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "canli(name,url)",url,thumbnail)
        match3=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <link><!\[CDATA\[(.*?)\]\]></link>\r\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\r\n').findall(link)
        for name,url,thumbnail in match3:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "canli(name,url)",url,thumbnail)
        match4=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\r\n    <description>.*?</description>\r\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\r\n').findall(link)
        for name,thumbnail,url in match4:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        match5=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\r\n    <link><!\[CDATA\[(.*?)\]\]></link>\r\n').findall(link)
        for name,thumbnail,url in match5:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)

def canli(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def UrlResolver_Player(name,url):
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
