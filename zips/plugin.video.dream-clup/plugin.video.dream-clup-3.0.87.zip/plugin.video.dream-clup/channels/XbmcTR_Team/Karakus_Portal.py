# -*- coding: utf-8 -*- by HappyFeets
import xbmcplugin,araclar,xbmcgui,cozucu,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Karakus_Portal"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        turkfilmi='http://speedturk.allalla.com/karakus/turk_filmi/turkfilmi_anamenu.xml'
        yabancifilm='http://speedturk.allalla.com/karakus/yabanci/yabancifilm_menu.xml'
        belgesel='http://speedturk.allalla.com/karakus/belgesel/belgesel_menu.xml'
        cizgifilm='http://speedturk.allalla.com/karakus/cocuk/cizgi_film.xml'
        dinifilm='http://speedturk.allalla.com/karakus/dini/dini_menu.xml'
        muzik='http://speedturk.allalla.com/karakus/muzik/muzik_menu.xml'
        dizitv='http://speedturk.allalla.com/karakus/dizi_portal/dizi_anamenu.xml'
        karma='http://speedturk.allalla.com/karakus/karma_portal/karma_menu.xml'
        iptv='http://speedturk.allalla.com/karakus/iptv/iptvmenu.xml'
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme OKUYUNUZ  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR lightblue][B]>> Turk Filmleri [/B][/COLOR] ', "kategori(url)",turkfilmi,"http://speedturk.allalla.com/karakus/image/JMZG.png")
        araclar.addDir(fileName,'[COLOR lightgreen][B]>> Yabanci Filmler [/B][/COLOR]', "kategori(url)",yabancifilm,"http://speedturk.allalla.com/karakus/image/9LG8.png")
        araclar.addDir(fileName,'[COLOR lightyellow][B]>> Belgeseller [/B][/COLOR]', "kategori(url)",belgesel,"http://speedturk.allalla.com/karakus/image/Z3AA.png")
        araclar.addDir(fileName,'[COLOR pink][B]>> Cizgi Filmler[/B][/COLOR]', "kategori(url)",cizgifilm,"http://www.fullindirizle.gen.tr/wp-content/uploads/2011/12/pepe-indir.jpg")
        araclar.addDir(fileName,'[COLOR orange][B]>> Dini Filmler[/B][/COLOR] ', "kategori(url)",dinifilm,"http://speedturk.allalla.com/karakus/image/CQJB.png")
        araclar.addDir(fileName,'[COLOR lightblue][B]>> Muzik [/B][/COLOR] ', "kategori(url)",muzik,"http://speedturk.allalla.com/karakus/image/F5ZX.png")
        araclar.addDir(fileName,'[COLOR lightgreen][B]>> Dizi TV Portal [/B][/COLOR] ', "kategori(url)",dizitv,"http://speedturk.allalla.com/karakus/image/diziler.jpg")
        araclar.addDir(fileName,'[COLOR lightyellow][B]>> Karma Filmler [/B][/COLOR] ', "kategori(url)",karma,"http://www.fragman.web.tr/wp-content/gallery/birbirine-benzeyen-film-afisleri/8.jpg")
        araclar.addDir(fileName,'[COLOR pink][B]>> Karma IPTV [/B][/COLOR] ', "ipkategori(url)",iptv,"https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcShD0jnojt2iHf1K2-FsS09DZzZjE2R27s-0pZwyR6r7BOSZyA-3w")

def kategori(url):
    link=araclar.get_url(url)
    match=re.compile('<title>(.*?)</title><logo_30x30>(.*?)</logo_30x30><description>.*?</description><playlist_url>(.*?)</playlist_url>').findall(link)
    for name,thumbnail,url in match:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR lightgreen]> [/COLOR]'+name+'[/B][/COLOR]', "kategoriicerik(url)",url,thumbnail)
        
def kategoriicerik(url):
    link=araclar.get_url(url)
    link=link.replace('amp','').replace(';','').replace('#038','')
    match=re.compile('<title>(.*?)</title><logo_30x30>(.*?)</logo_30x30><description>.*?</description><stream_url>(.*?)</stream_url>').findall(link)
    for name,thumbnail,url in match:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR lightgreen]> [/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
    match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
    for name,thumbnail,url in match1:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR lightgreen]> [/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)

def ipkategori(url):
    link=araclar.get_url(url)
    match=re.compile('<title>(.*?)</title><logo_30x30>(.*?)</logo_30x30><description>.*?</description><playlist_url>(.*?)</playlist_url>').findall(link)
    for name,thumbnail,url in match:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR lightgreen]> [/COLOR]'+name+'[/B][/COLOR]', "ipkategoriicerik(url)",url,thumbnail)
        
def ipkategoriicerik(url):
    link=araclar.get_url(url)
    match=re.compile('<title>(.*?)</title><logo_30x30>(.*?)</logo_30x30><description>.*?</description><stream_url>(.*?)</stream_url>').findall(link)
    for name,thumbnail,url in match:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR lightgreen]> [/COLOR]'+name+'[/B][/COLOR]', "ipoynat(name,url)",url,thumbnail) 
    match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n\n\n\n\t<logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n\n\n\n\t<description>.*?</description>\n\n\n\n\t<playlist_url><!\[CDATA\[(.*?)\]\]></playlist_url>\n\n\n\n\t').findall(link)
    for name,thumbnail,url in match1:
        araclar.addDir(fileName,'[COLOR beige][B][COLOR lightgreen]> [/COLOR]'+name+'[/B][/COLOR]', "ipoynat(name,url)",url,thumbnail)

def ipoynat(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def VIDEOLINKS(name,url):
                link=araclar.get_url(url)
                vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
                for url in vk_1:
                        url = 'http://vk.com/'+str(vk_1[0])
	   
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                link=araclar.get_url(url)
                scan=re.compile('video_host = \'(.*?)/\';\nvar video_uid = \'(.*?)\';\nvar video_vtag = \'(.*?)\'').findall(link)

                for a,b,c in scan:
                        
                        videoLink=a +'/u'+ b +'/videos/' + c + '.480.mp4'
                        araclar.addLink(name,videoLink,'')

                try:
                        link=araclar.get_url(url)
                        youtube=re.compile('"http:\/\/www.youtube.com\/watch\?v\=(.*?)"').findall(link)
                        for url in youtube:
                                yt = 'plugin://plugin.video.youtube/?action=play_video&videoid='+str(url).encode('utf-8', 'ignore')
                                araclar.addLink('~~Son~~',yt,'')
                                playList.add(yt)
                        xbmcPlayer.play(playList)

                except:
                        pass

##def VIDEOLINKS(name,url):
##        #---------------------------#
##        urlList=[]
##        #---------------------------#
##        playList.clear()
##        link=araclar.get_url(url)
##        link=link.replace('&amp;', '').replace('&#038;', '').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
##
##		#---------------------------------------------#
##        vk_2=re.compile('"http://vk.com/(.*?)"').findall(link)
##        for url in vk_2:
##                url = 'https://vk.com/'+str(url).encode('utf-8', 'ignore')
##                urlList.append(url)
##		#---------------------------------------------#
##        youtube=re.compile('"http://www.youtube.com/embed/(.*?)"').findall(link)
##        for url in youtube:
##                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
##                urlList.append(url)
##		#---------------------------------------------#
##        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
##        for url in dm:
##                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
##                urlList.append(url)
##        #------------------------------- 
##        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
##        for videodgelen in video:
##                url =videogelen
##                urlList.append(url)
##		#---------------------------------------------#
##        if not urlList:
##                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
##                print match
##                if match:
##                        for url in match:
##                                VIDEOLINKS(name,url)
##       
##        if urlList:
##                Sonuc=playerdenetle(name, urlList)
##                for name,url in Sonuc:
##                        araclar.addLink(name,url,'')
##                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
##                        listitem.setInfo('video', {'name': name } )
##                        playList.add(url,listitem=listitem)
##                xbmcPlayer.play(playList)
##
##        else:
##                dialog = xbmcgui.Dialog()
##                i = dialog.ok(name,"Site uyarısı","     Film Siteye henuz yuklenmedi   ","  Yayınlandıktan sonra yüklenecektir.  ")
##                return False 
##
##        
##def playerdenetle(name, urlList):
##        value=[]
##        import cozucu
##        for url in urlList if not isinstance(urlList, basestring) else [urlList]:
##
##                if "vk.com" in url:
##                    value.append((name,araclar.VK_Player(url)))
##                    
##                if 'youtube' in url:
##                    value.append((name,araclar.Youtube_Player(url)))
##
##                if 'dailymotion' in url:
##                    value.append((name,araclar.Daily_Player(url)))
##
##                if "video.ak.fbcdn.net" in url:
##                    value.append(("F Server",url))
##
##                if "fbcdn-video-a.akamaihd.net" in url:
##                    value.append(("F Server",url))
##
##                if "mail.ru" in url:
##                    value.append((name,araclar.MailRu_Player(url)))
##                    
##        if  value:
##            return value

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]Paylasimlarimizin hepsi internet uzerinde bulunan yayinlardir.[/COLOR]","[COLOR pink]Paylasimlar embed kod ile Portalimzida çalısmaktadır.[/COLOR]")
  except:
        
        pass
