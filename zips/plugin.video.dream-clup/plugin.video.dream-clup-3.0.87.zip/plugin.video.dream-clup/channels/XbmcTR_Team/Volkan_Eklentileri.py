# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Volkan_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        vtv='http://xbmctr.com/livetv/Volkan64_Canli_TV.xml'
        vrd='http://xbmctr.com/livetv/Radyo_Sefasi.xml'
        url='http://xbmctr.com/livetv/Volkan64/'
        bundes='http://xbmctr.com/livetv/Volkan64/AlmanCanli/'
        araclar.addDir(fileName,'[COLOR orange][B]>>> Volkan Canli TV ~~[/B][/COLOR][COLOR red] [B]>>>>[/B][/COLOR][COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]', "vtv(name,url)", vtv,"http://xbmctr.com/livetv/Volkan64_Canli_TV.png")
        araclar.addDir(fileName,'[COLOR lightyellow][B]>>> Volkan Canli Radyo ~~[/B][/COLOR][COLOR red] [B]>>>>[/B][/COLOR][COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]', "vtv(name,url)",vrd,"http://xbmctr.com/livetv/Radyo_Sefasi.png")
        araclar.addDir(fileName,'[COLOR lightblue][B]>>>[COLOR red] Volkan Bundes Republic ~~[/B][/COLOR][COLOR lightyellow] [B]>>>>[/B][/COLOR][COLOR orange]OTO GUNCEL [/COLOR][COLOR lightyellow]<<<<[/COLOR]', "bundes(url)",bundes,"http://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Faux_drapeau_germano-turc.svg/800px-Faux_drapeau_germano-turc.svg.png")
        
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?).png"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>\n').findall(link)
        for url,thumbnail in match:
                name=url
                thumbnail='http://xbmctr.com/livetv/Volkan64/'+url+'.png'
                url='http://xbmctr.com/livetv/Volkan64/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,thumbnail)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)

def vtv(name,url):
        link=araclar.get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for name,thumbnail,url in match:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail)
        match1=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,thumbnail)


def bundes(url):
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>').findall(link)
        for t,url in match:
                name=url
                t='http://xbmctr.com/livetv/Volkan64/AlmanCanli/'+t
                url='http://xbmctr.com/livetv/Volkan64/AlmanCanli/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"bundesicerik(name,url)",url,t)

def bundesicerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for name,t,url in match:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"yeni4(name,url)",url,t)

def yeni4(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
        
def UrlResolver_Player(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
