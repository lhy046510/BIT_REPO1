# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Thomas_Bouquet"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

hgbein='http://www.hqsport.tv/sky_sports1.php'
tlc='http://202.75.23.34:8800/live/ch35/01.m3u8'

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
##        hq='http://hqsport.tv/index.php'
##        hdembed='http://hdembed.com/'
        #cri='http://skysport.tv/live/index.php'#20
        cri='http://www.fifaembed.com/'#20
        ukiptv='http://en.iphone-tv.eu/channels/uk'
        get='http://skysport.tv/movie/sky-movies-action-live-stream.php'#22
        
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR yellow][B]Thomas Sports [COLOR blue]>>>[/COLOR][COLOR orange] FiFA [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]','multiembed(name,url)',cri,"http://i0.wp.com/www.tsmplug.com/wp-content/uploads/2013/06/TV-Channels-broadcasting-English-Premier-League-2013-2014.jpg" )
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR pink][B] Thomas Movies [/B][/COLOR]','multibulucusky(url)',get,'http://4.bp.blogspot.com/-kwT1nw0etf8/UtZqVLNBlbI/AAAAAAAADQg/m2RSvXt-H2I/s320/SKY.jpeg')
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR orange][B]Yerli Navix [/B][/COLOR]','update(url)',update2,"http://skystreamx.com/wp-content/uploads/2013/11/script.navi-x.png")
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Yerli Navixstreme-2 [/B][/COLOR]','navixiki(url)',navixiki,"http://www.xbmchub.com/blog/wp-content/uploads/navi-x.png")
##        addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR red][B]Being Sports [/B][/COLOR]',being,16,"http://skystreamx.com/wp-content/uploads/2013/11/script.navi-x.png")
##        addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR beige][B]Thomas Sports [COLOR blue] >>>[/COLOR][COLOR orange] HQ [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]',hq,1,'special://home/addons/plugin.video.HappyFeets.Thomas/icon.png')
##        addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR lightblue][B]Thomas Sports [COLOR blue]>>>[/COLOR][COLOR orange] Embed [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]', hdembed,10,'special://home/addons/plugin.video.HappyFeets.Thomas/icon.png')
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightyellow][B] N-Joy [/B][/COLOR]','njoy(url)',njoy,"http://media-cdn.tripadvisor.com/media/photo-s/04/87/40/06/njoy-bar-and-restaurant.jpg")        
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B] Ann UK TV [/B][/COLOR]','bobliste(url)',ukiptv,"http://www.radioandtelly.co.uk/images/freeviewchannels.jpg")        


def multiembed(name,url):
        link=araclar.get_url(url)
        match=re.compile('class="menu-item menu-item-type-post_type menu-item-object-page menu-item-.*?"><a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B]'+name+'[/B][/COLOR]','multibulucu(name,url)',url,'')
                
def multibulucu(name,url):
        link=araclar.get_url(url)
        link=link.replace('#038;',"")
        match=re.compile('<iframe src=\'(.*?)\' width=\'650\' height=\'480\' name=\'.*?\' frameborder=\'0\' marginwidth=\'0\' marginheight=\'0\' scrolling=\'no\'></iframe>').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile('file: "(.*?)"').findall(link)
                for url in match:
                        playList.clear()        
                        playList.add(name)
                        araclar.addLink(name,url,'')
                if playList:
                        xbmcPlayer.play(playList)

def multibulucusky(url):
        link=araclar.get_url(url)
        match2=re.compile('<button type=button onClick="location.href=\'(.*?)\'"><b><img src="(.*?)"').findall(link)
        for url2,t in match2:
                n=url2
                n=n.replace('-',' ').replace('live','').replace('stream.php','')
                url2='http://cricfree.tv/movie/'+url2
                t='http://cricfree.tv/movie/'+t
                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B]'+n+'[/B][/COLOR]','multibulucuskyicerik(name,url)',url,t)


def multibulucuskyicerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('id="iframe" src="(.*?)"').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile(' fid="(.*?)"').findall(link)
                for idi in match:
                        playList.clear()
                        url='rtmpe://46.246.29.150:1935/redirect app=redirect playpath='+idi+' swfUrl=http://www.hdcast.org/players.swf token=Fo5_n0w?U.rA6l3-70w47ch pageUrl=http://www.hdcast.org/embedlive2.php?u='+idi+'&vw=640&vh=460&domain=skysport.tv live=1'
                        #rtmpe://46.246.29.150:1935/redirect app=redirect playpath=action swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf token=Fo5_n0w?U.rA6l3-70w47ch pageUrl=http://www.hdcast.org/embedlive2.php?u=action&vw=640&vh=460&domain=skysport.tv live=1
                        #rtmpe://46.246.124.31:1935/redirect app=redirect playpath=action swfUrl=http://www.hdcast.org/players.swf pageUrl=http://www.hdcast.org/embedlive2.php?u=action&vw=640&vh=460&domain=skysport.tv 
                        playList.add(name)
                        araclar.addLink(name,url,'')              



##def njoy(url):#60
##        link=araclar.get_url(url)
##        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
##        match=re.compile('#EXTINF:-1,(.*?)<br />\n(.*?)<').findall(link)
##        for name,url in match:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
###############################################
##
##def being(url):#16
##        link=araclar.get_url(url)
##        match=re.compile('<a href="http://aflam4you.tv/(.*?)" class="pm-thumb-fix pm-thumb-.*?"><span class="pm-thumb-fix-clip"><img src="(.*?)" alt="(.*?)" width="145">').findall(link)
##        for url,thumbnail,name in match:
##                url=url.replace(" ","%20")
##                url='http://aflam4you.tv/'+url
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','beingicerik(url)',url,thumbnail)
##
##def beingicerik(url):
##        link=araclar.get_url(url)
##        match=re.compile('<script type="text/javascript"> width=(.*?), height=(.*?), channel="(.*?)", e="(.*?)";</script><script type="text/javascript" src="(.*?)"></script>').findall(link)
##        for iki,uc,idi,bir,url2 in match:
##                print url,idi,bir,iki,uc
##                link=araclar.get_url(url2)
##                match=re.compile(' src=(.*?)\'').findall(link)
##                for url in match:
##                        idi=idi
##                        bir='/'+bir
##                        iki='/'+iki
##                        uc='/'+uc
##                        url=url+idi+bir+iki+uc
##                        name='Play'
##                        print url
##                        araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','beingoynat(url)',url,'')
##
##def beingoynat(url):
##        link=araclar.get_url(url)
##        match=re.compile(' type="text/javascript">id="(.*?)";').findall(link)
##        for url2 in match:
##                idi=url2
##                url2='http://zingo.tv/watch.php?id='+url2
##                print idi,url2
##                link=araclar.get_url(url2)
##                match=re.compile('file: "rtmpe:\/\/(.*?)\/(.*?)\/(.*?)"').findall(link)
##                for rtmp,app,playpath in match:
##                        idi=idi
##                        rtmp='rtmpe://'+rtmp+'/'+app
##                        app=' app='+app
##                        playpath=' playpath='+playpath
##                        playList.clear()
##                        url=rtmp+app+playpath+' swfUrl=http://zingo.tv/jw5/player1.swf pageUrl=http://zingo.tv/watch.php?id='+idi+'&width=600&height=450 live=1'
##
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
##
##
##########################################
##def update(url):#25        
##        link=araclar.get_url(url)
##        link=link.replace('amp;','')
##        match=re.compile('<h3 class=\'post-title entry-title\' itemprop=\'name\'>\n<a href=\'(.*?)\'>(.*?)</a>\n</h3>\n<div class=\'post-header\'>\n<div class=\'post-header-line-1\'></div>\n</div>\n<div class=\'post-body entry-content\' id=\'.*?\' itemprop=\'description articleBody\'>\n<div class="separator" style="clear: both; text-align: center;">\n<a href="(.*?)"').findall(link)
##        for url,name,thumbnail in match:
##                name=name.replace('Rtmp Playlist Simpletv :',"").replace('SImpletv / Vlc / iphone :',"").replace('USA  For Vlc / SimpletV /',"").replace('Rtmp .mms Links For Vlc / SimpleTV / Mobel :',"").replace('Playlist Rtmp For Vlc / SimpletV / Ipad',"").replace('Rtmp Playlist HD :',"").replace('Rtmp ',"").replace('Playlist',"").replace('Super  M3U8 Arabic:',"").replace('Links ',"").replace('For Vlc /',"").replace('M3U8',"")
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','updateliste(url)',url,thumbnail)
##        page=re.compile('<a class=\'blog-pager-older-link\' href=\'(.*?)\'').findall(link)
##        for url in page:
##                name='Sonraki Sayfa'
##                araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR]''[COLOR lightblue][B] '+name+'[/B][/COLOR]','update(url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##
##def updateliste(url):
##        link=araclar.get_url(url)
##        link=link.replace('amp;','')
##        match=re.compile('<br /> (.*?) <br /> (.*?) ').findall(link)
##        for name,url in match:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match4=re.compile('\n\#EXTINF\:(.*?)\,-<br />\n(.*?)<br />\n').findall(link)
##        for name,url in match4:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match6=re.compile('<br /># EXTINF: -1, <br />(.*?)<br />').findall(link)
##        for url in match6:
##                name='Herbiri Ayri Kanaldir'
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match7=re.compile('S (.*?)<br />(.*?) ;').findall(link)
##        for name,url in match7:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        epname= 'Kanal'
##        a=0
##        match9=re.compile('# EXTINF: 0 ,<br />(.*?)<br').findall(link)
##        for url in match9:
##                a= a+1
##                name = epname + ' - '+str(a)
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match8=re.compile('<br />\n(.*?)<br />\n').findall(link)
##        for url in match8:
##                name=url
##                name=name.replace('http://totiptv.no-ip.org:8080/','').replace('.m3u8','')
##                url=url.replace('<br />','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match1=re.compile('<span style="font-size: small;"><b><a href="(.*?)"').findall(link)
##        for url in match1:
##                name='Listeyi Getir'
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightblue][B] '+name+'[/B][/COLOR]','updateicerik(url)',url,'')
##        match2=re.compile('<div style="text-align: center;">\n<a href="(.*?)"').findall(link)
##        for url in match2:
##                name='Listeyi Getir'
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightblue][B] '+name+'[/B][/COLOR]','updateicerik(url)',url,'')
##        match3=re.compile('<span style="font-size: large;"><b><a href="(.*?)"').findall(link)
##        for url in match3:
##                name='Listeyi Getir'
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightblue][B] '+name+'[/B][/COLOR]','updateicerik(url)',url,'')
##        match5=re.compile(' center;">\n<b><a href="(.*?)"').findall(link)
##        for url in match5:
##                name='Listeyi Getir'
##                aaraclar.ddDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightblue][B] '+name+'[/B][/COLOR]','updateicerik(url)',url,'')
##        
##
##def updateicerik(url):
##        link=araclar.get_url(url)
##        link=link.replace('rtmp://$OPT:rtmp-raw=',"").replace('amp;','')
##        match=re.compile('#EXTINF:-1,SPORT:(.*?)\r\n(.*?)\r\n').findall(link)
##        for name,url in match:
##                name=name.replace('http://playlist-for.blogspot.com','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match1=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n\r\n').findall(link)
##        for name,url in match1:
##                name=name.replace('http://playlist-for.blogspot.com','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match2=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link)
##        for name,url in match2:
##                name=name.replace('http://playlist-for.blogspot.com','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match3=re.compile('\r\n\r\n(.*?)\r\n(.*?)\r\n\r\n').findall(link)
##        for name,url in match3:
##                name=name.replace('http://playlist-for.blogspot.com','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match4=re.compile('#EXTINF:.*?,(.*?)\r\n(.*?)\r\n\r\n').findall(link)
##        for name,url in match4:
##                name=name.replace('http://playlist-for.blogspot.com','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match5=re.compile('# EXTINF: -1, (.*?)\r\n(.*?)\r\n').findall(link)
##        for name,url in match5:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match6=re.compile('# EXTINF: 0 , (.*?)\r\n(.*?)\r\n').findall(link)
##        for name,url in match6:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##
##
##
####################################################
##def navixiki(url):#4
##        link=araclar.get_url(url)
##        match=re.compile('<h2 class="entry-title"><a href="(.*?)" title="Permalink to (.*?)"').findall(link)
##        for url,name in match:
##                name=name.replace('&gt;','').replace('&amp;','').replace('&#8211;','').replace('&#8230;','').replace('&#8221;','').replace('&#8220;','')
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','navixikicerik(url)',url,'http://a4.mzstatic.com/us/r30/Purple/v4/0e/d8/a7/0ed8a7f3-08dd-1679-bf5e-1ebe6f7bc507/icon_256.png')
##        page=re.compile('<link rel="next" href="(.*?)"').findall(link)
##        for url in page:
##                name='Sonraki Sayfa'
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR blue][B] '+name+'[/B][/COLOR]','navixiki(url)',url,'http://a4.mzstatic.com/us/r30/Purple/v4/0e/d8/a7/0ed8a7f3-08dd-1679-bf5e-1ebe6f7bc507/icon_256.png')
##        
##def navixikicerik(url):#5
##        link=araclar.get_url(url)
##        link=link.replace('rtmp://$OPT:rtmp-raw=',"").replace('amp;','')
##        match=re.compile('<p>(.*?)</p>\n<p>(.*?)</p>').findall(link)
##        for name,url in match:
##                    araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match1=re.compile('# EXTINF: -1, (.*?)<br />\n(.*?)<br />\n').findall(link)
##        for name,url in match1:
##                    araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##        match3=re.compile('\n(.*?)<br />\n(.*?)<br />').findall(link)
##        for name,url in match3:
##                    araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','duzoynat(name,url)',url,'http://www.miracneon.com/upload/NJOY.jpg')
##
####################################################                
##def naviiki(url):#32
##        link=araclar.get_url(url)
##        link=link.replace('#038;',"")#.replace('amp;','')
##        match=re.compile('<p>(.*?)</p>\n<p>(.*?)</p>\n').findall(link)
##        for name,url in match:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+name+'[/B][/COLOR]','naviikiicerik(url)',url,'http://a4.mzstatic.com/us/r30/Purple/v4/0e/d8/a7/0ed8a7f3-08dd-1679-bf5e-1ebe6f7bc507/icon_256.png')
##
##def naviikiicerik(url):
##        link=araclar.get_url(url)
##        match=re.compile('file: "rtmp:(.*?)\=\/(.*?)"').findall(link)
##        for rtmp,play in match:
##                idi='pageUrl=rtmp:'+url
##                rtmp='rtmp:'+rtmp+'=/'
##                play=' playpath='+play+' swfUrl=http://p.jwpcdn.com/6/8/jwplayer.flash.swf '+idi
##                name='[COLOR gold] Play [/COLOR]'
##                url=rtmp+play+idi
##                xbmcPlayer = xbmc.Player()
##                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##                playList.clear()
##                playList.add(name)
##                araclar.addLink(name,url,'https://pbs.twimg.com/profile_images/419153085546516480/oExvbnRb.jpeg')
##        
##def hq(name,url):#1
##        link=araclar.get_url(url)  
##        match=re.compile('<a href="/sky_(.*?).php"><img src="(.*?)" width="120" height="23" align="center" border="0" alt=""/></a>').findall(link)
##        for url,thumbnail in match:
##                name=url
##                url='http://www.hqsport.tv/sky_'+url+'.php'
##                thumbnail='http://www.hqsport.tv'+thumbnail
##                araclar.addDir(fileName,'[COLOR lightblue][B]Sky '+name+'[/B][/COLOR]','hqskybulucu(name,url)',url,thumbnail)
##        match1=re.compile('<a href="/bt_(.*?).php"><img src="(.*?)" width="120" height="23" align="center" border="0" alt=""/></a>').findall(link)
##        for url,thumbnail in match1:
##                name=url
##                url='http://www.hqsport.tv/bt_'+url+'.php'
##                thumbnail='http://www.hqsport.tv/'+thumbnail
##                araclar.addDir(fileName,'[COLOR lightblue][B]Sky '+name+'[/B][/COLOR]','hqskybulucu(name,url)',url,thumbnail)
##        link=araclar.get_url(hgbein)                
##        match=re.compile('<a href="/bein_(.*?).php"><img src="(.*?)"').findall(link)
##        for url,thumbnail in match:
##                name=url
##                url='http://www.hqsport.tv/bein_'+url+'.php'
##                thumbnail='http://www.hqsport.tv/'+thumbnail
##                araclar.addDir(fileName,'[COLOR lightblue][B]Sky '+name+'[/B][/COLOR]','hqskybulucu(name,url)',url,thumbnail)
##                
##def hqskybulucu(name,url):
##        link=araclar.get_url(url)  
##        match=re.compile('<iframe src="(.*?)"').findall(link)
##        for url2 in match:
##                print url2
##                link=araclar.get_url(url2)  
##                match=re.compile(' fid="(.*?)"').findall(link)
##                for idi in match:
##                        xbmcPlayer = xbmc.Player()
##                        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##                        playList.clear()
##                        url='rtmpe://46.246.124.9:1935/redirect app=redirect playpath='+idi+' swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf token=Fo5_n0w?U.rA6l3-70w47ch pageUrl=http://www.hdcast.org/embedlive2.php?u='+idi+'&vw=600&vh=400&domain=hqsport.tv live=1'
##                #rtmpe://46.246.124.9:1935/redirect app=redirect playpath=sky1hqsport swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf pageUrl=http://www.hdcast.org/embedlive2.php?u=sky1hqsport&vw=600&vh=400&domain=hqsport.tv live=1
##                #rtmpe://46.246.124.15:1935/redirect app=redirect swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf pageUrl=http://www.hdcast.org/embedlive2.php?u=sky1hqsport&vw=600&vh=400&domain=hqsport.tv playpath=sky1hqsport
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)

##def hqbtbulucu(name,url):
##        link=araclar.get_url(url)  
##        match=re.compile('<iframe src="(.*?)"').findall(link)
##        for url2 in match:
##                print url2
##                link=araclar.get_url(url2)  
##                match=re.compile(' fid="(.*?)"').findall(link)
##                for idi in match:
##                        xbmcPlayer = xbmc.Player()
##                        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##                        playList.clear()
##                        url='rtmpe://46.246.124.9:1935/redirect app=redirect playpath='+idi+' swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf token=Fo5_n0w?U.rA6l3-70w47ch pageUrl=http://www.hdcast.org/embedlive2.php?u='+idi+'&vw=600&vh=400&domain=hqsport.tv live=1'
##                #rtmpe://46.246.124.9:1935/redirect app=redirect playpath=sky1hqsport swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf pageUrl=http://www.hdcast.org/embedlive2.php?u=sky1hqsport&vw=600&vh=400&domain=hqsport.tv live=1
##                #rtmpe://46.246.124.15:1935/redirect app=redirect swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/pl5.swf pageUrl=http://www.hdcast.org/embedlive2.php?u=sky1hqsport&vw=600&vh=400&domain=hqsport.tv playpath=sky1hqsport
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
#######################################################################

##def embed(name,url):#10
##        link=araclar.get_url(url)
##        match=re.compile('align="center"><a href="(.*?)" target="fdf" class="imgvisited1"><img src="(.*?)" width="90" height="90" border="0"></a></br>BT (.*?)</center>').findall(link)
##        for url,thumbnail,name in match:
##                name='BT '+name
##                url='http://hdembed.com/'+url
##                araclar.addDir(fileName,'[COLOR lightblue][B] '+name+'[/B][/COLOR]','embedbulucu(name,url)',url,thumbnail)
##        match1=re.compile(' align="center"><a href="(.*?)" target="fdf" class="imgvisited1"><img src="(.*?)" width="90" height="90" border="0"></a></br>Sky (.*?)</center>').findall(link)
##        for url,thumbnail,name in match1:
##                name='SKY '+name
##                url='http://hdembed.com/'+url
##                araclar.addDir(fileName,'[COLOR lightblue][B] '+name+'[/B][/COLOR]','embedbulucu(name,url)',url,thumbnail)
##        match2=re.compile(' align="center"><a href="(.*?)" target="fdf" class="imgvisited1"><img src="(.*?)" width="90" height="90" border="0"></a></br>Bein (.*?)</center>').findall(link)
##        for url,thumbnail,name in match2:
##                name='Bein '+name
##                araclar.addDir(fileName,'[COLOR lightblue][B] '+name+'[/B][/COLOR]','embedbulucu(name,url)',url,thumbnail)
##                
##def embedbulucu(name,url):
##        link=araclar.get_url(url)
##        match=re.compile(' type="text/javascript">id="(.*?)";').findall(link)
##        for url2 in match:
##                idi=url2
##                url2='http://zingo.tv/watch.php?id='+url2
##                print idi,url2
##                link=araclar.get_url(url2)
##                match=re.compile('file: "rtmpe:\/\/(.*?)\/(.*?)\/(.*?)"').findall(link)
##                for rtmp,app,playpath in match:
##                        idi=idi
##                        rtmp='rtmpe://'+rtmp+'/'+app
##                        app=' app='+app
##                        playpath=' playpath='+playpath
##                        playList.clear()
##                        url=rtmp+app+playpath+' swfUrl=http://zingo.tv/jw5/player1.swf pageUrl=http://zingo.tv/watch.php?id='+idi+'&width=600&height=450 live=1'
##
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
##                match1=re.compile('file: "rtmp://(.*?)/liveedge/(.*?)"\n').findall(link)
##                for rtmp,kanalname in match1:
##                        idi=idi
##                        rtmp='rtmp://'+rtmp
##                        playList.clear()
##                        url=rtmp+'/liveedge/'+' app=liveedge/'+' playpath='+kanalname +' '+'swfUrl=http://zingo.tv/jw5/player1.swf pageUrl=http://zingo.tv/watch.php?id='+idi+'&width=600&height=450 live=1'
##
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
##                match2=re.compile(' "rtmpe://(.*?)",\n                    file: "(.*?)",\n').findall(link)
##                for rtmp,kanalname in match2:
##                        idi=idi
##                        rtmp='rtmp://'+rtmp
##                        playList.clear()
##                        url=rtmp+' app=liveedge/'+' playpath='+kanalname +' '+'swfUrl=http://zingo.tv/jw5/player1.swf pageUrl=http://zingo.tv/watch.php?id='+idi+'&width=600&height=450 live=1'
##
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
#########################################################



#####################################################################
        #skysport.tv
##        link=araclar.get_url(url)
##        match=re.compile('id="iframe" src="(.*?)"').findall(link)
##        for url2 in match:
##                print url2
##                link=araclar.get_url(url2)
##                match=re.compile('fid=\'(.*?)\'').findall(link)
##                for idi in match:
##                        xbmcPlayer = xbmc.Player()
##                        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##                        playList.clear()
##                        url='rtmp://31.220.0.82:1935/live app=live playpath='+idi+' swfUrl=http://www.eucast.tv/player5.9.swf pageUrl=http://www.eucast.tv/embed.php?live='+idi+'&vw=620&vh=490 live=1 Conn=S:OK'
##                        #rtmp://31.220.0.82:1935/live app=live playpath=ss1x swfUrl=http://www.eucast.tv/player5.9.swf pageUrl=http://www.eucast.tv/embed.php?live=ss1x&vw=620&vh=490 live=1
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
##
##         
#######################################################################
##
##def SkyMovies(url):#30
##        addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR red][B]Gold [/B][/COLOR]','duzoynat(name,url)',gold,"http://www.comedy.co.uk/images/library/comedies/300/u/uktv_gold.jpg")
####        link=araclar.get_url(url)  
####        match=re.compile('<button type=button onClick="location.href=\'(.*?).php\'"><b><img src="(.*?)" width="65" height="30"align="center" border="0" alt="" />').findall(link)
####        for url,thumbnail in match:
####                name=url
####                url='http://cricfree.tv/movie/'+url+'.php'
####                thumbnail='http://cricfree.tv/movie/'+thumbnail
####                name=name.replace('live',"").replace('-'," ").replace('stream',"")
####                addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B]'+name+'[/B][/COLOR]',url,31,thumbnail)
##        link=araclar.get_url(url)
##        match=re.compile('<span class="nt">&lt;title&gt;</span>(.*?)<span class="nt">&lt;/title&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;link&gt;</span>(.*?)<span class="nt">&lt;/link&gt;</span></div><div class=\'.*?\' id=\'.*?\'><span class="nt">&lt;thumbnail&gt;</span>(.*?)<span class="nt">&lt;/thumbnail&gt;</span>').findall(link)
##        for n,url,t in match:
##                araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR]''[COLOR lightgreen][B] '+n+'[/B][/COLOR]','duzoynat(name,url)',url,t)
##
##
##def SkyMoviesbulucu(name,url):
##        link=araclar.get_url(url)  
##        match=re.compile(' id="iframe" src="(.*?)"').findall(link)
##        for url2 in match:
##                print url2
##                link=araclar.get_url(url2)
##                match=re.compile(' fid="(.*?)"').findall(link)
##                for idi in match:
##                        xbmcPlayer = xbmc.Player()
##                        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##                        playList.clear()
##                        url='rtmpe://46.246.124.28:1935/redirect app=redirect playpath='+idi+' swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/bba.swf pageUrl=http://www.hdcast.org/embedlive2.php?u='+idi+'&vw=620&vh=490&domain=cricfree.tv live=1'
##                        #rtmpe://46.246.124.28:1935/redirect app=redirect playpath=action swfUrl=http://77231864591d8245d027-dbd663cdd4719bbeb13e13f9ee6e6f1f.r39.cf5.rackcdn.com/bba.swf pageUrl=http://www.hdcast.org/embedlive2.php?u=action&vw=620&vh=490&domain=cricfree.tv live=1
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        xbmcPlayer.play(playList)
##
##def duzoynat(name,url):#40
##        xbmcPlayer = xbmc.Player()
##        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
##        playList.clear()
##        araclar.addLink(name,url,'')
##        listitem = xbmcgui.ListItem(name)
##        playList.add(url, listitem)
##        xbmcPlayer.play(playList)
###############################################
##
##def bobliste(url):#50
##        addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR red][B]TLC [/B][/COLOR]','duzoynat(name,url)',tlc,"http://a5.mzstatic.com/us/r30/Purple/v4/56/52/9b/56529b30-40d2-8a48-4a02-1cd7001d041f/icon_256.png")
##        link=araclar.get_url(url)
##        link=link.replace('amp;','')
##        match=re.compile('<a href="(.*?)" title=".*?"><img src="(.*?)" width="90" height="80" alt="(.*?)"></a>\n').findall(link)
##        if match >0:
##                del match[7]
##
##                for url,thumbnail,name in match:
##                        url='http://en.iphone-tv.eu/'+url
##                        thumbnail='http://en.iphone-tv.eu'+thumbnail
##                        araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen][B]'+ name+'[/B][/COLOR]','boblisteicerik(url)',url,thumbnail)
##    
##def boblisteicerik(url):#51
##        link=araclar.get_url(url)                        
##        match=re.compile('var\|(.*?)\|(.*?)\|(.*?)\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|\|(.*?)\|extern').findall(link)
##        for index,m3,kanal,token in match:
##                name='[COLOR pink]>> start play Server - 1[/COLOR]'
##                m3='.'+m3+'?c='
##                token='&auth='+token+'&gts=false'
##                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
##                url=url.replace('tv|','')
##                playList.clear()
##                playList.add(name)
##                araclar.addLink(name,url,'')
##        if playList:
##                playList.clear()
##                xbmcPlayer.play(playList)
##
##        match1=re.compile('\'var\|(.*?)\|\|(.*?)\|(.*?)\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|\|(.*?)\|extern').findall(link)
##        for index,m3,kanal,token in match1:
##                name='[COLOR orange]>> start play Server - 2[/COLOR]'
##                m3='.'+m3+'?c='
##                token='&auth='+token+'&gts=false'
##                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
##                url=url.replace('tv|','')
##                playList.clear()
##                playList.add(name)
##                araclar.addLink(name,url,'')
##        if playList:
##                playList.clear()
##                xbmcPlayer.play(playList)
##
##        match2=re.compile(',\'var\|\|index\|m3u8\|(.*?)\|1345\|auth\|eu\|http\|streamURL\|ipm\|iphone\|\|tv\|(.*?)\|extern').findall(link)
##        for kanal,token in match2:
##                name='[COLOR pink]>> start play Server - 3 [/COLOR]'
##                kanal='index.m3u8?c='+kanal
##                token='&auth='+token+'&gts=false'
##                url='http://ipm.iphone-tv.eu:1345/'+kanal+token
##                playList.clear()
##                playList.add(name)
##                araclar.addLink(name,url,'')
##        if playList:
##                playList.clear()
##                xbmcPlayer.play(playList)
##     
##        filmon=re.compile('\|http\|www\|(.*?)\|height\|').findall(link)
##        for url2 in filmon:
##                url2='http://www.filmon.com/tv/channel/export?channel_id='+url2
##                print url2
####                import time
####                time.sleep(5)
##                link=araclar.get_url(url2)
##                match=re.compile('"streams":\[\{".*?":.*?,".*?":".*?",".*?":"rtmp:\/\/(.*?)\/(.*?)\?id\=(.*?)","name":"(.*?)",').findall(link)
##                for rt,live,idi,pl in match:
##                        idii=url2
##                        name='[COLOR pink]>> start play [/COLOR]'
##                        rt='rtmp://'+rt+'/'
##                        pl=' playpath='+pl+' '
##                        idi='?id='+idi+pl+' swfUrl=http://www.filmon.com/tv/modules/FilmOnTV/files/flashapp/filmon/FilmonPlayer.swf?v=54 '
##                        idii='pageUrl='+idii+' live=1'
##                        url=rt+live+idi+idii
##                        print url
##                        playList.clear()
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        playList.clear()
##                        xbmcPlayer.play(playList)
##
##        filmoniki=re.compile('\|iframe\|channel\|export\|(.*?)\|channel_id\|tv\|filmon\|').findall(link)
##        for url2 in filmoniki:
##                url2='http://www.filmon.com/tv/channel/export?channel_id='+url2+'&amp;quality=high'
##                print url2
##                link=araclar.get_url(url2)
##                idii=url2
##                match=re.compile('"streams":\[\{".*?":.*?,".*?":".*?",".*?":"rtmp:\/\/(.*?)\/(.*?)\?id\=(.*?)","name":"(.*?)",').findall(link)
##                for rt,live,idi,pl in match:
##                        name='[COLOR pink]>> start play [/COLOR]'
##                        rt='rtmp://'+rt+'/'
##                        pl=' playpath='+pl+' '
##                        idi='?id='+idi+pl+' swfUrl=http://www.filmon.com/tv/modules/FilmOnTV/files/flashapp/filmon/FilmonPlayer.swf?v=54 '
##                        idii='pageUrl='+idii+' live=1'
##                        url=rt+live+idi+idii
##                        print url
##                        playList.clear()
##                        playList.add(name)
##                        araclar.addLink(name,url,'')
##                if playList:
##                        playList.clear()
##                        xbmcPlayer.play(playList)
##
###################################################
##
##def dual(url):#15        
##        link=araclar.get_url(url)
##        match=re.compile('#EXTINF: 0 , (.*?)</p>\n<p>(.*?)</p>\n').findall(link)
##        for name,url in match:
##                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen][B]'+ name+'[/B][/COLOR]','duzoynat(name,url)',url,'')
