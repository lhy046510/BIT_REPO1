# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="UK_Thomas_Bouquet"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

hgbein='http://www.hqsport.tv/sky_sports1.php'
tlc='http://202.75.23.34:8800/live/ch35/01.m3u8'
thomast='aHR0cDovL2kwLndwLmNvbS93d3cudHNtcGx1Zy5jb20vd3AtY29udGVudC91cGxvYWRzLzIwMTMvMDYvVFYtQ2hhbm5lbHMtYnJvYWRjYXN0aW5nLUVuZ2xpc2gtUHJlbWllci1MZWFndWUtMjAxMy0yMDE0LmpwZw=='

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
##        hq='http://hqsport.tv/index.php'
##        hdembed='http://hdembed.com/'
        #cri='http://skysport.tv/live/index.php'#20
        ukiptv='http://en.iphone-tv.eu/channels/uk'
        get='http://skysport.tv/movie/sky-movies-action-live-stream.php'#22
        fifaembed='aHR0cDovL2hhcHB5ZmVldHMubmV0NzgubmV0L3dvcmRwcmVzcy9hbGluYWNha2tvZC9GaWZhRW1iZWQueG1s'
        skysportstv='aHR0cDovL3hibWN0ci5jb20va29kY3UvdGFta29kL1NreVNwb3J0c1RWLnhtbA=='
        skymovies='aHR0cDovL3hibWN0ci5jb20va29kY3UvdGFta29kL1NreU1vdmllcy54bWw='

        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR yellow][B]FIFA [/B][/COLOR]',"fifaembed(url)",(base64.b64decode(fifaembed)),(base64.b64decode(thomast)))
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR orange][B]SkySports TV [/B][/COLOR]',"fifaembed(url)",(base64.b64decode(skysportstv)),(base64.b64decode(thomast)))
        araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR pink][B]Sky Movies [/B][/COLOR]',"fifaembed(url)",(base64.b64decode(skymovies)),(base64.b64decode(thomast)))

##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR pink][B] Thomas Movies [/B][/COLOR]','multibulucusky(url)',get,'http://4.bp.blogspot.com/-kwT1nw0etf8/UtZqVLNBlbI/AAAAAAAADQg/m2RSvXt-H2I/s320/SKY.jpeg')
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR orange][B]Yerli Navix [/B][/COLOR]','update(url)',update2,"http://skystreamx.com/wp-content/uploads/2013/11/script.navi-x.png")
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Yerli Navixstreme-2 [/B][/COLOR]','navixiki(url)',navixiki,"http://www.xbmchub.com/blog/wp-content/uploads/navi-x.png")
##        addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR red][B]Being Sports [/B][/COLOR]',being,16,"http://skystreamx.com/wp-content/uploads/2013/11/script.navi-x.png")
##        addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR beige][B]Thomas Sports [COLOR blue] >>>[/COLOR][COLOR orange] HQ [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]',hq,1,'special://home/addons/plugin.video.HappyFeets.Thomas/icon.png')
##        addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR][COLOR lightblue][B]Thomas Sports [COLOR blue]>>>[/COLOR][COLOR orange] Embed [/COLOR][COLOR blue]<<<[/COLOR][/B][/COLOR]', hdembed,10,'special://home/addons/plugin.video.HappyFeets.Thomas/icon.png')
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightyellow][B] N-Joy [/B][/COLOR]','njoy(url)',njoy,"http://media-cdn.tripadvisor.com/media/photo-s/04/87/40/06/njoy-bar-and-restaurant.jpg")        
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B] Ann UK TV [/B][/COLOR]','bobliste(url)',ukiptv,"http://www.radioandtelly.co.uk/images/freeviewchannels.jpg")        

def fifaembed(url):
        link=araclar.get_url(url)
        match=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n        <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>').findall(link)
        for name,url in match:
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]','oynat(name,url)',url,(base64.b64decode(thomast)))
        

def oynat(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,(base64.b64decode(thomast)))
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
