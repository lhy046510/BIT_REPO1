# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="HappyFeets_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

kanalf='rtmp://stream.taksimbilisim.com/kanalf/bant1'
yy='rtmp://yayin.canlitv.com/live/21yytv'

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
        tv='http://xbmctr.com/livetv/Volkan64_Canli_TV.xml'
        radyo='http://canliyayinradyolar.com/mini-mod/?canli-yayin=2'
        ts='http://www.tv-fm.com/HD-sinema-Turk-izle_ULUSAL_2204.html'
        sbir='http://www.tv-fm.com/hd-sinema-salon-1_ULUSAL_2221.html'
        siki='http://tv-fm.com/hd-sinema-salon-2_ULUSAL_2222.html'
        suc='http://tv-fm.com/hd-sinema-salon-3_ULUSAL_2223.html'
        sdort='http://tv-fm.com/hd-sinema-salon4_ULUSAL_222.html'
        sbes='http://tv-fm.com/hd-sinema-salon-5_ULUSAL_2225.html'
        salti='http://tv-fm.com/hd-sinema-salon-6_ULUSAL_2226.html'
        syedi='http://www.tv-fm.com/Kanal-M--izle_ULUSAL_2182.html'
        ssekiz='http://www.tv-fm.com/HD-Sinema-Yabanci_ULUSAL_2220.html'
        scizgi='http://tv-fm.com/cizgi-film-tv-izle_ULUSAL_2190.html'
        
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR pink][B]TV izle [COLOR beige]== [COLOR red]Volkan64 Canli TV[/B][/COLOR]','alttv(url)',tv,'http://xbmctr.com/livetv/Volkan64_Canli_TV.png')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR lightgreen][B]Radyo Dinle[/B][/COLOR]','altradyo(url)',radyo,'http://a1.mzstatic.com/us/r30/Purple6/v4/32/fe/60/32fe6085-6843-3180-7bf6-f7bd6cbcc794/icon_256.png')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR lightyellow][B]TURK SINEMASI izle[/B][/COLOR]','oynat2(name,url)',ts,'http://www.tv-fm.com/picture/logo/2204.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR yellow][B]Sinema Salon-1[/B][/COLOR]','oynat2(name,url)',sbir,'http://www.tv-fm.com/picture/logo/2221.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR orange][B]Sinema Salon-2[/B][/COLOR]','oynat2(name,url)',siki,'http://tv-fm.com/picture/logo/2222.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR green][B]Sinema Salon-3[/B][/COLOR]','oynat2(name,url)',suc,'http://tv-fm.com/picture/logo/2223.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR lightyellow][B]Sinema Salon-4[/B][/COLOR]','oynat2(name,url)',sdort,'http://tv-fm.com/picture/logo/2224.jpg')        
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR pink][B]Sinema Salon-5[/B][/COLOR]','oynat2(name,url)',sbes,'http://tv-fm.com/picture/logo/2225.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR orange][B]Sinema Salon-6[/B][/COLOR]','oynat2(name,url)',salti,'http://tv-fm.com/picture/logo/2226.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR lightgreen][B]Sinema Salon-7[/B][/COLOR]','oynat2(name,url)',syedi,'http://tv-fm.com/picture/logo/2226.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR lightyellow][B]Sinema Salon-8[/B][/COLOR]','oynat2(name,url)',ssekiz,'http://www.tv-fm.com/picture/logo/2220.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR pink][B]Cizgi Film tv[/B][/COLOR]','oynat2(name,url)',scizgi,'http://tv-fm.com/picture/logo/2190.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR turquoise][B]Fethiyeden CANLI[/B][/COLOR]','fethiye(url)','','http://farm4.staticflickr.com/3248/3006487718_24e1e077a2_o.jpg')

def alttv(url):
        link=araclar.get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for name,thumbnail,url in match:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "oynat(name,url)",url,thumbnail)
        match1=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link> \n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "oynat(name,url)",url,thumbnail)

def altradyo(url):
        link=araclar.get_url(url)
        match=re.compile('<option value="(.*?)">(.*?)</option>').findall(link)
        for url, name in match:
                url='http://canliyayinradyolar.com/mini-mod/?canli-yayin='+url
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/COLOR][COLOR lightgreen]'+ name+'[/B][/COLOR]','trradyooynat(name,url)',url,'http://www.akdeniz-elektronik.com/wp-content/uploads/akdeniz-sub-woofer-slider.png')

def trradyooynat(name,url):
        page=url
        link=araclar.get_url(url)
        match=re.compile(' href=\"http:\/\/canliyayinradyolar.com\/wp-content\/themes\/canliyayinradyolar\/mediaplayer.php\?url\=(.*?)&').findall(link)
        for pl in match:
                pl='rtmp://1.rtmp.org/canliyayinradyolar.com playpath='+pl+' swfUrl=http://canliyayinradyolar.com/wp-content/themes/canliyayinradyolar/flash/kucuk.swf'
                page=' pageUrl='+page+' live=1'
                url=pl+page
                playList.clear()
                araclar.addLink('[COLOR lightblue]'+' server 1 oynat' +'[/COLOR]'+name,url,'http://www.beejazzy.net/img/logo-wmp11.png')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
        match2=re.compile('<param name="flashvars" value="rtmp=(.*?)\&ns\=(.*?)&').findall(link)
        for rt,pl in match2:
                pl=' playpath='+pl+' swfUrl=http://canliyayinradyolar.com/wp-content/themes/canliyayinradyolar/flash/kucuk.swf'
                page=' pageUrl='+page+' live=1'
                url=rt+pl+page
                playList.clear()
                araclar.addLink('[COLOR lightgreen]'+' server 2 oynat' +'[/COLOR]'+name,url,'http://www.simarikradyo.com/wp-content/uploads/online-dinle.png')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        match=re.compile('ns=(.*?)&').findall(link)
        if match >0:
                del match[1]
                for url in match:
                        playList.clear()
                        araclar.addLink('[COLOR pink]'+' server 3 oynat' +'[/COLOR]'+name,url,'http://radyo.lolturk.net/images/wmp.png')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

##        match=re.compile(' value="var1=(.*?)\&').findall(link)
##        for url in match:
##                name=fileName,'[COLOR lightblue]'+' server 1 oynat' +'[/COLOR]'
##                araclar.addDir(name,'oynat(name,url)',url,'http://www.beejazzy.net/img/logo-wmp11.png')
##        match1=re.compile(' href\="\/mac-win-mediaplayer.php\?url\=(.*?)\&.*?">').findall(link)
##        for url in match1:
##                name='[COLOR lightgreen]'+' server 2 oynat' +'[/COLOR]'
##                araclar.addDir(name,'oynat(name,url)',url,'http://www.simarikradyo.com/wp-content/uploads/online-dinle.png')
##        match=re.compile(' value\="rtmp\=(.*?)\&.*?').findall(link)
##        for url in match:
##                url=url+' playpath=power.stream?radyo=powerfm:type=aacp64:source=www swfUrl=http://www.canliyayinradyolar.com/player/canliyayinradyolar.com.mini.mod.rtmp.swf pageUrl=http://canliyayinradyolar.com/mini-mod/?canli-yayin=97 live=1'
###rtmp://cdn.powergroup.com.tr:80/power playpath=power.stream?radyo=powerfm:type=aacp64:source=www swfUrl=http://www.canliyayinradyolar.com/player/canliyayinradyolar.com.mini.mod.rtmp.swf pageUrl=http://canliyayinradyolar.com/mini-mod/?canli-yayin=97 live=1
##                addDir('[COLOR pink]'+' server 3 oynat' +'[/COLOR]',url,11,'http://radyo.lolturk.net/images/wmp.png')
##        match2=re.compile('<embed id="FlashKontrol" style=".*?" width=".*?" height=".*?" type=".*?" src="(.*?)" quality=".*?" wmode=".*?" devicefont=".*?" swliveconnect=".*?" allowscriptaccess=".*?" flashvars="rtmp\=(.*?)\&ns\=(.*?)&facebooklinki\=(.*?)\&.*?').findall(link)
##        for swf,url,playpath,pageurl in match2:
##                swf=' swfUrl='+swf
##                playpath=' playpath='+playpath
##                pageurl=' pageUrl='+pageurl
##                url=url+playpath+swf+pageurl
##                name='[COLOR pink]'+' server 3 oynat' +'[/COLOR]'
##                araclar.addDir(name,'oynat(name,url)',url,'http://radyo.lolturk.net/images/wmp.png')


def fethiye(url):
        #araclar.addDir(fileName,'[COLOR orange][B]>>> Volkan Canli TV ~~[/B][/COLOR]', "vtv(name,url)", vtv,"http://xbmctr.com/livetv/Volkan64_Canli_TV.png")
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR hotpink][B]Kanal F [/B][/COLOR]','oynat(name,url)',kanalf,'http://www.onlinetelevizyon.com/wp-content/uploads/2013/09/kanal-f.jpg')
        araclar.addDir(fileName,'[COLOR lightblue]>>> [COLOR peru][B]21yy TV [/B][/COLOR]','oynat(name,url)',yy,'http://www.canlitv.com/kanal/logo/11287.jpg')

def oynat(name,url):
##        xbmcPlayer = xbmc.Player()
##        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def oynat2(name,url):            
##        xbmcPlayer = xbmc.Player()
##        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        
        link=araclar.get_url(url)
        match=re.compile('<MediaSource>(.*?)</MediaSource>').findall(link)
        for url in match:
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
