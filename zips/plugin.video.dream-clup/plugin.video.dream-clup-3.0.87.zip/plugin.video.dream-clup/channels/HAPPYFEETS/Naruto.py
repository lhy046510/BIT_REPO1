# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Naruto"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

naruto='http://fc01.deviantart.net/fs71/f/2013/106/1/9/naruto_shippuuden__naruto_uzumaki__by_lkoizumil-d61xfee.png'
mirbir='https://pbs.twimg.com/profile_images/428198553572229120/DwPDf9e4.png'
miriki='https://pbs.twimg.com/profile_images/378800000429891847/80f83e08e3c352092e870b42d3263233.png'

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+'' 
        url='http://www.yabancidiziizle1.com/dizi/naruto-shippuuden-full'
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?" class="img"><img src="(.*?)" alt="Naruto Shippuuden (.*?)"').findall(link)
        for url,t,name in match:
            t='http://www.yabancidiziizle1.com/'+t
            araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]','ayristirma(url)',url,t)

def ayristirma(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?">720p</a></li>').findall(link)
        for url in match:
            url='http://www.yabancidiziizle1.com'+url
            name='720p izle'
            araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]','VIDEOLINKS(name,url)',url,naruto)
        match1=re.compile('<li><a href="(.*?)" title=".*?">ALT</a></li>').findall(link)
        for url in match1:
                url='http://www.yabancidiziizle1.com'+url
                name='Alternatif izle'
                araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR lightblue]'+name+'[/B][/COLOR]','VIDEOLINKS(name,url)',url,mirbir)
        match2=re.compile('<li><a href="(.*?)" title=".*?">ALT (.*?)</a></li>').findall(link)
        for url,name in match2:
                url='http://www.yabancidiziizle1.com'+url
                name='Alternatif '+name
                araclar.addDir(fileName,'[COLOR blue][B]>> [COLOR pink]'+name+'[/B][/COLOR]','VIDEOLINKS(name,url)',url,miriki)
##def getir(url):
##        link=araclar.get_url(url)
##        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
##        for tarih,url,name,durum in match:
##                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR red]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
##                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kardes)
##        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
##        for url in s:
##                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
##                araclar.addDir(fileName,name,'getir(url)',url,kardes)

def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                name='VK Server'
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player('[COLOR blue][B]>> [COLOR orange]'+name+'[/B][/COLOR]',url)
		#---------------------------------------------#
        youtube=re.compile(' src="//www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                name='YouTube Server'
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player('[COLOR blue][B]>> [COLOR lightblue]'+name+'[/B][/COLOR]',url)
		#---------------------------------------------#
                            #<iframe src="http://api.video.mail.ru/videos/embed/mail/yenisezon/_myvideo/1128.html?rel=0&autoplay=1"
        mailru=re.compile('<iframe src=\"http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html\?rel\=.*?\&autoplay\=.*?"').findall(link)
        for mailrugelen in mailru:
                name='MailRU Server'
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                name='DM Server'
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player('[COLOR blue][B]>> [COLOR pink]'+name+'[/B][/COLOR]',url)

		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append(('[COLOR blue][B]>> [COLOR lightyellow]'+name+'[/B][/COLOR]',cozucu.MailRu_Player(url)))
                    
        if  value:
            return value

