# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

#!/usr/bin/python
# -*- coding: utf-8 -*-         #print ""+url
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets
# Turkiye, E-mail: androidmkersco@gmail.com

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Live_ITALY"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

ithumb='http://a2.mzstatic.com/us/r30/Purple2/v4/3f/51/84/3f51846b-daa8-0c1e-e28e-6bc80c10d06c/icon_256.png'
calciohd='http://skysport.tv/sky-calcio-in-diretta.php'
calciohdt='http://skysport.tv/images/sky-calcio-in-diretta.png'
calcio1='http://skysport.tv/sky-sport-1-in-streaming.php'
calcio1t='http://skysport.tv/images/sky_it_sport1.jpg'
calcio2='http://skysport.tv/sky-sport-2-in-streaming.php'
calcio2t='http://skysport.tv/images/sky_it_sport2.jpg'
calcio3='http://skysport.tv/sky-sport-3-in-streaming.php'
calcio3t='http://skysport.tv/images/sky_it_sport3.jpg'

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
##        hq='http://hqsport.tv/index.php'
##        hdembed='http://hdembed.com/'
        url='http://en.iphone-tv.eu/channels/it'
        hasbah='http://01.gen.tr/HasBahCa_IPTV/italya.m3u'

        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Sky calcio hd [/B][/COLOR]','yeni(url)',calciohd,calciohdt)
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Sky Sport 1[/B][/COLOR]','yeni(url)',calcio1,calcio1t)
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Sky Sport 2[/B][/COLOR]','yeni(url)',calcio2,calcio2t)
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Sky Sport 3[/B][/COLOR]','yeni(url)',calcio3,calcio3t)
        link=araclar.get_url(hasbah)
        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link)
        if match >0:
                del match[0]
                for name,url in match:
                        name=name.replace('mmsh','').replace('mms','')
                        araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]','oynat(name,url)',url,ithumb)
##        link=araclar.get_url(url)
##        link=link.replace('amp;','')
##        match=re.compile('<a href="(.*?)" title=".*?"><img src=".*?" width="90" height="80" alt="(.*?)"></a>\n').findall(link)
##        for url,name in match:
##                url='http://en.iphone-tv.eu/'+url
##                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',url,2,ithumb)

def yeni(url):#1
        link=araclar.get_url(url)
        match=re.compile('id="iframe" src="(.*?)" ').findall(link)
        for url2 in match:
                print url2
                link=araclar.get_url(url2)
                match=re.compile('id="iframe" src="(.*?)" ').findall(link)
                for url3 in match:
                        print url3
                        link=araclar.get_url(url3)
                        match=re.compile('fid=\'(.*?)\'').findall(link)
                        for idi in match:
                                name='[COLOR pink]>> inizio [/COLOR]'
                                url='rtmp://31.220.0.134:1935/live playpath='+idi+' swfUrl=http://www.eucast.tv/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live='+idi+'&vw=620&vh=490 live=1'
        #                        rtmp://31.220.0.134:1935/live playpath=skycalcioit swfUrl=http://www.eucast.tv/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.eucast.tv/embed.php?live=skycalcioit&vw=620&vh=490 live=1
                                #rtmp://31.220.0.195:1935/live playpath=sky1ita swfUrl=http://www.flashtv.co/ePlayerr.swf pageUrl=http://www.flashtv.co/embed.php?live=sky1ita&vw=620&vh=490 live=1
                                playList.clear()
                                playList.add(name)
                                araclar.addLink(name,url,'http://www.fornokia.net/data/programs/images/31790004_256x256-192x192__programView1_8225.jpg')
                        if playList:
                                xbmcPlayer.play(playList)
               
def boblisteicerik(url):#2
        link=araclar.get_url(url)
        match=re.compile('var\|(.*?)\|(.*?)\|(.*?)\|1345\|auth\|eu\|http\|streamURL\|ipm\|iphone\|tv\|\|(.*?)\|.*?').findall(link)
        for index,m3,kanal,token in match:
                name='[COLOR pink]>> inizio [/COLOR]'
                m3='.'+m3+'?c='
                token='&auth='+token+'&gts=false'
                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'http://www.fornokia.net/data/programs/images/31790004_256x256-192x192__programView1_8225.jpg')
        if playList:
                xbmcPlayer.play(playList)       

def oynat(name,url):#4

        playList.clear()        
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList) 
                



