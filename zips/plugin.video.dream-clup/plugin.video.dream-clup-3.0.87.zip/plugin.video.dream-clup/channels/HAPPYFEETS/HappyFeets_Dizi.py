# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="HappyFeets_Dizi"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

kacakt='http://www.filmleyelim.com/wp-content/uploads/2013/10/Ka%C3%A7ak-200x300.jpg'
kardest='http://picload.org/image/ldcacpd/kardes_payi.png'
kvpt='http://1.bp.blogspot.com/--12nKzBVp4s/U54ELuZX0yI/AAAAAAAADg4/kEAssbXIWh4/s1600/2230.jpg'

############# ANA GIRIS KLASORLERI ##############################
def main():
        
        kacak='http://urlji.com/kacak'
        kardes='http://urlji.com/kardespayi'
        kvvp='http://kurtlarvadisi2023.blogspot.co.uk/p/kurtlar-vadisi-pusu-eski-bolumler.html'
        
        araclar.addDir(fileName,'[COLOR red][B]>> Bilgilendirme Onemli <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR lightblue][B] Kardes Payi [/B][/COLOR]', "kardes(url)",kardes,kardest)
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR lightgreen][B] Kacak[/B][/COLOR]', "kacak(url)",kacak,kacakt)
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR] [COLOR pink][B] Kurtlar Vadisi Pusu [/B][/COLOR]', "kvvp(url)",kvvp,kvpt)

###################################################################                
################################################################### ################################################################### 
def kardes(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
        for tarih,url,name,durum in match:
                name='[COLOR lightblue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR orange]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kardest)
        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
        for url in s:
                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
                araclar.addDir(fileName,name,'kardesgetir(url)',url,kardest)
def kardesgetir(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
        for tarih,url,name,durum in match:
                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR red]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kardest)
        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
        for url in s:
                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
                araclar.addDir(fileName,name,'kardesgetir(url)',url,kardest)
################################################################### ################################################################### 
def kacak(url):
        link=araclar.get_url(url)        
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
        for tarih,url,name,durum in match:
                name='[COLOR lightblue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR orange]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kacakt)
        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
        for url in s:
                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
                araclar.addDir(fileName,name,'kacakgetir(url)',url,kacakt)
def kacakgetir(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
        for tarih,url,name,durum in match:
                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR orange]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kacakt)
        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
        for url in s:
                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
                araclar.addDir(fileName,name,'kacakgetir(url)',url,kacakt)
################################################################### ###################################################################
def kvvp(url):
        link=araclar.get_url(url)
        match=re.compile('<li><a href=\'(.*?)\'>Kurtlar Vadisi Pusu (.*?)</a></li>').findall(link)
        for url,name in match:
                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kvpt)
        match2=re.compile(' href="(.*?)"><span style=".*?">Kurtlar Vadisi Pusu (.*?)</span>').findall(link)
        for url,name in match2:
                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kvpt)


def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR orange]>>>   [/COLOR] V Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
                 
        youtube=re.compile(' src="\/\/www.youtube.com\/embed\/(.*?)\?rel\=0"').findall(link)
        #youtube=re.compile('http:\/\/www.youtube.com\/embed\/(.*?)').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR lightblue]>>>   [/COLOR] Y Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('<iframe src=\'http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html\'').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                name='[COLOR beige][B][COLOR green]>>>   [/COLOR] V Server [/B][/COLOR]'
                urlList.append(url)
        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value


def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]Serverdan Kaldirilmamis ise Tum Diziler Sorunsuz Calisir.[/COLOR]","[COLOR pink]Herkese iyi seyirler[/COLOR]")
  except:
        
        pass 

def name_fix(x):        
        x=x.replace('-',' ').replace('_',' ')
        return x[0].capitalize() + x[1:]
