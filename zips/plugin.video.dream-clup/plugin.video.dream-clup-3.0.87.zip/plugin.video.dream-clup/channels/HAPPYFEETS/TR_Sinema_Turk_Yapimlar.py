# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="TR_Sinema_Turk_Yapimlar"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

ekle='aHR0cDovL3Nwb3J0Ym9zcy5vcmcv'

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''      
        url='aHR0cDovL3Nwb3J0Ym9zcy5vcmcvc2luZW1hLnBocA=='
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<a href="(.*?)"><img src="(.*?)"width=".*?" height=".*?"></a>\n').findall(link)
        for url,t in match:
                url=(base64.b64decode(ekle))+url.encode('utf-8', 'ignore')
                print url
                name='[COLOR blue][B]>> [COLOR lightgreen] iyi seyirler [/B][/COLOR]'                
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,t)

def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR orange]>>>   [/COLOR] V Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        youtube=re.compile('http:\/\/www.youtube.com\/embed\/(.*?)').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR lightblue]>>>   [/COLOR] Y Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('<iframe src=\'http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html\'').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                name='[COLOR beige][B][COLOR green]>>>   [/COLOR] V Server [/B][/COLOR]'
                urlList.append(url)
        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
