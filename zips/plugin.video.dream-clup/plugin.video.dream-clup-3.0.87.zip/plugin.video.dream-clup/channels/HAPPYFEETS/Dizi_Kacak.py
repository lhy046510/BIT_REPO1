# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Dizi_Kacak"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

kacak='http://www.filmleyelim.com/wp-content/uploads/2013/10/Ka%C3%A7ak-200x300.jpg'

def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''      
        url='http://urlji.com/kacak'
        link=araclar.get_url(url)
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
        for tarih,url,name,durum in match:
                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR red]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kacak)
        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
        for url in s:
                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
                araclar.addDir(fileName,name,'getir(url)',url,kacak)
def getir(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="tarih">(.*?)</div>\r\n\t\t\t\t\t\t<a href="(.*?)"><img src=".*?" ></a>\r\n\t\t\t\t\t\t<h2><a href=".*?">(.*?)</a></h2>\r\n\t\t\t\t\t\t<div class="durum">(.*?)</div>\r\n').findall(link)
        for tarih,url,name,durum in match:
                name='[COLOR blue][B]>> [COLOR lightgreen]'+name+'[/B][/COLOR]'+'[COLOR red]'+tarih+'[/COLOR]'+' '+'[COLOR lightblue]'+durum+'[/COLOR]'
                araclar.addDir(fileName,name,'VIDEOLINKS(name,url)',url,kacak)
        s=re.compile('<span class="current">.*?</span><a href="(.*?)"').findall(link)
        for url in s:
                name='[COLOR blue]>>[COLOR yellow] Sonraki Sayfa [/COLOR] '
                araclar.addDir(fileName,name,'getir(url)',url,kacak)

def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR orange]>>>   [/COLOR] V Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        youtube=re.compile('http:\/\/www.youtube.com\/embed\/(.*?)').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR beige][B][COLOR lightblue]>>>   [/COLOR] Y Server [/B][/COLOR]'
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('<iframe src=\'http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html\'').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                name='[COLOR beige][B][COLOR green]>>>   [/COLOR] V Server [/B][/COLOR]'
                urlList.append(url)
        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
