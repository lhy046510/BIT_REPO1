# -*- coding: utf-8 -*- happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,urlresolver,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="UK_TV_SHOWS"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

url33 = 'http://www.tvip.co.vu/2014/01/englais-iptv-sky-sport-drama-premiere.html'
url2='http://www.tvonlinestreams.com/english-hd-channels-list/'
fant='special://home/addons/plugin.video.dream-clup/resources/images/UK_TV_SHOWS.png'
def main():
        url='https://raw.githubusercontent.com/mash2k3/MashUpTNPB/master/TV%20Shows.xml'
        yediyirmidort='aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2pha2V5amFrZS9qYWtleWpha2UvbWFzdGVyLzI0LTclMjBUVi54bWw='
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Live TV Shows 7/24 [/B][/COLOR]', "yediyirmidort(url)",(base64.b64decode(yediyirmidort)),fant)
        link=araclar.get_url(url)
        match=re.compile('<name>(.*?)</name>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n').findall(link)
        for name,url,thumbnail in match:
            araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"LiveTvShowsYeni(url)",url,thumbnail)

def LiveTvShowsYeni(url):
    link=araclar.get_url(url)
    match=re.compile('<name>(.*?)</name>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n').findall(link)
    for name,url,thumbnail in match:
            araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR][COLOR lightgreen][B] '+name+'[/B][/COLOR]',"LiveTvShowsYeni2(url)",url,thumbnail)

def LiveTvShowsYeni2(url):
    link=araclar.get_url(url)
    link=link.replace('https','http')
    match=re.compile('<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n').findall(link)
    for name,url,thumbnail in match:
            araclar.addDir(fileName,'[COLOR gold][B]>> [/B][/COLOR][COLOR beige][B] '+name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,thumbnail)

def yediyirmidort(url):
        link=araclar.get_url(url)
        link=link.replace('\n','')
        match=re.compile('<title>(.*?)</title><link><sublink>(.*?)</sublink><sublink></sublink></link><thumbnail>(.*?)</thumbnail>').findall(link)
        for name,url,t in match:
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/COLOR][COLOR lightgreen]'+ name+'[/B][/COLOR]','LiveTvShowsOynat(name,url)',url,t)

def LiveTvShowsOynat(name,url):
    xbmcPlayer = xbmc.Player()
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playList.clear()
    araclar.addLink(name,url,'')
    listitem = xbmcgui.ListItem(name)
    playList.add(url, listitem)
    xbmcPlayer.play(playList)

def UrlResolver_Player(name,url):
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
