# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Online_Film"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        FILMSAATI='http://www.fullonlinefilmizle.com/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "FILMSAATIRecent(url)",FILMSAATI,'')
        link=araclar.get_url(FILMSAATI)
        match=re.compile('<li id="menu-item-.*?"><a href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "FILMSAATIRecent2(url)",url,"")

def FILMSAATIRecent(url):
        link=araclar.get_url(url)
        match1=re.compile('href="(.*?)" title=".*?"><div class=".*?" original-title=".*?"></div>\n<img src=".*?" data-original="(.*?)" alt="(.*?)"').findall(link)
              #re.compile('href="(.*?)" title=".*?"><div class=".*?"></div>\n<img src=".*?" data-original="(.*?)" alt="(.*?)" ').findall(link)
        for url,thumbnail,name in match1:
                name=name.replace('&#8217','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('class=\'page active\' >.*?</a><a href=\'(.*?)\' class=\'page inactive\' >(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FILMSAATIRecent(url)",url,"next")
def FILMSAATIRecent2(url):
        link=araclar.get_url(url)
        match1=re.compile('href="(.*?)" title=".*?"><div class=".*?"></div>\n<img src=".*?" data-original="(.*?)" alt="(.*?)" ').findall(link)
        for url,thumbnail,name in match1:
                name=name.replace('&#8217','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('class=\'page active\' >.*?</a><a href=\'(.*?)\' class=\'page inactive\' >(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+ '[COLOR red][B]'+name+'[/B][/COLOR]', "FILMSAATIRecent2(url)",url,"next")

def ayrisdirma(name,url):
        link=araclar.get_url(url)
        match1=re.compile('<li class="tab-link"><a href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match1:
                
               # code=''
               # url=url
                #name=' FRAGMAN Izle '
               thumbnail='http://blog.lengow.de/wp-content/uploads/2011/09/play_logo.jpg'
               araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
##        match2=re.compile('<a href="(.*?)">(.*?).Par\xc3\xa7a</a>').findall(link)
##        for url,name in match2:
##                name=name+' PART'
##                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
##        match=re.compile('rel="nofollow"(.*?)">Part(.*?)</a>').findall(link)
##        for url,name in match:
##                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]Vk -'+name+'  PART [/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        	
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.fullonlinefilmizle.com/?s='+query)
            FILMSAATIRecent2(url)

def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

		#---------------------------------------------#

        youtube=re.compile('value="file=http:\/\/www.youtube.com\/watch\?v\=(.*?)\&').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

		#---------------------------------------------#
        mailru2=re.compile('value="movieSrc=mail\/(.*?)&').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#

        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x
