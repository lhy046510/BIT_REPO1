# -*- coding: utf-8 -*- by happyfeets


import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,urlresolver,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="FULL_Stream"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        url2='aHR0cDovL3hibWN0ci50di9jYW5saS10di92aWRlby83My1mb3gtdHY='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        url='http://full-stream.net/index.php'     
        araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR][COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")
        link=araclar.get_url(url)
        match=re.compile('<li><a href="\/index.php\?do\=cat\&amp\;category\=(.*?)"><span>(.*?)</span></a></li>\n').findall(link)
        for url,name in match:#films-en-vk-streaming/action/
                url='http://full-stream.net/films-en-vk-streaming/'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")
        match1=re.compile('</li><li><a href="\/index.php\?do\=cat\&amp\;category\=(.*?)"><span>(.*?)</span></a>\n').findall(link)
        for url,name in match1:#films-en-vk-streaming/action/
                url='http://full-stream.net/films-en-vk-streaming/'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")
       
###################################################################                
def Yeni(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="short-poster">\n      <div class="rait"><span id=".*?">&nbsp;<font color=".*?"><b>.*?</b></font>&nbsp;</span></div>\n        <div class=".*?">.*?</div> \n<a href="(.*?)">\n    <div class=".*?"></div>\n\n\n <div align="center">  <span class="short-title"><span style=".*?">(.*?) </span></span> </div>\n    <img src\="\/IMG\/full-stream.php\?src\=(.*?)\&w\=210\&h\=280" width=".*?" height=".*?" alt=".*?" />\n    </div>').findall(link)
        for url,name,t in match:
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"ayris(url)",url,t)
        page=re.compile('<span>.*?</span> <a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR]'+'[COLOR lightblue][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")

def ayris(url):
    link=araclar.get_url(url)
    link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')
    match=re.compile('<iframe src="(.*?)" ').findall(link)
    for url in match:
            name='VK'
            araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,'')
    idi=url
    match=re.compile(' href\="\#lecteur(.*?)">  <img width="80" height="18" alt="(.*?)" src="(.*?)"').findall(link)
    for url,name,t in match:
            url=idi+'#lecteur'+url
            t='http://full-stream.net'+t
            araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,t)

def UrlResolver_Player(name,url):
        safe='aHR0cDovL3d3dy54Ym1jdHIudHYvdmlkZW8vMzAtcGxhbmV0LXR1cms='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        UrlResolverPlayer = url 
        playList.clear() 
        media = urlresolver.HostedMediaFile(UrlResolverPlayer) 
        source = media 
        if source: 
                url = source.resolve() 
                araclar.addLink(name,url,'') 
                araclar.playlist_yap(playList,name,url) 
                xbmcPlayer.play(playList)
