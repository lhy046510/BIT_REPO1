# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="NOSTALJI"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        url='http://www.nostaljifilmizle.com/'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
        araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR] [COLOR lightgreen][B]Son Eklenenler [/B][/COLOR]', "Yeni(url)",url,"")
                ##### KATEGORILERI OKU EKLE ##########################
        
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link)
        for url,name in match:               
                araclar.addDir(fileName,'[COLOR orange][B]>>[/B][/COLOR] '+'[COLOR beige][B]' + name+'[/B][/COLOR]',"icerik(url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.nostaljifilmizle.com/?s='+query)
            Yeni(url)


def url_tara(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('#8211',"").replace('ddd',"")
        response.close()
        return link


############
def Yeni(url):
        link=url_tara(url)
        match=re.compile('<a href="(.*?)">\n<img src="(.*?)" alt="(.*?)" height="125px" width="119px" />').findall(link)
        for url,thumbnail,name in match:
                #url = url+'/2'
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     
        
###########        

                                
###########
def icerik(url):
        link=url_tara(url)  
        match=re.compile('<a href="(.*?)">\n<img src="(.*?)" alt="(.*?) &#8211; .*?" height="125px" width="119px" />').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        link=url_tara(url)  
        match1=re.compile('href="(.*?)">\n<img src="(.*?)" alt="(.*?)" height="125px" width="119px"').findall(link)
        for url,thumbnail,name in match1:
                araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
                
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"icerik(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")
        
def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        playList.clear()
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('#038;',"").replace('\xd6',"O").replace('\xfc',"u").replace('amp;',"").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        response.close()
        match=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in match:
                url='http://vk.com/'+url
                cozucu.magix_player(name,url)

               
        match1=re.compile('http:\/\/www.youtube.com\/watch\?v=(.*?)" /><param').findall(link)
        for url in match1:
                url='http://www.youtube.com/embed/'+url
                cozucu.magix_player(name,url)

