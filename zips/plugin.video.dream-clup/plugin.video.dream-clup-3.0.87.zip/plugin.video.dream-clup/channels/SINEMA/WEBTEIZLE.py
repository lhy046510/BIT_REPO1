# -*- coding: utf-8 -*-
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import araclar, cozucu,base64
from BeautifulSoup import BeautifulSoup
Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
addon_icon    = __settings__.getAddonInfo('icon')
images = 'special://home/addons/plugin.video.dream-clup/resources/images/'
FILENAME = "WEBTEIZLE"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)




############# ANA GIRIS KLASORLERI ##############################
def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        webteizleurl='http://www.webteizle.org/'
        araclar.addDir(FILENAME,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "webteizleSearch()", "",images+"search.png")
        
        
                ##### KATEGORILERI OKU EKLE #####
        link=araclar.get_url(webteizleurl)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"id": "menu"})
        liste=BeautifulSoup(str(panel))
        for li in liste.findAll('li'):
            a=li.find('a')
            url= 'http://www.webteizle.org'+a['href']
            url=url_fix(url)
            name= li.text
            name=name.encode('utf-8', 'ignore')
            name=replace_fix(name)
            araclar.addDir(FILENAME,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "webteizleRecentRecent(url)",url,"")

def webteizleRecentRecent(Url):
        link=araclar.get_url(Url)
        match=re.compile('<div class="product-image"> <a href="(.*?)" class="red-link" title=".*?"><img src="(.*?)" alt="(.*?)"').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(FILENAME,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org'+url,thumbnail)
        page=re.compile('<a href="(.*?)" title="Sonraki Sayfa">').findall(link)
        for url in page:
                name='Sonraki Sayfa'
                url='http://webteizle.org'+url
                araclar.addDir(FILENAME,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "webteizleRecentRecent(url)",url,"")


            
########	?	ARAMA	?	#######
def webteizleSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
			
        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----WEBTEIZLE YABANCI FILM-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.webteizle.org/Arama.asp?Sozcuk='+query+'&Kategori=yabanci')
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "body-center"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "product-box"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR lightgreen][B]>> - '+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org/'+url,thumbnail)

        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Webteizle Yabanci Film Acilamadi[/B][/COLOR]")')

        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----WEBTEIZLE YERLI FILM-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.webteizle.org/Arama.asp?Sozcuk='+query+'&Kategori=yerli')
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "body-center"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "product-box"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR lightgreen][B]>> - '+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org/'+url,thumbnail)
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Webteizle Yerli Film Acilamadi[/B][/COLOR]")')

        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----WEBTEIZLE YERLI DIZI-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.webteizle.org/Arama.asp?Sozcuk='+query+'&Kategori=yerlidizi')
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "body-center"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "product-box"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR lightgreen][B]>> - '+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org/'+url,thumbnail)

        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Webteizle Yerli Dizi Acilamadi[/B][/COLOR]")')

        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----WEBTEIZLE YABANCI DIZI-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.webteizle.org/Arama.asp?Sozcuk='+query+'&Kategori=yabancidizi')
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "body-center"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "product-box"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR lightgreen][B]>> - '+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org/'+url,thumbnail)
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Webteizle Yabanci Dizi Acilamadi[/B][/COLOR]")')

        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----WEBTEIZLE BELGESEL-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.webteizle.org/Arama.asp?Sozcuk='+query+'&Kategori=belgesel')
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "body-center"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "product-box"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR lightgreen][B]>> - '+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org/'+url,thumbnail)

        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Webteizle Belgesel Acilamadi[/B][/COLOR]")')

        try:
            araclar.addDir(FILENAME,'[COLOR blue][B]-----WEBTEIZLE CIZGI FILM-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.webteizle.org/Arama.asp?Sozcuk='+query+'&Kategori=cizgi')
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"id": "body-center"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "product-box"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(FILENAME,'[COLOR lightgreen][B]>> - '+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",'http://www.webteizle.org/'+url,thumbnail)
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]Webteizle Cizgi Film Acilamadi[/B][/COLOR]")')

        araclar.addDir(FILENAME,'[COLOR yellow][B]YENI ARAMA YAP[/B][/COLOR]', "webteizleSearch()","","Search")
        araclar.addDir(FILENAME,'[COLOR red][B]ANA SAYFAYA GIT[/B][/COLOR]', "main()",Url,"anasayfa")

'''#############################################################################################'''
'''#############################################################################################'''
#######################################    VIDEO    ###############################################
##def VIDEOLINKS(name,url):
##        urlList=[]
##        #---------------------------#
##        playList.clear()
##        link=araclar.get_url(url)
##		#---------------------------------------------#
##        vk=re.compile('src=".*?vk.com/(.*?)"').findall(link)
##        for url in vk:
##                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
##                url = replace_fix(url)
##                cozucu.magix_player(name,url)
##		#---------------------------------------------#
##        mailru=re.compile('Src":.*?"mail/(.*?)"').findall(link)
##        for mailrugelen in mailru:
##                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
##                url = replace_fix(url)
##                cozucu.magix_player(name,url)
##                
##        if urlList:
##                Sonuc=cozucu.videobul(urlList)
##                for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
##                        araclar.addLink(name,url,'')
##                        araclar.playlist_yap(playList,name,url) 
##                xbmcPlayer.play(playList)
##
##        else:
##             showMessage('Acilamadi', 'iptal edildi' )   showMessage(heading='SKYMC', message = '', times = 2000, pics = addon_icon):
##		try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
##		except Exception, e:
##			xbmc.log( '[%s]: showMessage: exec failed [%s]' % (addon_id, e), 1 )
def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('src=".*?vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        

        mailru=re.compilematch=re.compile('Src":.*?"mail/(.*?)"').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                urlList.append(url)


        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
            
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

            
def url_fix(x):        
        x=x.replace('/iletisim.asp','/kategori/yabanci/31/james-bond-filmleri/').replace('/filmara.htm','/kategori/yabanci/34/clint-eastwood-filmleri/').replace('http://m.webteizle.org','/kategori/yerli/11/kemal-sunal-filmleri/')
        return x
        
def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&').replace('Mobil', 'Kemal Sunal Filmleri').replace('İletişim', 'James Bond Filmleri').replace('Ana Sayfa', 'Yeni Eklenenler').replace('Film Ara', 'Client Eastwood Filmleri')
        return x
