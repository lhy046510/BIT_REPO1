# -*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS



  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="Pasha_SINEMA"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
  
def main():
    cinema='http://www.sinemadafilmizle.com/'
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]SINEMA - Son Eklenenler[/I][/B][/COLOR] ', "cinemaSinema(url)",cinema,"http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png") 
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]SINEMA - Kategorileri[/I][/B][/COLOR] ', "cinemakatsine(url)",cinema,"http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png")


def tek_link(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        match=re.compile('<i>(.*?)</i></font></font></b>\r\n<iframe src="http://vk.com/(.*?)"').findall(link)
        for name,url in match:
                url='http://vk.com/'+url
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,'') 
                


def cinemakatsine(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>').findall(link) 
        for url,name in match:
                name=name.replace('&#8211;', ' ')#.replace('&#038;', '&')
                araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR mediumaquamarine][B]'+name+'[/B][/COLOR]', "cinemaSinema(url)",url,'http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png') 
  
def cinemaSinema(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="sinema-resim">\n<a href=".*?" title=".*?">\n<div class=".*?"></div><img src="(.*?)" alt=".*?" />\n</a>\n</div>\n<div class=".*?"><a href="(.*?)" title=".*?">(.*?)</a></div>\n</div>').findall(link) 
        for thumbnail,url,name in match: 
            araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR mintcream][B]'+name+'[/B][/COLOR]', "tek_link(url)",url,thumbnail) 
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link) 
        for url,name in page: 
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>>  [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "cinemaSinema(url)",url,"http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png") 
                  
