# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="BAGLANBIZE"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        baglanfilmizle='http://www.baglanfilmizle.com/'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "baglanfilmizleRecent(url)",baglanfilmizle,"yeni")
        link=araclar.get_url(baglanfilmizle)
        match=re.compile('<li><a href="http://www.baglanfilmizle.com/film-izle/kategoriler/(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://www.baglanfilmizle.com/film-izle/kategoriler/'+url
                araclar.addDir(fileName,'[COLOR green][B][COLOR lightblue]> [/COLOR]'+name+'[/B][/COLOR]', "baglanfilmizleRecent(url)",url,"")

def baglanfilmizleRecent(url):
        link=araclar.get_url(url)
        match=re.compile('    <a href="(.*?)" title=".*?">\n    <figure><img src="(.*?)" alt="(.*?)"').findall(link)
        for url,t,name in match:
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url+'/30',t)
##        soup = BeautifulSoup(link)
##        panel = soup.findAll("div", {"class": "body"},smartQuotesTo=None)
##        panel = panel[0].findAll("div", {"class": "filmm sol"})
##        for i in range (len (panel)):
##            gelenurl=panel[i].find("div", {"class": "bt"})
##            url=gelenurl.find('a')['href'].encode('utf-8', 'ignore')
##            name=panel[i].find("div", {"class": "bs"}).text.encode('utf-8', 'ignore')
##            thumbnail=panel[i].find("img", {"class": "afis-resim"})['src'].encode('utf-8', 'ignore')
##            name=name.replace('&#8211','').replace('&#8217','')
            
				
        #############    SONRAKI SAYFA  >>>> #############
        page=re.compile('<a class="next page-numbers" href="(.*?)">').findall(link)
        for Url in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+'[/B][/COLOR]', "baglanfilmizleRecent(url)",Url,"next")
def ayrisdirma(name,url):
        link=araclar.get_url(url)
        link=link.replace('&nbsp;'," ")#.replace('(VK)','')

        fragman=re.compile('<a href="http://www.baglanfilmizle.com/(.*?)" rel="nofollow">(.*?)</a> ').findall(link)
        for url,name in fragman:
                url='http://www.baglanfilmizle.com/'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')
        match2=re.compile('<a href="(.*?)">Part(.*?)</a>').findall(link)
        for url,name in match2:
               # url='http://www.baglanfilmizle.com/'+url
                name='PART '+name
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'')

        	

def baglanfilmizleRecent2(Url):
        link=araclar.get_url(Url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("span", {"class": "filmm sol"})
        for i in range (len (panel)):
                gelenurl=panel[i].find("div", {"class": "bt"})
                url=gelenurl.find('a')['href'].encode('utf-8', 'ignore')
                name=panel[i].find("div", {"class": "bs"}).text.encode('utf-8', 'ignore')
                img=re.compile('src="(.*?)"').findall(str(panel[i]))
                for a in img:
                    if not "bt" in a:
                            thumbnail =a
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "ayrisdirma(name,url)",url+'/30',thumbnail)
        page=re.compile('<a class=\'aktif\'>.*?</a><a href=\'(.*?)\' class=\'inaktif\' >(.*?)</a>').findall(link)
        for Url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "baglanfilmizleRecent2(url)",Url,"next")
        page2=re.compile('<link rel=\'prev\' href=\'(.*?)\' />').findall(link)
        for Url in page2:
                araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa[/B][/COLOR]', "baglanfilmizleRecent2(url)",Url,"onceki")

def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x

def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)        
		#---------------------------------------------#
        youtube=re.compile(' src\="\/\/www.youtube.com\/embed\/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru4=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
