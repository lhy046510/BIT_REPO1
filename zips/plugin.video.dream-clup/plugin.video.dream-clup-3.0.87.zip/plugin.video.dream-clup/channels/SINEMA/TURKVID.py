# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="TURKVID"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        url='http://www.canlifilmizlet.com/'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.Test/resources/images/yeni.png" )
        
        ##### KATEGORILERI OKU EKLE ##########################
        
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "side-item", "id": "kats", })
        liste=BeautifulSoup(str(panel))
        for li in liste.findAll('li'):
                a=li.find('a')
                url= a['href']
                name= li.text
                name=name.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "Yeni(url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.canlifilmizlet.com/?s='+query)
            Yeni(url)

############
def Yeni(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"id": "icerik"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "film"})
        for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('a')['title'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,name,"VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('<span id="next"><a href="(.*?)" id="prev-post">(.*?)</a></span>').findall(link)
        for Url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B] >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "Yeni(url)",Url,'')
                
def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        

        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
