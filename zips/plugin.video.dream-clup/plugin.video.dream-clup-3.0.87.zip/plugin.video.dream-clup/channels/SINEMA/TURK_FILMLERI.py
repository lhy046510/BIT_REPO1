# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="TURK_FILMLERI"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://01.gen.tr/HasBahCa_IPTV/turkmovies_tsmedia.xml'
        araclar.addDir(fileName,'[COLOR red][B]>> Bilgilendirme Onemli <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
       
        link=araclar.get_url(url)
        link=link.replace('['," ").replace(']]',"").replace('CDATA',"").replace('!',"").replace('  ',"").replace('MYVIDEO.AZ',"").replace('HasBahCa',"").replace('IPTV',"").replace('http://01.gen.tr',"")
        match=re.compile('<name>(.*?)</name>\n\t\t<piconname><.*?></piconname>\t\t\n\t\t<stream_url><(.*?)></stream_url>\n\t\t').findall(link)
        for name,url in match:
            araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR pink][B]' + name+'[/B][/COLOR]',"oynatbakalim(name,url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/TURK_FILMLERI.png')

###################################################################                

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]Serverdan Kaldirilmamis ise Tum Filmler Sorunsuz Calisir.[/COLOR]","[COLOR pink]Herkese iyi seyirler[/COLOR]")
  except:
        
        pass

def oynatbakalim(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
