# -*- coding: utf-8 -*-
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import araclar, cozucu,base64
from BeautifulSoup import BeautifulSoup

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
addon_icon    = __settings__.getAddonInfo('icon')
images = 'special://home/addons/plugin.video.dream-clup/resources/images/'
fileName = "IZLETIME"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        filmifullizle='http://www.filmifullizle.com/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "filmifullizleSearch()", "",images+"search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "filmifullizleRecent(url)",filmifullizle,images+"yeni.png")

                ##### KATEGORILERI OKU EKLE #######
        link=araclar.get_url(filmifullizle)

        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "filmifullizleRecent(url)",url,"")

def filmifullizleRecent(Url):
        link=araclar.get_url(Url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("div", {"class": "post"},smartQuotesTo=None)
        panel = panel[0].findAll("div", {"class": "cover"})
        for i in range (len (panel)):
            url=panel[i].find('a')['href']
            name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
            thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
            araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "filmifullizlevideolinks(url,name,thumbnail)",url,thumbnail)

        #############    SONRAKI SAYFA  >>>> #############
        page=re.compile('class="active_page"><a href=".*?">.*?</a></li>\n<li><a href="(.*?)">(.*?)</a>').findall(link)
        for Url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "filmifullizleRecent(url)",Url,images+"sonrakisayfa.png")

        #############     ONCEKI SAYFA  <<<< #############
        page2=re.compile('<a href="(.*?)">.*?</a></li>\n<li class="active_page">').findall(link)
        for Url in page2:
                araclar.addDir(fileName,'[COLOR red][B]Onceki Sayfa[/B][/COLOR]', "filmifullizleRecent(url)",Url,images+"oncekisayfa.png")

        #############      ^^^^ANASAYFA^^^^      #############
        araclar.addDir(fileName,'[COLOR red][B]ANA SAYFA[/B][/COLOR]', "main()",Url,"anasayfa")	

        #############      ^^^^SAYFAYAGIT^^^^      #############
        araclar.addDir(fileName,'[COLOR blue][B]SAYFAYA GIT[/B][/COLOR]', "filmifullizlegit(url)",Url,"anasayfa")	
		
def filmifullizlegit(Url):
        gelengit = Url
        if 'page' in gelengit:
            page1=re.compile('(.*?)page/.*?').findall(gelengit)
            for url in page1:
                git=url
        else:
            git=gelengit+'/'
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
            Url = (git+'page/'+query)
            return filmifullizleRecent(Url)

########	?	ARAMA	?	########
def filmifullizleSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
			
        try:
            araclar.addDir(fileName,'[COLOR blue][B]-----FILMIFULLIZLE-----[/B][/COLOR]', "","","Search")
            Url = ('http://www.filmifullizle.com/'+'?s='+query)
            link=araclar.get_url(Url)
            soup = BeautifulSoup(link)
            panel = soup.findAll("div", {"class": "post"},smartQuotesTo=None)
            panel = panel[0].findAll("div", {"class": "cover"})
            for i in range (len (panel)):
                url=panel[i].find('a')['href']
                name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
                thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR green][B]>> - [/B][/COLOR]'+name, "filmifullizlevideolinks(url,name,thumbnail)",url,thumbnail)

            #############    SONRAKI SAYFA  >>>> #############
            page=re.compile('class="active_page"><a href=".*?">.*?</a></li>\n<li><a href="(.*?)">(.*?)</a>').findall(link)
            for Url,name in page:
                    araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "filmifullizleRecent(url)",Url,images+"sonrakisayfa.png")
        except:
            xbmc.executebuiltin('Notification("[COLOR yellow][B]Dream - Clup[/B][/COLOR]","[COLOR yellow][B]filmifullizle Acilamadi[/B][/COLOR]")')

        araclar.addDir(fileName,'[COLOR yellow][B]YENI ARAMA YAP[/B][/COLOR]', "filmifullizleSearch()","","Search")
        araclar.addDir(fileName,'[COLOR red][B]ANA SAYFAYA GIT[/B][/COLOR]', "main()",Url,"anasayfa")
########   linkleri topla   ########
def filmifullizlevideolinks(url,name,thumbnail):
        thumbnail=str(thumbnail)
        araclar.addDir(fileName,'[COLOR red]'+name+'[/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        try:
                link=araclar.get_url(url)
                soup = BeautifulSoup(link)
                panel = soup.findAll("div", {"id": "pagelink"})
                match=re.compile('href="(.*?)">(.*?)</a>').findall(str(panel[0]))
                for url2,name2 in match:
                    araclar.addDir(fileName,'[COLOR orange][B] >> [COLOR blue]'+str(name2)+'[COLOR orange] >> [/COLOR][COLOR lightblue]'+str(name)+'[/COLOR]',"VIDEOLINKS(name,url)",url2,thumbnail)
        except:
                pass
        return #VIDEOLINKS(name,url)

'''#############################################################################################'''
'''#############################################################################################'''
#######################################    VIDEO    ###############################################

def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('src=".*?vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        youtube=re.compile('src=".*?youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
            
def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]
        
def replace_fix(x):
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('&amp;', '&')
        return x
