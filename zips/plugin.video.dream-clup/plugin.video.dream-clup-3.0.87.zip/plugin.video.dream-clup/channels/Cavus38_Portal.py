# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64
import araclar,cozucu,urlresolver,time

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Cavus38_Portal"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
urll='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L0NhdnVzMzhfRWtsZW50aWxlci8='
def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        url='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L0NhdnVzMzhfRWtsZW50aWxlci8='
        link=araclar.get_url(base64.b64decode(url))      
        match=re.compile('<a href=".*?"> (.*?).xml</a></li>\n').findall(link)
        for url in match:
                name=url
                thumbnail=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.png'
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR lightgreen]'+name+'[/B][/COLOR]', "icerik(name,url)",url,thumbnail)

def icerik(name,url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
               araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        matchxor=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>').findall(link)
        for name,thumbnail,url in matchxor:
                araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "UrlResolver_Player(name,url)",url,thumbnail)
        match2=re.compile('<title><!\[CDATA\[ (.*?) \]\]></title>\n    <link><!\[CDATA\[(.*?)\]\]></link>\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n').findall(link)
        for name,url,thumbnail in match2:
            araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,thumbnail)      

def yeni4(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def UrlResolver_Player(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)

