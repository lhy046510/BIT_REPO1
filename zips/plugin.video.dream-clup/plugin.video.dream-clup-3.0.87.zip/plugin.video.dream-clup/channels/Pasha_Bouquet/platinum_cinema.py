import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS



  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="platinum_cinema"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
    web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
    link=araclar.get_url(base64.b64decode(web))
    match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
    for bul in match:
            bul=''
            print bul 
    olbop='https://github.com/mash2k3/MashUpTNPB/blob/master/1080p%20Movies.xml'
    olomobop='https://raw.githubusercontent.com/mash2k3/MashUpTNPB/master/kidszone.xml'
    hdforteen='https://raw.githubusercontent.com/mash2k3/Staael1982/master/2014%20HD.xml'
    hducrteen='https://raw.githubusercontent.com/mash2k3/Staael1982/master/2013%20HD.xml'
    hducdeerteen='https://raw.githubusercontent.com/mash2k3/Staael1982/master/3D.xml'
    dede='https://raw.githubusercontent.com/mash2k3/demon88/master/1080pMovies%20.xml'
    last='https://raw.githubusercontent.com/mash2k3/One242415/master/Movies/LatestRelease.xml'
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - 1080p MOVIE [/I][/B][/COLOR] ', "olbop(url)",olbop,"http://www.tosarang.net/data/file/torrent_movie_dvd/1889931251_tafG1mCE_fullhd1080p_400_01_400.jpg")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - KIDS MOVIE [/I][/B][/COLOR] ', "hducdeerteen(url)",olomobop,"http://wpuploads.appadvice.com/wp-content/uploads/2011/07/MovieRemote-Icon.png")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - 2014 HD [/I][/B][/COLOR] ', "hdforteen(url)",hdforteen,"https://cdn3.iconfinder.com/data/icons/multimedia/100/hd_sign-512.png")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - 2013 HD [/I][/B][/COLOR] ', "hducrteen(url)",hducrteen,"http://1.bp.blogspot.com/-2SNjlKBk6Zw/UN6NdoBNdJI/AAAAAAAADg0/aNvHLOTgQ54/s1600/11860261-new-year-2013-icon-golden-with-diamonds-vector.jpg")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - 3D [/I][/B][/COLOR] ', "hducdeerteen(url)",hducdeerteen,"http://img1.findthebest.com/sites/default/files/2678/media/images/_599241_i0.png")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - 1080i MOVIE [/I][/B][/COLOR] ', "hducdeerteen(url)",dede,"http://www.tosarang.net/data/file/torrent_movie_dvd/1889931251_tafG1mCE_fullhd1080p_400_01_400.jpg")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - LATEST ADDED [/I][/B][/COLOR] ', "hducdeerteen(url)",last,"http://www.perspective-espana.com/minix/wp-content/uploads/2013/09/3591814295_e063d7020f.jpg")


def olbop(url):
    web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
    link=araclar.get_url(base64.b64decode(web))
    match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
    for bul in match:
            bul=''
            print bul 
    link=araclar.get_url(url)
    match=re.compile('<span class="nt">&lt;item&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;title&gt;</span>(.*?)<span class="nt">&lt;/title&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;link&gt;</span>(.*?)<span class="nt">&lt;/link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;thumbnail&gt;</span>(.*?)<span class="nt">&lt;/thumbnail&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/item&gt;</span>').findall(link)
    for name,url,thumbnail in match:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match3=re.compile('<span class="nt">&lt;item&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;title&gt;</span>(.*?)<span class="nt">&lt;/title&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>.*?<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>(.*?)<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>.*?<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;thumbnail&gt;</span>(.*?)<span class="nt">&lt;/thumbnail&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/item&gt;</span>').findall(link)
    for name,url,humbnail in match3:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match1=re.compile('<span class="nt">&lt;item&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;title&gt;</span>(.*?)<span class="nt">&lt;/title&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>(.*?)<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>.*?<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>.*?<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;thumbnail&gt;</span>(.*?)<span class="nt">&lt;/thumbnail&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/item&gt;</span>').findall(link)
    for name,url,thumbnail in match1:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match2=re.compile('<span class="nt">&lt;item&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;title&gt;</span>(.*?)<span class="nt">&lt;/title&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>.*?<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>.*?<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;sublink&gt;</span>(.*?)<span class="nt">&lt;/sublink&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;thumbnail&gt;</span>(.*?)<span class="nt">&lt;/thumbnail&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/item&gt;</span>').findall(link)
    for name,url,thumbnail in match2:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    
def hdforteen(url):
    web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
    link=araclar.get_url(base64.b64decode(web))
    match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
    for bul in match:
            bul=''
            print bul 
    link=araclar.get_url(url)
    match=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match7=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match7:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match8=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match8:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match9=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match9:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match10=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match10:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match11=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match11:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match3=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,humbnail in match3:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match1=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match1:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match2=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match2:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match4=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match4:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match5=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match5:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match6=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match6:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)


def hducrteen(url):
    web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
    link=araclar.get_url(base64.b64decode(web))
    match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
    for bul in match:
            bul=''
            print bul 
    link=araclar.get_url(url)
    match=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match7=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match7:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match8=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match8:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match9=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match9:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match10=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match10:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match11=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match11:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match3=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,humbnail in match3:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match1=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match1:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match2=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match2:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match4=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match4:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match5=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match5:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match6=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match6:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)


def hducdeerteen(url):
    web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
    link=araclar.get_url(base64.b64decode(web))
    match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
    for bul in match:
            bul=''
            print bul 
    link=araclar.get_url(url)
    match=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match7=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match7:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match8=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match8:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match9=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match9:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match10=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match10:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match11=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match11:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match12=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>(.*?)</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match12:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match13=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match13:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match3=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,humbnail in match3:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match1=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match1:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match2=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match2:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match4=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match4:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match5=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>.*?</sublink>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match5:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)
    match6=re.compile('<item>\n<title>(.*?)</title>\n<link>\n<sublink>(.*?)</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n<sublink>.*?</sublink>\n</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    for name,url,thumbnail in match6:
        araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,thumbnail)



##def ingkategory(url): 
##        link=araclar.get_url(url) 
##        match=re.compile('<li><a href="http://www.oneclickmoviez.ag/movie-tags/(.*?)">(.*?)</a></li>\n').findall(link)
##        for url,name in match:
##            url='http://www.oneclickmoviez.ag/movie-tags/'+url
##            araclar.addDir(fileName,'[COLOR slateblue][B][COLOR yellowgreen]>>>   [/COLOR]'+name+'[/B][/COLOR]', "ingkaticerik(url)",url,'http://www.oneclickmoviez.ag/templates/svarog/images/ocm_logo.png')
#<span class="nt">&lt;item&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;title&gt;</span>(.*?)<span class="nt">&lt;/title&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;link&gt;</span>(.*?)<span class="nt">&lt;/link&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;thumbnail&gt;</span>(.*?)<span class="nt">&lt;/thumbnail&gt;</span></div><div class=\'line\' id=\'.*?\'><span class="nt">&lt;/item&gt;</span>
