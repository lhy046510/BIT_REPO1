# -*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="Pasha_Buket"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
  
def main(): 
        url='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url))
        rk=re.compile('<a href="/" >(.*?)</a><ul class="nav-child unstyled small">').findall(link)
        for url8 in rk:
                print url8+'merci'

                
        url='http://xbmctr.tv/video/3-atv'        
        link=araclar.get_url(url)
        match=re.compile('itv>>(.*?)<<ca').findall(link)
        for canlitv in match:
                print '1'
        match1=re.compile('li1>>(.*?)<<ca').findall(link)
        for canli1 in match1:
                print '2'
        match2=re.compile('iing>>(.*?)<<ca').findall(link)
        for canliing in match2:
                print '3'
        match3=re.compile('izi>>(.*?)<<TRd').findall(link)

        for TRdizi in match3:
                print '4'
        match4=re.compile('ma>>(.*?)<<si').findall(link)
        for sinema in match4:
                print '5'
        match5=re.compile('sel>>(.*?)<<be').findall(link)
        for belgesel in match5:
                print '6'
        match6=re.compile('ema>>(.*?)<<c').findall(link)
        for cinema in match6:
                print '7'
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR red][B][I]CANLI - TV[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(canlitv)),"http://tv.batmanliyiz.biz/logo.gif") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR red][B][I]CANLI - TV ALTERNATIV[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(canli1)),"http://tv.batmanliyiz.biz/logo.gif") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR red][B][I]CANLI - SPOR[/I][/B][/COLOR] ', "VIDEOLINKSS(name,url)",(base64.b64decode(canliing)),"http://tv.batmanliyiz.biz/logo.gif") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR yellow][B][I]TRdizi - Son Eklenenler[/I][/B][/COLOR]', "TRdizi(url)", TRdizi,"http://domainsigma.com/widget/trust/trdizi.tv.png") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR yellow][B][I]TRdizi - Kategoriler[/I][/B][/COLOR]', "TRdizikat(url)", TRdizi,"http://domainsigma.com/widget/trust/trdizi.tv.png") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]SINEMA - Son Eklenenler[/I][/B][/COLOR] ', "cinemaSinema(url)",cinema,"http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR pink][B][I]SINEMA - Kategorileri[/I][/B][/COLOR] ', "cinemakatsine(url)",cinema,"http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR orange][B][I]BELGESEL - Son EKLENENLER[/I][/B][/COLOR] ', "belgeselyerli(url)",belgesel,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
        araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR orange][B][I]BELGESEL - Kategorileri [/I][/B][/COLOR] ', "belgeselkat(url)",belgesel,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
  
  
def yeni4(name,url):
        url4='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url4))
        rk=re.compile('<a href="/" >(.*?)</a><ul class="nav-child unstyled small">').findall(link)
        for url8 in rk:
                print url8+'merci'
        xbmcPlayer = xbmc.Player() 
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
        playList.clear() 
        araclar.addLink(name,url,'') 
        listitem = xbmcgui.ListItem(name) 
        playList.add(url, listitem) 
        xbmcPlayer.play(playList) 
  
  

def sinema(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" title=".*?">\n\t\t\t\t\t\t<img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" title="" />\t\t\t\t\t</a>').findall(link) 
        for url,thumbnail,name in match: 
            name=name.replace('&#8211;','-').replace('&#8217;',' ').replace('&#8230;', '...') 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail) 
        page=re.compile('class=\'.*?\'>.*?</span>\n<a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a>').findall(link) 
        for url,name in page: 
            araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >> [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "sinema(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
  
  
def sinkat(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class=".*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link) 
        for url,name in match: 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>> [/COLOR]'+name+'[/B][/COLOR]', "ayrisdirmakkkscsc(name,url)",url,'') 
##        page=re.compile('<a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a>').findall(link) 
##        for url in page: 
##                araclar.addDir(fileName,'[COLOR purple][B]>> Sonraki Sayfa [/B][/COLOR]',"sinemaicerik(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png") 
  
  
def ayrisdirmakkkscsc(name,url): 
        link=araclar.get_url(url) 
        match1=re.compile('<figure class="poster">\n\t\t\t\t\t\t\t\t\t\t<a href="(.*?)" title=".*?">\n\t\t\t\t\t\t<img width="300" height=".*?" src="(.*?)" class="small-poster wp-post-image" alt="(.*?)" title="" />\t\t\t\t\t</a>\t\n\t\t\t\t</figure>').findall(link) 
        for url,thumbnail,name in match1: 
                name=name.replace('&#8211;','-').replace('&#8217;',' ').replace('&#8230;', '...') 
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"callistirir(name,url)",url,'') 
        page=re.compile('<a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a>').findall(link) 
        for url,name in page: 
                name=name.replace('&#8211;','-').replace('&#8217;',' ').replace('&#8230;', '...') 
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >> [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "sinema(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
  
  
def callistirir(name,url): 
        link=araclar.get_url(url) 
        match1=re.compile('<a class=\'.*?\' href=\'(.*?)\'>(.*?)</a>').findall(link) 
        for url,name in match1: 
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'') 
        match2=re.compile('<a href="(.*?)">(.*?)</a>').findall(link) 
        for url,name in match2: 
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'') 
##        page=re.compile('<a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a>').findall(link) 
##        for url,name in page: 
##                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >> [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "sinema(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
  
  
def name_fix(x):         
        x=x.replace('-',' ') 
        return x[0].capitalize() + x[1:] 
  
def replace_fix(x):         
        x=x.replace('&#8211;', '-').replace('&#8217;', ' ').replace('&#8230;', '...') 
        return x 
          
####################### 
def belgeselkat(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>').findall(link) 
        for url,name in match:
                print url
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "belgeselyerli(url)",url,'http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png') 
          
def belgeselyerli(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" title="(.*?)">\n\n<img src="(.*?)" class="img" alt=".*?" /></a>\n\n<h1 class="baslik"><a href=".*?" title=".*?">').findall(link) 
        for url,name,thumbnail in match:
                
                #thumbnail=thumbnail+'.jpg'
                
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "belgeselpartlama(name,url)",url,thumbnail) 
        page=re.compile('current\'>.*?</span>\n<a class=\'page-numbers\' href=\'(.*?)\'>(.*?)</a').findall(link) 
        for url,name in page: 
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "belgeselyerli(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
  
def belgeselpartlama(name,url): 
        link=araclar.get_url(url)         
        match=re.compile('<a href="(.*?)" target="_blank">(.*?).B\xc3\xb6l\xc3\xbcm</a>').findall(link) 
        for url,name in match: 
                url='http://www.sadecebelgesel.com/'+url 
                name=name+'  Bolum'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
        match2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for code in match2: 
                code=''
                  
                name='Diger Reolver Bulundu'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
        match3=re.compile('src="http://www.dailymotion.com/(.*?)">').findall(link) 
        for code in match3: 
                code='' 
                  
                name='Diger Reolver Bulundu'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
######################araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>>[/B][/COLOR]'+ name+'[COLOR red][B]'+'[/B][/COLOR]', "belgeselyerli(url)",url,'')
def tek_link(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        match=re.compile('<i>(.*?)</i></font></font></b>\r\n<iframe src="http://vk.com/(.*?)"').findall(link)
        for name,url in match:
                url='http://vk.com/'+url
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,'') 
                
  
  
def TRdizi(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="video-box">\n<div class="thumb"><a href=".*?"><img src="(.*?)" alt=".*?" width="100" height="97" /></a></div>\n<h3><a href="(.*?)" title="(.*?)</a></h3>').findall(link) 
        for thumbnail,url,name in match: 
                araclar.addDir(fileName,'[COLOR blue][B][COLOR red]>>[/COLOR]'+ name+'[/B][/COLOR]', "TRdizipartlama(name,url)",url,thumbnail) 
              
              
  
def TRdizikat(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class="item.*?"><a href="(.*?)" title="">(.*?)</a></li>').findall(link) 
        for url,name in match: 
            araclar.addDir(fileName,'[COLOR blue][B][COLOR red]>>>[/COLOR]'+ name+'[/B][/COLOR]', "katagoriicerik(url)",url,'') 
  
def katagoriicerik(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="video-box">\n<div class="thumb"><a href="(.*?)"><img src="(.*?)" alt="(.*?)" width="100" height="97" /></a></div>').findall(link) 
        for url,thumbnail,name in match: 
            araclar.addDir(fileName,'[COLOR pink][B][COLOR red]>>>[/COLOR]'+ name+'[/B][/COLOR]', "TRdizipartlama(name,url)",url,thumbnail) 
  
def TRdizipartlama(name,url): 
        link=araclar.get_url(url)         
        match=re.compile('<a class="current">Part (.*?)</a>').findall(link) 
        for name in match: 
                name='Part '+name 
                url=url 
                #code='' 
                araclar.addDir(fileName,'[COLOR brown][B][COLOR red]>>>[/COLOR]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
        match1=re.compile('<a href="(.*?)" rel="nofollow">Part (.*?)</a>').findall(link) 
        for url,name in match1: 
                name='Part '+name 
  
                araclar.addDir(fileName,'[COLOR brown][B][COLOR red]>>>[/COLOR]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
                  
##                 
##                #name='Diger Resolver Bulundu' 
##                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
##        match3=re.compile('src="http://www.dailymotion.com/(.*?)">').findall(link) 
##        for code in match3: 
##                code='' 
##                 
##                name='Diger Resolver Bulundu' 
##                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
              
  
########################### 
def cinemakatsine(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>').findall(link) 
        for url,name in match: 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "cinemaSinema(url)",url,'http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png') 
  
def cinemaSinema(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="sinema-resim">\n<a href=".*?" title=".*?">\n<div class=".*?"></div><img src="(.*?)" alt=".*?" />\n</a>\n</div>\n<div class=".*?"><a href="(.*?)" title=".*?">(.*?)</a></div>\n</div>').findall(link) 
        for thumbnail,url,name in match: 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "tek_link(url)",url,thumbnail) 
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link) 
        for url,name in page: 
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "cinemaSinema(url)",url,"http://www.fullfilmizleyin.com/wp-content/themes/tahamata-V1/images/logo.png") 
                  
def VIDEOLINKSS(name,url): 
        link=araclar.get_url(url)
        match=re.compile("<name>(.*?)</nam.*?ail>(.*?)</th.*?nk>(.*?)</link>").findall(link) 
        for name,thumbnail,url in match: 
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail) 
        match1=re.compile("<name>(.*?)</name>\n<thumbnail>(.*?)</thumbnail>\n<link>(.*?)</link>").findall(link) 
        for name,thumbnail,url in match1: 
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail) 
        match2=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link) 
        for name,thumbnail,url in match2: 
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail) 
        match3=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link> \n').findall(link) 
        for name,thumbnail,url in match3: 
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail) 
        match4=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>\n').findall(link) 
        for name,thumbnail,url in match4: 
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail) 
        match5=re.compile('#EXTINF:-1,(.*?)\n\n(.*?)\n').findall(link) 
        for name,url in match5: 
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]>[/B][/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,'') 
        match6=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link) 
        for name,url in match6: 
                araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR]''[COLOR yellow][B]---[/B][/COLOR]''[COLOR blue][B]>[/B][/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,'') 
          
##############      #
def VIDEOLINKS2(name,url):
        url4='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url4))
        rk=re.compile('<a href="/" >(.*?)</a><ul class="nav-child unstyled small">').findall(link)
        for url8 in rk:
                print url8+'merci'
        xbmcPlayer = xbmc.Player() 
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
        playList.clear() 
        araclar.addLink(name,url,'') 
        listitem = xbmcgui.ListItem(name) 
        playList.add(url, listitem) 
        xbmcPlayer.play(playList) 
################### 
def VIDEOLINKS(name,url): 
        #---------------------------# 
        urlList=[] 
        #---------------------------# 
        playList.clear() 
        link=araclar.get_url(url) 
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
  
        #---------------------------------------------# 
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for url in vk_2: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url)#
        #---------------------------------------------# 
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link) 
        for url in youtube: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        youtube1=re.compile(' value="http://www.youtube.com/v/(.*?)\?.*?"').findall(link) 
        for url in youtube1: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link) 
        for mailrugelen in mailru: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url 
                urlList.append(url) 
        mailru4=re.compile(' value\="movieSrc\=mail/(.*?)\&autoplay\=0"').findall(link) 
        for mailrugelen in mailru4: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #-------------------------------                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link) 
        for url in dm: 
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #-------------------------------  
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link) 
        for mailrugelen in mailru3: 
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link) 
        for mailrugelen in mailru2: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link) 
        for mailrugelen in mailru5: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
        for videodgelen in video: 
                url =videogelen 
                cozucu.magix_player(name,url) 
        if not urlList: 
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
                print match 
                if match: 
                        for url in match: 
                                VIDEOLINKS(name,url) 
         
        if urlList: 
                Sonuc=playerdenetle(name, urlList) 
                for name,url in Sonuc: 
                        araclar.addLink(name,url,'') 
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='') 
                        listitem.setInfo('video', {'name': name } ) 
                        playList.add(url,listitem=listitem) 
                xbmcPlayer.play(playList) 
       
def playerdenetle(name, urlList): 
        value=[] 
        import cozucu 
        for url in urlList if not isinstance(urlList, basestring) else [urlList]: 
  
  
                if "mail.ru" in url: 
                    value.append((name,cozucu.MailRu_Player(url))) 
                      
        if  value: 
            return value

