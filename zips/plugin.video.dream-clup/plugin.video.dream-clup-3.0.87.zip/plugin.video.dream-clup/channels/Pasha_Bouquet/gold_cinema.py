# -*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS



  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="gold_cinema"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
    web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
    link=araclar.get_url(base64.b64decode(web))
    match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
    for bul in match:
            bul=''
            print bul 
    ing='http://www.oneclickmoviez.ag/'
    ings='http://www.oneclickmoviez.ag/tv-shows'
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - MOVIE HOME [/I][/B][/COLOR] ', "inghome(url)",ing,"http://www.oneclickmoviez.ag/templates/svarog/images/ocm_logo.png")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - MOVIE KATEGORY [/I][/B][/COLOR] ', "ingkategory(url)",ing,"http://www.oneclickmoviez.ag/templates/svarog/images/ocm_logo.png")
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR green][B][I]ENGLISH - TV SHOWS [/I][/B][/COLOR] ', "ingshows(url)",ings,"http://www.oneclickmoviez.ag/templates/svarog/images/ocm_logo.png")


def inghome(url): 
        link=araclar.get_url(url) 
        match=re.compile('<a href="(.*?)" class="spec-border-ie" title="">\n\t\t\t            \t\t\t<img class="img-preview spec-border"  src="(.*?)" alt=" " style="width:130px;height:190px;background-color: #717171;"/>\n\t\t\t            \t\t</a>\n\t\t            \t\t\t\t            \t</div>\n\t\t                <h5 style="text-align: center;">\n\t\t                \t\t\t\t                \t<a class="link" href=".*?" title="(.*?)">\n\t\t\t\t\t\t\t\t\t.*?\n\t\t\t\t                </a>').findall(link) 
        for url,thumbnail,name in match: 
            araclar.addDir(fileName,'[COLOR seagreen][B][COLOR thistle]>>>   [/COLOR]'+name+'[/B][/COLOR]', "playericerik(url)",url,thumbnail)

def ingkategory(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li><a href="http://www.oneclickmoviez.ag/movie-tags/(.*?)">(.*?)</a></li>\n').findall(link)
        for url,name in match:
            url='http://www.oneclickmoviez.ag/movie-tags/'+url
            araclar.addDir(fileName,'[COLOR slateblue][B][COLOR yellowgreen]>>>   [/COLOR]'+name+'[/B][/COLOR]', "ingkaticerik(url)",url,'http://www.oneclickmoviez.ag/templates/svarog/images/ocm_logo.png')



def ingkaticerik(url):
        link=araclar.get_url(url)#######
        match=re.compile('src="(.*?)" alt=" " style=".*?"/>\n                                </a>\n                                                    </div>\n                        <h5 class="left">\n                                                            <a class="link" href="(.*?)" title=".*?">\n                                    (.*?)\n                                </a>').findall(link) 
        for thumbnail,url,name in match: 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "playericerik(url)",url,thumbnail)
        match1=re.compile('\t\t\t<img class="img-preview spec-border"  src="(.*?)" alt=" " style="width:130px;height:190px;background-color: #717171;"/>\n\t\t\t            \t\t</a>\n\t\t            \t\t\t\t            \t</div>\n\t\t                <h5 class="left">\n\t\t                \t\t\t\t                \t<a class="link" href="(.*?)" title="(.*?)">\n\t\t\t\t\t\t\t\t\t.*?\n\t\t\t\t').findall(link) 
        for thumbnail,url,name in match1: 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "playericerik(url)",url,thumbnail)
        match2=re.compile('<img class="img-preview spec-border"  src="http:\/\/www.oneclickmoviez.ag\/templates\/svarog\/timthumb.php\?src\=(.*?)\&amp\;w\=130\&amp;h\=190\&amp\;zc\=1" alt=" " style=".*?"/>\n                                </a>\n                                                    </div>\n                        <h5 class="left">\n                                                            <a class="link" href="(.*?)" title="(.*?)">\n').findall(link)
        for url,thumbnail,name in match2:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "playericerik(url)",url,thumbnail)

        page=re.compile('<li class=\'current\'><a href="(.*?)">(.*?)</a></li>   <li><a href=".*?">.*?</a></li>').findall(link)
        for url,name in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>  [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "ingkaticerik(url) ",url,'') 

  

def ingshows(url):
        link=araclar.get_url(url)###<li class=\'current\'><a href=".*?">.*?</a></li>   <li><a href="(.*?)">(.*?)</a></li>
        match=re.compile('<a href="http://www.oneclickmoviez.ag/show/(.*?)" class=".*?" title="">\r\n\t\t\t            \t\t\t<img class=".*?"  src="(.*?)" alt=" " />').findall(link)
        for a,b in match:
            url='http://www.oneclickmoviez.ag/show/'+a
            #http://www.oneclickmoviez.ag/templates/svarog/timthumb.php?src=http://www.oneclickmoviez.ag/thumbs/show_c0f0dfa00710ba7a24a081a624a8b0fe.jpg&amp;w=130&amp;h=190&amp;zc=1
            name=a
            name=name.replace('-',' ')
            thumbnail=b
            thumbnail=thumbnail.replace('http://www.oneclickmoviez.ag/templates/svarog/timthumb.php?src=','').replace('&amp;w=130&amp;h=190&amp;zc=1','') 
            araclar.addDir(fileName,'[COLOR royalblue][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "showsicerik(url)",url,thumbnail)
##        page=re.compile('<li class=\'current\'><a href=".*?">.*?</a></li>   <li><a href="(.*?)">(.*?)</a></li>').findall(link)#sayfalama yanlisdi yarin bakariz yat hadi kafama takildi ben biraz takilcam 
##        if page >0:
##                del page[1]
##                for url,name in page:
        match1=re.compile('\t\t\t<img class="img-preview spec-border"  src="http:\/\/www.oneclickmoviez.ag\/templates\/svarog\/timthumb.php\?src\=(.*?)\&amp\;w\=130\&amp\;h\=190\&amp\;zc\=1" alt=" " style=".*?"/>\n\t\t\t            \t\t</a>\n\t\t            \t\t\t\t            \t</div>\n\t\t                <h5 class="left">\n\t\t                \t\t\t\t                \t<a class="link" href="(.*?)" title="(.*?)"').findall(link)
        for thumbnail,url,name in match1:
                araclar.addDir(fileName,'[COLOR royalblue][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "showsicerik(url)",url,thumbnail)
        
        page=re.compile('<li class=\'current\'><a href=".*?">.*?</a></li>   <li><a href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in page:
                name='Sayfa No: '+name
                araclar.addDir(fileName,'[COLOR blue][B]  [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "ingshows(url)",url,"http://www.oneclickmoviez.ag/templates/svarog/images/ocm_logo.png") 


def showsicerik(url):
        link=araclar.get_url(url)                
        match1=re.compile('<a href=".*?" title="">\r\n\t\t            \t\t\t<img class="img-preview spec-border"  src="(.*?)" alt=" " style="width:190px;height:136px;background-color: #717171;"/>\r\n\t\t            \t\t</a>\r\n\t            \t\t\t            \t</div>\r\n\t                <h5 class="left">\r\n\t                \t\t\t\t\t\t\t\t<a class="link" href="(.*?)" title="(.*?)</a>').findall(link) 
        for thumbnail,url,name in match1: 
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "playericerik(url)",url,thumbnail)


def playericerik(url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul 
        link=araclar.get_url(url)
        match=re.compile('<span>(.*?)</span></a>\n\t                    \t                </h5>\n\t                \n\t                <ul class=".*?" style=".*?">\n\t                    \t                    \t\t                        \t<li class=".*?" style=".*?"><a href="(.*?)" target=".*?">.*?</a>').findall(link)
        for name,url in match: 
            araclar.addDir(fileName,'[COLOR teal][B][COLOR powderblue]>>-->  [/COLOR]'+name+'      ~ DVD ~[/B][/COLOR]', "cozucu.magix_player(name,url)",url,'http://rocketdock.com/images/screenshots/Blu-Ray-1.jpg')
        match1=re.compile('\t<li class="current" style="float:right"><a href="(.*?)" target="_blank">(.*?)</a></li>\n\t\t').findall(link)
        for url,name in match1: 
            araclar.addDir(fileName,'[COLOR teal][B][COLOR powderblue]>>-->  [/COLOR]'+name+'      ~ DVD ~[/B][/COLOR]', "cozucu.magix_player(name,url)",url,'http://rocketdock.com/images/screenshots/Blu-Ray-1.jpg')
##        match2=re.compile('\t<li class="current" style="float:right"><a href="http://filenuke.com/(.*?)" target="_blank">.*?</a></li>\n\t\t').findall(link)
##        for url in match2:
##                url='http://filenuke.com/'+url
##                name='FileNuke'
##                araclar.addDir(fileName,'[COLOR teal][B][COLOR powderblue]>>-->  [/COLOR]'+name+'      ~ DVD ~[/B][/COLOR]', "cozucu.magix_player(name,url)",url,'http://rocketdock.com/images/screenshots/Blu-Ray-1.jpg')

##################################
