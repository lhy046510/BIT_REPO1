# -*- coding: utf-8 -*- c by HappyFeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="Live_French"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://01.gen.tr/HasBahCa_IPTV/fransa.m3u'
        fr='http://en.iphone-tv.eu/channels/fr'
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B] French TV List [/B][/COLOR]', "french(url)", url,'http://www.studentuniverse.com/student-blog/wp-content/uploads/2012/06/francecheap.jpg')
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] French TV Buketi [/B][/COLOR]', "bobliste(url)",fr,"http://img.whitezine.com/she-is-frank5.jpeg")     
        
#def french(url):
        link=araclar.get_url(url)
        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link)
        if match >0:
                del match[0]
                for name,url in match:
                        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"oynatalimugurcuum(name,url)",url,'http://img.whitezine.com/she-is-frank5.jpeg')

def oynatalimugurcuum(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
#################################################

def bobliste(url):
        link=araclar.get_url(url)
        link=link.replace('amp;','')
        match=re.compile('<a href="(.*?)" title=".*?"><img src="(.*?)" width="90" height="80" alt="(.*?)"></a>\n').findall(link)
        for url,thumbnail,name in match:
                url='http://en.iphone-tv.eu/'+url
                thumbnail='http://en.iphone-tv.eu'+thumbnail
                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',"boblisteicerik(url)",url,thumbnail)
               
def boblisteicerik(url):
        link=araclar.get_url(url)
        match=re.compile('var\|(.*?)\|(.*?)\|(.*?)\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|\|(.*?)\|extern').findall(link)
        for index,m3,kanal,token in match:
                name='[COLOR pink]>> start play Server - 1[/COLOR]'
                m3='.'+m3+'?c='
                token='&auth='+token+'&gts=false'
                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
                url=url.replace('tv|','')
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'')
        if playList:
                playList.clear()
                xbmcPlayer.play(playList)

        match1=re.compile('\'var\|(.*?)\|\|(.*?)\|(.*?)\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|.*?\|\|(.*?)\|extern').findall(link)
        for index,m3,kanal,token in match1:
                name='[COLOR orange]>> start play Server - 2[/COLOR]'
                m3='.'+m3+'?c='
                token='&auth='+token+'&gts=false'
                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
                url=url.replace('tv|','')
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'')
        if playList:
                playList.clear()
                xbmcPlayer.play(playList)

        match2=re.compile(',\'var\|\|index\|m3u8\|(.*?)\|1345\|auth\|eu\|http\|streamURL\|ipm\|iphone\|\|tv\|(.*?)\|extern').findall(link)
        for kanal,token in match2:
                name='[COLOR pink]>> start play Server - 3 [/COLOR]'
                kanal='index.m3u8?c='+kanal
                token='&auth='+token+'&gts=false'
                url='http://ipm.iphone-tv.eu:1345/'+kanal+token
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'')
        if playList:
                playList.clear()
                xbmcPlayer.play(playList)
#################################################
