# -*- coding: utf-8 -*- by happyfeets


import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,urlresolver,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="FULL_Stream"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
##        url2='aHR0cDovL3hibWN0ci50di9jYW5saS10di92aWRlby83My1mb3gtdHY='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
        url='http://full-stream.net/index.php'
        series='http://full-stream.net/6871-les-experts-csi-las-vegas-saison-11.html'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR][COLOR orange][B]TV Series [/B][/COLOR]', "series(url)",series,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")
        araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR][COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")
        link=araclar.get_url(url)
        match=re.compile('<li><a href="/films-en-vk-streaming/(.*?)/">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://full-stream.net/films-en-vk-streaming/'+url+'/'
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")

###################################################################                
def Yeni(url):
        link=araclar.get_url(url)
        match=re.compile('<h3 class="mov-title"><a href="(.*?)">(.*?)</a></h3>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"ayris(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")
        page=re.compile('<span>.*?</span> <a href="(.*?)">.*?</a>').findall(link)
        for url in page:
                name='Sonraki Sayfa'
                araclar.addDir(fileName,'[COLOR blue][B]>> [/B][/COLOR]'+'[COLOR lightblue][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")

def ayris(url):
        link=araclar.get_url(url)
        link=link.replace('amp;','')
        thumbnail=re.compile(' href="(.*?)" onclick="return hs.expand\(this\)"').findall(link)
        for t in thumbnail:
                print t
        you=re.compile('<iframe src="http://youwatch.org/(.*?).html"').findall(link)
        for url in you:
                url='http://youwatch.org/'+str(url).encode('utf-8', 'ignore')+'.html'
                name='Server 1'
        vk=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk:
                url='http://vk.com/'+str(url).encode('utf-8', 'ignore')
                name='Server 2'
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,t)

        idi=url
        match=re.compile(' href\="\#lecteur(.*?)">  <img width="80" height="18" alt="(.*?)" src=".*?"').findall(link)
        for url,name in match:
            url=idi+'#lecteur'+url
            #t='http://full-stream.net'+t
            araclar.addDir(fileName,'[COLOR red][B]Info > [/B][/COLOR]'+'  '+name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,t)
            #araclar.addDir(fileName,'[COLOR red][B]Info > [/B][/COLOR]'+'  '+name,"VIDEOLINKS(name,url)",url,thumbnail)

def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','%20')
            url = ('http://full-stream.net/index.php?story={'+query+'}&do=search&subaction=search')
            Yeni(url)


def series(url):
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)"> (.*?) </a></li>').findall(link)
        for url,name in match:
                url=url.replace(' ','%20')
                url='http://full-stream.net'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"seasons(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/Full_Stream.png")

def seasons(url):
        link=araclar.get_url(url)
        thumbnail=re.compile(' class="full-stream-view full-stream-view-hover">\n<img src="\/IMG\/full-stream.php\?src\=(.*?)\&amp\;w\=210\&amp\;h\=280" ').findall(link)
        for t in thumbnail:
                print t
        match=re.compile('<h3 class="mov-title"><a href="(.*?)">(.*?)</a></h3>').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"seriess(url)",url,t)

def seriess(url):
        link=araclar.get_url(url)
        thumbnail=re.compile(' href="(.*?)" onclick="return hs.expand\(this\)"').findall(link)
        for t in thumbnail:
                print t
        match=re.compile('\r\n<a href="(.*?)" title="(.*?)" ').findall(link)
        for url,name in match:
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,t)

        
def UrlResolver_Player(name,url):
##        safe='aHR0cDovL3d3dy54Ym1jdHIudHYvdmlkZW8vMzAtcGxhbmV0LXR1cms='
##        link=araclar.get_url(base64.b64decode(safe))
##        match1=re.compile('sir>>(.*?)<<be').findall(link)
##        for kkk in match1:
##                print kkk
        UrlResolverPlayer = url 
        playList.clear() 
        media = urlresolver.HostedMediaFile(UrlResolverPlayer) 
        source = media 
        if source: 
                url = source.resolve() 
                araclar.addLink(name,url,'') 
                araclar.playlist_yap(playList,name,url) 
                xbmcPlayer.play(playList)
