# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="FILMZE"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

web='http://www.filmze.la'

############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://www.filmze.la'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
        
                ##### KATEGORILERI OKU EKLE ##########################
        
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?">(.*?) </a>').findall(link)
        for url,name in match:               
                araclar.addDir(fileName,'[COLOR orange][B]>>[/B][/COLOR] '+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Edit(url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://www.filmze.com/search.php?query='+query)
            Edit(url)

############
def Yeni(url):
        link=araclar.get_url(url)
        soup = BeautifulSoup(link)
        panel = soup.findAll("table", {"class": "videowalltable"},smartQuotesTo=None)
        panel = panel[0].findAll("td", {"align": "center"})
        for i in range (len (panel)):
            url=panel[i].find('a')['href']
            name=panel[i].find('img')['alt'].encode('utf-8', 'ignore')
            thumbnail=panel[i].find('img')['src'].encode('utf-8', 'ignore')
            name=name.replace("Regarder","").replace("Streaming","")
            araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)

                           
        
###########        
def Edit(url):
        link=araclar.get_url(url)       
        match=re.compile('<a href="(.*?)"> \r\n\r\n\r\n\r\n\r\n\r\n\r\n          \r\n\r\n\r\n\r\n\r\n\r\n\r\n          \r\n\r\n\r\n\r\n\r\n\r\n\r\n           <img src="(.*?)" width=120px alt=".*?" /><br />\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n                \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n           <font face="Arial" style="font-size: 9pt">(.*?)</font>').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR lightblue][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

        page=re.compile('<td class="paginact"><a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                url=web+url
                #url=replace_fix(url)
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Edit(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")
                                

        
#############
def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        
        vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        for url in divxstage:
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        	#---------------------------------------------#
##        youtube2=re.compile('src=".*?.youtube.com/embed/(.*?)?feature=player_detailpage"').findall(link)
##        for url in youtube2:
##                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
##                cozucu.magix_player(name,url)
		#---------------------------------------------#
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        for url in movshare:
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
        for url,uploadcgelen in uploadc:
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                #print url
                urlList.append(url)

        #-------------------------------
        mailru4=re.compile('"movieSrc":   "mail/(.*?)"').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru5:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
        for url,divxstagegelen in divxstage:
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
