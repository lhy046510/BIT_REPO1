# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="UZMANTV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://www.uzmantv.com/'
        araclar.addDir(fileName,'[COLOR blue][B]>>  Bilgilendirme  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/icon.png')
        araclar.addDir(fileName,'[COLOR pink][B]~~ Uzman ~~[/COLOR][/B] [COLOR red]>>>>[/COLOR][COLOR turquoise] ARA [/COLOR][COLOR red]<<<<[/COLOR]', "Search()", "",'https://pbs.twimg.com/profile_images/378800000542381647/6ba320404c70c48568fad0d11877e61f.png')
       
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)" title=".*?"  >(.*?)</a></li>\n').findall(link)
        for url,name, in match:
                url='http://www.uzmantv.com'+url
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,'http://www.iptv.org.tr/iptv/wp-content/uploads/2011/01/uzmantv_logo-e1294047835649.jpg')
        match=re.compile('<li class="level1"><a href="(.*?)" class="">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://www.uzmantv.com/kategori/'+url   
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,"")
                      
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.uzmantv.com/arama?q='+query)
            bulucu(url)

def get_url(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/230008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb1',"i").replace('\xc3\xb6',"O").replace('\xc3\xbc',"u").replace('\xc5\x9f',"s").replace('\xc3\xa7',"c").replace('\xe2\x80\x93',"").replace('\xc4\xb0',"i").replace('&#8211;'," ").replace('&#8211;'," ").replace('\xc5\x9e',"S")#.replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        return link

def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('div class=".*?">\n                                <a href="(.*?)" title="(.*?)">\n                                    <img src="(.*?)"\n                                         class=".*?" height=".*?" width=".*?">\n                                    <span class=".*?"></span>').findall(link)
        for url,name,thumbnail in match:
                url='http://www.uzmantv.com'+url
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        match=re.compile('<li class="level1"><a href="(.*?)" class="">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://www.uzmantv.com/kategori/'+url   
                araclar.addDir(fileName,'[COLOR brown][B]Hizli Kategori ~~~ [/COLOR][/B][COLOR orange][B]'+name+'[/B][/COLOR]',"altliste(url)",url,thumbnail)

def altliste(url):
        link=araclar.get_url(url)
        match=re.compile('div class=".*?">\n                                <a href="(.*?)" title="(.*?)">\n                                    <img src="(.*?)"\n                                         class=".*?" height=".*?" width=".*?">\n                                    <span class=".*?"></span>').findall(link)
        for url,name,thumbnail in match:
            url='http://www.uzmantv.com'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        match=re.compile('<li class="level1"><a href="(.*?)" class="">(.*?)</a></li>').findall(link)
        for url,name in match:
            url='http://www.uzmantv.com/kategori/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)


def bulucu(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title="(.*?)" itemprop=".*?">\n                      <img src="(.*?)" width=".*?" height=".*?" class=".*?" itemprop=".*?" >').findall(link)
        for url,name,thumbnail in match:
                url='http://www.uzmantv.com'+url
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        sayfalama=re.compile('<a href="(.*?)" class=".*?">(.*?)</a></div>').findall(link) 
        for url,name in sayfalama:
                url='http://www.uzmantv.com'+url
                araclar.addDir(fileName,'[COLOR purple][B]'+name+' Sayfa [/B][/COLOR]',"bulucu(url)",url,thumbnail)
                
def VIDEOLINKS(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()

        link=get_url(url)
        match=re.compile('content="http://(.*?).mp4"').findall(link)
        for url in match:
                url='http://'+url+'.mp4'

                playList.add(name)
                addLink(name,url,'')
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(playList)

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok
