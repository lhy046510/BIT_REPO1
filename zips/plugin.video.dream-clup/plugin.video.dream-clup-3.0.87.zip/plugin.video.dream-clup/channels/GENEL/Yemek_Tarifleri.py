# -*- coding: utf-8 -*- happyfeets
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="Yemek_Tarifleri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        yemek='http://video.lezzetler.com'
        corba='http://video.lezzetler.com/video-corba-tarifleri'
        salata='http://video.lezzetler.com/video-salata-tarifleri'
        makarna='http://video.lezzetler.com/video-makarna-tarifleri'
        pilav='http://video.lezzetler.com/video-pilav-tarifleri'
        yumurta='http://video.lezzetler.com/video-yumurta-tarifleri'
        sebze='http://video.lezzetler.com/video-sebze-tarifleri'
        zeytin='http://video.lezzetler.com/video-zeytinyagli-tarifleri'
        dolma='http://video.lezzetler.com/video-dolma-tarifleri'
        bakla='http://video.lezzetler.com/video-baklagil-tarifleri'
        et='http://video.lezzetler.com/video-et-yemegi-tarifleri'
        kebap='http://video.lezzetler.com/video-kebap-tarifleri'
        kofte='http://video.lezzetler.com/video-kofte-tarifleri'
        sakatat='http://video.lezzetler.com/video-sakatat-tarifleri'
        tavuk='http://video.lezzetler.com/video-tavuk-tarifleri'
        balik='http://video.lezzetler.com/video-balik-tarifleri'
        recel='http://video.lezzetler.com/video-recel-tarifleri'
        tursu='http://video.lezzetler.com/video-tursu-tarifleri'
        sos='http://video.lezzetler.com/video-sos-tarifleri'
        kek='http://video.lezzetler.com/video-kek-tarifleri'
        kurabiye='http://video.lezzetler.com/video-kurabiye-tarifleri'
        pasta='http://video.lezzetler.com/video-pasta-tarifleri'
        hamur='http://video.lezzetler.com/video-hamur-isi-tarifleri'
        borek='http://video.lezzetler.com/video-borek-tarifleri'
        corek='http://video.lezzetler.com/video-corek-tarifleri'
        serbet='http://video.lezzetler.com/video-serbetli-tatli-tarifleri'
        sutlu='http://video.lezzetler.com/video-sutlu-tatli-tarifleri'
        meyve='http://video.lezzetler.com/video-meyve-tatli-tarifleri'
        helva='http://video.lezzetler.com/video-helva-tarifleri'
        kanepe='http://video.lezzetler.com/video-kanepe-tarifleri'
        icecek='http://video.lezzetler.com/video-icecek-tarifleri'
        sekerleme='http://video.lezzetler.com/video-sekerleme-tarifleri'
        yoresel='http://video.lezzetler.com/video-yoresel-tarifleri'
        yabanci='http://video.lezzetler.com/video-yabanci-tarifleri'
        ramazanbayrami='http://video.lezzetler.com/video-ramazan-tarifleri'
        geleneksel='http://video.lezzetler.com/video-geleneksel-tarifleri'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yemek Tarifleri Genel Gorunum[/B][/COLOR]', "Yerli(url)", yemek,"http://3.bp.blogspot.com/-x1e81CWxh6c/UM4rvMlazlI/AAAAAAAAEAw/UYg6U_WHgtQ/s1600/lezzet.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Corba Tarifleri[/B][/COLOR]', "Yerli(url)", corba,"http://www.selva.com.tr/Images/CorbaSefasi/Tarif/Sebzeli-Sehriye-Corbasi.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]Salata Tarifleri[/B][/COLOR]', "Yerli(url)", salata,"http://tavacifettahusta.com/wp-content/uploads/2013/01/mevsim-salata.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Makarna Tarifleri[/B][/COLOR]', "Yerli(url)", makarna,"http://media.dunyabulteni.net/250x190/2010/10/24/makarna.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR yellow][B]Pilav Tarifleri[/B][/COLOR]', "Yerli(url)", pilav,"http://2.bp.blogspot.com/-3xv5KD-uovI/UE5SoZZ85FI/AAAAAAAAAUY/BhChP2DWr2I/s1600/Bezelyeli-Pilav.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Yumurta ile Yapilan Tarifler[/B][/COLOR]', "Yerli(url)", yumurta,"http://static.uzmantv.com/articles/125/n0dQVQPIYnh/1.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Sebze Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", sebze,"http://resim.nepisirsem.com/resimliyemek/ispanak-borani.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Zeytin Yagli Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", zeytin,"http://www.portakalagaci.com/oburcuk/images/imambayildi.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]Dolma Tarifleri[/B][/COLOR]', "Yerli(url)", dolma,"http://upload.wikimedia.org/wikipedia/commons/0/0b/Dolma.JPG")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Baklagil ile Yapilan Tarifleri[/B][/COLOR]', "Yerli(url)", bakla,"http://resim.nepisirsem.com/resimliyemek/kuru_fasulye.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR yellow][B]Et Yemegi Tarifleri[/B][/COLOR]', "Yerli(url)", et,"http://www.yemex.com/upload/450x450/et-sote---sac-kavurma-yemek-1.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Kebap Tarifleri[/B][/COLOR]', "Yerli(url)", kebap,"http://www.kolayresimliyemektarifleri.com/images/yogurtlu_kebap.gif")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Kofte Tarifleri[/B][/COLOR]', "Yerli(url)", kofte,"http://farm6.staticflickr.com/5516/10314111275_61fcecda3d_c.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Sakatat Tarifleri[/B][/COLOR]', "Yerli(url)", sakatat,"http://www.ajans5.com/photos/arsiv/1/1861.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]Tavuk Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", tavuk,"http://www.trendyemektarifleri.com/wp-content/uploads/pilic-sis.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Balik Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", balik,"http://im.haberturk.com/2011/04/14/620772_detay.jpg?1302776253")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR yellow][B]Recel Tarifleri[/B][/COLOR]', "Yerli(url)", recel,"http://www.evdeimalat.com/wp-content/uploads/2011/08/re%C3%A7el1.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Tursu Tarifleri[/B][/COLOR]', "Yerli(url)", tursu,"http://www.regindex.com/wp-content/uploads/karisik-tursu-tarifi.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Sos Tarifleri[/B][/COLOR]', "Yerli(url)", sos,"http://img.yemektarifleri.com/photos/16298/1299449513_1_400.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Kek Tarifleri[/B][/COLOR]', "Yerli(url)", kek,"http://cafefernando.com/images/cikolatali_kek.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]Kurabiye Tarifleri[/B][/COLOR]', "Yerli(url)", kurabiye,"http://www.oktayustatarifleri.co/wp-content/uploads/j10xo8.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Pasta Tarifleri[/B][/COLOR]', "Yerli(url)", pasta,"http://www.yemektarifleri8.com/img/1214603297tum_resimler_002.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Hamur isi Tarifleri[/B][/COLOR]', "Yerli(url)", hamur,"http://www.lezzetliyemektarifi.com/wp-content/uploads/2012/02/tn_hamur-i%C5%9Fleri.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Borek Tarifleri[/B][/COLOR]', "Yerli(url)", borek,"http://www.balkantravellers.com/images/stories/food/spinach-burek.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]Corek Tarifleri[/B][/COLOR]', "Yerli(url)", corek,"http://www.kadinlar.tc/wp-content/uploads/2009/09/Cevizli-%C3%87%C3%B6rek.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Serbetli Tatli Tarifleri[/B][/COLOR]', "Yerli(url)", serbet,"http://galeri.uludagsozluk.com/32/serbet_64116.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Sutlu Tatli Tarifleri[/B][/COLOR]', "Yerli(url)", sutlu,"http://yemektarifleri.tatlialem.net/wp-content/uploads/2013/09/tatlialem-tatl%C4%B1tarifleri72.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR yellow][B]Meyveli Tatli Tarifleri[/B][/COLOR]', "Yerli(url)", meyve,"http://www.oktayusta.net/wp-content/uploads/2013/07/Kar%C4%B1%C5%9F%C4%B1k-Meyveli-Kup.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Helva Tarifleri[/B][/COLOR]', "Yerli(url)", helva,"http://4.bp.blogspot.com/_YOkRG1va6QQ/Sc0sPN_QVMI/AAAAAAAAAZI/xjmdT_sYb8E/s1600-h/misir_unlu_helva%5B1%5D.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Kanepe Tarifleri[/B][/COLOR]', "Yerli(url)", kanepe,"http://1.bp.blogspot.com/-sr-RLq1Lnjs/UAJwgfMs3sI/AAAAAAAAAf4/DSwx0ZfM08w/s1600/1dba4f52351e58d68d88c5fe23514341_1322684580.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR brown][B]icecek Tarifleri[/B][/COLOR]', "Yerli(url)", icecek,"http://www.naxi.rs/media/images/o/Hrana-letnji-kokteli.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Sekerleme Tarifleri[/B][/COLOR]', "Yerli(url)", sekerleme,"http://www.mevlutsekerim.com/b_images/sekerleme-jole.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]Yoresel Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", yoresel,"http://www.enfesyemektarifi.com/images/izmir-kofte/izmir_kofte_00.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR yellow][B]Geleneksel Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", geleneksel,"http://www.meleklermekani.com/imagehosting/istanbul_yoresel_yemekleri-279.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yabanci Yemek Tarifleri[/B][/COLOR]', "Yerli(url)", yabanci,"http://www.gastronomi.com.tr/images/haberler/unutulmus_istanbul_yemekleri_modern_sunumlarla_bulustu_h1242.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B]Bayrama Ozel Tarifler[/B][/COLOR]', "Yerli(url)", ramazanbayrami,"http://db2.stb.s-msn.com/i/B5/A29DFF415C61DEEE58972C336A9F98_h338_w598_m2_q90_cdUGTTcXB.jpg")
             
def Yerli(url):
        link=araclar.get_url(url)
        link=link.replace('\xfe',"s").replace('\xfd',"i").replace('\xdd',"I").replace('\xf0',"g").replace('\xde',"S").replace('\xf6',"o")
        match=re.compile('<td class="saridolgu" width="160" align="center" valign="top" style="padding: 6">\n<a href="(.*?)" target=\'_blank\' class=".*?"><img border="0" src="(.*?)" width="146" height="110" alt="(.*?)">').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "Youtube(url)",url,thumbnail)
        page=re.compile('&nbsp;&nbsp;<a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            name=name.replace('&raquo;','')
            url='http://video.lezzetler.com/'+url
            araclar.addDir(fileName,'[COLOR blue][B]Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "Yerli(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

def Youtube(url):
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                link=araclar.get_url(url)
                you_match=re.compile('<embed src="http:\/\/www.youtube.com\/v\/(.*?)\?version=3&amp;hl=en_US&amp;rel=0&amo;autoplay=1" type="application/x-shockwave-flash" width="400" height="300" allowscriptaccess="always" allowfullscreen="true"></embed>').findall(link)
                for code in you_match:
                        yt=('plugin://plugin.video.youtube/?action=play_video&videoid='+str(code))
                        araclar.addLink('~~izle~~',yt,'')
                        playList.add(yt)
                xbmcPlayer.play(playList)
                if not xbmcPlayer.isPlayingVideo():
                        d = xbmcgui.Dialog()
