# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString
#art = main.art

#---------------------------------------------------


fileName="XbmcTR_DUYURU"

        
def main():
        url='http://xbmctr.com/livetv/duyurular/duyuru.xml'
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>').findall(link)
        for name in match:
                url='http://xbmctr.com/final.flv'
                thumbnail='http://www.mirrorservice.org/sites/addons.superrepo.org/Frodo/.metadata/script.xbmctr.png'
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)
        url='http://xbmctr.com/livetv/duyurular/duyuru.xml'
        link=araclar.get_url(url)
        match1=re.compile('<admin>(.*?)</admin>').findall(link)
        for name in match1:
                url='http://xbmctr.com/final.flv'
                thumbnail='http://www.mirrorservice.org/sites/addons.superrepo.org/Frodo/.metadata/script.xbmctr.png'
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)
        url='http://xbmctr.com/livetv/duyurular/duyuru.xml'
        link=araclar.get_url(url)
        match=re.compile('<smod>(.*?)</smod>').findall(link)
        for name in match:
                url='http://xbmctr.com/final.flv'
                thumbnail='http://www.mirrorservice.org/sites/addons.superrepo.org/Frodo/.metadata/script.xbmctr.png'
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)
        url='http://xbmctr.com/livetv/duyurular/duyuru.xml'
        link=araclar.get_url(url)
        match=re.compile('<mod>(.*?)</mod>').findall(link)
        for name in match:
                url='http://xbmctr.com/final.flv'
                thumbnail='http://www.mirrorservice.org/sites/addons.superrepo.org/Frodo/.metadata/script.xbmctr.png'
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)
        url='http://xbmctr.com/livetv/duyurular/duyuru.xml'
        link=araclar.get_url(url)
        match=re.compile('<moda>(.*?)</moda>').findall(link)
        for name in match:
                url='http://xbmctr.com/final.flv'
                thumbnail='http://www.mirrorservice.org/sites/addons.superrepo.org/Frodo/.metadata/script.xbmctr.png'
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)
def VIDEOLINKS(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
        




