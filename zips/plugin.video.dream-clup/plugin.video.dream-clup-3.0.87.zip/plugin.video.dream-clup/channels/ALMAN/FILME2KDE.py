# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
import urllib,urllib2,re,cookielib

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="FILME2KDE"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://www.filme2k.net/'
        #araclar.addDir(fileName,name,"mode(name,url)",url,thumbnail)
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Yeni Eklenen Filmler [/B][/COLOR]', "Yeni(name,url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/yeni.png" )
                ##### KATEGORILERI OKU EKLE ##########################
        
        link=araclar.get_url(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link)
        for url,name in match:               
                araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"Yeni(name,url)",url,"")

###################################################################                

                                                
######                       
def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://www.filme2k.net/?s='+query)
            Yeni(name,url)

############
def Yeni(name,url):
        link=araclar.get_url(url)  
        match=re.compile('<a class="coverimg" title=".*?" href="(.*?)"><img src="(.*?)" width="150" height="220" alt="(.*?)" title=".*?" />').findall(link)
        for url,thumbnail,name in match:
                #url = url+'/2'
                try:
                    reg=re.search(r'&#(.*?);', name).group(1)
                    name=name.replace('&#'+reg+';', '-')
                except:
                        pass
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"tek(name,url)",url,thumbnail)
                #print thumbnail

        page=re.compile('current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a>').findall(link)
        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"Yeni(name,url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     
        
###########        
        
      
def tek(name,url):
        playList.clear()
        link=araclar.get_url(url)  
        match=re.compile('<a href="http://streamcloud.eu/(.*?)"').findall(link)
        for url in match:
                
                url='http://streamcloud.eu/'+url
                Sonuc=cozucu.videobul(url)
                #print "donen sonuc",Sonuc
                if Sonuc=="False":
                        dialog = xbmcgui.Dialog()
                        i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yüklenecektir.  ")
                        return False 
                else:                                
                        for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                                        araclar.addLink(name,url,'')
                                        araclar.playlist_yap(playList,name,url) 
                        xbmcPlayer.play(playList)
        
