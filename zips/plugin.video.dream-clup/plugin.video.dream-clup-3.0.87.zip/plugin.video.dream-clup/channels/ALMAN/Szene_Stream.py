# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,urlresolver,base64
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="Szene_Stream"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        url='http://www.szene-streams.com/'
        araclar.addDir(fileName,'[COLOR gold][B]>>>>>>[/B][/COLOR][COLOR yellow][B] Neue Filme[/B][/COLOR][COLOR gold][B] <<<<<[/B][/COLOR]', "Yeni2(url)", url,"special://home/addons/plugin.video.Test/resources/images/search.png")
        link=araclar.get_url(url)
        match=re.compile('href="(.*?)">  <div class="CatWrapInf">  <div class="CatNumInf">(.*?)</div>  <div class="CatNameInf">(.*?)</div>').findall(link)
        for url,a,b in match:
                url='http://www.szene-streams.com'+url
                name=b+ ' { '+a+' }'
                araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]', "Yeni(url)",url,"")

def Yeni(url):
    link=araclar.get_url(url)
    soup = BeautifulSoup(link)
    panel = soup.findAll("div", {"style": "float:left; width:50%;"},smartQuotesTo=None)
    for i in range (len (panel)):

        div1=panel[i].findAll("div", {"class": "ImgWrapNews"},smartQuotesTo=None)
        thumbnail=panel[i].find('a')['href'].encode('ISO-8859-1', 'ignore')
        name=panel[i].find('img')['alt'].encode('ISO-8859-1', 'ignore')
        div2=panel[i].findAll("a", {"class": "newstitl entryLink"},smartQuotesTo=None)
        url= div2[0]['href']
        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"Linkler(url)",url,thumbnail)
                

                         

    page=re.compile('<b class="swchItemA"><span>.*?</span></b>  <a class="swchItem" href="(.*?)" onclick=".*?"><span>(.*?)</span>').findall(link)       
    for url,name in page:
            if page >1:
                    del page[1]
                    
                
                    araclar.addDir(fileName,'[COLOR purple][B]>>'+'Sayfa ' + name+'[/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.Test/resources/images/sonrakisayfa.png")

def Yeni2(url):
    print 'geldim'    
    link=araclar.get_url(url)
    soup = BeautifulSoup(link)
    panel = soup.findAll("div", {"style": "float:left; width:50%;"},smartQuotesTo=None)
    for i in range (len (panel)):

        div1=panel[i].findAll("div", {"class": "ImgWrapNews"},smartQuotesTo=None)
        thumbnail=panel[i].find('a')['href'].encode('ISO-8859-1', 'ignore')
        name=panel[i].find('img')['alt'].encode('ISO-8859-1', 'ignore')
        div2=panel[i].findAll("a", {"class": "newstitl entryLink"},smartQuotesTo=None)
        url= div2[0]['href']
        url='http://www.szene-streams.com'+url
        araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"Linkler(url)",url,thumbnail)
                

                         

    page=re.compile('<b class="swchItemA"><span>.*?</span></b>  <a class="swchItem" href="(.*?)" onclick=".*?"><span>(.*?)</span>').findall(link)       
    for url,name in page:
            if page >1:
                    del page[1]
                    
                
                    araclar.addDir(fileName,'[COLOR purple][B]>>'+'Sayfa ' + name+'[/B][/COLOR]',"Yeni2(url)",url,"special://home/addons/plugin.video.Test/resources/images/sonrakisayfa.png")


def Linkler(url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)
        match=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in match:
                url='http://www.youtube.com/embed/'+url
                
                araclar.addDir(fileName,'Trailer >>',"cozucu.magix_player(name,url)",url,'')
        match1=re.compile('href="\n\nhttp://vidstream.in/(.*?)\n\n">').findall(link)
        for url in match1:
                url='http://vidstream.in/'+url
                
                araclar.addDir(fileName,'VidStream    >>',"cozucu.magix_player(name,url)",url,'')
        match2=re.compile('href="\n\nhttp://www.divxstage.eu/video/(.*?)\n\n">').findall(link)
        for url in match2:
                url='http://www.divxstage.eu/video/'+url
                
                araclar.addDir(fileName,'DivxStage    >>',"cozucu.magix_player(name,url)",url,'')
        match3=re.compile('href="\n\nhttp://primeshare.tv/download/(.*?)\n\n">').findall(link)
        for url in match3:
                url='http://primeshare.tv/download/'+url
                
                araclar.addDir(fileName,'PrimeShare    >>',"cozucu.magix_player(name,url)",url,'')
        match4=re.compile('href="\n\nhttp://www.movshare.net/video/(.*?)\n\n">').findall(link)
        for code in match4:
                code=''
                
                araclar.addDir(fileName,'MovShare    >>',"NowVideo(name,url)",url,'')
        match9=re.compile('href="\n\nhttp://www.nowvideo.sx/video/(.*?)\n\n">').findall(link)
        for url in match9:
                url='http://www.nowvideo.sx/video/'+url
                
                araclar.addDir(fileName,'NowVideo    >>',"cozucu.magix_player(name,url)",url,'')
        match8=re.compile('href="\n\nhttp://streamcloud.eu/(.*?)\n\n">').findall(link)
        for url in match8:
                url='http://streamcloud.eu/'+url
                
                araclar.addDir(fileName,'Stream Cloud   >>',"cozucu.magix_player(name,url)",url,'')
        match5=re.compile('href="http://played.to/(.*?)">').findall(link)
        for url in match5:
                url='http://played.to/'+url
                
                araclar.addDir(fileName,'Played   >>',"cozucu.magix_player(name,url)",url,'')
        match6=re.compile('href="http://xvidstage.com/(.*?)">').findall(link)
        for url in match6:
                url='http://xvidstage.com/'+url
                
                araclar.addDir(fileName,'XvidStage   >>',"cozucu.magix_player(name,url)",url,'')
        match7=re.compile('href="http://faststream.in/(.*?)">').findall(link)
        for url in match7:
                url='http://faststream.in/'+url
                
                araclar.addDir(fileName,'FastStream   >>',"cozucu.magix_player(name,url)",url,'')
        match10=re.compile('href="http://youwatch.org/(.*?)">').findall(link)
        for url in match10:
                url='http://youwatch.org/'+url
                
                araclar.addDir(fileName,'YouWATCH   >>',"cozucu.magix_player(name,url)",url,'')
        match11=re.compile('href="http://streamcloud.eu/(.*?)">').findall(link)
        for url in match11:
                url='http://streamcloud.eu/'+url
                
                araclar.addDir(fileName,'StreamCLD   >>',"cozucu.magix_player(name,url)",url,'')




       


def name_fix(x):        
        x=x.replace('-',' ').replace('_',' ')
        return x[0].capitalize() + x[1:]
        
def replace_fix(x):        
        x=x.replace('&#8211;', '-').replace('&#038;', '&').replace('http://loads7.com/blog/', '').replace('http://loads7.com', '').replace(' ', '')
        return x
       
