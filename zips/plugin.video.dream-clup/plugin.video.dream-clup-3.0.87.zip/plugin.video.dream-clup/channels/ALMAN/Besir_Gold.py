# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Besir_Gold"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        FILMSAATI='http://gold-streams.eu/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B]Film Suche - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<[/B][/COLOR]', "Search()", "","search.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Neue Filme [/B][/COLOR]', "FILMSAATIRecent(url)",FILMSAATI,"yeni")
        link=araclar.get_url(FILMSAATI)
        link=link.replace("xxx","")
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>').findall(link)
        for url,name in match:
            if match >1:
                del match[-1]
                araclar.addDir(fileName,'[COLOR green][B][COLOR red]>[/COLOR]'+name+'[/B][/COLOR]', "kategoriicerik(url)",url,"")



def FILMSAATIRecent(url):
        link=araclar.get_url(url)
        match=re.compile('href="(.*?)" rel="bookmark" title="(.*?)">\n             <img width="95" height="102" src="(.*?)" class=" wp-post-image" alt=".*?" />').findall(link)
        for url,name,thumbnail in match:
                name=name.replace('&#8211','').replace('&','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('<link rel=\'next\' href=\'(.*?)\'').findall(link)
        for url in page:
                url=url.replace('#038;','')
                name='Sonraki Sayfa'
                araclar.addDir(fileName,'[COLOR red][B] '+name+'[/B][/COLOR]', "kategoriicerik(url)",url,"")


def kategoriicerik(url):
        link=araclar.get_url(url)
        
        match=re.compile('href="(.*?)" rel="bookmark" title="(.*?)">\r\n             <img width=".*?" height=".*?" src="(.*?)"').findall(link)
        
        for url,name,thumbnail in match:
                name=name.replace('&#8211','').replace('&','').replace('burayagozukmemesini istedigini koy','')
                thumbnail=thumbnail.replace('-140x150','')
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('<link rel=\'next\' href=\'(.*?)\'').findall(link)
        for url in page:
                url=url.replace('#038;','')
                name='Sonraki Sayfa'
                araclar.addDir(fileName,'[COLOR red][B] '+name+'[/B][/COLOR]', "kategoriicerik(url)",url,"")

        
def searchcikart(url):
        link=araclar.get_url(url)
        match=re.compile('<a class="widget-title" href="(.*?)"><img src="(.*?)" alt="(.*?)" title=".*?"').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR cyan][B]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
            
def Search():#http://gold-streams.eu/?s=matrix&x=0&y=0
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            url = ('http://gold-streams.eu/?s='+query+'&x=0&y=0')
            searchcikart(url)




def VIDEOLINKS(name,url):
        link=araclar.get_url(url)
        match=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in match:
                url='http://www.youtube.com/embed/'+url
                araclar.addDir(fileName,'Trailer >>',"cozucu.magix_player(name,url)",url,'')
        match1=re.compile('href="\n\nhttp://vidstream.in/(.*?)\n\n">').findall(link)
        for url in match1:
                url='http://vidstream.in/'+url
                araclar.addDir(fileName,'VidStream    >>',"cozucu.magix_player(name,url)",url,'')
        match2=re.compile('href="\n\nhttp://www.divxstage.eu/video/(.*?)\n\n">').findall(link)
        for url in match2:
                url='http://www.divxstage.eu/video/'+url                
                araclar.addDir(fileName,'DivxStage    >>',"cozucu.magix_player(name,url)",url,'')
        match3=re.compile('href="\n\nhttp://primeshare.tv/download/(.*?)\n\n">').findall(link)
        for url in match3:
                url='http://primeshare.tv/download/'+url               
                araclar.addDir(fileName,'PrimeShare    >>',"cozucu.magix_player(name,url)",url,'')
        match4=re.compile('href="\n\nhttp://www.movshare.net/video/(.*?)\n\n">').findall(link)
        for code in match4:
                code=''
                araclar.addDir(fileName,'MovShare    >>',"NowVideo(name,url)",url,'')
        match9=re.compile('href="\n\nhttp://www.nowvideo.sx/video/(.*?)\n\n">').findall(link)
        for url in match9:
                url='http://www.nowvideo.sx/video/'+url                
                araclar.addDir(fileName,'NowVideo    >>',"cozucu.magix_player(name,url)",url,'')
        match8=re.compile('href="\n\nhttp://streamcloud.eu/(.*?)\n\n">').findall(link)
        for url in match8:
                url='http://streamcloud.eu/'+url
                araclar.addDir(fileName,'Stream Cloud   >>',"cozucu.magix_player(name,url)",url,'')
        match5=re.compile('href="http://played.to/(.*?)">').findall(link)
        for url in match5:
                url='http://played.to/'+url 
                araclar.addDir(fileName,'Played   >>',"cozucu.magix_player(name,url)",url,'')
        match6=re.compile('href="http://xvidstage.com/(.*?)">').findall(link)
        for url in match6:
                url='http://xvidstage.com/'+url                
                araclar.addDir(fileName,'XvidStage   >>',"cozucu.magix_player(name,url)",url,'')
        match7=re.compile('href="http://faststream.in/(.*?)">').findall(link)
        for url in match7:
                url='http://faststream.in/'+url                
                araclar.addDir(fileName,'FastStream   >>',"cozucu.magix_player(name,url)",url,'')
        match10=re.compile('href="http://youwatch.org/(.*?)">').findall(link)
        for url in match10:
                url='http://youwatch.org/'+url                
                araclar.addDir(fileName,'YouWATCH   >>',"cozucu.magix_player(name,url)",url,'')
        match11=re.compile('href="http://streamcloud.eu/(.*?)">').findall(link)
        for url in match11:
                url='http://streamcloud.eu/'+url                
                araclar.addDir(fileName,'StreamCLD   >>',"cozucu.magix_player(name,url)",url,'')
        match12=re.compile('<a title=".*?" href="https:\/\/www.firedrive.com\/file\/(.*?)" target="_blank"><img class="alignnone" alt="" src="(.*?)" width="640" height="400" /></a>\r\n<br><br>\r\n').findall(link)
        for url,thumbnail in match12:
            url='https://www.firedrive.com/file/'+url
            araclar.addDir(fileName,'Firedrive   >>',"cozucu.magix_player(name,url)",url,'')
        match13=re.compile('<a title=".*?" href="http://www.uploadc.com/(.*?)" target="_blank"><img class="alignnone" alt="" src="(.*?)"').findall(link)
        for url,thumbnail in match13:
            url='http://www.uploadc.com/'+url
            araclar.addDir(fileName,'UploadC   >>',"cozucu.magix_player(name,url)",url,'')
        match14=re.compile('src="http:\/\/play.flashx.tv\/player\/embed.php\?vid\=(.*?)"').findall(link)
        for url in match14:
            url='http://play.flashx.tv/player/embed.php?vid='+str(url).encode('utf-8', 'ignore')
            araclar.addDir(fileName,'FlashX   >>',"cozucu.magix_player(name,url)",url,'')


def name_fix(x):        
        x=x.replace('-',' ')
        return x[0].capitalize() + x[1:]

def replace_fix(x):        
        x=x.replace('Ã¢â‚¬â€œ', '-').replace('&', '&').replace('&amp;', '&')
        return x
