# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString


fileName="Live_German"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

a='rtmp://server101-yt.stream-company.org/live/'
b=' swfUrl=http://www.yourtv.to/js/jwplayer.flash.swf pageUrl=http://www.yourtv.to/online/live/fernsehen/stream/'
c='.html'
d='http://www.yourtv.to/img/data/channels/'
e='.gif'
f=' live=1'
k=''
t='rtmp://server101-yt.stream-company.org/live/ playpath='

yenit='http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg'

def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        Live='http://www.yourtv.to/'
        #yeni='http://de.iphone-tv.eu/channels/de'
        hasbah='http://01.gen.tr/HasBahCa_IPTV/GERMAN_DEUTSCH.m3u'
        uk='http://de.iphone-tv.eu/channels/uk'
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] UK List [/B][/COLOR]', "uk(url)", uk,"https://lh5.ggpht.com/LtBGqzPrt3Ejp5C70kHiUws1koJwvfqRWpWaKxsTK8E6aXr9n2BlaHoyuCInPdKt3dg=h900")
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] German TV Buketi [/B][/COLOR]', "deutsch(url)", yeni,"http://www.satellitetveurope.co.uk/IMAGES/turksat/buket_tv.jpg")
        araclar.addDir(fileName,'[COLOR lightblue][B]>>[/B][/COLOR] [COLOR lightgreen][B] German TV List [/B][/COLOR]', "hasbah(url)", hasbah,yenit)
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] Deutsch TV [/B][/COLOR]', "tarih(url)", tarih,"http://s14.directupload.net/images/140329/ycqw73vd.jpg")
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Mega TV List [/B][/COLOR]', "megtv(url)", alman,"https://fbcdn-profile-a.akamaihd.net/hprofile-ak-frc3/t1/p160x160/10449_474656445963686_1599030923_n.png")
        #araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] Your TV List [/B][/COLOR]', "Livee(url)", Live,"http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg")


def deutsch(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title="(.*?) Live Stream"><img src="(.*?)"').findall(link)
        for url,name,thumbnail in match:
                url='http://de.iphone-tv.eu/'+url
                thubnail='http://de.iphone-tv.eu/'+thumbnail
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [/B][/COLOR]'+'[COLOR lightblue][B]' + name+'[/B][/COLOR]',"deutschoynat(name,url)",url,'http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg')

def deutschoynat(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)
        match=re.compile('var\|(.*?)\|(.*?)\|(.*?)\|.*?\|auth\|.*?\|.*?\|.*?\|.*?\|​.*?\|.*?\|\|(.*?)\|.*?').findall(link)
        for index,m3,kanal,token in match:
                #name='[COLOR pink]>> Start Sendung[/COLOR]'
                m3='.'+m3+'?c='
                token='&auth='+token+'&gts=false'
                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token

                playList.clear()
                playList.add(name)
                araclar.addLink(name+'[COLOR pink] >> Start Sendung[/COLOR]',url,'http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg')
        if playList:
                xbmcPlayer.play(playList)          

                
        
def Livee(url):
        link=araclar.get_url(url)
        match=re.compile('<a href="/online/live/fernsehen/stream/(.*?).html" title=".*?Online Live Stream">').findall(link)
        for x in match:
                name=x
                name=Liveeename_fix(name)
                url=a+x+b+x+c+f
                url=t+x+b+x+c+f
                thumbnail=d+x+e
                araclar.addLink('[COLOR beige][B]>> '+name+' [/B][/COLOR]',url,thumbnail)

def Liveeename_fix(x):        
        x=x.replace('aaa','bbb').replace("-",' ')
        return x[0].capitalize() + x[1:]

def megtv(url):
        link=araclar.get_url(url)
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C")
        match=re.compile('a href="(.*?)">\r\n<img width=".*?" height=".*?" src="(.*?)" class="postimg wp-post-image" alt="(.*?)" />').findall(link)
        for url,thumbnail,name in match:
            name=name.replace('-','').replace('_',' ').replace('738px','').replace('t#U00fc','Tu')
            name=megatvname_fix(name)
            araclar.addDir(fileName,'[COLOR orange][B]>> DE [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"megatvyeni3(name,url)",url,thumbnail)

def megatv(url):
        link=araclar.get_url(url)
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C")
        match=re.compile('a href="(.*?)">\r\n<img width=".*?" height=".*?" src="(.*?)" class="postimg wp-post-image" alt="(.*?)" />').findall(link)
        for url,thumbnail,name in match:
            name=name.replace('-','').replace('_',' ').replace('738px','').replace('t#U00fc','Tu')
            name=megatvname_fix(name)
            araclar.addDir(fileName,'[COLOR orange][B]>> DE [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"megatvyeni3(name,url)",url,thumbnail)

def megatv2(url):            
        link=araclar.get_url(url)
        match=re.compile('a href="http:\/\/MegaTv.TO\/Live-Stream\/allgemein\/(.*?).html">\r\n<img width=".*?" height=".*?" src="(.*?)"').findall(link)
        for a,thumbnail in match:
            url='http://MegaTv.TO/Live-Stream/allgemein/'+a+'.html'
            name=a
            name=name.replace('-','').replace('_',' ').replace('738px','').replace('t#U00fc','Tu')
            araclar.addDir(fileName,'[COLOR orange][B]>> DE - [/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"megatvyeni3(name,url)",url,thumbnail)

def megatvalternative(url):            
        link=araclar.get_url(url)
        match=re.compile('<a title=".*?" href="(.*?)"><img title="(.*?)" alt=".*?" src="(.*?)" width=".*?" height=".*?"').findall(link)
        for url,name,thumbnail in match:
            araclar.addDir(fileName,'[COLOR red][B]T[/B][/COLOR]'+'[COLOR white][B]R -[/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"megatvyeni4(name,url)",url,thumbnail)
        
def megatvYeni(url):
        link=araclar.get_url(url)  
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"I")
        match=re.compile('<a href="(.*?)" rel=".*?">\n                    \t<img width=".*?" height=".*?" src="(.*?)" class="entry-thumb wp-post-image" alt="(.*?)" /> ').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"megatvyeni2(name,url)",url,thumbnail)           
        page=re.compile('.</span><span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a').findall(link)        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"megatvYeni(url)",url,"")                     
    
def megatvyeni2(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)  
        match=re.compile('var sourceMedia = "(.*?)";').findall(link)
        for url in match:
                print url,'aaa'
                
                
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

def megatvyeni3(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)  
        match=re.compile("file\': \'(.*?)\\'").findall(link)
        for url in match:
                
                
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

def megatvyeni4(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)  
        match=re.compile('src="(.*?).m3u8"').findall(link)
        for url in match:
                url=url+'.m3u8'
                
                
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

def megatvname_fix(x):        
        x=x.replace('aaa','bbb').replace("-",' ')
        return x[0].capitalize() + x[1:]

##def yeni(url):
##        link=araclar.get_url(url)
##        match=re.compile('<a href="(.*?)" title="(.*?) Live Stream"><img src="(.*?)"').findall(link)
##        for url,name,thumbnail in match:
##                url='http://de.iphone-tv.eu/'+url
##                thubnail='http://de.iphone-tv.eu/'+thumbnail
##                araclar.addDir(fileName,'[COLOR lightgreen][B]' + name+'[/B][/COLOR]',"yenioynat(name,url)",url,'http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg')
##
##def yenioynat(name,url):
##        link=araclar.get_url(url)
##        match=re.compile('var\|(.*?)\|(.*?)\|(.*?)\|1345\|auth\|eu\|http\|streamURL​​\|ipm\|iphone\|tv\|\|(.*?)\|.*?').findall(link)
##        for index,m3,kanal,token in match:
##                name='[COLOR pink]>>Start Sendung[/COLOR]'
##                m3='.'+m3+'?c='
##                token='&auth='+token+'&gts=false'
##                url='http://ipm.iphone-tv.eu:1345/'+index+m3+kanal+token
##                playList.clear()
##                playList.add(name)
##                araclar.addLink(name,url,'http://1.bp.blogspot.com/-P1ykZvW7YQs/Tcg_hZHZ-xI/AAAAAAAAAt8/jB8Cx2KQfv8/s1600/Wallpaper+Flag+of+Romania.jpg')
##        if playList:
##                xbmcPlayer.play(playList)

##############

def bobliste(url):
        link=araclar.get_url(url)
        link=link.replace('amp;','')
        match=re.compile('<a href="(.*?)" title=".*?"><img src="(.*?)" width="90" height="80" alt="(.*?)"></a>\n').findall(link)
        for url,thumbnail,name in match:
                url='http://en.iphone-tv.eu/'+url
                thumbnail='http://en.iphone-tv.eu'+thumbnail
                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',"boblisteicerik(url)",url,thumbnail)
               
def boblisteicerik(url):
        link=araclar.get_url(url)
        link=link.replace('STREAM_URL_2','http://ipm.iphone-tv.eu:1345')
        match=re.compile('var streamURL = "(.*?)"').findall(link)
        for url in match:
                name='[COLOR pink]>> start live streaming [/COLOR]'
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'')
        if playList:
                xbmcPlayer.play(playList)

##################

def tarih(url):
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)" title="(.*?) izle"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            araclar.addDir(fileName,'[COLOR beige][B]' + name+'[/B][/COLOR]',"tarih2(url)",url,thumbnail)

def tarih2(url):
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)" title="(.*?) izle"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            araclar.addDir(fileName,'[COLOR beige][B]' + name+'[/B][/COLOR]',"VIDEOLINKS2(name,url)",url,thumbnail)


def hasbah(url):
        link=araclar.get_url(url)
        link=link.replace('rtmp://$OPT:rtmp-raw=',"")
        match=re.compile('#EXTINF:-1,(.*?)\r\n(.*?)\r\n').findall(link)
        if match >0:
                del match[0]

                for name,url in match:
                        araclar.addDir(fileName,'[COLOR beige][B]' + name+'[/B][/COLOR]',"VIDEOLINKS2(name,url)",url,'http://us.cdn1.123rf.com/168nwm/kaarsten/kaarsten1101/kaarsten110100156/8588091-cheering-blonde-woman-with-german-flag-all-on-white-background.jpg')

def VIDEOLINKS2(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

##################
