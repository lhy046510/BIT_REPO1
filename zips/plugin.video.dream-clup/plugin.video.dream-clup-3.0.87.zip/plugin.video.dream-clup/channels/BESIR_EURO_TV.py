# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys,time
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString

#---------------------------------------------------
web='aHR0cDovL3hibWN0ci5jb20vYmVzaXIv'

fileName="BESIR_EURO_TV"
#--------------- YENI KOMUTLAR  --------------------
# sayfa taratma --> araclar.get_url(url)
# klasor ekleme --> araclar.addDir(fileName,name, mode, url="", thumbnail="")
# link ekleme   --> araclar.addLink(name,url,thumbnail)
# videolink bulma --> urlList=cozucu.videobul(url)
# sonrasında     --> for url in urlList if not isinstance(urlList, basestring) else [urlList]:
#                               araclar.addlink(name,url,thumbnail) yada playList.add(url)
#---------------------------------------------------
        
def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Turkce Ulusual Kanallar[/B][/COLOR]', "BuildPage(code='tr',dil='TR.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/tr.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Deutsche Sender[/B][/COLOR]', "BuildPage(code='de',dil='DE.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/de.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Besir Filmler[/B][/COLOR]', "BuildPage(code='sn',dil='Sinema.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/sn.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Yabanci Kanallar[/B][/COLOR]', "BuildPage(code='muz',dil='yabanci.xml')",web,'http://www.volkanmakina.com.tr/FileUpload/bs438266/File/1-1.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Turkce Radyolar[/B][/COLOR]', "BuildPage(code='rdy',dil='Radyo.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/rdy.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Turkce Spor Kanallari[/B][/COLOR]', "BuildPage(code='spr',dil='SPOR.xml')",web,'http://www.tav-sanpark.com/images/spor_all.png')
        #araclar.addDir(fileName,__language__(30052), "BuildPage(code='dini',dil='ULUSAL.xml')",web,'special://home/addons/plugin.video.dream-clup/resources/images/XBMCTRSPOR.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Cocuk Kanallari[/B][/COLOR]', "BuildPage(code='cocuk',dil='cocuk.xml')",web,'http://evdonaucity.wdfiles.com/local--files/news-2008-2009/VBSLogoKinder.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Muzik Kanallari[/B][/COLOR] ', "BuildPage(code='muz',dil='muz.xml')",web,'http://www.heridan.com/butonlar/mp3-muzik.png')
        araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+ '[COLOR beige][B]Dini Kanallar[/B][/COLOR] ', "BuildPage(code='muz',dil='dini.xml')",web,'http://www.abload.de/img/pic69001zqp8h.png')
                

def BuildPage(code,dil):
    a=0
    link=araclar.get_url(base64.b64decode(web)+dil)
    
    tr=re.compile('<item>\n.*?<title>(.*?)</title>\n.*?<link>(.*?)</link>\n.*?<thumbnail>(.*?)</thumbnail>\n.*?</item>').findall(link)
    de=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    sn=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    klp=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    rdy=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    spr=re.compile('<item>\n.*?<title>(.*?)</title>\n.*?<link>(.*?)</link>\n.*?<thumbnail>(.*?)</thumbnail>\n.*?</item>').findall(link)
    ulus=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    cocuk=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    muz=re.compile('<item>\n<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
    if code is 'tr':
         for name,url,thumbnail in tr:
              araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail) 
    else:
        pass
    if code is 'de':
          for name,url,thumbnail in de:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass
    if code is 'sn':
          for name,url,thumbnail in sn:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass
    if code is 'klp':
          for name,url,thumbnail in sn:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass
    if code is 'rdy':
          for name,url,thumbnail in sn:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass

    if code is 'spr':
          for name,url,thumbnail in spr:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)
    else:
        pass

    if code is 'cocuk':
          for name,url,thumbnail in cocuk:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)

    else:
        pass

    if code is 'muz':
            for name,url,thumbnail in muz:
               araclar.addDir(fileName,name, "yeni4(name,url)",url,thumbnail)

    else:
        pass
def yeni4(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmcPlayer = xbmc.Player() 
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
        playList.clear() 
        araclar.addLink(name,url,'') 
        listitem = xbmcgui.ListItem(name) 
        playList.add(url, listitem) 
        xbmcPlayer.play(playList)




def INFO(url):
  try:
        #CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "www.xmbctr.com TEAM katkilariyla","Iyi seyirler dileriz...","Hazirlayan @Besir")
  except:
        #print "Hata olustu"
        pass 
