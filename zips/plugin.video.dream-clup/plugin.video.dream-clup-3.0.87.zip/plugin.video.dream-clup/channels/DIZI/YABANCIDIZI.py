# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


#------------------eklenecek kısım------------------
import araclar,cozucu
##addon_id = 'script.module.xbmctr'
##__settings__ = xbmcaddon.Addon(id=addon_id)
##__language__ = __settings__.getLocalizedString

#---------------------------------------------------
web="http://www.yabancidizi-izle.com"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
fileName="YABANCIDIZI"
#--------------- YENI KOMUTLAR  --------------------
# sayfa taratma --> araclar.araclar.get_url(url)
# klasor ekleme --> araclar.addDir(fileName,name, mode, url="", thumbnail="")
# link ekleme   --> araclar.addLink(name,url,thumbnail)
# videolink bulma --> urlList=cozucu.videobul(url)
# sonrasında     --> for url in urlList if not isinstance(urlList, basestring) else [urlList]:
#                               araclar.addlink(name,url,thumbnail) yada playList.add(url)
#---------------------------------------------------
        
def main():
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Film ARA - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "Search()", "","special://home/addons/plugin.video.dream-clup/resources/images/search.png")
        araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR][COLOR beige][B]Yeniler[/B][/COLOR]','yeni(url)',web,"")
        kategoriler(web)

def Search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=araclar.name_fix(query)
            url = ('http://yabancidizi-izle.com/ara.php?q='+ query)
            yeni(url)                

def yeni(url):
        link=araclar.get_url(url)
        soup = BS(link)
        for div in soup.findAll('div',  {"class": "yabanci-dizi-izle-div"},smartQuotesTo=None):
            name= div.find('a')['title']
            name=name.encode("utf-8")
            url= div.find('a')['href']
            thumbnail=div.find('img')['src']
            print "film adresi",url
            if not "http" in url:
                    url=web+url
            if not "http" in thumbnail:
                    thumbnail=web+thumbnail  
            araclar.addDir(fileName,'[COLOR gold][B]>>[/B][/COLOR][COLOR beige][B]'+name+'[/B][/COLOR]','prevideo(url)',url,thumbnail)
        
        #sayfalama basladi
        page=re.compile('class="aktif">.*?</a><a href="(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
                name="Sonraki Sayfa"
                url='http://www.yabancidizi-izle.com'+str(url)
                araclar.addDir(fileName,'[COLOR blue][B]>>>>>  '+name+'[/B][/COLOR]',"yeni(url)",url,"")
def panel(url):
        link=araclar.araclar.get_url(web)
        soup=BS(link.decode('utf-8','ignore'))
        div = soup.findAll("div",{"class":"blok-liste"})
        for li in div[int(url)].findAll('li'):#-------------dizi anasayfalari bulur
                url= li.a['href']
                name = li.a.text
                name=name.encode("utf-8")
                araclar.addDir(fileName,'[COLOR red][B]>>[/B][/COLOR][COLOR pink][B]'+name+'[/B][/COLOR]',"kategoriler(url)",url,"YOK") 

def kategoriler(url):                    
        link=araclar.get_url(url)
        soup = BS(link)
        value=[]
        panel = soup.findAll("ul", {"class": "diziler"},smartQuotesTo=None)
        exception=['*Eski Diziler','* Fragmanlar']
        for a in panel[1].findAll('a'):
                url='http://yabancidizi-izle.com'+a['href']
                name=a.text
                if name in exception:
                    pass
                else:
                        araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B]'+name.encode('utf-8')+'[/B][/COLOR]',"sezon(url)",url,"")
                
def sezon(url):
        value=[]
        link=araclar.get_url(url)
        match=re.compile('<a href="(.*?)" title=".*?" class="img"><img src="(.*?)" alt="(.*?)"').findall(link)
        exception=['*Eski Diziler','* Fragmanlar']
        result=[]
        for url,thumbnail,sname in match:
                print sname
                link=araclar.get_url(url)
                match=re.compile(u'<a href="(.*?)" title="(.*?)" class="img"><img src="(.*?)" alt=".*?"').findall(link)
                if not thumbnail.startswith('http'):
                        thumbnail='http://www.yabancidizi-izle.com'+thumbnail
                for url,name,x in match:
                    if not url.startswith('http'):
                        url='http://yabancidizi-izle.com'+url
                    else:
                        pass
                    # name=re.findall(r".*?/(.*?).html$", url)
                    # name=name[0].replace('-izle',"").replace('-'," ").replace('/yabancidizi.com/',"")
                    name=name#.capitalize()
                    araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B]'+name+'[/B][/COLOR]',"prevideo(url)",url,thumbnail)
def prevideo(url):
            tablist=[]
            urllist=[]
            desc='Simdilik bos'
            link=araclar.get_url(url)
##            link=link.replace('\xc5\x9f',"s").replace('&#038;',"&").replace('&#8217;',"'").replace('\xfd',"i").replace('\xc3\x87',"C").replace('\xc4\xb1',"ı").replace('&#8211;',"-").replace('\xc3\xa7',"c").replace('\xc3\x96',"O").replace('\xc5\x9e',"S").replace('\xc3\xb6',"o").replace('\xc4\x9f',"g").replace('\xc4\xb0',"I").replace('\xe2\x80\x93',"-")
            soup = BS(link)
            panel = soup.findAll("ul", {"class": "ozel"})
            tablar=["Kota Dostu","ALT","ALT 2","ALT 3","ALT 4"]
            try:
                for a in panel[0].findAll('a'):
                        if not a['href'] in tablar and not a.text in tablar:
                            urllist.append(web+a['href'])
                            tablist.append(a.text)
            except:
                return serverlist
            tablist[:] = (value for value in tablist if value != "")
            tablist[:] = (value for value in tablist if value != "Kota Dostu")
            urllist[:] = (value for value in urllist if value != r"http://www.yabancidizi-izle.comjavascript:void(0)")        
            print "******************",len(tablist),len(urllist)
            for i, url in enumerate(urllist):
                            server=tablist[i]
                            name=server.encode("utf-8")
                            araclar.addDir(fileName,'[COLOR green][B]>>[/B][/COLOR][COLOR lightgreen][B]'+name+'[/B][/COLOR]',"video(name,url)",url,"")

            
            
            

def video(name,url):
            if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
            playList.clear()
            yabanci_dizi=[]
            value=[]
            link=araclar.get_url(url)
     
            partlink=re.compile('<a id="part_.*?" href=\'(.*?)\' class=\'.*?\'>.*?</a>').findall(link)
            if partlink:
                    for x in partlink:
                            adres="http://www.yabancidizi-izle.com/"+x
                            data=araclar.get_url(adres)
                            match=matchbul(data)
                            if match:
                                for item in match if not isinstance(match, basestring) else [match]:
                                    print "itemmmmmmmmm",item
                                    if item in yabanci_dizi:
                                        pass
                                    else:
                                        if "vk" in item:
                                                Sonuc=cozucu.videobul(item)
                                                if Sonuc=="False":
                                                        dialog = xbmcgui.Dialog()
                                                        i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yüklenecektir.  ")
                                                        return False 
                                                else:                                
                                                        for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                                                                        araclar.addLink(name,url,'')
                                                                        araclar.playlist_yap(playList,name,url) 
                                        else:
                                                yabanci_dizi.append(item)
            else:
                    match=matchbul(link)
                    print match,"*-*-*-*-*-*-*-*-*-*-"
                    if match:
                        for item in match if not isinstance(match, basestring) else [match]:
                            yabanci_dizi.append(item)


            
            if "HQ" in name:
                for i,url in enumerate(yabanci_dizi):
                    if i<3:
                        part="  HD Quality "+str(i+1)
                        araclar.playlist_yap(playList,name,url) 
                        araclar.addLink(name+part,url,"")
                    else:
                        part="  SD Quality "+str(i-2)
                        araclar.addLink(name+part,url,"")
            else:
                for i,url in enumerate(yabanci_dizi):
                    print url
                    araclar.playlist_yap(playList,name,url) 
                    araclar.addLink(name+" "+str(i+1),url,"")
                
            if playList:
               xbmcPlayer.play(playList)
            
        
                

##        if sonuc:
##                play(sonuc)
##        else:
##                dialog = xbmcgui.Dialog()
##                i = dialog.ok(name,"Site uyarısı","     Film Siteye henuz yuklenmedi   ","  Yayınlandıktan sonra yüklenecektir.  ")
##                return False
def matchbul(link):
        match=[]
        try:
                match=re.compile(r'{ file: "(.*?)" }').findall(link)#sayfada attachmail.ru linkleri
        except:
                pass
        try:
                streamer=re.compile('streamer: "(.*?)"').findall(link)#sayfada streamer linki
                match.extend(streamer)
        except:
                pass
        try:
                streamer=re.compile(u'ticket=(.*?)"').findall(link)#sayfada streamer linki
                match.extend(streamer)
        except:
            pass
        try:
                vk=re.compile('http://vk.com/(.*?)"').findall(link)#sayfada vk linki
                for index, item in enumerate(vk):
                        vk[index]='http://vk.com/'+str(item)
                match.extend(vk)
        except:
            pass
        try:
                youtube=re.compile("encodeURIComponent\(\\'(.*?)\\'").findall(link)#sayfada vk linki
                match.extend(youtube)
        except:
            pass
        try:
                fragman=re.compile('www.youtube.com/embed/(.*?)"').findall(link)#sayfada FRAGMAN linki
                for index, item in enumerate(fragman):
                        fragman[index]="http://www.youtube.com/embed/"+str(item)
                match.extend(fragman)
        except:
            pass
        
    
        return match     



def HQ_COZ(data):
        low=[]
        high=[]
        if len(data)<4:
                return data
        for i in range(len(data)):
            if i<3:
                high.append(data[i])
            if (2< i < 6):
                low.append(data[i])
                
        dialog = xbmcgui.Dialog()
        ret = dialog.select(__language__(30008),['Dusuk Kalite >200kb/s','Orta Kalite >500 kb/sn'])
        if ret == 0:
                liste=low

        if ret == 1:
                liste=high
        return liste
def search():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            query=xbmctools.name_fix(query)
            url = ('http://yabancidizi-izle.com/ara.php?q='+ query)
            RECENT(url)
            
def play(sonuc):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        if xbmcPlayer.isPlaying():
                xbmcPlayer.stop()
        playList.clear()
        for x in sonuc:
                name=x[0]
                url=x[1]
                if "youtube" in str(url):
                        code=url.replace("http://www.youtube.com/watch?v=","")
                        url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code)
                playList.add(url)
                araclar.addLink(name,url,"")
                
        if playList:
               xbmcPlayer.play(playList)
        


##########  eklenecek kısım 2  #####################################


