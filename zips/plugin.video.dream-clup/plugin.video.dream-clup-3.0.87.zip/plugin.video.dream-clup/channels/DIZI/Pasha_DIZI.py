# -*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS



  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="Pasha_DIZI"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
  
def main():
    TRdizi='http://www.trdizi.tv/'
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR yellow][B][I]TRdizi - Son Eklenenler[/I][/B][/COLOR]', "TRdizi(url)", TRdizi,"http://domainsigma.com/widget/trust/trdizi.tv.png") 
    araclar.addDir(fileName,'[COLOR red][B]>>>[/B][/COLOR][COLOR yellow][B]---[/B][/COLOR][COLOR blue][B]>[/B][/COLOR]   [COLOR yellow][B][I]TRdizi - Kategoriler[/I][/B][/COLOR]', "TRdizikat(url)", TRdizi,"http://domainsigma.com/widget/trust/trdizi.tv.png") 


def tek_link(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()

        match=re.compile('<i>(.*?)</i></font></font></b>\r\n<iframe src="http://vk.com/(.*?)"').findall(link)
        for name,url in match:
                url='http://vk.com/'+url
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>>>   [/COLOR]'+name+'[/B][/COLOR]', "cozucu.magix_player(name,url)",url,'') 
                
  
  
def TRdizi(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class=".*?">\n<div class=".*?"><a href=".*?"><img src="(.*?)" alt="(.*?)" width="100" height="97" /></a></div>\n<h3><a href="(.*?)" title=".*?</a></h3>').findall(link) 
        for thumbnail,name,url in match:
                araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR blanchedalmond][B]'+ name+'[/B][/COLOR]', "TRdizipartlama(name,url)",url,thumbnail)
             
              
  
def TRdizikat(url): 
        link=araclar.get_url(url) 
        match=re.compile('<li class="item.*?"><a href="(.*?)" title="">(.*?)</a></li>').findall(link) 
        for url,name in match: 
            araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR lawngreen][B]'+ name+'[/B][/COLOR]', "katagoriicerik(url)",url,'') 
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page \'>(.*?)</a>').findall(link)
        for url,name in page:              
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "katagoriicerik(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
  
def katagoriicerik(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="video-box">\n<div class="thumb"><a href="(.*?)"><img src="(.*?)" alt="(.*?)" width="100" height="97" /></a></div>').findall(link) 
        for url,thumbnail,name in match: 
            araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR darkorange][B]'+ name+'[/B][/COLOR]', "TRdizipartlama(name,url)",url,thumbnail) 
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page \'>(.*?)</a>').findall(link) 
        for url,name in page: 
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>>    [/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "katagoriicerik(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 

  
def TRdizipartlama(name,url): 
        link=araclar.get_url(url)         
        match=re.compile('<a class="current">Part (.*?)</a>').findall(link) 
        for name in match: 
                name='Part '+name 
                url=url 
                #code='' 
                araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR cadetblue][B]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
        match1=re.compile('<a href="(.*?)" rel="nofollow">Part (.*?)</a>').findall(link) 
        for url,name in match1: 
                name='Part '+name
                araclar.addDir(fileName,'[COLOR red]>>[/COLOR][COLOR white]--[/COLOR][COLOR blue]>   [/COLOR][COLOR cadetblue][B]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
        page=re.compile('<span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page \'>(.*?)</a>').findall(link) 
        for url,name in page: 
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+name+'[COLOR red][B]'+'[/B][/COLOR]', "katagoriicerik(url)",url,"http://bibelgeselizle.com/wp-content/themes/bibelgeselizle/images/reklam-sag.png") 
                  
##                 
##                #name='Diger Resolver Bulundu' 
##                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'')tmm sayfasayfayi yapok 
##        match3=re.compile('src="http://www.dailymotion.com/(.*?)">').findall(link) 
##        for code in match3: 
##                code='' 
##                 
##                name='Diger Resolver Bulundu' 
##                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,'') 
#################################################
def VIDEOLINKS(name,url): 
        #---------------------------# 
        urlList=[] 
        #---------------------------# 
        playList.clear() 
        link=araclar.get_url(url) 
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
  
        #---------------------------------------------#
        
        #---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for url in vk_2: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url)#
        #---------------------------------------------# 
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link) 
        for url in youtube: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        youtube1=re.compile(' value="http://www.youtube.com/v/(.*?)\?.*?"').findall(link) 
        for url in youtube1: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link) 
        for mailrugelen in mailru: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url 
                urlList.append(url) 
        mailru4=re.compile(' value\="movieSrc\=mail/(.*?)\&autoplay\=0"').findall(link) 
        for mailrugelen in mailru4: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #-------------------------------                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link) 
        for url in dm: 
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #-------------------------------  
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link) 
        for mailrugelen in mailru3: 
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url) 
        #---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link) 
        for mailrugelen in mailru2: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link) 
        for mailrugelen in mailru5: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
        for videodgelen in video: 
                url =videogelen 
                cozucu.magix_player(name,url) 
        if not urlList: 
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
                print match 
                if match: 
                        for url in match: 
                                VIDEOLINKS(name,url) 
         
        if urlList: 
                Sonuc=playerdenetle(name, urlList) 
                for name,url in Sonuc: 
                        araclar.addLink(name,url,'') 
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='') 
                        listitem.setInfo('video', {'name': name } ) 
                        playList.add(url,listitem=listitem) 
                xbmcPlayer.play(playList) 
       
def playerdenetle(name, urlList): 
        value=[] 
        import cozucu 
        for url in urlList if not isinstance(urlList, basestring) else [urlList]: 
  
  
                if "mail.ru" in url: 
                    value.append((name,cozucu.MailRu_Player(url))) 
                      
        if  value: 
            return value

        



                
