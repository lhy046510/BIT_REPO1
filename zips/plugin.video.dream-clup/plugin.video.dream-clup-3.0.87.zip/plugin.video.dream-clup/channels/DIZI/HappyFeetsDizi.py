# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="HappyFeetsDizi"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# ANA GIRIS KLASORLERI ##############################
def main():
        url='http://www.diziizlehdfull.net/diziler/kurtlar-vadisi-pusu'
        araclar.addDir(fileName,'[COLOR red][B]>> Bilgilendirme Onemli <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
       
        link=araclar.get_url(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="http://www.diziizlehdfull.net/diziler/(.*?)" ').findall(link)
        for url in match:
            name=url
            url='http://www.diziizlehdfull.net/diziler/'+url
            name=name_fix(name)
            araclar.addDir(fileName,'[COLOR orange][B]>> [/B][/COLOR]'+'[COLOR lightgreen][B]' + name+'[/B][/COLOR]',"Yeni(url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/Happyfeetsdizi.png')

###################################################################                


############
def Yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<div class="panel">\n\t\t\t\t<a href="(.*?)">\n\t\t\t\t<img src="(.*?)" alt="(.*?)" height="138px" width="110px" ').findall(link)
        for url,thumbnail,name in match:
                araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]''[COLOR red][B] izle[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('<link rel=\'next\' href=\'(.*?)\' />').findall(link)
        for url in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>Sonraki Sayfa [/B][/COLOR]',"Yeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]Serverdan Kaldirilmamis ise Tum Diziler Sorunsuz Calisir.[/COLOR]","[COLOR pink]Herkese iyi seyirler[/COLOR]")
  except:
        
        pass 

def name_fix(x):        
        x=x.replace('-',' ').replace('_',' ')
        return x[0].capitalize() + x[1:]
        
def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        for url in divxstage:
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        	#---------------------------------------------#
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        for url in movshare:
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
        for url,uploadcgelen in uploadc:
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                urlList.append(url)

        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
        for url,divxstagegelen in divxstage:
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
