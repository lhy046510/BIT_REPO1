# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Media64_DIZIZLETEN"

xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://www.diziizleten.com/'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B]Bizim Dizi ( Son Eklenenler )[/B][/COLOR]', "bizimdizisoneklenenler(url)",url,'http://www.diziizleten.com/wp-content/uploads/2014/01/logob.png')
        link=araclar.get_url(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="(.*?)" title=".*?">(.*?)</a>\n</li>\n\t').findall(link)
        for url,name in match:
            araclar.addDir(fileName,'[COLOR green][B]'+name+'[/B][/COLOR]',"diziizletenkategoriicerik(url)",url,'http://www.diziizleten.com/wp-content/uploads/2014/01/logob.png') 

def bizimdizisoneklenenler(url): 
        link=araclar.get_url(url) 
        match=re.compile('<div class="diziler">\r\n<a href="(.*?)" title=".*?">\r\n<img src="(.*?)" width="110" height="90" alt="(.*?)" />\r\n</a>\r\n<h2><a').findall(link)
        for url,thumbnail,name in match: 
                araclar.addDir(fileName,'[COLOR blue][B][COLOR red]>>[/COLOR]'+ name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)

def diziizletenkategoriicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="dizi-bolumleric">\n<a href="(.*?)" title=".*?">\n<img src=".*?" width="80" height="60" alt="(.*?)" />\n</a>\n<h2><a ').findall(link) 
        for url,name in match: 
                araclar.addDir(fileName,'[COLOR grey][B]'+name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,'http://www.diziizleten.com/wp-content/uploads/2014/01/logob.png') 
        sayfalama=re.compile('<a class="nextpostslink" href="(.*?)">.*?</a>\n').findall(link) 
        for url in sayfalama:
                name='Sonraki Sayfa' 
                araclar.addDir(fileName,'[COLOR blue][B]'+name+'[/B][/COLOR]',"diziizletenkategoriicerik(url)",url,'http://www.diziizleten.com/wp-content/uploads/2014/01/logob.png') 

def VIDEOLINKS(name,url): 
        #---------------------------# 
        urlList=[] 
        #---------------------------# 
        playList.clear() 
        link=araclar.get_url(url) 
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/') 
  
        #---------------------------------------------# 
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link) 
        for url in vk_2: 
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url)#
        #---------------------------------------------# 
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link) 
        for url in youtube: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #---------------------------------------------# 
        youtube1=re.compile(' value="http://www.youtube.com/v/(.*?)\?.*?"').findall(link) 
        for url in youtube1: 
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        mailru=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link) 
        for mailrugelen in mailru: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url 
                urlList.append(url) 
        mailru4=re.compile(' value\="movieSrc\=mail/(.*?)\&autoplay\=0"').findall(link) 
        for mailrugelen in mailru4: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #-------------------------------                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link) 
        for url in dm: 
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore') 
                cozucu.magix_player(name,url) 
        #-------------------------------  
        mailru3=re.compile('movieSrc: "(.*?)"').findall(link) 
        for mailrugelen in mailru3: 
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link) 
        for mailrugelen in mailru2: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link) 
        for mailrugelen in mailru5: 
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url) 
        #---------------------------------------------# 
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
        for videodgelen in video: 
                url =videogelen 
                cozucu.magix_player(name,url) 
        if not urlList: 
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link) 
                print match 
                if match: 
                        for url in match: 
                                VIDEOLINKS(name,url) 
         
        if urlList: 
                Sonuc=playerdenetle(name, urlList) 
                for name,url in Sonuc: 
                        araclar.addLink(name,url,'') 
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='') 
                        listitem.setInfo('video', {'name': name } ) 
                        playList.add(url,listitem=listitem) 
                xbmcPlayer.play(playList) 
       
def playerdenetle(name, urlList): 
        value=[] 
        import cozucu 
        for url in urlList if not isinstance(urlList, basestring) else [urlList]: 
  
  
                if "mail.ru" in url: 
                    value.append((name,cozucu.MailRu_Player(url))) 
                      
        if  value: 
            return value 
