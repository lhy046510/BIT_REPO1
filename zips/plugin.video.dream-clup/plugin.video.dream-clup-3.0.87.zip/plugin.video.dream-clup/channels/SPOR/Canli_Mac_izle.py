import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re,base64 
import araclar,cozucu,time
  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="Canli_Mac_izle"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 

urll='aHR0cDovL2NyaWNmcmVlLnN4L2xpdmUvd2F0Y2gtbGl2ZS1mb290YmFsbC1zdHJlYW0='
livet='http://1.bp.blogspot.com/-k_a-9qP_TQw/Ubk0KowrukI/AAAAAAAAHmc/EPwt68xFrYc/s1600/live_transp400x400.png'
thomast='special://home/addons/plugin.video.dream-clup/resources/images/UK_Thomas_Bouquet.png'
hangii='aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20v'

def main(): 
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        url='aHR0cDovL2NyaWNmcmVlLnN4L2xpdmUvd2F0Y2gtbGl2ZS1mb290YmFsbC1zdHJlYW0='
        hangi='aHR0cDovL3d3dy53aGVyZXN0aGVtYXRjaC5jb20vbGl2ZS1mb290YmFsbC1vbi10di8='
        araclar.addDir(fileName,'[COLOR blue][B]>>> [COLOR violet]Hangi Mac Hangi Kanalda icin Burdan[/B][/COLOR]',"hangi(url)",(base64.b64decode(hangi)),'special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>> [COLOR navajowhite]Altta Mac Listesi YOKSA,[COLOR lightgreen] Mac Bitmistir,[COLOR red] Yada Daha Baslamamistir.[/B][/COLOR]', "",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        araclar.addDir(fileName,'[COLOR blue][B]***** [COLOR lightblue] Altta Suan CANLI Yayin Olan Maclar Gozukur[COLOR blue][B] *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        araclar.addDir(fileName,'[COLOR blue][B] [/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        link=araclar.get_url(base64.b64decode(urll))
        match=re.compile('<td style="color:#7BA314;font-weight:bold; font-size: small" width=".*?" class="matchtime">(.*?)</td>\n\t\t\t\t\t\t\t<td style=".*?" width=".*?">(.*?)</td>\n\n\t\t\t\t\t\t\t\t<td width=".*?"> \t<img src=".*?" /></td>\n\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</table>\n\n\t\t\t\t\t\t<div style=".*?" class="hidden"><a target=\'_blank\' href=\'(.*?)\' ').findall(link)
        for saat,name,url in match:
            name=name+' '+'[COLOR beige]'+saat+'[COLOR yellow]'+' uk time zone[/COLOR]'
            #name=name.replace(':00',' uk time zone')
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "icerik(name,url)",url,livet)

def ayniyim(url):
        link=araclar.get_url(base64.b64decode(urll))
        araclar.addDir(fileName,'[COLOR blue][B]***** [COLOR lightblue] Baslamis Maclar [COLOR blue][B] *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        match=re.compile('<td style="color:#7BA314;font-weight:bold; font-size: small" width=".*?" class="matchtime">(.*?)</td>\n\t\t\t\t\t\t\t<td style=".*?" width=".*?">(.*?)</td>\n\n\t\t\t\t\t\t\t\t<td width=".*?"> \t<img src=".*?" /></td>\n\n\t\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</table>\n\n\t\t\t\t\t\t<div style=".*?" class="hidden"><a target=\'_blank\' href=\'(.*?)\' ').findall(link)
        for saat,name,url in match:
            name=name+' '+'[COLOR beige]'+saat+' uk time zone[/COLOR]'
            #name=name.replace(':00',' uk time zone')
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "icerik(name,url)",url,livet)

def icerik(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)
        match=re.compile('<iframe frameborder="0" marginheight="0" marginwidth="0" height="490" src="(.*?)"').findall(link)
        for url2 in match:
                link=araclar.get_url(url2)
                match=re.compile('fid=\'(.*?)\';').findall(link)
                for kanal in match:
                        #rtmp://31.220.0.195:1935/live playpath=channel4 swfUrl=http://www.flashtv.co/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live=channel4&vw=620&vh=490 live=1
                        url='rtmp://31.220.0.195:1935/live playpath='+kanal+' swfUrl=http://www.flashtv.co/ePlayerr.swf token=%ZZri(nKa@#Z pageUrl=http://www.flashtv.co/embed.php?live='+kanal+'&vw=620&vh=490 live=1'
                        playList.clear()
                        araclar.addLink(name,url,livet)
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)  

def hangi(url):
        link=araclar.get_url(url)
        araclar.addDir(fileName,'[COLOR blue][B]***** [COLOR lightblue] Gunun Maclari [COLOR blue][B] *****[/B][/COLOR]', "ayniyim(url)",'','special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')
        match=re.compile('<span class="fixture"><a href="../(.*?)">\r\n                    (.*?)\r\n                    vs\r\n                    (.*?)</a></span> <span class="ground">\r\n                      \r\n                         (.*?)\r\n').findall(link)
        for url,bir,iki,saat in match:
            name='[COLOR beige]'+bir+'[COLOR lightblue] vs '+'[COLOR beige]'+iki+' '+'[COLOR yellow]'+saat
            url=base64.b64decode(hangii)+url
            #name='[COLOR lightblue]'+canli+' '+'[COLOR lightyellow]'+saat+'[COLOR beige]'+mac+'[COLOR lightgreen]'+kanal+'[/COLOR]'
            araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "hangikanal(url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/Canli_Mac_izle.png')

def hangikanal(url):            #special://home/addons/plugin.video.dream-clup/channels/HAPPYFEETS/UK_Thomas_Bouquet.py
        link=araclar.get_url(url)
        araclar.addDir(fileName,'[COLOR lightgreen][B] >>> [COLOR tomato] Thomas Bouguet ten Bu Kanali [COLOR lightblue]HD [COLOR tomato]Olarak izleyebilirsiniz[/B][/COLOR]','','',thomast)
        match=re.compile('<div class="channel-logo"> <a href=""><img src="../(.*?)" alt="(.*?)"').findall(link)
        for t,name in match:
                t=(base64.b64decode(hangii))+t.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR]Beklemeden izlemek icin burdan [COLOR orange][B]'+name+'[/B][/COLOR]', "ayniyim(url)",url,t)
        match1=re.compile('<div class="channel-logo"> <a href=".*?"><img src="../(.*?)" alt="(.*?)"').findall(link)
        for t,name in match1:
                t=(base64.b64decode(hangii))+t.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR]Beklemeden izlemek icin burdan [COLOR orange][B]'+name+'[/B][/COLOR]', "ayniyim(url)",url,t)
