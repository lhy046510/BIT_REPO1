# -*- coding: utf-8 -*- 
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re 
import araclar,cozucu,base64
# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

#happyfeets was here :D
  
Addon = xbmcaddon.Addon('plugin.video.dream-clup') 
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup') 
__language__ = __settings__.getLocalizedString 
  
fileName ="Tum_Mac_Ozetleri"
xbmcPlayer = xbmc.Player() 
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO) 
urll='aHR0cDovL2Zvb3R5cm9vbS5jb20='

def main(): 
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        url='aHR0cDovL2Zvb3R5cm9vbS5jb20v'
        link=araclar.get_url(base64.b64decode(url))
        match=re.compile('<header class="vidTop"><a href="(.*?)">(.*?)</a></header>\n\t\t\n\t<div class="vidthumb">\n\t\t<a href=".*?">\n\t\t\t<img src="(.*?)"').findall(link)
        for url,name,t in match:
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "icerik(url)",url,t)
        page=re.compile('<li class="active"><span>.*?</span></li><li><a href=\'(.*?)\' title=\'.*?\'>(.*?)</a></li>').findall(link)
        for url,name in page:
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B]Sayfa >> [/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "gerisi(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

def gerisi(url):
        link=araclar.get_url(url)
        match=re.compile('<header class="vidTop"><a href="(.*?)">(.*?)</a></header>\n\t\t\n\t<div class="vidthumb">\n\t\t<a href=".*?">\n\t\t\t<img src="(.*?)"').findall(link)
        for url,name,t in match:
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B] >> [/B][/COLOR][COLOR orange][B]'+name+'[/B][/COLOR]', "icerik(url)",url,t)
        page=re.compile('<li class="active"><span>.*?</span></li><li><a href=\'(.*?)\' title=\'.*?\'>(.*?)</a></li>').findall(link)
        for url,name in page:
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR blue][B]Sayfa >> [/B][/COLOR]'+'[COLOR red][B]'+name+'[/B][/COLOR]', "gerisi(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")

def icerik(url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)
        match=re.compile('&config=(.*?).json"').findall(link)
        for url2 in match:
            url2=url2+'.json'
            link=araclar.get_url(url2)
            match=re.compile('"rtmp:\/\/streaming.playwire.com\/(.*?)/mp4:(.*?)"').findall(link)
            for url,iki in match:
                    url='http://cdn.playwire.com/'+url+'/'+iki
                    name='[COLOR lightblue] play [/COLOR]'
                    playList.clear()
                    araclar.addLink(name,url,'http://www.maltafootball.com/wp/wp-content/uploads/2011/11/Brasil-2014-World-Cup.gif')
                    listitem = xbmcgui.ListItem(name)
                    playList.add(url, listitem)
                    xbmcPlayer.play(playList)

