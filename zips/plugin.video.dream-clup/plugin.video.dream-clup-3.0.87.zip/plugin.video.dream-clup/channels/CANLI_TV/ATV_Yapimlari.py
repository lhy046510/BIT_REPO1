# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="ATV_Yapimlari"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        tom='rtmp://159.253.131.115/atv playpath=atv3 swfUrl=http://i.tmgrup.com.tr/p/flowplayer-3.2.10.swf?i=2 pageUrl=http://www.atv.com.tr/webtv/canli-yayin live=1'
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme OKUYUNUZ  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B] 7/24 CANLI YAYIN [/B][/COLOR]', "VIDEOLINKS2(name,url)",tom,'special://home/addons/plugin.video.dream-clup/resources/images/ATV.png')
        url='http://www.atv.com.tr/diziler'
        link=araclar.get_url(url)
        link=link.replace('&#252;',"u").replace('&#231;',"c")
        match=re.compile('<li><a href="\/diziler\/(.*?)">(.*?)</a></li>').findall(link)
        for url,name in match:
            url='http://www.atv.com.tr/webtv/'+url+'/bolum'
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"yeni(url)",url,'special://home/addons/plugin.video.dream-clup/resources/images/ATV.png')

def yeni(url):
        link=araclar.get_url(url)  
        #link=link.replace('ü',"u").replace('''," ").replace('\xc4\xb1',"i").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('ç',"c").replace('\xc5\x9f',"s").replace('ö',"o")#.replace('\xc3\x87',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<li><a href="/webtv/(.*?)" target=".*?"><em></em>\r\n<img src="(.*?)" alt="" width=".*?" height=".*?" />            <strong class=".*?"><strong style=".*?">.*?</strong> <span class="bolum">(.*?) </span>').findall(link)
        for url,thumbnail,name in match:
            url='http://www.atv.com.tr/webtv/'+url
            araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]''[COLOR red][B] izle[/B][/COLOR]',"yeni3(name,url)",url,thumbnail)
        page=re.compile('<li class="bn next"><a href="(.*?)">(.*?)</a></li>').findall(link)
        for url,name in page:
            url='http://www.atv.com.tr'+url
            araclar.addDir(fileName,'[COLOR blue][B]'+ name+ '[/B][/COLOR]',"yeni(url)",url,'')
                  
def yeni3(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)  
        match=re.compile('&quot;:&quot;http://rtmp02.atv.com.tr/diziler/(.*?)\/playlist.m3u8%3').findall(link)
        for url in match:
            url='http://rtmp02.atv.com.tr/diziler/'+url+'/playlist.m3u8'
                
            xbmcPlayer = xbmc.Player()
            playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playList.clear()
            araclar.addLink(name,url,'')
            listitem = xbmcgui.ListItem(name)
            playList.add(url, listitem)
            xbmcPlayer.play(playList)

def VIDEOLINKS2(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Kurtlar Vadisi Pusu Haric Tum ATV Dizileri Calisir[/COLOR]","[COLOR orange]Herkese iyi Seyirler.[/COLOR]")
  except:
        
        pass
