# -*- coding: utf-8 -*- happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="SHOW_Yapimlari"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme OKUYUNUZ  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        Show='rtmp://mn-l.mncdn.com/showtv/ playpath=showtv2 swfUrl=http://static.oroll.com/p.swf?v=22.41&ts=9-3-2014 pageUrl=http://www.showtv.com.tr/canli-yayin/showtv live=1'
        ShowTurk='rtmp://mn-l.mncdn.com/showturktv/ playpath=showturktv1 swfUrl=http://static.oroll.com/p.swf?v=22.41&ts=9-3-2014 pageUrl=http://www.showtv.com.tr/canli-yayin/showturk live=1'
        url='http://www.showtv.com.tr/video/category/diziler'
        dahasi='http://www.showtv.com.tr/diziler/arsivdeki-diziler'
        sevda='http://www.diziizlehdfull.net/diziler/sevdaluk'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B]7/24 CANLI YAYIN Show TV [/B][/COLOR]', "VIDEOLINKS2(name,url)",Show,"yeni")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]7/24 CANLI YAYIN Show TURK [/B][/COLOR]', "VIDEOLINKS2(name,url)",ShowTurk,"yeni")
        link=araclar.get_url(url)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('\xc4\xb1',"i").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc5\x9f',"s").replace('&#246;',"o")#.replace('\xc3\x87',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<li class="dp-alt-menu"><a href="\/dizi\/tanitim\/(.*?)" title="">(.*?)</a></li>').findall(link)
        for url,name in match:
                url='http://www.showtv.com.tr/dizi/tum_bolumler/'+url
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"yenidiziler(url)",url,'')
        araclar.addDir(fileName,'[COLOR lightgreen][B]Sevdaluk [/B][/COLOR]', "sevda(url)",sevda,"http://www.aktifhaber.com/d/other/sevdaluk-001-001.jpg")                
        link=araclar.get_url(dahasi)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('\xc4\xb1',"i").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc5\x9f',"s").replace('&#246;',"o")#.replace('\xc3\x87',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match1=re.compile('<div class="dizi" id=".*?">\r\n\t\t\t\t<a href="\/dizi\/tanitim\/(.*?)"><img class=".*?" src="(.*?)" width="250" height="250">\r\n\t\t\t\t\t<ul class=".*?">\r\n\t\t\t\t\t\t<li class=".*?">(.*?)</li>').findall(link)
        for url,thumbnail,name in match1:
                url='http://www.showtv.com.tr/dizi/tum_bolumler/'+url
                araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]''[COLOR red][B] izle[/B][/COLOR]',"eskidiziler2(url)",url,thumbnail)
                
def yenidiziler(url):
        link=araclar.get_url(url)  
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('\xc4\xb1',"i").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc5\x9f',"s").replace('&#246;',"o")#.replace('\xc3\x87',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<a href="(.*?)">\r\n\t\t\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t\t\t<div class="video-play-icon"></div>\r\n\t\t\t\t\t\t\t\t\t<img src="(.*?)" alt="" width=".*?" height=".*?"/>\r\n\t\t\t\t\t\t\t\t\t<div class=".*?">\r\n\t\t\t\t\t\t\t\t\t\t<h3>(.*?)</h3>').findall(link)
        for url,thumbnail,name in match:
                url='http://www.showtv.com.tr'+url
                araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]''[COLOR red][B] izle[/B][/COLOR]',"ayrisdirma(name,url)",url,thumbnail)
        page=re.compile('<a class="sonraki" href="(.*?)"></a>').findall(link)
        for url in page:
                url='http://www.showtv.com.tr'+url
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+'[/B][/COLOR]',"yenidiziler(url)",url,'')

def ayrisdirma(name,url):
        link=araclar.get_url(url)
        link=link.replace('\\',"")
        match1=re.compile('class="selected">\r\n\t\t\t\t\t\t\t(.*?) KISIM\t\t\t\t\t\t</a>').findall(link)
        for name in match1:
                url=url
                name=name+' KISIM '
                araclar.addDir(fileName,'[COLOR pink]>'+name+'[/COLOR]', "mpdort1(name,url)",url,"")
        match=re.compile('<a href="/dizi/tum_bolumler/(.*?)">\r\n\t\t\t\t\t\t\t(.*?)\t\t\t\t\t\t</a>').findall(link)
        for url,name in match:
                url='http://www.showtv.com.tr/dizi/tum_bolumler/'+url
                araclar.addDir(fileName,'[COLOR pink]>'+name+'[/COLOR]', "mpdort1(name,url)",url,"")
        match2=re.compile('var videoPlayerData \= {\n\tid: 99965,\n\turl: "http:\/\/ciner.mncdn.net\/(.*?).flv"').findall(link)
        for flv in match2:
                flv=''
                araclar.addDir(fileName,'[COLOR red]>FLV Str.   '+name+'[/COLOR]', "flv(name,url)",url,"")

def sevda(url):
        link=araclar.get_url(url)  
        match=re.compile('<div class="moviefilm">\n<a href="http:\/\/www.diziizlehdfull.net\/sevdaluk-(.*?).html">\n<img src="(.*?)" ').findall(link)
        for url,thumbnail in match:
                name=url
                url='http://www.diziizlehdfull.net/sevdaluk-'+url+'.html'
                araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]''[COLOR red][B] izle[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('<link rel=\'next\' href=\'(.*?)\' />').findall(link)
        for url in page:
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+'[/B][/COLOR]',"sevda(url)",url,'')


def eskidiziler2(url):
        link=araclar.get_url(url)  
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('\xc4\xb1',"i").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc5\x9f',"s").replace('&#246;',"o")#.replace('\xc3\x87',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<a href="(.*?)">\r\n\t\t\t\t\t\t\t\t<li>\r\n\t\t\t\t\t\t\t\t\t<div class=".*?"></div>\r\n\t\t\t\t\t\t\t\t\t<img src="(.*?)\?v\=.*?" alt="" width="288" height="162"/>\r\n\t\t\t\t\t\t\t\t\t<div class=".*?">\r\n\t\t\t\t\t\t\t\t\t\t<h3>(.*?)</h3>').findall(link)
        for url,thumbnail,name in match:
                url='http://www.showtv.com.tr'+url
                araclar.addDir(fileName,'[COLOR orange][B]'+name+'[/B][/COLOR]''[COLOR red][B] izle[/B][/COLOR]',"flv(name,url)",url,thumbnail)
        page=re.compile('<a class="sonraki" href="(.*?)"></a>').findall(link)
        for url in page:
                url='http://www.showtv.com.tr'+url
                araclar.addDir(fileName,'[COLOR blue][B]Sonraki Sayfa >>[/B][/COLOR]'+'[COLOR red][B]'+'[/B][/COLOR]',"eskidiziler2",url,'')

def mpdort1(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('\\',"")
        match=re.compile('\n\turl: "http://cdn.ciner.com.tr/(.*?).mp4"').findall(link)
        for url in match:
                url='http://cdn.ciner.com.tr/'+url+'.mp4'
                
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

def flv(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)
        link=link.replace('\\',"")
        match=re.compile(' "http:\/\/ciner.mncdn.net\/(.*?).flv"').findall(link)
        for url in match:
                url='http://ciner.mncdn.net/'+url+'.flv'

                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
                
                

def VIDEOLINKS2(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'http://www.showtv.com.tr/images/core/showtv_logo.png')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Tum ShowTV Yapitlari.[/COLOR]","[COLOR orange]Herkese iyi Seyirler.[/COLOR]")
  except:
        
        pass

def VIDEOLINKS(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        
        vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        for url in divxstage:
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
        	#---------------------------------------------#
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        for url in movshare:
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
        for url,uploadcgelen in uploadc:
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                urlList.append(url)

        #-------------------------------
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)

        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                cozucu.magix_player(name,url)
		#---------------------------------------------#
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
        for url,divxstagegelen in divxstage:
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
                cozucu.magix_player(name,url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
     
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:


                if "mail.ru" in url:
                    value.append((name,cozucu.MailRu_Player(url)))
                    
        if  value:
            return value
