# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="FOX"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
        url='http://www.fox.com.tr/bolum-izle'
        tom='http://38.117.88.253:7777/%46%6F%78%54%75%72%6B%69%79%65_%48%44/%46%6F%78%54%75%72%6B%69%79%65_%48%69%67%68.m3u8'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B] 7/24 CANLI YAYIN [/B][/COLOR]', "VIDEOLINKS2(name,url)",tom,'special://home/addons/plugin.video.dream-clup/resources/images/FOX.png')
        link=araclar.get_url(url)  
        match=re.compile('<div class=\'black\'>\r\n\t\t\t\t\t\t\t\t<a href=\'(.+?)\'>(.+?)</a>\r\n\t\t\t\t\t\t\t</div>\r\n\t\t\t\t\t\t\t<div>\r\n\t\t\t\t\t\t\t\t<img width=\'400\' src=\'(.+?)\' alt=.+? title=.+?').findall(link)
        for url,name,thumbnail in match:
            thumbnail='http://www.fox.com.tr'+thumbnail
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"yeni(url)",url,thumbnail)

def yeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<div class=\'videoThmp\'><a href=\'(.*?)\' title=\'.*?\'><img class=\'.*?\' data-original=\'.*?\' src=\'(.*?)\' width=\'.*?\' alt=\'(.*?)\' title=\'.*?\'\' /></a>').findall(link)
        for url,thumbnail,name in match:
            url='http://www.fox.com.tr/'+url
            araclar.addDir(fileName,'[COLOR pink][B]'+name+'[/B][/COLOR]',"yeni3(name,url)",url,'')
        sayfa=re.compile('<li class=\'nrm sayfaitemsAktive\' id=".+?"><a href=\'.+?\'>.+?</a></li>\r\n\t\t\t\t   \r\n\t\t\t\t\t\t\t<li class="nrm" id=".+?"><a href=\'(.+?)\'>(.+?)</a></li>').findall(link)
        for url,name in sayfa:
            url='http://www.fox.com.tr/'+url
            araclar.addDir(fileName,'[COLOR blue][B]Sayfa '+name+'[/B][/COLOR]',"yeni(url)",url,'')
            
def yeni2(name,url):
        link=araclar.get_url(url)  
        match=re.compile('<iframe id="hdsframe" src="(.*?)\&preview\=\&ipadtype\=0\&tip\=1\&part\=" width=".*?" height=".*?" frameborder=".*?" scrolling=".*?"></iframe>').findall(link)
        for url in match:
                print url
                araclar.addDir(fileName,'[COLOR red][B]izle~~ [/B][/COLOR]''[COLOR orange][B]'+ name+ '[/B][/COLOR]',"yeni3(name,url)",url,'')
                              
def yeni3(name,url):       
##        safe='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(safe))
##        match1=re.compile('sir>>(.*?)<<be').findall(link)
##        for kkk in match1:
##                print kkk
        link=araclar.get_url(url)  
        match=re.compile('mobileSource: { ios_sd: "(.*?)"').findall(link)		
        for url in match:
                araclar.addLink(name,url,'')

def VIDEOLINKS2(name,url):
##                safe='aHR0cDovL3hibWN0ci50di8='
##                link=araclar.get_url(base64.b64decode(safe))
##                match1=re.compile('sir>>(.*?)<<be').findall(link)
##                for kkk in match1:
##                        print kkk
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
