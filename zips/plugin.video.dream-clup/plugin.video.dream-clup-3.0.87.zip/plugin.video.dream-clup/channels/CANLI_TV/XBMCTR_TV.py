# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64,time


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="XBMCTR_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
###########
adem='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L0FkZW1UdXJrX0VrbGVudGlsZXJpL1VsdXNhbC1Udi​1LYW5hbGxhcmkueG1s'
ademt='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2L0FkZW1UdXJrX0VrbGVudGlsZXJpL1VsdXNhbC1Udi1LYW5hbGxhcmkucG5n'
urll='aHR0cDovL3hibWN0ci50dg=='
urlll='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2Lw=='
def main():
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        xbmctrtv='aHR0cDovL3hibWN0ci50di9jYW5saS10dg=='
        xbmctrtvt='aHR0cDovL3hibWN0ci50di90ZW1wbGF0ZXMvaW5kaWVsaWZlL2ltYWdlcy9sb2dvcy94Ym1jdHIucG5n'
        xbmctrteam='aHR0cDovL3hibWN0ci5jb20vbGl2ZXR2Lw=='
##        araclar.addDir(fileName,'[COLOR lightblue][B]>>>[COLOR turquoise] XbmcTR_TV IPTV [/B][/COLOR]', "xbmctrtv(url)",(base64.b64decode(xbmctrtv)),(base64.b64decode(xbmctrtvt)))
        araclar.addDir(fileName,'[COLOR lightblue][B]>>>[COLOR lightyellow] XbmcTR_Team IPTV[/B][/COLOR]', "xbmctrteam(url)",(base64.b64decode(xbmctrteam)),'special://home/addons/plugin.video.dream-clup/resources/images/teamm.png')
        
def xbmctrtv(url):
        link=araclar.get_url(url)
        match=re.compile('<a class="yendifItem" style="width:145px;" href="(.*?)">\r\n  \t<span class="yendifItemWrapper">\r\n  \t  <span class="yendifThumb" style="width:145px; height:80px;">\r\n    \t<img class="yendifThumbClip"\r\n             src="(.*?)"             \r\n             alt="(.*?)"').findall(link)
        for url,t,name in match:
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [COLOR lightgreen][B]'+name+'[/B][/COLOR]',"xbmctrtvicerik(url)",url,t)        

def xbmctrtvicerik(url):
        link=araclar.get_url(url)  
        match=re.compile('<a class="yendifItem" style=".*?" href="(.*?)">\n  \t  <span class="yendifItemWrapper">\n    \t<span class="yendifThumb" style=".*?">    \t  \n    \t  <img class="yendifThumbClip"\n               src="(.*?)"               \n               alt="(.*?)"').findall(link)
        for url,t,name in match:
                url=(base64.b64decode(urll))+url.encode('utf-8', 'ignore')
                araclar.addDir(fileName,'[COLOR lightgreen][B]>> [COLOR lightblue][B]'+name+'[/B][/COLOR]',"xbmctrtvoynat(name,url)",url,t)

def xbmctrteam(url):        
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)"> .*?</a></li>\n<li><a href="(.*?).xml"> .*?</a></li>').findall(link)
        if match >0:
                del match[6]
                
                for t,url in match:
                        name=url
                        t=(base64.b64decode(urlll))+t
                        url=(base64.b64decode(urlll))+url.encode('utf-8', 'ignore')+'.xml'
                        araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"xbmctrteamicerik(url)",url,t)
                araclar.addDir(fileName,'[COLOR red]''>> [COLOR beige][B] Adem Media [/B][/COLOR]', "xbmctrteamademicerik(url)",'http://xbmctr.tv',(base64.b64decode(ademt)))
        
        
def xbmctrteamicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>').findall(link)
        for name,t,url in match:
                araclar.addDir(fileName,'[COLOR beige][B]' + name+'[/B][/COLOR]',"xbmctrteamoynat(name,url)",url,t)
        match1=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,t,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B] ' + name+'[/B][/COLOR]',"xbmctrteamoynat(name,url)",url,t)
def xbmctrteamademicerik(url):
        link=araclar.get_url(base64.b64decode(adem))
        match=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\r\n    <link><!\[CDATA\[(.*?)\]\]></link>\r\n    <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\r\n').findall(link)
        for name,url,t in match:            
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"xbmctrteamoynat(name,url)",url,t)
        

def xbmctrteamoynat(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def xbmctrtvoynat(name,url):
        web='aHR0cDovL3NpbmVtYS54Ym1jdHIudHYv'
        link=araclar.get_url(base64.b64decode(web))
        match=re.compile('<li><a href="#" class="toplam">(.*?)</a></li>').findall(link)
        for bul in match:
                bul=''
                print bul
        link=araclar.get_url(url)        
        vlc=re.compile('target="(.*?)"></div>').findall(link)
        for url in vlc:
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        idi=url
        link=link.replace('live.atv.com.tr',"185.2.138.212")
        yendif=re.compile('<source type="video/flash" src=(.*?) data-rtmp="(.*?)">').findall(link)
        for pl,rt in yendif:
                pl=' playpath='+pl
                url=rt+pl+' swfUrl=http://xbmctr.tv/media/yendifvideoshare/player/player.swf pageUrl='+idi+' live=1'
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        dm=re.compile('<iframe src="(.*?)" frameborder="0" height="360" width="540"></iframe>').findall(link)
        for url2 in dm:
                link=araclar.get_url(url2)
                dm1=re.compile('"stream_h264_hq_url":"(.*?)"').findall(link)
                for url in dm1:
                        url=url.replace('\\/',"/")
                        playList.clear()
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name)
                        playList.add(url, listitem)
                        xbmcPlayer.play(playList)

        idi=url
        link=link.replace('%3A',":").replace('%2F',"/")
        hdtv=re.compile(' flashvars="&autostart=true&bandwidth=0&controlbar.size=20&dock=false&file=(.*?)\&image=http://www.hdtvizle.com/preview.jpg&level=0&logo=http://www.hdtvizle.com/tvlogo2.png&plugins=viral-2d&repeat=false&skin=http://www.hdtvizle.com/proplayer/players/skins/nacht.swf&streamer=rtmp://(.*?)\&.*?"').findall(link)
        for pl,rt in hdtv:
                pl=' playpath='+pl
                rt='rtmp://'+rt
                url=rt+pl+' swfUrl=http://www.hdtvizle.com/proplayer/players/player.swf pageUrl='+idi+' live=1'
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        idi=url
        cnnturk=re.compile(' flashvars="file=(.*?)&streamer=rtmp://(.*?)\&').findall(link)
        for pl,rt in cnnturk:
                pl=' playpath='+pl
                rt='rtmp://'+rt
                url=rt+pl+' swfUrl=http://gusto.trt.net.tr/VideoPlayer/player.swf pageUrl='+idi+' live=1'
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        idi=url
        haber61=re.compile(' flashvars="src=rtmp://win8.yayinda.org/haber61tv\/(.*?)\&').findall(link)
        for pl in haber61:
                pl=' playpath='+pl
                url='rtmp://win8.yayinda.org/haber61tv'+pl+' swfUrl=http://www.hdtvizle.com/player/StrobeMediaPlayback.swf pageUrl='+idi+' live=1'
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        halk=re.compile(' flashvars\="src\=rtmp:\/\/(.*?)redirect\/(.*?)\&').findall(link)
        for rt,pl in halk:
                rt='rtmp://'+rt+'liveedge'
                pl=' playpath='+pl
                url=rt+pl+' swfUrl=http://www.hdtvizle.com/player/StrobeMediaPlayback.swf pageUrl='+idi+' live=1'
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

        fox=re.compile('<iframe name="tv" src="(.*?)" width="680" height="410"').findall(link)
        for url2 in fox:
                link=araclar.get_url(url2)
                match=re.compile('"http:\/\/(.*?)\/.*?.m3u8').findall(link)
                if match >0:
                        del match[0]
                        for url in match:
                                url='http://'+url+'/FoxTurkiye_HD/FoxTurkiye_High.m3u8'
                                playList.clear()
                                araclar.addLink(name,url,'')
                                listitem = xbmcgui.ListItem(name)
                                playList.add(url, listitem)
                                xbmcPlayer.play(playList)

        idi=url
        yedi=re.compile(' src=(.*?) data-rtmp="(.*?)"></video>').findall(link)
        for pl,rt in yedi:
                pl=' playpath='+pl
                url=rt+pl+' swfUrl=http://www.hdtvizle.com/player/StrobeMediaPlayback.swf pageUrl='+idi+' live=1'
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
