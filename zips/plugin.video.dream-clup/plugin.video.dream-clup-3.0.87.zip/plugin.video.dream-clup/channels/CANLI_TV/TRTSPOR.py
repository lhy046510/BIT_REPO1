# -*- coding: iso-8859-9 -*- import
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="TRTSPOR"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
#by TheKingLeon - xbmctrTeam www.xbmctr.com

def main():
##        url2='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(url2))
##        match=re.compile('ir>>(.*?)<<be').findall(link)
##        for web1 in match:
##                print web1+''
        canliyayin='http://www.livetv.az/trtspor/'	
	url='http://www.trtspor.com.tr/video-galerileri.html'	
	araclar.addDir(fileName,'[COLOR blue][B]>>CANLI YAYIN[/B][/COLOR]',canliyayin,"Videolinkleri(url,name)",'special://home/addons/plugin.video.dream-clup/resources/images/trtsporcanli.png')
        araclar.addDir(fileName,'>>Yeni Eklenenler',url,"yenieklenen(url)",'special://home/addons/plugin.video.dream-clup/resources/images/trtsporyeni.png')        	
        link=araclar.get_url(url)
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
	match=re.compile('<li><a href="(.+?)" >(.+?)</a></li>').findall(link)		
        for url,name in match:
                araclar.addDir(fileName,'>>' + name,url,"Videobolumler(url)",'')

def ANAMENU(url):
        araclar.addDir(fileName,'[COLOR white][B]<<ANAMENU[/B][/COLOR]',url,'','special://home/addons/plugin.video.dream-clup/resources/images/trtspormain.png')
	
	
def yenieklenen(url):
        link=araclar.get_url(url)
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        #ANAMENU(url)      
        match=re.compile('<li><a href="(.+?)"><i></i><img src="(.+?)" width="150" height="100" alt="" /><span>(.+?)</span></a></li>').findall(link)
        url='http://www.trtspor.com.tr/'+url
        thumbnail='http://www.trtspor.com.tr/'+thumbnail
        for url,thumbnail,name in match:
                araclar.addDir(fileName,name,url,"Videolinkleri(url,name)",thumbnail)
				
                                				
def Videobolumler(url):
        link=araclar.get_url(url)
        link=link.replace('\xf6',"o").replace('&amp;',"&").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
        ANAMENU(url)        
        match=re.compile('<li><a href="(.+?)"><img src="(.+?)" alt="" width="190" height="127" />(.+?)<i></i></a></li>').findall(link)
        for url,thumbnail,name, in match:
		url='http://www.trtspor.com.tr/'+url
                araclar.addDir(fileName,name,url,"Videolinkleri(url,name)",thumbnail)
        sayfa=re.compile('<a href="(.+?)" class="btn-white next-page">(.+?)</a>').findall(link)
        for url,name in sayfa:
                url='http://www.trtspor.com.tr/'+url
                araclar.addDir(fileName,'Sonraki Sayfa  >',url,"Videobolumler(url)",'http://www.carllivseycpa.com/images/arrow_r1_c8.png') 
				
				
def Videolinkleri(url,name):
##        safe='aHR0cDovL3hibWN0ci50di8='
##        link=araclar.get_url(base64.b64decode(safe))
##        match1=re.compile('sir>>(.*?)<<be').findall(link)
##        for kkk in match1:
##                print kkk
        link=araclar.get_url(url)
        ANAMENU(url)
        match=re.compile('file=(.+?)&autostart=true"/>').findall(link)		
        for url in match:
                araclar.addLink(name,url,'')
        canli=re.compile('file: "(.+?)"').findall(link)		
        for url in canli:
                araclar.addLink(name,url,'')     


