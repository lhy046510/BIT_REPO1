# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Cavus38_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://xbmctr.com/livetv/Cavus38_Eklentiler/'
        link=araclar.get_url(url)
        match=re.compile('<a href=".*?"> (.*?).xml</a></li>\n').findall(link)
        for url in match:
                name=url
                thumbnail='http://xbmctr.com/livetv/Cavus38_Eklentiler/'+url+'.png'
                url='http://xbmctr.com/livetv/Cavus38_Eklentiler/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,thumbnail)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
            araclar.addDir(fileName,'[COLOR lightblue][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "Youtube(url)",url,thumbnail)

def yeni4(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)

def Youtube(url):
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                link=araclar.get_url(url)
                link=link.replace('\xf6',"o").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
                match=re.compile('"http:\/\/www.youtube.com\/watch\?v\=(.*?)"').findall(link)
                for url in match:
                    yt = 'plugin://plugin.video.youtube/?action=play_video&videoid='+str(url).encode('utf-8', 'ignore')
                    araclar.addLink('~~Son~~',yt,'')
                    playList.add(yt)
                xbmcPlayer.play(playList)
                if not xbmcPlayer.isPlayingVideo():
                        d = xbmcgui.Dialog()
                        d.ok('Sunucu Hatasi', 'Aranan Video Bulunamadi.','Baska Video Deneyiniz.')
            
