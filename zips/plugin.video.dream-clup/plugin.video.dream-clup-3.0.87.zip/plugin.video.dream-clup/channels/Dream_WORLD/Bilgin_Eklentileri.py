# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Bilgin_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://xbmctr.com/livetv/BilginMediaCenter/'
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?).png"> .*?</a></li>\n').findall(link)
        for url in match:
                name=url
                thumbnail='http://xbmctr.com/livetv/BilginMediaCenter/'+url+'.png'
                url='http://xbmctr.com/livetv/BilginMediaCenter/'+url+'.xml'
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]''[COLOR pink]'+name+'[/B][/COLOR]', "icerik(url)",url,thumbnail)

def icerik(url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        match1=re.compile('<title><!\[CDATA\[(.*?)\]\]></title>\n    <logo_30x30><!\[CDATA\[(.*?)\]\]></logo_30x30>\n    <description>.*?</description>\n    <stream_url><!\[CDATA\[(.*?)\]\]></stream_url>\n').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)

def VIDEOLINKS(name,url):
                link=araclar.get_url(url)
                vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
                for url in vk_1:
                        url = 'http://vk.com/'+str(vk_1[0])
	   
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()

                link=araclar.get_url(url)
                scan=re.compile('video_host = \'(.*?)/\';\nvar video_uid = \'(.*?)\';\nvar video_vtag = \'(.*?)\'').findall(link)

                for a,b,c in scan:
                        
                        videoLink=a +'/u'+ b +'/videos/' + c + '.480.mp4'
                        araclar.addLink(name,videoLink,'')

                try:
                        link=araclar.get_url(url)
                        youtube=re.compile('"http:\/\/www.youtube.com\/watch\?v\=(.*?)"').findall(link)
                        for url in youtube:
                                yt = 'plugin://plugin.video.youtube/?action=play_video&videoid='+str(url).encode('utf-8', 'ignore')
                                araclar.addLink('~~Son~~',yt,'')
                                playList.add(yt)
                        xbmcPlayer.play(playList)

                except:
                        pass
