# -*- coding: utf-8 -*-
import urllib,urllib2,re,base64,os,sys
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS


import araclar,cozucu
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
__language__ = __settings__.getLocalizedString


fileName="Danish_Live_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

t='http://2.bp.blogspot.com/-2sJN4WRahxw/T9T7msMxctI/AAAAAAAACP8/v-6zXdCfx24/s1600/hollanda+danimarka+ma%C3%A7%C4%B1ndaki+g%C3%BCzel.jpg'

def main():
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        url='http://www.floppirepo7.esy.es/site/vlc/?chid=380'        
        link=araclar.get_url(url)
        link=link.replace('&nbsp;',"")
        match=re.compile('<a  href="(.*?)">(.*?)</a>(.*?)<br>').findall(link)
        for url,name,iki in match:
                url='http://www.floppirepo7.esy.es/site/vlc/'+url
                name=name+'[COLOR beige] '+iki+'[/COLOR]'
                araclar.addDir(fileName,'[COLOR lightblue][B]>> [/B][/COLOR]'+'[COLOR lightgreen][B]' + name+'[/B][/COLOR]',"oynat(name,url)",url,t)

def oynat(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        link=araclar.get_url(url)
        link=link.replace('/',"//").replace('&nbsp;',"")
        match=re.compile(' target="rtmp:////(.*?)//(.*?)//(.*?)">').findall(link)
        for rt,iki,pl in match:
                playList.clear()
                rt='rtmp://'+rt+'/'+iki+' '
                pl='playpath='+pl
                url=rt+pl
                playList.clear()
                araclar.addLink(name,url,t)
        if playList:
                xbmcPlayer.play(playList)

        match1=re.compile(' target="http://(.*?)"').findall(link)
        for url in match1:
                url='http://'+url
                playList.clear()
                araclar.addLink(name,url,t)
        if playList:
                xbmcPlayer.play(playList)

