# -*- coding: iso-8859-9 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu
import os,base64

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="Tom_ve_Jerry"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


############# @xmaxell and XbmcTR Team  ##############################
def main():
        tom='rtmp://204.45.108.2/ctv playpath=tom swfUrl=http://www.canaistv.net/swf/player.swf live=r.ates pageUrl=http://www.canaistv.net/tvamigos/tomejerry.html'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR red][B]7/24 CANLI YAYIN Tom & Jerry [/B][/COLOR]', "VIDEOLINKS2(name,url)",tom,"yeni")
        url='http://www.tomvejerryizle.org/'
        link=araclar.get_url(url)
        match=re.compile('<li><a href="(.*?)" title=".*?"><img src="(.*?)" alt="(.*?)" /></a><br />.*?</li>').findall(link)
        for url,thumbnail,name in match:
                name='[COLOR beige][B]'+name+'[/B][/COLOR]'			
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS(name,url)",url,thumbnail)

def VIDEOLINKS(name,url):

        link=araclar.get_url(url)
        match=re.compile('file=(.*?).flv&amp').findall(link)
        for url in match:
                url=url+'.flv'
               # print url
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
def VIDEOLINKS2(name,url):

                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)


