# -*- coding: utf-8 -*- happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,urlresolver
from BeautifulSoup import BeautifulStoneSoup, BeautifulSoup, BeautifulSOAP as BS

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Live_UK"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

url33 = 'http://www.tvip.co.vu/2014/01/englais-iptv-sky-sport-drama-premiere.html'
url2='http://www.tvonlinestreams.com/english-hd-channels-list/'

def main():
        url='http://simplymovies.net/'
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR yellow][B] Movie - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "mSearch()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR red][B]>>>>>>>>>>>>>>>>>[/B][/COLOR][COLOR pink][B] Series - SEARCH[/B][/COLOR][COLOR red][B] <<<<<<<<<<<<<<<<<[/B][/COLOR]', "sSearch()", "","special://home/addons/plugin.video.dream-clup/resources/images/ARAMA_SEARCH.png")
        araclar.addDir(fileName,'[COLOR orange][B]>>  Dikkat OKUYUNUZ  <<[/B][/COLOR] ', "simplyINFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR lightyellow][B]>>  Attention  <<[/B][/COLOR] ', "simplyINFO1(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR pink][B]>> Episode, Series or Movies.. All in One <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR lightyellow][B]>>>>>>>>  New Movies List <<<<<<<<<[/B][/COLOR] ', "soupfilm(url)",url,'http://s4.postimg.org/igqqmbiot/logo16.png')
        link=araclar.get_url(url)  
        match=re.compile('<h3 class="overlayMovieTitle">(.*?)</h3></a>\n\t\t\t\t\t\t<p class="overlayMovieRelease">(.*?)</p>\n\t\t\t\t\t\t<p class="overlayMovieGenres"></p>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="overlayMovieRating">\n\t\t\t\t\t\t\t\t<div class="ratingGreyStars"></div>\n\t\t\t\t\t\t\t\t<div class="ratingYellowStars" style=".*?"></div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class=".*?">\n\t\t\t\t\t\t\t\t<p>.*?</p>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=".*?" href=".*?" target="_blank">.*?</a>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t<p class="overlayMovieDescription">.*?</p>\n\t\t\t\t\t\t<br />\n\t\t\t\t\t</div>\n\t\t\t\t\t<a href="(.*?)">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<img src="(.*?)" ').findall(link)
        for name,date,url,t in match:
                url='http://www.simplymovies.net/'+url
                name=name+' '+'[COLOR red]'+date+'[/COLOR]'
                name=name.replace(', -0001','')
                araclar.addDir(fileName,'[COLOR lightgreen][B]> [COLOR lightblue]'+name+'[/B][/COLOR]',"vkbul(url)",url,t)
                
def vkbul(url):
        link=araclar.get_url(url)
        match=re.compile(' src="http://vk.com/(.*?)"').findall(link)
        for url in match:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                name='[COLOR lightgreen][B]> [COLOR orange] V Server Found [/COLOR]'
                araclar.addDir(fileName,'[COLOR lightgreen][B]> [COLOR lightblue]'+name+'[/B][/COLOR]',"UrlResolver_Player(name,url)",url,'http://cdn.flaticon.com/png/256/2150.png')

def mSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://simplymovies.net/index.php?searchTerm='+query+'&sort=added&genre=')
            simplyYeni(url)

def sSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://simplymovies.net/tv_shows.php?searchTerm='+query+'&sort=added&genre=')
            series(url)

def simplyYeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<h3 class="overlayMovieTitle">(.*?)</h3></a>\n\t\t\t\t\t\t<p class="overlayMovieRelease">(.*?)</p>\n\t\t\t\t\t\t<p class="overlayMovieGenres">.*? </p>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="overlayMovieRating">\n\t\t\t\t\t\t\t\t<div class="ratingGreyStars"></div>\n\t\t\t\t\t\t\t\t<div class="ratingYellowStars" style=".*?"></div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class="numericRating">\n\t\t\t\t\t\t\t\t<p>.*?</p>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class="fancybox fancybox.iframe overlayMovieTrailer" href=".*?" target="_blank">.*?</a>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t<br />\n\t\t\t\t\t\t\t<a class="imdbPageLink" href=".*?" target=".*?">.*?</a>\n\t\t\t\t\t\t\t\t\t\t\t\t<p class="overlayMovieDescription">.*?</p>\n\t\t\t\t\t\t<br />\n\t\t\t\t\t</div>\n\t\t\t\t\t<a href="(.*?)">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<img src="(.*?)" ').findall(link)
        for name,date,url,t in match:
                url='http://www.simplymovies.net/'+url
                name=name+' '+date
                name=name.replace(', -0001','')
                araclar.addDir(fileName,'[COLOR lightgreen][B]> [COLOR lightblue]'+name+'[/B][/COLOR]',"vkbul(url)",url,t)
        match1=re.compile('<h3 class="overlayMovieTitle">(.*?)</h3></a>\n\t\t\t\t\t\t<p class="overlayMovieRelease">(.*?)</p>\n\t\t\t\t\t\t<p class="overlayMovieGenres">.*? </p>\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a class=".*?" href=".*?" target=".*?">.*?</a>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t<br />\n\t\t\t\t\t\t\t<a class=".*?" href=".*?" target=".*?">.*?</a>\n\t\t\t\t\t\t\t\t\t\t\t\t<p class="overlayMovieDescription">.*?</p>\n\t\t\t\t\t\t<br />\n\t\t\t\t\t</div>\n\t\t\t\t\t<a href="(.*?)">\n\t\t\t\t\t\t\t\t\t\t\t\t\t<img src="(.*?)" ').findall(link)
        for name,date,url,t in match1:
                url='http://www.simplymovies.net/'+url
                name=name+' '+date
                name=name.replace(', -0001','')
                araclar.addDir(fileName,'[COLOR lightgreen][B]> [COLOR lightblue]'+name+'[/B][/COLOR]',"vkbul(url)",url,t)

def series(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href=".*?"><h3 class="overlayMovieTitle">(.*?)</h3></a>\n\t\t\t\t\t\t<p class="overlayMovieGenres">.*? </p>\n\t\t\t\t\t\t\t\t\t\t\t\t\t<div class="overlayMovieRating">\n\t\t\t\t\t\t\t\t<div class="ratingGreyStars"></div>\n\t\t\t\t\t\t\t\t<div class="ratingYellowStars" style=".*?"></div>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\t<div class=".*?">\n\t\t\t\t\t\t\t\t<p>.*?</p>\n\t\t\t\t\t\t\t</div>\n\t\t\t\t\t\t\n\t\t\t\t\t\t\t\t\t\t\t\t\t<br />\n\t\t\t\t\t\t\t<a class="imdbPageLink" href=".*?" target="_blank">.*?</a>\n\t\t\t\t\t\t\t\t\t\t\t\t<p class="overlayMovieDescription">.*?</p>\n\t\t\t\t\t\t<br />\n\t\t\t\t\t</div>\n\t\t\t\t\t<a href="(.*?)"><img src="(.*?)" ').findall(link)
        for name,url,t in match:
                url='http://www.simplymovies.net/'+url
                name=name.replace(', -0001','')
                araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"season(url)",url,t)

def season(url):
        link=araclar.get_url(url)  
        match=re.compile('<p><a href="(.*?)">(.*?)</a> (.*?)</p>').findall(link)
        for url,name,date in match:
                url='http://simplymovies.net/'+url
                araclar.addDir(fileName,'[COLOR lightgreen][B]> [COLOR lightblue]'+ name +'[/B][/COLOR][COLOR red]'+ date +'[/COLOR]',"vkbul(url)",url,'special://home/addons/plugin.video.happyfeets.dunyasi/resources/images/SimplyMovies.png')


def simplyINFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]Filmler TAMAMIYLE Orjinal Dillerindedir.[/COLOR]","[COLOR pink]AltYazi ile izlemeniz Tavsiye Edilir.[/COLOR]")
  except:
        
        pass

def simplyINFO1(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR beige]Latest Moveis , Episodes or Series..[/COLOR]","[COLOR pink]Enjoy..[/COLOR]")
  except:
        
        pass

def UrlResolver_Player(name,url):
        UrlResolverPlayer = url
        playList.clear()
        media = urlresolver.HostedMediaFile(UrlResolverPlayer)
        source = media
        if source:
                url = source.resolve()
                araclar.addLink(name,url,'')
                araclar.playlist_yap(playList,name,url)
                xbmcPlayer.play(playList)
