# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="MarcoPasha_Eklentileri"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        ssmc='http://marcopasha.esy.es/root/PasHa/pasha.xml'
        enter='http://xbmctr.com/livetv/yeni.xml'
        sinema='http://www.filmizlendi.org'
        hepsiburda='http://xbmc-support.site50.net/blog/new-mixed-iptv-list-sports-french-channels-documentry-channels-movies-and-general-entertainment/'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]SSMC Eklentisi[/B][/COLOR]', "Yerli(url)", ssmc,"special://home/addons/plugin.video.dream-clup/resources/images/SSMC.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightgreen][B]Entertainment Eklentisi[/B][/COLOR]', "enter(url)", enter,"http://www.countrypark.co.uk/CMSImages//Entertainment%20Banner.jpg")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B]En Son Filmler[/B][/COLOR]', "sinema(url)", sinema,"http://www.azimdemirbas.com/wp-content/uploads/2013/07/logo-star.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B]Karma IPTV[/B][/COLOR]', "hepsiburda(url)", hepsiburda,"http://lh5.ggpht.com/MNpUKrEnooLgl5BomertlKUztrts9yety1fIfDzPgj25XvDEqhri9HGt_MbxxDPM_w=w300")

def Yerli(url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n\n\t\t\t<thumbnail>(.*?)</thumbnail>\n\n\t\t\t<link>(.*?)</link>').findall(link)
        for name,thumbnail,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,thumbnail)

def yeni4(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
######################
def enter(url):
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\r\n        <thumbnail>(.*?)</thumbnail>\r\n        <link>(.*?)</link>\r\n').findall(link)
        for name,url,thumbnail in match:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,thumbnail)
        match1=re.compile('<title>(.*?)</title>\r\n    <thumbnail>(.*?)</thumbnail>\r\n    <link>(.*?)</link>\r\n\t').findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,thumbnail)
        match2=re.compile('<title>(.*?)</title>\r\n\t\t<thumbnail>(.*?)</thumbnail>\r\n\t\t<link>(.*?)</link>\r\n\t').findall(link)
        for name,thumbnail,url in match2:
                araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,thumbnail)
#####################
def sinema(url):
        link=araclar.get_url(url)
        match=re.compile('<li class="cat-item cat-item-.*?"><a href="http://www.filmizlendi.org/(.*?)/" ').findall(link)
        for url in match:
            name=url
            url='http://www.filmizlendi.org/'+url+'/'
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "sinemaicerik(url)",url,'http://www.azimdemirbas.com/wp-content/uploads/2013/07/logo-star.png')

def sinemaicerik(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="moviefilm">\n<a href="(.*?)">\n<span class=".*?"></span><img src="(.*?)" alt="(.*?)" ').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]>[/COLOR]'+name+'[/B][/COLOR]', "VIDEOLINKS(name,url)",url,thumbnail)
        page=re.compile('<a class="nextpostslink" href="(.*?)"').findall(link)
        for url in page:
                araclar.addDir(fileName,'[COLOR purple][B]>> Sonraki Sayfa [/B][/COLOR]',"sinemaicerik(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")
#################
def hepsiburda(url):
        link=araclar.get_url(url)
        match=re.compile('#EXTINF:-1,(.*?)</p>\n<p>(.*?)</p>\n<p>').findall(link)
        for name,url in match:
            araclar.addDir(fileName,'[COLOR beige][B][COLOR orange]> [/COLOR]'+name+'[/B][/COLOR]', "yeni4(name,url)",url,'http://lh5.ggpht.com/MNpUKrEnooLgl5BomertlKUztrts9yety1fIfDzPgj25XvDEqhri9HGt_MbxxDPM_w=w300')
#--------------------------#
def VIDEOLINKS(name,url):
        #---------------------------#
        urlList=[]
        #---------------------------#
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('&amp;', '&').replace('&#038;', '&').replace('%3A',':').replace('%2F','/').replace('%3F','?').replace('%3D','=').replace('%26','&').replace('%2F','/')

		#---------------------------------------------#
        vk_2=re.compile('<iframe src="http://vk.com/(.*?)"').findall(link)
        for url in vk_2:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)
        
        vk_1=re.compile('src="http://vk.com/(.*?)"').findall(link)
        for url in vk_1:
                url = 'http://vk.com/'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)
		#---------------------------------------------#
        veka=re.compile('value="http:\/\/.*?\/veka.swf\?file\=(.*?)\&otobaslat\=0"').findall(link)
        for url in veka:
                url = 'http://'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)
		#---------------------------------------------#
        divxstage=re.compile('src=\'http://embed.divxstage.eu/(.*?)&').findall(link)
        for url in divxstage:
                url = 'http://embed.divxstage.eu/'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)
        	#---------------------------------------------#
##        youtube2=re.compile('src=".*?.youtube.com/embed/(.*?)?feature=player_detailpage"').findall(link)
##        for url in youtube2:
##                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
##                urlList.append(url)
		#---------------------------------------------#
        youtube=re.compile('src="http://www.youtube.com/embed/(.*?)"').findall(link)
        for url in youtube:
                url = 'http://www.youtube.com/embed/'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)
		#---------------------------------------------#
        movshare=re.compile('src=\'http://embed.movshare.net/(.*?)&').findall(link)
        for url in movshare:
                url = 'http://embed.movshare.net/'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)
		#---------------------------------------------#
        uploadc=re.compile('src="(.*?)uploadc(.*?)"').findall(link)
        for url,uploadcgelen in uploadc:
                url = str(url)+'uploadc'+str(uploadcgelen).encode('utf-8', 'ignore')
                urlList.append(url)
		#---------------------------------------------#
        mailru=re.compilematch=re.compile('src="http:\/\/api.video.mail.ru\/videos\/embed\/mail\/(.*?).html?').findall(link)
        for mailrugelen in mailru:
                url = 'http://video.mail.ru/movieSrc=/mail/'+str(mailrugelen)+'&autoplay=0'
                print url
                urlList.append(url)

        #-------------------------------
        mailru4=re.compile('"movieSrc":   "mail/(.*?)"').findall(link)
        for mailrugelen in mailru4:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
        #-------------------------------
                
        dm=re.compile('src="http://www.dailymotion.com/embed/video/(.*?)"').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+str(url).encode('utf-8', 'ignore')
                urlList.append(url)

        mailru3=re.compile('movieSrc: "(.*?)"').findall(link)
        for mailrugelen in mailru3:
                url = 'http://api.video.mail.ru/videos/embed/'+str(mailrugelen)+'.html'
                urlList.append(url)
		#---------------------------------------------#
        mailru2=re.compile('src=".*?mail.*?mail/(.*?).html"').findall(link)
        for mailrugelen in mailru2:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        mailru5=re.compile('<iframe src=\'http://api.video.mail.ru/videos/embed/mail/(.*?).html\'').findall(link)
        for mailrugelen in mailru5:
                url = 'http://video.mail.ru/movieSrc=/mail/'+mailrugelen+'&autoplay=0'
                urlList.append(url)
		#---------------------------------------------#
        video=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
        for videodgelen in video:
                url =videogelen
                urlList.append(url)
		#---------------------------------------------#
        divxstage=re.compile('src="(.*?)divxstage(.*?)"').findall(link)
        for url,divxstagegelen in divxstage:
                url = str(url)+'divxstage'+str(divxstagegelen).encode('utf-8', 'ignore')
                urlList.append(url)
		#---------------------------------------------#
		#---------------------------------------------#
		#---------------------------------------------#
        if not urlList:
                match=re.compile('flashvars="file=(.*?)%3F.*?" />').findall(link)
                print match
                if match:
                        for url in match:
                                VIDEOLINKS(name,url)
       
        if urlList:
                Sonuc=playerdenetle(name, urlList)
                for name,url in Sonuc:
                        araclar.addLink(name,url,'')
                        listitem = xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage='')
                        listitem.setInfo('video', {'name': name } )
                        playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)

        else:
                dialog = xbmcgui.Dialog()
                i = dialog.ok(name,"Site uyarısı","     Film Siteye henuz yuklenmedi   ","  Yayınlandıktan sonra yüklenecektir.  ")
                return False 

        
def playerdenetle(name, urlList):
        value=[]
        import cozucu
        for url in urlList if not isinstance(urlList, basestring) else [urlList]:

                if "vk.com" in url:
                    value.append((name,araclar.VK_Player(url)))
                    
                if 'youtube' in url:
                    value.append((name,araclar.Youtube_Player(url)))


                if 'dailymotion' in url:
                    value.append((name,araclar.Daily_Player(url)))

                if "video.ak.fbcdn.net" in url:
                    value.append(("F Server",url))

                if "fbcdn-video-a.akamaihd.net" in url:
                    value.append(("F Server",url))

                if "mail.ru" in url:
                    value.append((name,araclar.MailRu_Player(url)))
                    
        if  value:
            return value







