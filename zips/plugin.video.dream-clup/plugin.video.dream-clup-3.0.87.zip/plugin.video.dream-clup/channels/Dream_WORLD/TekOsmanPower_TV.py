# -*- coding: utf-8 -*- happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="TekOsmanPower_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        url='http://xbmctr.com/acces/TEKOSMANPOWERTV.xml'
        link=araclar.get_url(url)
        match=re.compile('<title>(.*?)</title>\n<link>(.*?)</link>\n<thumbnail>(.*?)</thumbnail>\n</item>').findall(link)
        for name,url,thumbnail in match:
                araclar.addDir(fileName,'[COLOR beige]~~ '+ name+'[/COLOR]',"oynatbakalim(name,url)",url,thumbnail)

def oynatbakalim(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
