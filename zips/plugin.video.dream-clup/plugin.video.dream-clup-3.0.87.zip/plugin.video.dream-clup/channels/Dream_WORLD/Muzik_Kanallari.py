# -*- coding: utf-8 -*- c by happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu

Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString

fileName ="Muzik_Kanallari"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        Karma='http://www.xbmctr.com/'
        trradyo='http://canliyayinradyolar.com/mini-mod/?canli-yayin=2'
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B] Tum Radyolar [/B][/COLOR]', "trradyo(url)",trradyo,"http://a1.mzstatic.com/us/r30/Purple6/v4/32/fe/60/32fe6085-6843-3180-7bf6-f7bd6cbcc794/icon_256.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightyellow][B] Karma[/B][/COLOR] [COLOR red]>>>>[/COLOR][COLOR turquoise] ARA [/COLOR][COLOR red]<<<<[/COLOR]', "KarmaSearch()", "",'special://home/addons/plugin.video.dream-clup/resources/images/KARMA.png')
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR pink][B] Emir Erim YouTube[/B][/COLOR] [COLOR red]>>>>[/COLOR][COLOR turquoise] ARA [/COLOR][COLOR red]<<<<[/COLOR]', "EmirErimSearch()", "","special://home/addons/plugin.video.dream-clup/resources/images/emirerimyoutube.PNG")

def trradyo(url):
        link=araclar.get_url(url)
        match=re.compile('<option value="(.*?)">(.*?)</option>\n').findall(link)
        for url, name in match:
                url='http://canliyayinradyolar.com/mini-mod/?canli-yayin='+url
                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',"trradyooynat(url)",url,'http://www.akdeniz-elektronik.com/wp-content/uploads/akdeniz-sub-woofer-slider.png')

def trradyooynat(url):
        link=araclar.get_url(url)
        match=re.compile(' value="var1=(.*?)\&').findall(link)
        for url in match:
                ame='[COLOR lightblue]'+' server 1 oynat' +'[/COLOR]'
                araclar.addDir(fileName,name,url,'http://www.beejazzy.net/img/logo-wmp11.png')
        match1=re.compile(' href\="\/mac-win-mediaplayer.php\?url\=(.*?)\&.*?">').findall(link)
        for url in match1:
                name='[COLOR lightgreen]'+' server 2 oynat' +'[/COLOR]'
                araclar.addDir(fileName,name,"trOynat(url)",url,'http://www.simarikradyo.com/wp-content/uploads/online-dinle.png')
        match2=re.compile('<embed id="FlashKontrol" style=".*?" width=".*?" height=".*?" type=".*?" src="(.*?)" quality=".*?" wmode=".*?" devicefont=".*?" swliveconnect=".*?" allowscriptaccess=".*?" flashvars="rtmp\=(.*?)\&ns\=(.*?)&facebooklinki\=(.*?)\&.*?').findall(link)
        for swf,url,playpath,pageurl in match2:
                swf=' swfUrl='+swf
                playpath=' playpath='+playpath
                pageurl=' pageUrl='+pageurl
                url=url+playpath+swf+pageurl
                name='[COLOR pink]'+' server 3 oynat' +'[/COLOR]'
                araclar.addDir(fileName,name,"trOynat(url)",url,'http://radyo.lolturk.net/images/wmp.png')

def trOynat(url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(url)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)       
##############################################################
def KarmaSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://www.myvideo.az/c/search?srch_str='+query)
            KarmaYeni(url)

def KarmaYeni(url):
        link=araclar.get_url(url)  
        match=re.compile('<a href="\?video_id\=(.*?)" class=".*?">(.*?)</a>').findall(link)
        for url,name in match:
            name=name.replace('&#039;','&')
            url='http://www.myvideo.az/?video_id='+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"KarmaVIDEOLINKS(name,url)",url,"")
        sayfalama=re.compile('<li class="selected">1</li><li><a href="(.*?)" >(.*?)</a>').findall(link)
        for url,name in sayfalama:
            url='http://www.myvideo.az/'+url
            url=url.replace('amp;','')
            print url,name
            araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"KarmaYeni(url)",url,"special://home/addons/plugin.video.dream-clup/resources/images/sonrakisayfa.png")                     

def KarmaVIDEOLINKS(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()

        link=araclar.get_url(url)
        match=re.compile("'http://(.*?).mp4\'").findall(link)
        for url in match:
                url='http://'+url+'.mp4?start=0'
        playList.add
        araclar.addLink(name,url,'')
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(playList)
##############################################################

def EmirErimSearch():
        keyboard = xbmc.Keyboard("", 'Search', False)
        keyboard.doModal()
        if keyboard.isConfirmed():
            query = keyboard.getText()
            query=query.replace(' ','+')
            url = ('http://www.youtube.com/user/muyap/search?query='+query)
            EmirErimYeni(url)

def EmirErimYeni(url):
        link=araclar.get_url(url)  
        match=re.compile('title="(.*?)"\n        data-sessionlink=".*?"\n        href="\/watch\?v=(.*?)"\n').findall(link)
        for name,a in match:
            thumbnail='http://i1.ytimg.com/vi/'+a+'/hqdefault.jpg'
            url='http://www.youtube.com/watch?v='+a
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"VIDEOLINKSEmirErim(url)",url,thumbnail)

def VIDEOLINKSEmirErim(url):
    xbmcPlayer = xbmc.Player()
    playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playList.clear()
    link=araclar.get_url(url) 
    link=link.replace('\xf6',"o").replace('\xd6',"O").replace('\xfc',"u").replace('\xdd',"I").replace('\xfd',"i").replace('\xe7',"c").replace('\xde',"s").replace('\xfe',"s").replace('\xc7',"c").replace('\xf0',"g")
    you_match=re.compile('<link rel="canonical" href="http:\/\/www.youtube.com\/watch\?v\=(.*?)">').findall(link)
    for url in you_match:
        url='http://www.youtube.com/embed/'+url
        Sonuc=cozucu.videobul(url)
        if Sonuc=="False":
            dialog = xbmcgui.Dialog()
            i = dialog.ok(name,"Site uyarisi","     Film Siteye henuz yuklenmedi   ","  Yayinlandiktan sonra yuklenecektir.  ")
            return False
        else:
            for name,url in Sonuc if not isinstance(Sonuc, basestring) else [Sonuc]:
                            araclar.addLink(name,url,'')
                            araclar.playlist_yap(playList,name,url)
            xbmcPlayer.play(playList)
##############################################################

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Muzik Bizim isimiz[/COLOR]","[COLOR orange]Radyo yetmedi diyenler icin ozel aramayi kullaniniz[/COLOR]")
  except:
        
        pass
##############################################################

