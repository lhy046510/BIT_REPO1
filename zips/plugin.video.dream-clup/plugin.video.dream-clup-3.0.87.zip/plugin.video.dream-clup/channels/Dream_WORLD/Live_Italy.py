# -*- coding: utf-8 -*- c by HappyFeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="Live_Italy"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

def main():
        it='http://en.iphone-tv.eu/channels/it'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B] Italy TV Buketi [/B][/COLOR]', "bobliste(url)",it,"http://i2.cdn.turner.com/cnn/dam/assets/111110054126-italy-girl-flag-story-top.jpg")

def bobliste(url):
        link=araclar.get_url(url)
        link=link.replace('amp;','')
        match=re.compile('<a href="(.*?)" title=".*?"><img src="(.*?)" width="90" height="80" alt="(.*?)"></a>\n').findall(link)
        for url,thumbnail,name in match:
                url='http://en.iphone-tv.eu/'+url
                thumbnail='http://en.iphone-tv.eu'+thumbnail
                araclar.addDir(fileName,'[COLOR blue]>> [/COLOR][COLOR lightgreen]'+ name+'[/COLOR]',"boblisteicerik(url)",url,thumbnail)
               
def boblisteicerik(url):
        link=araclar.get_url(url)
        link=link.replace('STREAM_URL_2','http://ipm.iphone-tv.eu:1345')
        match=re.compile('var streamURL = "(.*?)"').findall(link)
        for url in match:
                name='[COLOR pink]>> start live streaming [/COLOR]'
                playList.clear()
                playList.add(name)
                araclar.addLink(name,url,'http://www.fornokia.net/data/programs/images/31790004_256x256-192x192__programView1_8225.jpg')
        if playList:
                xbmcPlayer.play(playList)
#################################################
