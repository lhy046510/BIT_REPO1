# -*- coding: utf-8 -*- happyfeets
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu,base64


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="TRT1"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)


def main():
        url2='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(url2))
        match=re.compile('ir>>(.*?)<<be').findall(link)
        for web1 in match:
                print web1+''
        araclar.addDir(fileName,'[COLOR red][B]>>  Bilgilendirme OKUYUNUZ  <<[/B][/COLOR] ', "INFO(name)",'','special://home/addons/plugin.video.dream-clup/resources/images/unlem.png')
        canli='rtmp://trt-i.mncdn.com/r_trt1/_definst_/tvizlet.me playpath=trt13  swfUrl=http://tvizlet-me.do.am/tvizlet.me4.5.swf pageUrl=http://www.tvizlet.me/2012/11/trt-1-hd-izle.html'
        url='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=1'
        diziler2='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=2'
        diziler3='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=3'
        diziler4='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=4'
        diziler5='http://www.trt.net.tr/anasayfa/dinleizle.aspx?tur=tv&sk=t5tnXaBKYkGRZGnm_k3vgg&sn=5'
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR orange][B]7/24 CANLI YAYIN [/B][/COLOR]', "VIDEOLINKS2(name,url)",canli,'special://home/addons/plugin.video.dream-clup/resources/images/TRT1.png')
        link=araclar.get_url(url)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler2)  
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler3)  
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler4)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
        link=araclar.get_url(diziler5)
        link=link.replace('&#252;',"u").replace('&#39;'," ").replace('&#246;',"o").replace('\xc5\x9f',"s").replace('\xc4\x9f',"g").replace('&#231;',"c").replace('\xc4\xb1',"i").replace('&#246;',"o").replace('&#199;',"C")#.replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"diziler(url)",url,thumbnail)
                
def diziler(url):
        link=araclar.get_url(url)
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"mpdort1(name,url)",url,thumbnail)
        page=re.compile('<div style="clear:both;"><br/><br/> | <a href\=".\/(.*?)">(.*?)</a>').findall(link)
        for url,name in page:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR blue][B]Sayfa >> [/B][/COLOR]'+'[COLOR pink][B]'+name+'[/B][/COLOR]',"diziler2(url)",url,'')

def diziler2(url):
        link=araclar.get_url(url)  
        match=re.compile('<div class="medyaKutu"><a href="(.*?)" title="(.*?) - .*?"><img src="(.*?)" ').findall(link)
        for url,name,thumbnail in match:
            url='http://www.trt.net.tr/anasayfa/'+url
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"mpdort1(name,url)",url,thumbnail)

def mpdort1(name,url):
        safe='aHR0cDovL3hibWN0ci50di8='
        link=araclar.get_url(base64.b64decode(safe))
        match1=re.compile('sir>>(.*?)<<be').findall(link)
        for kkk in match1:
                print kkk
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        link=araclar.get_url(url)
        link=link.replace('\\',"")
        match=re.compile('"mms://(.*?).wmv"').findall(link)
        for url in match:
                url='mms://'+url+'.wmv'
                                
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
                

def VIDEOLINKS2(name,url):
                safe='aHR0cDovL3hibWN0ci50di8='
                link=araclar.get_url(base64.b64decode(safe))
                match1=re.compile('sir>>(.*?)<<be').findall(link)
                for kkk in match1:
                        print kkk
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'http://www.showtv.com.tr/images/core/showtv_logo.png')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

def INFO(name):
  try:
        dialog = xbmcgui.Dialog()
        i = dialog.ok(name, "[COLOR pink]Yogunluktan Dolayi Bazen ilk Denemede Acilmayabilir.[/COLOR]","[COLOR orange]Brkac Dakika Sonra Tekrar Deneyin.[/COLOR]")
  except:
        
        pass
