# -*- coding: utf-8 -*-
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,urllib,urllib2,os,sys,re
import araclar,cozucu


Addon = xbmcaddon.Addon('plugin.video.dream-clup')
__settings__ = xbmcaddon.Addon(id='plugin.video.dream-clup')
__language__ = __settings__.getLocalizedString


fileName ="CANLI_TV"
xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
###########

def main():
        
            
        web='http://xbmctr.com/livetv/'
        link=araclar.get_url(web)
        match=re.compile('<li><a href="(.*?)">.*?.png</a></li>\n<li><a href="(.*?).xml">.*?.xml</a></li>').findall(link)
        for a,b in match:
                name=b
                name=araclar.name_fix(name)
                url=web+b+'.xml'                
                thumbnail='http://xbmctr.com/livetv/'+a                
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+'[COLOR beige][B]' +name+'[/B][/COLOR]',"VIDEOLINKS(name,url)",url,thumbnail)

        alternative='http://www.eniyitv.com/ipad-iphone-tv-izle/'
        happytv='http://happyfeets.net78.net/HFOTV/tvler.xml'
        happyradyo='http://happyfeets.net78.net/HFOTV/radyolar.xml'

        araclar.addDir(fileName,'[COLOR pink][B]>>>[/B] HappyFeets TV izle ~~[/COLOR][COLOR red] [B]>>>>[/B][/COLOR][COLOR turquoise] Alfabetik[/COLOR] & [COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]', "happyyayin(url)", happytv,"http://www.canlitvradyo.org/wp-content/themes/canlitv/images/logo.png")
        araclar.addDir(fileName,'[COLOR yellow][B]>>>[/B] HappyFeets Radyo Dinle ~~[/COLOR][COLOR red] [B]>>>>[/B][/COLOR][COLOR turquoise] Alfabetik[/COLOR] & [COLOR green]OTO GUNCEL [/COLOR][COLOR red]<<<<[/COLOR]', "happyyayin(url)", happyradyo,"http://www.canlitvradyo.org/wp-content/themes/canlitv/images/logo.png")
        araclar.addDir(fileName,'[COLOR blue][B]>>[/B][/COLOR] [COLOR lightblue][B]Alternatif Turkce TV Kanallari [/B][/COLOR]', "canliyayinalternative(url)", alternative,"http://www.istanbulbayrak.net/BAYRAK34.png")
        url='http://www.canlitvx.com/'
        link=araclar.get_url(url)  
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"I")
        match=re.compile('<a href="(.*?)" rel="bookmark">\n<img width="216" height="120" src="(.*?)" class=".*?" alt="(.*?)"/>').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"canliyayinyeni2(name,url)",url,thumbnail)
        url='http://www.canlitvx.com/page/2/'
        link=araclar.get_url(url)  
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"I")
        match=re.compile('<a href="(.*?)" rel="bookmark">\n<img width="216" height="120" src="(.*?)" class=".*?" alt="(.*?)"/>').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"canliyayinyeni2(name,url)",url,thumbnail)
        url='http://www.canlitvx.com/page/3/'
        link=araclar.get_url(url)  
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"I")
        match=re.compile('<a href="(.*?)" rel=".*?">\n                    \t<img width=".*?" height=".*?" src="(.*?)" class="entry-thumb wp-post-image" alt="(.*?)" /> ').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"canliyayinyeni2(name,url)",url,thumbnail)

def canliyayinalternative(url):            
        link=araclar.get_url(url)
        match=re.compile('<a title=".*?" href="(.*?)"><img title="(.*?)" alt=".*?" src="(.*?)" width=".*?" height=".*?"').findall(link)
        for url,name,thumbnail in match:
            araclar.addDir(fileName,'[COLOR red][B]T[/B][/COLOR]'+'[COLOR white][B]R -[/B][/COLOR]'+'[COLOR beige][B]' + name+'[/B][/COLOR]',"canliyayinyeni4(name,url)",url,thumbnail)
        

def canliyayinYeni(url):
        link=araclar.get_url(url)  
        link=link.replace('\xc4\xb0',"i").replace('\xc3\x9c',"u").replace('\xc3\x87',"C").replace('\xc4\xb1',"I")
        match=re.compile('<a href="(.*?)" rel=".*?">\n                    \t<img width=".*?" height=".*?" src="(.*?)" class="entry-thumb wp-post-image" alt="(.*?)" /> ').findall(link)
        for url,thumbnail,name in match:
            araclar.addDir(fileName,'[COLOR lightgreen][B]'+name+'[/B][/COLOR]',"canliyayinyeni2(name,url)",url,thumbnail)           
        page=re.compile('.</span><span class=\'current\'>.*?</span><a href=\'(.*?)\' class=\'page larger\'>(.*?)</a').findall(link)        
        for url,name in page:
                araclar.addDir(fileName,'[COLOR purple][B]>>SAYFA-' + name+'[/B][/COLOR]',"canliyayinYeni(url)",url,"")                     
        
#############       

def canliyayinyeni2(name,url):
        link=araclar.get_url(url)  
        match=re.compile('var sourceMedia = "(.*?)";').findall(link)
        for url in match:
                print url,'aaa'
                
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)

def canliyayinyeni4(name,url):  
        link=araclar.get_url(url)  
        match=re.compile('src="(.*?).m3u8"').findall(link)
        for url in match:
                url=url+'.m3u8'
                                
                xbmcPlayer = xbmc.Player()
                playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playList.clear()
                araclar.addLink(name,url,'')
                listitem = xbmcgui.ListItem(name)
                playList.add(url, listitem)
                xbmcPlayer.play(playList)
def canliyayinname_fix(x):        
        x=x.replace('aaa','bbb').replace("-",' ')
        return x[0].capitalize() + x[1:]

#############
def VIDEOLINKS(name,url):
        link=araclar.get_url(url)
        match=re.compile("<name>(.*?)</nam.*?ail>(.*?)</th.*?nk>(.*?)</link>").findall(link)
        for name,thumbnail,url in match:
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail)
        match1=re.compile("<name>(.*?)</name>\n<thumbnail>(.*?)</thumbnail>\n<link>(.*?)</link>").findall(link)
        for name,thumbnail,url in match1:
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail)
        match2=re.compile('<name><!\[CDATA\[(.*?)\]\]></name>\n  <thumbnail><!\[CDATA\[(.*?)\]\]></thumbnail>\n  <link><!\[CDATA\[(.*?)\]\]></link>\n').findall(link)
        for name,thumbnail,url in match2:
                araclar.addDir(fileName,'[COLOR red]''>>''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail)
        match3=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link> \n').findall(link)
        for name,thumbnail,url in match3:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail)
        match4=re.compile('<title>(.*?)</title>\n  <thumbnail>(.*?)</thumbnail>\n  <link>(.*?)</link>\n').findall(link)
        for name,thumbnail,url in match4:
                araclar.addDir(fileName,'[COLOR red]''>> ''[/COLOR]'+ name,"VIDEOLINKS2(name,url)",url,thumbnail)
        
##############
def VIDEOLINKS2(name,url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()
        araclar.addLink(name,url,'')
        listitem = xbmcgui.ListItem(name)
        playList.add(url, listitem)
        xbmcPlayer.play(playList)
##############

def happyyayin(url):            
        link=araclar.get_url(url)
        match=re.compile('<br/>\n(.*?)\=(.*?)<br/>').findall(link)
        for name,url in match:
            araclar.addDir(fileName,'[COLOR orange]'+ name+'[/COLOR]',"VIDEOLINKS2(name,url)",url,'http://www.netindir.gen.tr/wp-content/uploads/2012/05/tv1.png')
        altradyo=re.compile('<br/>\n(.*?)\=(.*?)<br/>').findall(link)
        for name,url in altradyo:
            araclar.addDir(fileName,'[COLOR orange]'+ name+'[/COLOR]',"VIDEOLINKS2(name,url)",url,'http://www.netindir.gen.tr/wp-content/uploads/2012/05/tv1.png')
           
                

