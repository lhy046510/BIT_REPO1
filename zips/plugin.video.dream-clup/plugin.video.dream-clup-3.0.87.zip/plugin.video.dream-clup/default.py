# -*- coding: utf-8 -*-

# for more info please visit http://xbmctr.com
'''
Created on 21 sempember 2012

@author: drascom
@version: 0.2.0

'''

import os
import sys
import urllib
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import araclar,xbmctools,cozucu
#--------------Sifre-----------#

#----------------
addon_id = 'plugin.video.dream-clup'
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
fanart = xbmc.translatePath( os.path.join( home, 'fanart.png' ) )
channels = xbmc.translatePath(os.path.join(home, 'channels'))
sys.path.append(channels)

klasorler=os.walk(channels).next()[1]
for klasor in klasorler:
    dizim=xbmc.translatePath(os.path.join(channels, klasor))
    sys.path.append(dizim)
IMAGES_PATH = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(IMAGES_PATH)

def main():
    klasorler=os.walk(channels).next()[1]
    for klasor in klasorler:
        fileName=klasor.replace(" ","")
        name='[COLOR lightgreen][B]'+klasor+'[/B][/COLOR]'
        thumbnail= os.path.join(IMAGES_PATH,klasor+".png")
        url=xbmc.translatePath(os.path.join(channels, klasor))
        araclar.addDir("araclar", name,"listing(IMAGES_PATH,url)", url,thumbnail)
    xbmc.executebuiltin("Container.SetViewMode(500)")
def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param
    
    
params = get_params()
name = None
fileName = None
mode = None
url = None
thumbnail = None

#Try-catch blocks to see which parameters are available 
try:
    name = urllib.unquote_plus(params["name"])
except:
    pass
try:
    fileName = urllib.unquote_plus(params["fileName"])
except:
    pass
try:
    mode = urllib.unquote_plus(params["mode"])
except:
    pass
try:
    url = urllib.unquote_plus(params["url"])
except:
    pass
try:
    thumbnail = urllib.unquote_plus(params["thumbnail"])
except:
    pass

print "Ad: "+str(name)
print "Dosya: "+str(fileName)
print "mode: "+str(mode)
print "Url: "+str(url)
print "Resim: "+str(thumbnail)


if fileName == None:
    main()
    cozucu.kalala(IMAGES_PATH,channels)

else:
    exec "import "+fileName+" as channel"
    exec "channel."+str(mode)
xbmcplugin.endOfDirectory(int(sys.argv[1]))



