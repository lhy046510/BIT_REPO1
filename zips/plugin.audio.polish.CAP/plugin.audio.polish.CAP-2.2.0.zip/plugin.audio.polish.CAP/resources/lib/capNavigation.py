# -*- coding: utf-8 -*-
import os, sys
import xbmcgui, xbmc, xbmcaddon, xbmcplugin
import capCommon, sdParser, sdLog


t = sys.modules[ "__main__" ].language
cap = xbmcaddon.Addon()
log = sdLog.pLog()
dbg = sys.modules[ "__main__" ].dbg
parser = sdParser.Parser()
Fanart = os.path.join(cap.getAddonInfo('path') + "\Fanart.jpg")


class VideoNav:
    def __init__(self):
	pass

    def addVideoContextMenuItems(self, params={}):
	params['action'] = 'download'
	param = parser.setParam(params)
	cm = []
	#cm.append((t(55800), "XBMC.RunPlugin(%s?service=%s&path=%s&action=play&url=%s&vtitle=%s)" % (sys.argv[0], params['service'], params['path'], params['url'], params['title'])))
	cm.append((t(55801), "XBMC.RunPlugin(%s%s)" % (sys.argv[0], param)))
	cm.append((t(55804), "XBMC.Action(Info)",))
	return cm

class RecordNav:
    def __init__(self):
	pass

    def addVideoContextMenuItems(self, params={}):
	path = ""
	cm = []
	cm.append((t(55800), "XBMC.RunPlugin(%s?service=%s&path=%s&action=play&item=%s)" % (sys.argv[0], params['service'], params['path'], params['item'])))
	cm.append((t(55802), "XBMC.RunPlugin(%s?service=%s&path=%s&action=recording&url=%s)" % (sys.argv[0], params['service'], params['path'], params['item'])))
	cm.append((t(55803), "XBMC.RunPlugin(%s?service=%s&path=%s&action=timerecording&url=%s)" % (sys.argv[0], params['service'], params['path'], params['item'])))
	cm.append((t(55804), "XBMC.Action(Info)",))
	return cm

class capGUI:
    def __init__(self):
	self.cm = capCommon.common()
	self.history = capCommon.history()

 #    def addDir(self, params, isFolders=True):
	# u=sys.argv[0] + parser.setParam(params)
	# if self.cm.isEmptyDict(params, 'icon'):
	#     params['icon'] = "DefaultVideo.png"

	# if dbg == True:
	#     log.info(" - addDir: ")
	#     parser.debugParams(params, True)

	# if self.cm.isEmptyDict(params, 'title'):
	#     return False
	# liz=xbmcgui.ListItem(params['title'], iconImage="DefaultFolder.png", thumbnailImage=params['icon'])
	# xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolders)

    def __setInfoLabels(self, params, pType):
	InfoLabels = {}
	if pType=="video":
		infoLabelsKeys = ["genre", "year", "episode", "season", "top250", "tracknumber", "rating", "playcount", "overlay",
		    "cast", "castandrole", "director", "mpaa", "plot", "plotoutline", "title", "originaltitle", "sorttitle",
		    "duration", "studio", "tagline", "writer", "tvshowtitle", "premiered", "status", "code", "aired", "credits",
		    "lastplayed", "album", "artist", "votes", "trailer", "dateadded"]
	elif pType=="music":
		infoLabelsKeys = ["tracknumber", "duration", "year", "genre", "album", "artist", "title", "rating",
			"lyrics", "playcount", "lastplayed"]

	for key, value in params.items():
	    if key in infoLabelsKeys:
		InfoLabels[key] = value
	return InfoLabels

    def __play(self, params, isPlayable=False, isFolders=False, pType="video"):
	if pType=="video":
	    params['name'] = 'playSelectedVideo'
	elif pType=="music":
	    params['name'] = 'playSelectedAudio'
	u=sys.argv[0] + parser.setParam(params)

	pType = pType.replace("dir_","")

	params['icon'] = params.get('icon') or "DefaultVideo.png"

	if dbg == True:
	    log.info(" - "+pType+": ")
	    parser.debugParams(params, True)

	params['title'] = params.get('title') or None
	if params['title'] == None: return False

	liz=xbmcgui.ListItem(params['title'], iconImage="DefaultFolder.png", thumbnailImage=params['icon'])
	if isPlayable:
	    liz.setProperty("IsPlayable", "true")

	params['fanart'] = params.get('fanart') or Fanart

	params['banner'] = params.get('banner') or params['icon']

	meta = self.__setInfoLabels(params, pType)
	meta.update({'art(banner)': params['banner'], 'art(poster)': params['icon']})

	liz.setProperty("fanart_image", params['fanart'])
	liz.setInfo( type=pType, infoLabels=meta )
	if (not self.cm.isEmptyDict(params, 'dstpath')) and pType=='music':
	    cm = self.__addDownloadContextMenu({ 'service': params['service'], 'title': params['title'], 'url': params['page'], 'path': (params['dstpath'], params['service']) })
	    liz.addContextMenuItems(cm, replaceItems=False)
	xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolders)

    def __addDownloadContextMenu(self, params={}):
	params['action'] = 'download'
	param = parser.setParam(params)
	cm = []
	cm.append((t(55801), "XBMC.RunPlugin(%s%s)" % (sys.argv[0], param)))
	cm.append((t(55804), "XBMC.Action(Info)",))
	return cm

    def playVideo(self, params, isPlayable=False, isFolders=False):
	self.__play(params, isPlayable, isFolders, "video")

    def playAudio(self, params, isPlayable=False, isFolders=False):
	self.__play(params, isPlayable, isFolders, "music")

    def addDir(self, params, isFolders=True):
	self.__play(params, False, isFolders, "dir_video")

    def endDir(self, sort=False, content=None, viewMode=None, ps=None):
	'''
	ToDo:
	Check is Confluence, not? other View Mode
	Confluence View Modes:
	http://www.xbmchub.com/forums/general-python-development/717-how-set-default-view-type-xbmc-lists.html#post4683
	https://github.com/xbmc/xbmc/blob/master/addons/skin.confluence/720p/MyVideoNav.xml
	'''
	if ps==None:
	    ps=int(sys.argv[1])
	if sort==True:
	    xbmcplugin.addSortMethod(ps, xbmcplugin.SORT_METHOD_LABEL)
	canBeContent = ["files", "songs", "artists", "albums", "movies", "tvshows", "episodes", "musicvideos"]
	if content in canBeContent:
	    xbmcplugin.setContent(ps,content)
	if viewMode!=None:
            if 'confluence' in xbmc.getSkinDir():
                if viewMode=='List':
                    view='50'
                elif viewMode=='Big List':
                    view='51'
                elif viewMode=='ThumbnailView':
                    view='500'
                elif viewMode=='PosterWrapView':
                    view='501'
                elif viewMode=='PosterWrapView2_Fanart':
                    view='508'
                elif viewMode=='MediaInfo':
                    view='504'
                elif viewMode=='MediaInfo2':
                    view='503'
                elif viewMode=='MediaInfo3':
                    view='515'
                elif viewMode=='WideIconView':
                    view='505'
                elif viewMode=='MusicVideoInfoListView':
                    view='511'
                elif viewMode=='AddonInfoListView1':
                    view='550'
                elif viewMode=='AddonInfoThumbView1':
                    view='551'
                elif viewMode=='LiveTVView1':
                    view='560'
                else:
                    view='None'
            else:
                view='None'
            xbmc.executebuiltin("Container.SetViewMode(%s)" % (view))
	xbmcplugin.endOfDirectory(ps)

    def new_playlist(self, playlist='audio'):
	playlists = {'audio': 0, 'video': 1}
	if playlist not in playlists.keys():
	    log.info('Playlista "%s" jest inwalidą ;).' % playlist)
	selected_playlist = xbmc.PlayList(playlists[playlist])
	selected_playlist.clear()
	return selected_playlist

    def add_to_playlist(self, playlist, items):
	if isinstance(items, list):
	    for item in items:
		playlist.add(item)
    	elif isinstance(items, str):
	    playlist.add(items)

    def __LOAD_AND_PLAY(self, url, title, player = True, pType='video'):
	if url == '':
	    d = xbmcgui.Dialog()
	    d.ok('Nie znaleziono streamingu', 'Może to chwilowa awaria.', 'Spróbuj ponownie za jakiś czas')
	    return False
	thumbnail = xbmc.getInfoImage("ListItem.Thumb")
	liz=xbmcgui.ListItem(title, iconImage="DefaultVideo.png", thumbnailImage=thumbnail)
	liz.setInfo( type="pType", infoLabels={ "Title": title } )
	try:
	    if player != True:
		print "custom player pCommon"
		xbmcPlayer = player
	    else:
		print "default player pCommon"
		xbmcPlayer = xbmc.Player()
	    xbmcPlayer.play(url, liz)
	except:
	    d = xbmcgui.Dialog()
	    if pType=="video":
	    	d.ok('Wystąpił błąd!', 'Błąd przy przetwarzaniu, lub wyczerpany limit czasowy oglądania.', 'Zarejestruj się i opłać abonament.', 'Aby oglądać za darmo spróbuj ponownie za jakiś czas.')
	    elif pType=="music":
	    	d.ok('Wystąpił błąd!', 'Błąd przy przetwarzaniu.', 'Aby wysłuchać spróbuj ponownie za jakiś czas.')
	    return False
	return True

    def LOAD_AND_PLAY_VIDEO(self, url, title, player = True):
	if url != False:
	    self.__LOAD_AND_PLAY(url, title, player, "video")
	else:
	    d = xbmcgui.Dialog()
	    d.ok('Brak linku!', 'Przepraszamy, chwilowa awaria.', 'Zapraszamy w innym terminie.')

    def LOAD_AND_PLAY_AUDIO(self, url, title, player = True):
	if url != False:
	    self.__LOAD_AND_PLAY(url, title, player, "music")
	else:
	    d = xbmcgui.Dialog()
	    d.ok('Brak linku!', 'Przepraszamy, chwilowa awaria.', 'Zapraszamy w innym terminie.')

    def searchInput(self, SERVICE, heading='Wyszukaj'):
	keyboard = xbmc.Keyboard('', heading, False)
	keyboard.doModal()
	if keyboard.isConfirmed():
	    text = keyboard.getText()
	    self.history.addHistoryItem(SERVICE, text)
	    return text

    def percentDialog(self):
	return xbmcgui.DialogProgress()
