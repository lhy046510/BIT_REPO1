service.subtitles.subscene
==========================

argenteam.net subtitle service plugin for XBMC

== Roadmap ==

v1.0
- Make the sync flag to appear on subtitles that are synced version of the original translation
- Make the hearing impared flag to appear con subtitles that are shown as "CC"