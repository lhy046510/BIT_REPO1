import urllib,urllib2,re,xbmcplugin,xbmcgui, xbmcaddon


# 
############################################################################

#Set root path
ROOTDIR = xbmcaddon.Addon('plugin.video.theverge').getAddonInfo('path')

#Settings
settings = xbmcaddon.Addon(id="plugin.video.theverge")

#Main settings
#NONE

#Localisation
local_string = xbmcaddon.Addon(id='plugin.video.theverge').getLocalizedString

#Content type
#xbmcplugin.setContent(int(sys.argv[1]), 'episodes')


#XML DOWNLOAD
############################################################################
def downloadFile(url,filename):
    response = urllib2.urlopen(url)
    downloadedXML = response.read().replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
    downloadedXML = ' '.join(downloadedXML.split()) #Removes whitespace
    print "Download successful"

    #Save the XML
    fileObj = open(os.path.join(ROOTDIR, filename),"w")
    fileObj.write(downloadedXML)
    fileObj.close()
    print "File Saved"

    
#XBMC INTERFACE  
############################################################################
def CATEGORIES():

    #Add categories
    addDir('On The Verge','on-the-verge',1,'')
    addDir('The Vergecast','the-vergecast',1,'')
    addDir('The Verge Mobile Show','the-verge-mobile-show',1,'')
    addDir('90 Seconds on The Verge','90-seconds-on-the-verge',1,'')
    addDir('Top Shelf','top-shelf',1,'')
    addDir('The Verge Book Club','book-club',1,'')
    #addDir('Latest Videos','latest-videos',1,'')
    addDir('The Verge at CES 2013','ces2013',1,'')

                   
def VIDEOS(url,name):

    if url == 'on-the-verge':
        addDir('Full Episodes','on-the-verge-full',1,'')
        addDir('Show Segments','on-the-verge-segments',1,'')
        addDir('Show Interviews','on-the-verge-interview',1,'')
    elif url == 'ces2013':
        #Download HTML
        feed_url = 'http://new.livestream.com/TheVerge'
        feed = urllib2.urlopen(feed_url)
        feed_xml = feed.read().replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
        feed_xml = ' '.join(feed_xml.split()) #Removes whitespace

        #Get all events
        items = []
        items = re.findall(r'<a title="Share".*?>', feed_xml)
        
        for item in items:
            if "CES" in item:
                title = re.findall(r'data-event_title="(.*?)"', item)[0]
                event_id = re.findall(r'data-event_id="(.*?)"', item)[0]
                addDir(title,event_id,2,'')                
 
    else:
        #Download the RSS feed
        feed_url = ''
        if url == 'the-vergecast':
            feed_url = 'http://feeds.feedburner.com/TheVergecastVideo'
        elif url == 'the-verge-mobile-show':
            feed_url = 'http://api.ooyala.com/syndication/podcast?id=592700e6-9ea7-45b3-ac83-423a37195a03'
        elif url == '90-seconds-on-the-verge':
            feed_url = 'http://api.ooyala.com/syndication/podcast?id=d8e8567a-7766-4229-b719-735d72cb35ad'
        elif url == 'latest-videos':
            feed_url = 'http://www.theverge.com/rss/label/video/index.xml'
        elif url == 'on-the-verge-full':
            feed_url = 'http://feeds.feedburner.com/on-the-verge'
        elif url == 'on-the-verge-segments':
            feed_url = 'http://www.theverge.com/rss/label/on-the-verge-segment/index.xml'
        elif url == 'on-the-verge-interview':
            feed_url = 'http://www.theverge.com/rss/label/on-the-verge-interview/index.xml'
        elif url == 'top-shelf':
            feed_url = 'http://feeds.podtrac.com/lw7snpU3FeU$'
        elif url == 'book-club':
            feed_url = 'http://feeds.podtrac.com/KP3hDOhhEko$'

        feed = urllib2.urlopen(feed_url, timeout=20)
        feed_xml = feed.read().replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
        feed_xml = ' '.join(feed_xml.split()) #Removes whitespace

        #Get all RSS feed items
        items = []
        if url == 'latest-videos' or url == 'on-the-verge-segments' or url == 'on-the-verge-interview':
            items = re.findall(r'<entry>(.*?)</entry>', feed_xml)
        else:
            items = re.findall(r'<item>(.*?)</item>', feed_xml)

        print items
        #Get title, url and thumb
        for item in items:
            title = re.findall(r'<title>([^"]+)</title>', item)
            video_url = []
            if url == 'latest-videos':
                video_url = re.findall(r'<link type="video/mp4" rel="enclosure" href="([^"]+)"/>', item)
            elif url == 'on-the-verge-segments' or url == 'on-the-verge-interview':
                video_url = re.findall(r'<content type="html"><a href="([^"]+)">', item)
            else:
                video_url = re.findall(r'<enclosure url="([^"]+)" ', item)
                
            thumb_url = ''
            if url == 'the-verge-mobile-show':
                thumb_url = re.findall(r'<media:thumbnail url="([^"]+)" ', item)[0]
    
            #Add videos
            if len(video_url) > 0 and len(title) > 0:
                if url == 'book-club':
                    fixedTitle = title[0].replace('&#x27;', '\"')
                    addLink(fixedTitle,video_url[0],fixedTitle,thumb_url)
                else:
                    addLink(title[0],video_url[0],title[0],thumb_url)
                    


def VIDEOS2(url,name):
    #Download HTML
    feed_url = 'http://new.livestream.com/TheVerge/events/' + url + "/videos"
    feed = urllib2.urlopen(feed_url)
    feed_xml = feed.read().replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
    feed_xml = ' '.join(feed_xml.split()) #Removes whitespace

    #Get all videos
    items = []
    items = re.findall('<div class="video">(.*?)</div>', feed_xml)

    for item in items:
        if "CES" in item:
            title = re.findall(r'"post-header">(.*?)</h3>', item)[0]
            post_id = re.findall(r'data-post_id="(.*?)"', item)[0]
            addDir2(title,'http://api.new.livestream.com/accounts/1818635/events/' + url + '/videos/' + post_id + '.smil',3,'')

    
    #Not used
    if url == 'on-the-verge-full':
        print'Full Episodes'
        addDir('Full Episodes','on-the-verge',1,'')
    elif url == 'on-the-verge-segments':
        print 'Show Segments'
        addDir('Show Segments','on-the-verge',1,'')
    elif url == 'on-the-verge-interviews':
        print 'Show Interviews'
        addDir('Show Interviews','on-the-verge',1,'')

    
def VIDEOS3(url,name):
    #Get video url
    feed_url = url
    feed = urllib2.urlopen(feed_url)
    feed_xml = feed.read().replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"').replace('&#39;', "'")
    feed_xml = ' '.join(feed_xml.split()) #Removes whitespace

    baseurl = re.findall('<meta name="httpBase" content="(.*?)"', feed_xml)[0]
    src = re.findall(r'src="(.*?)"', feed_xml)
    src=src[len(src)-1]

    #Play
    liz=xbmcgui.ListItem('', iconImage="DefaultVideo.png", thumbnailImage='')
    liz.setInfo( type="Video", infoLabels={ "Title": '' } )
    xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(baseurl+src,liz)
    

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param



def addLink(name,url,title,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": title } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir2(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        return ok
    
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()

elif mode==1:
        print ""+url
        VIDEOS(url,name)

elif mode==2:
        print ""+url
        VIDEOS2(url,name)

elif mode==3:
        print ""+url
        VIDEOS3(url,name)

        
xbmcplugin.endOfDirectory(int(sys.argv[1]))

