plugin.video.snagfilms
================


XBMC Addon for Snagfilms website

Version 1.0.6  added popular, most recent sort types
Version 1.0.5 added search
Version 1.0.4 added gzip processing for all url requests
version 1.0.3 minor bug cleanup
version 1.0.2 initial release

