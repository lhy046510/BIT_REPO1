# -*- encoding: utf-8 -*- 
"""
 Plugin for accessing videos on http://www.ceskatelevize.cz/ivysilani
"""

import sys
from xbmcPluginInterface import *

def run():
    from czechtvPlugin import CzechtvPlugin
    iface = XBMCPluginInterface("plugin.video.xbmc-czech.CzechTV")
    plugin = CzechtvPlugin( iface )
    plugin.call( *sys.argv )


if __name__ == '__main__':
    run()

