This XBMC script runs with iBeLight from RGB Styles.

For more informations visit http://www.rgb-styles.com

