metadata.artists.metal-archives.com
===================================

XBMC scraper for get artists metadata from www.metal-archives.com
