# ###  - By TheHighway ### #
# ########################################################## #

import xbmc,xbmcgui,urllib,urllib2,os,sys,logging,array,re,time,datetime,random,string,StringIO,xbmcplugin,xbmcaddon
from config import Config as Config
import common as Common
from common import *
import common

class MyWindow(xbmcgui.Window):
	button={}
	def __init__(self):
		self.scr={}; self.scr['L']=0; self.scr['T']=0; self.scr['W']=1280; self.scr['H']=720; 
		self.makePageItems(); 
	def makePageItems(self):
		tOffset=40; self.b1=artp("black1"); self.background=(xbmc.translatePath(Config.fanart)); self.background=artj("backdrop"); 
		self.texture=artp("fire_button-focus"); focus=artp("purple_button-focus"); nofocus=artp("pink_button-focus"); 
		## ### ##
		self.BG=xbmcgui.ControlImage(self.scr['L'],self.scr['T'],self.scr['W'],self.scr['H'],self.background,aspectRatio=0); self.addControl(self.BG)
		self.BG.setAnimations([('WindowOpen','effect=fade time=2000 start=0')])
		w=32; h=32; self.imgHeart=xbmcgui.ControlImage((self.scr['W']/2)-(w/2),(self.scr['H']/2)-(h/2),w,h,artp("tlrheart"),aspectRatio=0); self.addControl(self.imgHeart); 
		## ### ## Addon Title
		zz=["XBMCHUB","Your","HUB-HUG"]; w=1000; h=50; l=15; t=700; self.LabTitleText=Config.name; self.LabTitle=xbmcgui.ControlLabel(l,t,w,h,'','font30','0xFFFF0000',angle=90); self.addControl(self.LabTitle)
		for z in zz:
			if z+" " in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace(z+" ","[COLOR deepskyblue][B][I]"+z+"[/I][/B][/COLOR]  ")
		if "Highway" in self.LabTitleText: self.LabTitleText=self.LabTitleText.replace("Highway","[COLOR tan]Highway[/COLOR]")
		self.LabTitle.setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0-(l+10)))]); self.LabTitle.setLabel(self.LabTitleText); 
		## ### ##
		self.YN="Your Name"; self.TN="Their Name"; self.YNs=""+self.YN; self.TNs=""+self.TN; 
		try: self.YNs=""+SettingG("ynm"); #deb("YourName",self.YNs); 
		except:pass
		## ### ## Your Name
		w=200; h=32; l=200; t=345; l=(self.scr['W']/3)-(w); t=(self.scr['H']/2)-(h/2); 
		self.txtYourNameBG=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtYourNameBG)
		self.txtYourName=xbmcgui.ControlButton(l,t,w,h,self.YNs,textColor="0xFFFF1493",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.txtYourName)
		self.txtYourNameBGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtYourNameBGL)
		self.txtYourNameL=xbmcgui.ControlLabel(l,t-tOffset,w,h,self.YN,'font14','0xFF000000',alignment=2); self.addControl(self.txtYourNameL)
		## ### ## Crush's Name
		w=200; h=32; l=800; t=345; l=self.scr['W']-(self.scr['W']/3); t=(self.scr['H']/2)-(h/2); 
		self.txtTheirNameBG=xbmcgui.ControlImage(l,t,w,h,self.b1,aspectRatio=0); self.addControl(self.txtTheirNameBG)
		self.txtTheirName=xbmcgui.ControlButton(l,t,w,h,self.TNs,textColor="0xFFFF1493",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.txtTheirName)
		self.txtTheirNameBGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtTheirNameBGL)
		self.txtTheirNameL=xbmcgui.ControlLabel(l,t-tOffset,w,h,self.TN,'font14','0xFF000000',alignment=2); self.addControl(self.txtTheirNameL)
		## ### ## Results
		w=80; h=32; l=(self.scr['W']/2)-(w/2); t=(self.scr['H']/2)-(h); 
		self.txtResultBGL=xbmcgui.ControlImage(l,t-tOffset,w,h,self.texture,aspectRatio=0); self.addControl(self.txtResultBGL)
		self.txtResultL=xbmcgui.ControlLabel(l,t-tOffset,w,h,"?? %",'font14','0xFF000000',alignment=2); self.addControl(self.txtResultL)
		## ### ## Buttons
		w=135; h=32; l=30; t=70; 
		self.button[0]=xbmcgui.ControlButton(l,t,w,h,"Exit",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[0])
		self.button[0].setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0-l)+','+str(0-h-10))])
		w=200; h=32; l=(self.scr['W']/2)-(w/2); t=self.scr['H']-(self.scr['H']/4); 
		self.button[1]=xbmcgui.ControlButton(l,t,w,h,"Test your love",textColor="0xFF000000",focusedColor="0xFF00BFFF",alignment=2,focusTexture=focus,noFocusTexture=nofocus); self.addControl(self.button[1])
		self.button[1].setAnimations([('WindowOpen','effect=slide delay=1000 time=1000 start='+str(0)+','+str(self.scr['H']-t+10))])
		## ### ## Movements
		self.button[0].controlUp(self.button[1]); self.button[0].controlDown(self.txtYourName); self.txtYourName.controlUp(self.button[0]); self.txtYourName.controlDown(self.txtTheirName); self.txtTheirName.controlUp(self.txtYourName); self.txtTheirName.controlDown(self.button[1]); self.button[1].controlUp(self.txtTheirName); self.button[1].controlDown(self.button[0]); 
		self.button[0].controlLeft(self.button[1]); self.button[0].controlRight(self.txtYourName); self.txtYourName.controlLeft(self.button[0]); self.txtYourName.controlRight(self.txtTheirName); self.txtTheirName.controlLeft(self.txtYourName); self.txtTheirName.controlRight(self.button[1]); self.button[1].controlLeft(self.txtTheirName); self.button[1].controlRight(self.button[0]); 
		## ### ## Focus
		self.setFocus(self.button[0])
	def onAction(self,action):
		if   action == Config.ACTION_PREVIOUS_MENU: self.CloseWindow1st()
		elif action == Config.ACTION_NAV_BACK: self.CloseWindow1st()
	def onControl(self,control):
		if   control==self.button[0]: self.CloseWindow1st()
		elif control==self.txtYourName: self.txtYourName.setLabel(showkeyboard(txtMessage=self.txtYourName.getLabel(),txtHeader=self.YN)); SettingS("ynm",self.txtYourName.getLabel()); #deb("YourName",self.txtYourName.getLabel()); deb("YourName()",str(SettingG("ynm"))); 
		elif control==self.txtTheirName: self.txtTheirName.setLabel(showkeyboard(txtMessage=self.txtTheirName.getLabel(),txtHeader=self.TN))
		elif control==self.button[1]: 
			try:
				html=nolines(getURL('http://www.lovecalculator.com/love.php?name1=%s&name2=%s' % (urllib.quote_plus(self.txtYourName.getLabel()),urllib.quote_plus(self.txtTheirName.getLabel())))); #print html
				r=re.compile('<div class="result score">\s*(.+?)\s*</div>').findall(html)[0]; 
				self.txtResultL.setLabel(r+""); 
			except: pass
	def CloseWindow1st(self):
		#try: zz=[self.CtrlList,self.RepoThumbnail,self.RepoFanart2,self.RepoFanart,self.LabCurrentRepo,self.LabTitle,self.button[0],self.TVS,self.TVSBGB,self.BGB]
		#except: zz=[]
		#for z in zz:
		#	try: self.removeControl(z); del z
		#	except: pass
		self.close()
## ################################################## ##
## ################################################## ##
## Start of program
TempWindow=MyWindow(); TempWindow.doModal(); del TempWindow
## ################################################## ##
## ################################################## ##
