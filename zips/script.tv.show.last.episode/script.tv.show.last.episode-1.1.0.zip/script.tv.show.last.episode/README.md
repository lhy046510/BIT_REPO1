script.tv.show.last.episode
===========================

XBMC Script AddOn that lists the last episode of each TV show in the library
