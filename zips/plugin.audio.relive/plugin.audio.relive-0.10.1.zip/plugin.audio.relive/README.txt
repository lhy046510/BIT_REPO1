GENERAL

This is a simple XBMC add-on to listen to archives of demoscene related radio shows and podcasts - and primarily scenesat.com - an excellent demo scene orientated radio station - http://www.scenesat.com. It allows you to see all the tracks for a show and skip to a part of your choice. It also features some preset streams for the live broadcasts.

"The demoscene is a computer art subculture that specializes in producing demos, which are non-interactive audio-visual presentations that run in real-time on a computer. The main goal of a demo is to show off programming, artistic, and musical skills." /Wikipedia

Check out the SceneSat archives and their live stream as a good starting point.

INSTALL

The add-on is available in the official XBMC repository. 

If you still want to install manually, move the "plugin.audio.relive" directory into your "addons" directory.