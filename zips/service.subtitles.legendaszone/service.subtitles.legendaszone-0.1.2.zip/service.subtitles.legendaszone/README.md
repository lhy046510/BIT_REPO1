service.subtitles.legendaszone
=========================

Legendas-Zone.org subtitle service plugin for XBMC 13 Gotham or newer. Ported from
the Frodo version.

HiGhLaNdeR
