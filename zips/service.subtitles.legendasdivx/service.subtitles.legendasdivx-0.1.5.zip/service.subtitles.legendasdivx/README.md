service.subtitles.legendasdivx
=========================

LegendasDivx.com subtitle service plugin for XBMC 13 Gotham or newer. Ported from
the Frodo version.

HiGhLaNdeR
