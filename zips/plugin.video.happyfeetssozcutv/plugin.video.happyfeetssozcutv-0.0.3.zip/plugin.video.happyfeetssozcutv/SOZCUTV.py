import urllib,urllib2,re,xbmcplugin,xbmcgui

#!/usr/bin/python
# -*- coding: utf-8 -*-
# Copyright (c) 2013
# Writer (c) 2013, xbmcTR Team by HappyFeets & xmaxell
# Turkiye, E-mail: yenihandy@gmail.com

def CATEGORIES():
        addDir('[COLOR blue]<<< Bilgilendirme >>>[/COLOR]','Info',7,'http://happyfeets.net78.net/HFOTV/addon.png')
        addDir('[COLOR red]>>> Haber[/COLOR]','http://video.sozcu.com.tr/kategori/haber',5,'http://sozcu.cubecdn.net/static/images/sozculogo248x90.png')
        addDir('[COLOR green]>>> Spor[/COLOR]','http://video.sozcu.com.tr/kategori/spor',4,'http://sozcu.cubecdn.net/static/images/sozculogo248x90.png')
        addDir('[COLOR yellow]>>> Eglence[/COLOR]','http://video.sozcu.com.tr/kategori/eglence',6,'http://sozcu.cubecdn.net/static/images/sozculogo248x90.png')
        addDir('[COLOR red]>>> Ozel Roportajlar[/COLOR]','http://video.sozcu.com.tr/kategori/yorum',8,'http://sozcu.cubecdn.net/static/images/sozculogo248x90.png')
        addDir('[COLOR purple]>>> Magazin[/COLOR]','http://video.sozcu.com.tr/kategori/magazin',3,'http://sozcu.cubecdn.net/static/images/sozculogo248x90.png')

def INDEX(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb0',"I").replace('&#8221;'," ").replace('&#8220;'," ").replace('&#8230;'," ").replace('&#8216;'," ").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<a href="(.*?)" title=".*?"><img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" /></a>').findall(link)
        for url,thumbnail, name in match:
            print url,thumbnail,name
            addDir(name,url,2,thumbnail)
            

def Magazin(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    link=link.replace('\xc4\xb0',"I").replace('&#8221;'," ").replace('&#8220;'," ").replace('&#8230;'," ").replace('&#8216;'," ").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
    response.close()
    match=re.compile('<a href="(.*?)" title=".*?"><img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" /></a>').findall(link)
    for url,thumbnail, name in match:
        print url,thumbnail,name
        addDir('>>-'+name,url,14,thumbnail)

    sayfalama=re.compile('<li><a href=\'http://video.sozcu.com.tr/kategori/magazin/(.*?)\'>(.*?)</a>').findall(link)
    for url, name in sayfalama:
            url='http://video.sozcu.com.tr/kategori/magazin/'+url
            print url,name
            addDir('> SAYFA  '+name,url,3,'')  

def Spor(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb0',"I").replace('&#8221;'," ").replace('&#8220;'," ").replace('&#8230;'," ").replace('&#8216;'," ").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<a href="(.*?)" title=".*?"><img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" /></a>').findall(link)
        for url,thumbnail, name in match:
                print url,thumbnail,name
                addDir('>>-'+name,url,14,thumbnail)

        sayfalama=re.compile('<li><a href=\'http://video.sozcu.com.tr/kategori/spor/(.*?)\'>(.*?)</a>').findall(link)
        for url, name in sayfalama:
                url='http://video.sozcu.com.tr/kategori/spor/'+url
                print url,name
                addDir('> SAYFA  '+name,url,4,'')

def Haber(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb0',"I").replace('&#8221;'," ").replace('&#8220;'," ").replace('&#8230;'," ").replace('&#8216;'," ").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<a href="(.*?)" title=".*?"><img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" /></a>').findall(link)
        for url,thumbnail, name in match:
                print url,thumbnail,name
                addDir('>>-'+name,url,14,thumbnail)

        sayfalama=re.compile('<li><a href=\'http://video.sozcu.com.tr/kategori/haber/(.*?)\'>(.*?)</a>').findall(link)
        for url, name in sayfalama:
                url='http://video.sozcu.com.tr/kategori/haber/'+url
                print url,name
                addDir('> SAYFA  '+name,url,5,'')

def eglence(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb0',"I").replace('&#8221;'," ").replace('&#8220;'," ").replace('&#8230;'," ").replace('&#8216;'," ").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<a href="(.*?)" title=".*?"><img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" /></a>').findall(link)
        for url,thumbnail, name in match:
                print url,thumbnail,name
                addDir('>>-'+name,url,14,thumbnail)

        sayfalama=re.compile('<li><a href=\'http://video.sozcu.com.tr/kategori/eglence/(.*?)\'>(.*?)</a>').findall(link)
        for url, name in sayfalama:
                url='http://video.sozcu.com.tr/kategori/eglence/'+url
                print url,name
                addDir('> SAYFA  '+name,url,6,'')

def ozel(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb0',"I").replace('&#8221;'," ").replace('&#8220;'," ").replace('&#8230;'," ").replace('&#8216;'," ").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s")
        response.close()
        match=re.compile('<a href="(.*?)" title=".*?"><img width=".*?" height=".*?" src="(.*?)" class=".*?" alt="(.*?)" /></a>').findall(link)
        for url,thumbnail, name in match:
                print url,thumbnail,name
                addDir('>>-'+name,url,14,thumbnail)

        sayfalama=re.compile('<li><a href=\'http://video.sozcu.com.tr/kategori/yorum/(.*?)\'>(.*?)</a>').findall(link)
        for url, name in sayfalama:
                url='http://video.sozcu.com.tr/kategori/yorum/'+url
                print url,name
                addDir('> SAYFA  '+name,url,8,'')

def dm(url):
        xbmcPlayer = xbmc.Player()
        playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playList.clear()

        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()#src="http://www.dailymotion.com/embed/video/(.*?)\?logo=on">
        response.close()
        dm=re.compile('<iframe frameborder=".*?" width=".*?" height=".*?"  src="http://www.dailymotion.com/embed/video/(.*?)\?logo=on&syndication=158944"></iframe>').findall(link)
        for url in dm:
                url = 'http://www.dailymotion.com/embed/video/'+url
                req = urllib2.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
                response = urllib2.urlopen(req)
                link=response.read()
                response.close()
                dm1=re.compile('"stream_h264_hq_url":"(.*?)"').findall(link)
                for url in dm1:
                        
                        url=url.replace('\\/',"/")
                        playList.add(name) 
                        addLink(name,url,'')
                        xbmcPlayer.play(playList)

      

def VIDEOLINKS(url,name):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        link=link.replace('\xc4\xb0',"I").replace('\xc3\x96',"o").replace('\xc3\x9c',"u").replace('\xc4\x9e',"G").replace('&#8217;'," ").replace('\xc4\xb1',"i").replace('\xc3\xbc',"u").replace('\xe2\x80\x98'," ").replace('\xc4\x9f',"g").replace('\xc5\x9f',"s").replace('\xe2\x80\x99'," ")
        response.close()
        match=re.compile('<img src="http://www.dailymotion.com/thumbnail/video/(.*?)"  alt="(.*?)"  ').findall(link)
        for url,name in match:
                url='plugin://plugin.video.dailymotion_com/?url='+url+'&amp;mode=playVideo'
                print url,name

        xbmcPlayer.play(playList)
        if not xbmcPlayer.isPlayingVideo():
                d = xbmcgui.Dialog()
                d.ok('Sunucu Hatasi', 'Aranan Video Bulunamadi.','Baska Video Deneyiniz.')

                   
                        				
def INFO(url):
  try:
        CATEGORIES()
        dialog = xbmcgui.Dialog()
        i = dialog.ok(url, "[COLOR yellow]xbmcTR Team by HappyFeets & XMAXELL[/COLOR]","[COLOR red]Sozcu TV[/COLOR] Artik Heryerde. iyi seyirler.")
  except:
        
        pass 
                
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param




def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok


def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
        
              
params=get_params()
url=None
name=None
mode=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        print ""+url
        index(url)
        
elif mode==2:
        print ""+url
        VIDEOLINKS(url,name)

elif mode==3:
        print ""+url
        Magazin(url)

elif mode==4:
        print ""+url
        Spor(url)

elif mode==5:
        print ""+url
        Haber(url)

elif mode==7:
        print ""+url
        INFO(url)

elif mode==6:
        print ""+url
        eglence(url)

elif mode==8:
        print ""+url
        ozel(url)

elif mode==14:
        print ""+url
        dm(url)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
