xbmc-plugin.video.pyvideo
=========================

An XBMC plugin for pyvideo.org