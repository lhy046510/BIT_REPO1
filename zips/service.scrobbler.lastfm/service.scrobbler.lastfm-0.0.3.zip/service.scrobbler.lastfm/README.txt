info for skinners:
Window(Home).Property(LastFM.CanLove)
Window(Home).Property(LastFM.CanBan)

LastFM.Love:
RunScript(service.scrobbler.lastfm,action=LastFM.Love)

LastFM.Ban:
RunScript(plugin.audio.lastfm,action=LastFM.Ban)
