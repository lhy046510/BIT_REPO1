plugin.video.popcornflix================


XBMC Addon for popcornflix website

Version 1.0.5 Website change
Version 1.0.4 Fix stupid shortcut for US site so videos play on International sites
version 1.0.2 initial release

