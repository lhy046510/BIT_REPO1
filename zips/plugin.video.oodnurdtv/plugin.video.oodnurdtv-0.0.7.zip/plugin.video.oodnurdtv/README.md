XBMC scraper for the http://www.drundoo.com

Requires the user to set up an account with a username and password and enter them in the plugin settings.

The plugin depends on the following python modules to work properly. Please use "sudo pip install" to make sure the modules are available:
xbmcswift2, requests, beautifulsoup4

====
