plugin.video.gq================



XBMC Addon for GQ website

 
version 1.0.1 initial release



1.0.2 - added HD resolution select setting

1.0.3 - changed static strings to translatable strings

1.0.4 - fixed the fix above